package com.biogen.eisutil.controller;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.lang.invoke.MethodHandles;
import java.sql.Timestamp;
import java.util.Optional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.biogen.eisutil.dao.BioAppFile;
import com.biogen.eisutil.service.BioAppFileService;

@RestController
@RequestMapping("/file")
public class BioAppFileController {
	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioAppFileService")
	private BioAppFileService bioAppFileService;
	
	@GetMapping("/detail/{id}")
	public void downloadFile(@PathVariable Integer id, HttpServletResponse response)
	{
		logger.info("downloadFile() started");	
		Optional<BioAppFile> bioAppFile = null;
		
		bioAppFile = bioAppFileService.getBioAppFileByAppId(id);
		
		try {
			response.setHeader("Content-Disposition", "inline;filename=\"" +bioAppFile.get().getFileName()+ "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType("vsd");
			ByteArrayInputStream bis = new ByteArrayInputStream(bioAppFile.get().getFileData());
			IOUtils.copy(bis, out);
			out.flush();
			out.close();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("downloadFile() completed");
	}

	@PostMapping(path="/save/{appId}/{fileId}")
	public int uploadFile(@PathVariable Integer appId, @PathVariable Integer fileId, @RequestParam("file") MultipartFile  reqFile)
	{
		logger.info("uploadFile() started");	
		
		BioAppFile bioAppFile = new BioAppFile();
		logger.debug("File Name:"+reqFile.getOriginalFilename());
		logger.debug("File size:"+reqFile.getSize());
		logger.debug("appId:"+appId.intValue());
		
		int newFileId = 0;
			bioAppFile.setAppId(appId.intValue());
			bioAppFile.setFileName(reqFile.getOriginalFilename());
			if(fileId > 0) {
				bioAppFile.setId(fileId);
			} 
		try {

			byte[] bFile = reqFile.getBytes();
			
		    bioAppFile.setFileData(bFile);		    
			
		    BioAppFile bioAppF = bioAppFileService.saveAppFile(bioAppFile);
			
		    logger.debug("File upload FileId:"+bioAppF.getId());
			
			newFileId =  bioAppF.getId();
		}catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info("uploadFile() completed");	
		
		return newFileId;
	}
	
	
	@ResponseBody
	@GetMapping("/show/{appId}")
	public void showImage(@PathVariable Integer appId, HttpServletResponse response)
	{
		logger.info("showImage() started");	
		
		Optional<BioAppFile> bioAppFile = null;
		
		bioAppFile = bioAppFileService.getBioAppFileByAppId(appId);
		
		if(bioAppFile.isPresent() && bioAppFile != null)
		{
			try {
				response.setContentType("image/jpg");
				response.getOutputStream().write(bioAppFile.get().getFileData());
				response.getOutputStream().flush();
			
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		logger.info("showImage() completed");		
	}
	
}
