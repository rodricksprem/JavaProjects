package com.biogen.eisutil.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
@RequestMapping(value = "/",  method = RequestMethod.POST)
public class DefaultServices {
  @GetMapping("/login")
  public String login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	  System.out.println("DefaultService login method");

    return "login";
  }
  @GetMapping("/")
  public String ok(Principal principal, Map<String, Object> model) {
System.out.println("DefaultService OK method");  
    return "forward:/index.html";
  }
  
@GetMapping("/errorPage")
  public String error(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	  System.out.println("DefaultService error method");
	  request.getSession().invalidate();
		SecurityContextHolder.getContext().getAuthentication().setAuthenticated(false);
		SecurityContextHolder.createEmptyContext();
		SecurityContextHolder.clearContext();

	  return "errorPage";
	  
	  
  }
  
  @GetMapping("/invalidLogin")
  public String invalidLogin() {
	
  System.out.println("DefaultService invalidLogin method");
	  return "invalidLogin";
  }

  @GetMapping("/logout")
  public String logout() {
	
  System.out.println("DefaultService logout method");
	  
  return "logout";
  }
}
