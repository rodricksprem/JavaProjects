package com.biogen.eisutil.controller;

import java.lang.invoke.MethodHandles;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.AppGroupTemp;
import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.AppTypeTemp;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.dao.BioBUAppEntServiceEntity;
import com.biogen.eisutil.model.BioBusinessInfoData;
import com.biogen.eisutil.model.BioIntegrationDetails;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogAppGroup;
import com.biogen.eisutil.dao.BioLogAppType;
import com.biogen.eisutil.dao.BioLogApplication;
import com.biogen.eisutil.model.BioLogApplicationData;
import com.biogen.eisutil.model.BioLogApplicationTemp;
import com.biogen.eisutil.dao.BioLogCRDetailsEntity;
import com.biogen.eisutil.dao.BioLogITPDDetailsEntity;
import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.dao.BioLogLevel;
import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.model.LogLevelTemp;
import com.biogen.eisutil.model.ServerResponse;
import com.biogen.eisutil.service.BioBUAppESInfoService;
import com.biogen.eisutil.service.BioLogApplicationService;

@RestController
@RequestMapping("/app")
public class BioLogApplicationController {
	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioLogApplicationService")
	private BioLogApplicationService bioLogApplicationService;

	@Resource(name="BioBUAppESInfoService")
	private BioBUAppESInfoService bioBUAppESInfoService;
	
	@GetMapping("/details")
	public List<BioLogApplicationTemp> getAllApplicationDetails()
	{
		logger.info("getAllApplicationDetails() started");	
		List<Object[]> objectList = null;
		List<BioLogApplicationTemp> bioLogApplicationTempList = new ArrayList<BioLogApplicationTemp>();
		
		try
		{
			logger.debug("******* bioLogApplicationService.getAllApplicationDetails() Start *************");
			objectList =  bioLogApplicationService.getAllApplicationDetails();
			logger.debug("******* bioLogApplicationService.getAllApplicationDetails() End ************* objectList :: "+objectList.toString());
			
			for (Object[] object : objectList) {
				
				BioLogApplicationTemp bioLogApplicationTemp = new BioLogApplicationTemp();
				
				if(object[0] != null && object[0].toString().trim() != "")
				{
					bioLogApplicationTemp.setAppGroup(object[0].toString());
				}
				else
				{
					bioLogApplicationTemp.setAppGroup("");
				}
				
				if(object[1] != null && object[1].toString().trim() != "")
				{
					bioLogApplicationTemp.setAppName(object[1].toString());
				}
				else
				{
					bioLogApplicationTemp.setAppName("");
				}
				
				if(object[2] != null && object[2].toString().trim() != "")
				{
					bioLogApplicationTemp.setAppType(object[2].toString());
				}
				else
				{
					bioLogApplicationTemp.setAppType("");
				}
				
				if(object[3] != null && object[3].toString().trim() != "")
				{
					bioLogApplicationTemp.setLogLevel(object[3].toString());
				}
				else
				{
					bioLogApplicationTemp.setLogLevel("");
				}
				
				if(object[4] != null && object[4].toString().trim() != "")
					{
						bioLogApplicationTemp.setCreatedDate(object[4].toString());
					}
				else
				{
					bioLogApplicationTemp.setCreatedDate("");
				}
				
				if(object[5] != null && object[5].toString().trim() != "")
				{
					bioLogApplicationTemp.setUpdatedDate(object[5].toString());
				}
				
				else
				{
					bioLogApplicationTemp.setUpdatedDate("");
				}
				
				if(object[6] != null && object[6].toString().trim() != "")
				{
					bioLogApplicationTemp.setAppId( (Integer) object[6]);
				}

				
				bioLogApplicationTempList.add(bioLogApplicationTemp);
			}
			logger.debug("******* GetAllApplicationDetails() End ************* bioLogApplicationTempList :: "+bioLogApplicationTempList.toString());
		}
		catch(Exception exp)
		{
			logger.error("******* Exception ************* "+exp);
		}
		return bioLogApplicationTempList;
	}
	
	@GetMapping("/details/{appId}")
	public BioLogApplicationData getApplicationDetailsById(@PathVariable String appId)
	{
		logger.info("getApplicationDetailsById() started "+appId);	
		
		Integer appIdInt = Integer.parseInt(appId);
		BioLogApplicationData resultData = new BioLogApplicationData(); 
		try
		{

			Optional<BioLogApplication> applicationO=  bioLogApplicationService.getBioLogApplicationById(appIdInt);

			BioLogApplication application = applicationO.get();			
						
			resultData.setAppId(application.getAppId());
			resultData.setAppDesc(application.getAppDesc());
			resultData.setAppGroupId(application.getAppGroupId());
			resultData.setAppName(application.getAppName());
			resultData.setAppTypeId(application.getAppTypeId());
			resultData.setLoggerId(application.getLoggerId());
			

			List<BioBusinessInfoData> businessInfoDataList= bioBUAppESInfoService.getDetailsByAppId(appIdInt);
			resultData.setBusinessInfoDataList(businessInfoDataList);
			if( businessInfoDataList != null && businessInfoDataList.size() > 0) { 
				resultData.setEnterpriseService(businessInfoDataList.get(0).getEsId());
				resultData.setEntity(businessInfoDataList.get(0).getEntityId());
				List<BioLOVsData> sourceAppList = new ArrayList<BioLOVsData>();
				List<BioLOVsData> targetAppList = new ArrayList<BioLOVsData>();
				BioLOVsData appData = null;
				for(BioBusinessInfoData busData:businessInfoDataList) {
					appData = new BioLOVsData();
					appData.setId(busData.getBusinessId());
					appData.setText(busData.getApplicationId()+" "+busData.getBuId());
					appData.setRefId(busData.getSourceTargetTypeId());
					if("S".equalsIgnoreCase(busData.getSourceTargetTypeInd())){
						sourceAppList.add(appData);
					}
					if("T".equalsIgnoreCase(busData.getSourceTargetTypeInd())){
						targetAppList.add(appData);
					}
				}
				resultData.setSourceAppList(sourceAppList);
				resultData.setTargetAppList(targetAppList);
			}
			BioIntegrationDetails integrationDetails = bioLogApplicationService.getIntegrationDetails(appIdInt);
			resultData.setIntegrationDetails(integrationDetails);
			List<BioNotification> notificationList = bioLogApplicationService.getNotificationDetails(appIdInt);
			logger.debug("Notification List size:"+notificationList.size());
			resultData.setNotificationList(notificationList);
			
		}
		catch(Exception exp)
		{
			logger.error("******* Exception ************* "+exp);
		}
		return resultData;
	}
	
	@GetMapping("/type")
	public List<AppTypeTemp> getAppTypeList()
	{
		logger.info("getAppTypeList() started ");
		List<Object[]> objectList = null;
		List<AppTypeTemp> appTypeTempList = new ArrayList<AppTypeTemp>();
		
		objectList =  bioLogApplicationService.getAppTypeList();
		
		for (Object[] object : objectList) {
			
			AppTypeTemp appTypeTemp = new AppTypeTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				appTypeTemp.setAppTypeId(object[0].toString());
			}
			else
			{
				appTypeTemp.setAppTypeId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				appTypeTemp.setAppType(object[1].toString());
			}
			else
			{
				appTypeTemp.setAppType("");
			}
			
			appTypeTempList.add(appTypeTemp);
		}
		logger.info("getAppTypeList() completed ");
		
		return appTypeTempList;
	}
	
	@GetMapping("/group")
	public List<AppGroupTemp> getAppGroupList()
	{
		logger.info("getAppTypeList() started ");
		
		List<Object[]> objectList = null;
		List<AppGroupTemp> appGroupTempList = new ArrayList<AppGroupTemp>();
		
		objectList =  bioLogApplicationService.getAppGroupList();
		
		for (Object[] object : objectList) {
			
			AppGroupTemp appGroupTemp = new AppGroupTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				appGroupTemp.setAppGroupId(object[0].toString());
			}
			else
			{
				appGroupTemp.setAppGroupId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				appGroupTemp.setAppGroup(object[1].toString());
			}
			else
			{
				appGroupTemp.setAppGroup("");
			}
			
			appGroupTempList.add(appGroupTemp);
		}
		logger.info("getAppTypeList() completed ");
		
		return appGroupTempList;
	}
	
	@GetMapping("/log")
	public List<LogLevelTemp> getLogLevelList()
	{
		logger.info("getLogLevelList() started ");
		
		List<Object[]> objectList = null;
		List<LogLevelTemp> logLevelTempList = new ArrayList<LogLevelTemp>();
		
		objectList =  bioLogApplicationService.getLogLevelList();
		
		for (Object[] object : objectList) {
			
			LogLevelTemp logLevelTemp = new LogLevelTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				logLevelTemp.setLoggerId(object[0].toString());
			}
			else
			{
				logLevelTemp.setLoggerId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				logLevelTemp.setLoggerLevel(object[1].toString());
			}
			else
			{
				logLevelTemp.setLoggerLevel("");
			}
			
			logLevelTempList.add(logLevelTemp);
		}
		logger.info("getLogLevelList() completed ");
		
		return logLevelTempList;
	}
	
	@PostMapping(path="/save", consumes="application/json", produces="application/json")
	public ServerResponse createApplication(@RequestBody BioLogApplicationData bioLogApplicationData)
	{
		logger.info("createApplication()  started "+bioLogApplicationData.toString());
		bioLogApplicationData.setCreatedBy("Unknown");
		bioLogApplicationData.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		 User user  = null;
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioLogApplicationData.setCreatedBy(user.getUsername());
		 }
		 
		 ServerResponse serverResponse = new ServerResponse();
		 int appId = bioLogApplicationService.saveApplication(bioLogApplicationData);
		 serverResponse.setId(appId);
		logger.debug("appId:"+appId);
		 if(appId > 0) {
			 bioLogApplicationData.setAppId(appId);
			 try {
			 this.createBUAPP_ES_Info(bioLogApplicationData);
			 serverResponse.setStatus("SUCCESS");
			 } catch (Exception ex) {
				 serverResponse.setStatus("FAIL");
				 serverResponse.setErrorCode("-2");
				 serverResponse.setErrorDescription("Source and Target Systems mappings Not Created. Please Edit in Edit page.");
				 appId =-2;
			 }
		 }
		 if(appId ==0 ) {
			 serverResponse.setStatus("FAIL");
			 serverResponse.setErrorCode("0");
			 serverResponse.setErrorDescription("Interface Not created. Please try again.");
		 }
		 if(appId == -1 ) {
			 serverResponse.setStatus("FAIL");
			 serverResponse.setErrorCode("-1");
			 serverResponse.setErrorDescription("Interface already Exists.");
		 }
		 logger.info("createApplication() completed ");
		return serverResponse;
	}
	
	@PostMapping(path="/update", consumes="application/json", produces="application/json")
	public ServerResponse updateApplication(@RequestBody BioLogApplicationData bioLogApplicationData)
	{
		
		logger.info("updateApplication() started "+bioLogApplicationData.toString());
		bioLogApplicationData.setUpdatedBy("Unknown");
		bioLogApplicationData.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
		 User user  = null;
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioLogApplicationData.setUpdatedBy(user.getUsername());
		 }
		 
		 ServerResponse serverResponse = new ServerResponse();
		  boolean isUpdated = bioLogApplicationService.updateApplication(bioLogApplicationData);
		 serverResponse.setId(bioLogApplicationData.getAppId());
		 StringBuilder errorDesc = new StringBuilder();
		if(! isUpdated) {
			errorDesc.append("Interface Updation Failed.");
		}
			 try {
			 this.bioBUAppESInfoService.updateBUAPP_ES_Info(bioLogApplicationData);
			 serverResponse.setStatus("SUCCESS");
			 } catch (Exception ex) {
				 serverResponse.setStatus("FAIL");
				 serverResponse.setErrorCode("-2");
				 errorDesc.append("Source and Target Systems mappings Not Updated.");
				 serverResponse.setErrorDescription(errorDesc.toString());
			 }
	
			 logger.info("updateApplication() completed ");
				
			 return serverResponse;
	}
	
	@PostMapping(path="/saveInterface", consumes="application/json", produces="application/json")
	public int createIntegrationDetails(@RequestBody BioAppDocHistoryTemp inputData)
	{
		logger.info("createIntegrationDetails()  started "+inputData.toString());
		BioLogIntegrationDetailsEntity data = new BioLogIntegrationDetailsEntity(); 
		 data.setAppID(inputData.getAppId());
		 data.setFileID(inputData.getFileId());
		 data.setPatternID(inputData.getIntegrationPatternId());
		 BioLogIntegrationDetailsEntity result = bioLogApplicationService.createIntegrationDetails(data);
		 logger.info("createIntegrationDetails()  completed");
		 return result.getAppIntegrationID();
	}
	
	@PostMapping(path="/updateInterface", consumes="application/json", produces="application/json")
	public int updateIntegrationDetails(@RequestBody BioAppDocHistoryTemp inputData)
	{
		logger.info("updateIntegrationDetails() started "+inputData.toString());
		BioLogIntegrationDetailsEntity data = new BioLogIntegrationDetailsEntity(); 
		 data.setAppIntegrationID(inputData.getAppIntegrationId());
		 data.setAppID(inputData.getAppId());
		 data.setFileID(inputData.getFileId());
		 data.setPatternID(inputData.getIntegrationPatternId());
		
		 
		 BioLogIntegrationDetailsEntity result = bioLogApplicationService.createIntegrationDetails(data);
		 logger.info("updateIntegrationDetails() completed ");
		 return result.getAppIntegrationID();
	}
	
	@PostMapping(path="/saveITPDDetails", consumes="application/json", produces="application/json")
	public ServerResponse createITPDDetails(@RequestBody List<BioAppDocHistoryTemp> inputDataList)
	{
		logger.info("createITPDDetails() completed ");
		BioLogITPDDetailsEntity data = null;
		List<BioLogITPDDetailsEntity> dataList = new ArrayList<BioLogITPDDetailsEntity>();
		for(BioAppDocHistoryTemp ent :inputDataList) {
		logger.debug("saveITPDDetails-->BioAppDocHistoryTemp:"+ent.toString());
		data = new BioLogITPDDetailsEntity();
		 data.setAppIntegrationID(ent.getAppIntegrationId());
		 data.setItpdDescription(ent.getItpdDescription());
		 data.setItpdNumber(ent.getItpdNo());
		 dataList.add(data);
		}

		 boolean result = bioLogApplicationService.createITPDDetails(dataList);
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("createITPDDetails() completed ");
		 return response;
	}
	
	@PostMapping(path="/updateITPDDetails", consumes="application/json", produces="application/json")
	public ServerResponse updateITPDDetails(@RequestBody List<BioAppDocHistoryTemp> inputDataList)
	{
		 logger.info("updateITPDDetails() started ");
		 boolean result = bioLogApplicationService.updateITPDDetails(inputDataList);
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("updateITPDDetails() completed ");
		 return response;
	}

	@PostMapping(path="/saveCRDetails", consumes="application/json", produces="application/json")
	public ServerResponse createCRDetails(@RequestBody List<BioAppDocHistoryTemp> inputDataList)
	{
		logger.info("createCRDetails() started ");
		BioLogCRDetailsEntity data = null; 
		List<BioLogCRDetailsEntity> dataList = new ArrayList<BioLogCRDetailsEntity>();
		for(BioAppDocHistoryTemp ent: inputDataList) {
			data =new BioLogCRDetailsEntity();
			logger.debug("createCRDetails-->BioAppDocHistoryTemp:"+ent.toString());
		data.setAppIntegrationID(ent.getAppIntegrationId());
		data.setComments(ent.getComments());
		data.setCrDescription(ent.getCrDescription());
		data.setCrNumber(ent.getCrNo());
		data.setImplementationDate(ent.getImplementedDate());
		dataList.add(data);
		}
		 
		boolean result = bioLogApplicationService.createCRDDetails(dataList);
		 
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("createCRDetails() completed ");
		 return response;
	}
	
	@PostMapping(path="/updateCRDetails", consumes="application/json", produces="application/json")
	public ServerResponse updateCRDetails(@RequestBody List<BioAppDocHistoryTemp> inputDataList)
	{
		logger.info("updateCRDetails() started ");
		logger.debug("updateCRDetails() inputData ..."+inputDataList);
	
		boolean result = bioLogApplicationService.updateCRDetails(inputDataList);
		 
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("updateCRDetails() completed ");
		 return response;
	}
	private boolean createBUAPP_ES_Info(BioLogApplicationData bioLogApplicationData) {
		logger.info("createBUAPP_ES_Info() started ");
		BioBUAppEntServiceEntity sourceDataEntity = null;
		BioBUAppEntServiceEntity targetDataEntity = null;
		List<BioBUAppEntServiceEntity> sourceEntityList = new ArrayList<BioBUAppEntServiceEntity>();
		boolean isSuccess = false;
		try {
		for(BioLOVsData data:bioLogApplicationData.getSourceAppList()) {
			sourceDataEntity = new BioBUAppEntServiceEntity();
		sourceDataEntity.setAppId(bioLogApplicationData.getAppId());
		
		if ( data.getText() != null && data.getText().length() > 0 ) {
			sourceDataEntity.setBuID(Integer.parseInt(data.getText().substring(data.getText().indexOf(" ")+1,data.getText().length())));
				sourceDataEntity.setApplicationID(Integer.parseInt(data.getText().substring(0, data.getText().indexOf(" "))));
		}
		if( bioLogApplicationData.getEntity() != null ) {
			sourceDataEntity.setEntityID(bioLogApplicationData.getEntity());
		}
		if (bioLogApplicationData.getEnterpriseService() != null ) {
			sourceDataEntity.setEntServiceID(bioLogApplicationData.getEnterpriseService());
		}
		if( data.getType() != null && data.getType().length() > 0) {
			sourceDataEntity.setSourceTargetTypeId(Integer.parseInt(data.getType()));
			sourceDataEntity.setSourceTargetTypeIndicator("S");
		}
		if(sourceDataEntity.getApplicationID() != null || sourceDataEntity.getBuID() != null || sourceDataEntity.getEntityID() != null || sourceDataEntity.getEntServiceID() !=null) {
		sourceEntityList.add(sourceDataEntity);
		}
		}
		List<BioBUAppEntServiceEntity> targetEntityList = new ArrayList<BioBUAppEntServiceEntity>();
		
		for(BioLOVsData data:bioLogApplicationData.getTargetAppList()) {
			targetDataEntity = new BioBUAppEntServiceEntity();
			targetDataEntity.setAppId(bioLogApplicationData.getAppId());
			if ( data.getText() != null && data.getText().length() > 0 ) {
				targetDataEntity.setBuID(Integer.parseInt(data.getText().substring(data.getText().indexOf(" ")+1,data.getText().length())));
				targetDataEntity.setApplicationID(Integer.parseInt(data.getText().substring(0, data.getText().indexOf(" "))));
			}
			if( bioLogApplicationData.getEntity() != null ) {
				targetDataEntity.setEntityID(bioLogApplicationData.getEntity());
			}
			if (bioLogApplicationData.getEnterpriseService() != null ) {
				targetDataEntity.setEntServiceID(bioLogApplicationData.getEnterpriseService());
			}
			if( data.getType() != null && data.getType().length() > 0) {
				targetDataEntity.setSourceTargetTypeId(Integer.parseInt(data.getType()));
				targetDataEntity.setSourceTargetTypeIndicator("T");
			}
			if(targetDataEntity.getApplicationID() != null || targetDataEntity.getBuID() != null || targetDataEntity.getEntityID() != null || targetDataEntity.getEntServiceID() !=null) {
			targetEntityList.add(targetDataEntity);
		}
			}
		
		
		
			isSuccess = bioBUAppESInfoService.createBUAPP_ES_Info(sourceEntityList, targetEntityList);
			logger.info("createBUAPP_ES_Info() completed ");
	
		} catch(Exception ex) {
			logger.error("Exception .."+ex);
		}	
		return  isSuccess;
	}
	
	@PostMapping(path="/save/apptype", consumes="application/json", produces="application/json")
	public boolean createAppType(@RequestBody BioLogAppType bioLogAppType)
	{
		logger.info("createAppType() started");
		// logger.info("createAppType() completed");
		 return bioLogApplicationService.saveAppType(bioLogAppType);
	}
	
	@PostMapping(path="/save/appgroup", consumes="application/json", produces="application/json")
	public boolean createAppGroup(@RequestBody BioLogAppGroup bioLogAppGroup)
	{
		logger.info("createAppGroup() started");
		return bioLogApplicationService.saveAppGroup(bioLogAppGroup);
	}
	
	@PostMapping(path="/save/loglevel", consumes="application/json", produces="application/json")
	public boolean createLogLevel(@RequestBody BioLogLevel bioLogLevel)
	{
		logger.info("createLogLevel() started");
		logger.info("createLogLevel() completed ");
		
		return true;
	}
	
	@GetMapping("/type/details")
	public List<BioLogAppType> getAllBioLogAppTypeDetails() {
		logger.info("getAllBioLogAppTypeDetails() started");
		return bioLogApplicationService.getAllBioLogAppTypeDetails();
		
	}

	@GetMapping("/group/details")
	public List<BioLogAppGroup> getAllBioLogAppGroupDetails() {
		logger.info("getAllBioLogAppGroupDetails() started");
		return bioLogApplicationService.getAllBioLogAppGroupDetails();
	}
	
	@GetMapping("/name")
	public List<AppNameTemp> getAppNameList()
	{
		logger.info("getAppNameList() started");
		
		List<Object[]> objectList = null;
		List<AppNameTemp> appNameTempList = new ArrayList<AppNameTemp>();
		
		objectList =  bioLogApplicationService.getAppNameList();
		
		for (Object[] object : objectList) {
			
			AppNameTemp appNameTemp = new AppNameTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				appNameTemp.setAppId(object[0].toString());
			}
			else
			{
				appNameTemp.setAppId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				appNameTemp.setAppName(object[1].toString());
			}
			else
			{
				appNameTemp.setAppName("");
			}
			
			appNameTempList.add(appNameTemp);
		}
		logger.info("getAppNameList() completed ");
		return appNameTempList;
	}

	@GetMapping("/sistatus")
	public List<String> getServiceInvokerStatusList()
	{
		logger.info("getServiceInvokerStatusList() started ");
		List<String> serviceInvokerStatusList = null;
		
		serviceInvokerStatusList =  bioLogApplicationService.getServiceInvokerStatusList();
		logger.info("getServiceInvokerStatusList() completed ");
		return serviceInvokerStatusList;
	}
	
	@GetMapping("/name/group/{appGroupName}")
	public List<AppNameTemp> getAppNameByAppGroupId(@PathVariable String appGroupName)
	{
		logger.info("getAppNameByAppGroupId() started ");
		List<Object[]> objectList = null;
		List<AppNameTemp> appNameTempList = new ArrayList<AppNameTemp>();
		
		objectList =  bioLogApplicationService.getAppNameByAppGroupId(appGroupName);
		
		for (Object[] object : objectList) {
			
			AppNameTemp appNameTemp = new AppNameTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				appNameTemp.setAppId(object[0].toString());
			}
			else
			{
				appNameTemp.setAppId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				appNameTemp.setAppName(object[1].toString());
			}
			else
			{
				appNameTemp.setAppName("");
			}
			
			appNameTempList.add(appNameTemp);
		}
		logger.info("getAppNameByAppGroupId() completed ");
		return appNameTempList;
	}
}
