package com.biogen.eisutil.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.PurgeData;
import com.biogen.eisutil.model.PurgeDetailsData;
import com.biogen.eisutil.service.PurgeService;

@RestController
@RequestMapping("/bioPurge")
public class PurgeManagementController {
	
	@Resource(name = "PurgeService")
	private PurgeService purgeService;
	
	@GetMapping("/purgeHistory")
	public List<PurgeData> getPurgeHistoryDetails()
	{
		System.out.println("PurgeManagementController.getPurgeHistoryDetails() -------------");
		return purgeService.getPurgeHistory();
	}
	
	@GetMapping("/purgeDetails/{id}")
	public List<PurgeDetailsData> getPurgeDetails(@PathVariable Integer id)
	{
		System.out.println("PurgeManagementController.getPurgeDetails() ------------purgeId:"+id);
		return purgeService.getPurgeDetails(id);
	}
	
}
