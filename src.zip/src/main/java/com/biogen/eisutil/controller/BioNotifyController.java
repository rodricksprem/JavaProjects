package com.biogen.eisutil.controller;

import java.lang.invoke.MethodHandles;
import java.sql.Clob;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.dao.BioNotify;
import com.biogen.eisutil.model.BioNotifyCategory;
import com.biogen.eisutil.model.BioNotifyHistoryDetails;
import com.biogen.eisutil.model.BioNotifyPropsDaoTemp;
import com.biogen.eisutil.dao.BioNotifyProps;
import com.biogen.eisutil.model.BioNotifyPropsTemp;
import com.biogen.eisutil.model.BioNotifySearch;
import com.biogen.eisutil.model.BioNotifyTemp;
import com.biogen.eisutil.model.ServerResponse;
import com.biogen.eisutil.service.BioLogAppGroupService;
import com.biogen.eisutil.service.BioLogApplicationService;
import com.biogen.eisutil.service.BioNotifyService;
import com.biogen.eisutil.util.BioNotifyUtil;

@RestController
@RequestMapping("/notify")
public class BioNotifyController {
	
	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioNotifyService")
	private BioNotifyService bioNotifyService;
	
	@Resource(name = "BioLogApplicationService")
	private BioLogApplicationService bioLogApplicationService;
	
	@Resource(name = "BioLogAppGroupService")
	private BioLogAppGroupService bioLogAppGroupService;
	
	@Autowired
	BUSearchController buSearchController;
	
	@GetMapping("/category")
	public List<BioNotifyCategory> getAllBioNotify()
	{
	 	logger.info("getAllBioNotify() started");

		List<Object[]> objectList = null;
		List<BioNotifyCategory> bioNotifyCategoryList = new ArrayList<BioNotifyCategory>();
		
		objectList =  bioNotifyService.getAllBioNotify();
		
		for (Object[] object : objectList) {
			
			BioNotifyCategory bioNotifyCategory = new BioNotifyCategory();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifyCategory.setAppName(object[0].toString());
			}
			else
			{
				bioNotifyCategory.setAppName("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifyCategory.setExCategory(object[1].toString());
			}
			else
			{
				bioNotifyCategory.setExCategory("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioNotifyCategory.setExType(object[2].toString());
			}
			else
			{
				bioNotifyCategory.setExType("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				bioNotifyCategory.setCreatedBy(object[3].toString());
			}
			else
			{
				bioNotifyCategory.setCreatedBy("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioNotifyCategory.setCreatedDate(object[4].toString());
			}
			else
			{
				bioNotifyCategory.setCreatedDate("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioNotifyCategory.setUpdatedBy(object[5].toString());
			}
			else
			{
				bioNotifyCategory.setUpdatedBy("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioNotifyCategory.setUpdatedDate(object[6].toString());
			}
			else
			{
				bioNotifyCategory.setUpdatedDate("");
			}
			
			bioNotifyCategoryList.add(bioNotifyCategory);
		}
	 	logger.info("getAllBioNotify() completed");

		return bioNotifyCategoryList;
	}
	
	@GetMapping("/notification/{id}")
	public Optional<BioNotify> getNotification(@PathVariable Integer id)
	{
	 	logger.info("getNotification() started");

		return bioNotifyService.getNotificationById(id);
	}
	
	@DeleteMapping("/notification/{id}")
	public boolean deleteNotification(@PathVariable Integer id)
	{
		logger.info("getNotification() started");
		bioNotifyService.deleteNotification(id);
		return true;
	}
	
	@PostMapping(path="/save", consumes="application/json", produces="application/json")
	public ServerResponse createBioNotifiy(@RequestBody List<BioNotification> bioNotificationList){
		logger.info("getNotification() started");

		for(BioNotification bioNotification:bioNotificationList) {
			System.out.println("bioNotification"+bioNotification);

		 User user  = null;
		 bioNotification.setCreatedBy("Unknown");
		 bioNotification.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioNotification.setCreatedBy(user.getUsername());
		 }
		}
		boolean result = bioNotifyService.createNotification(bioNotificationList);
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("getNotification() completed");

		 return response;
	}

	@PostMapping(path="/update", consumes="application/json", produces="application/json")
	public ServerResponse updateBioNotifiy(@RequestBody List<BioNotification> bioNotificationList){
		logger.info("getNotification() started");
		
		String updatedBy = "Unknown";
		 User user  = null;
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 updatedBy = user.getUsername();
		 }
		
		boolean result = bioNotifyService.updateNotification(bioNotificationList, updatedBy);
		 ServerResponse response = new ServerResponse();
		 if(result) {
		response.setStatus("SUCCESS");
		
		 } else {
		response.setStatus("FAIL");
		 }
		 logger.info("getNotification() completed");
		 return response;
	}

	
	
	@GetMapping("/history")
	public List<BioNotifyTemp> getNotificationsAndHistory()
	{
		logger.info("getNotification() started");
		List<Object[]> objectList = null;
		List<BioNotifyTemp> bioNotifytemplist = new ArrayList<BioNotifyTemp>();
		
		objectList =  bioNotifyService.getAllNotificationsAndHistory();
		
		for (Object[] object : objectList) {
			
			BioNotifyTemp bioNotifytemp = new BioNotifyTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifytemp.setAppGroup(object[0].toString());
			}
			else
			{
				bioNotifytemp.setAppGroup("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifytemp.setAppName(object[1].toString());
			}
			else
			{
				bioNotifytemp.setAppName("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioNotifytemp.setExCategory(object[2].toString());
			}
			else
			{
				bioNotifytemp.setExCategory("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				bioNotifytemp.setExType(object[3].toString());
			}
			else
			{
				bioNotifytemp.setExType("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioNotifytemp.setStatus(object[4].toString());
			}
			else
			{
				bioNotifytemp.setStatus("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioNotifytemp.setCreatedDate(object[5].toString());
			}
			else
			{
				bioNotifytemp.setCreatedDate("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioNotifytemp.setUpdatedDate(object[6].toString());
			}
			else
			{
				bioNotifytemp.setUpdatedDate("");
			}
			
			if(object[7] != null && object[7].toString().trim() != "")
			{
				bioNotifytemp.setNotifyHistoryId(object[7].toString());
			}
			else
			{
				bioNotifytemp.setNotifyHistoryId("");
			}
			if(object[8] != null && object[8].toString().trim() != "")
			{
				bioNotifytemp.setBiogenTransId(object[8].toString());
			}
			else
			{
				bioNotifytemp.setBiogenTransId("");
			}
			
			bioNotifytemplist.add(bioNotifytemp);
		}
		logger.info("getNotification() completed");
		return bioNotifytemplist;
	}
	
	@PostMapping(path="/history/adsearch", consumes="application/json", produces="application/json")
	public List<BioNotifyTemp> getNotificationsAndHistoryByAdSearch(@RequestBody BioNotifySearch bioNotifySearch)
	{
		logger.info("getNotificationsAndHistoryByAdSearch() started");
		String adSearchParams = null;
		List<Object[]> objectList = null;
		List<BioNotifyTemp> bioNotifytemplist = null;
		
        adSearchParams = BioNotifyUtil.getBioNotifyDetailsWhereClause(bioNotifySearch);
		
        bioNotifytemplist = new ArrayList<BioNotifyTemp>();
		
		if(adSearchParams == null || adSearchParams.isEmpty() || adSearchParams.trim() == "")
		{
			objectList = bioNotifyService.getAllNotificationsAndHistory();
		}
		else
		{
			objectList =  bioNotifyService.getAllNotificationsAndHistoryByAdSearch(adSearchParams);
		}
		
		for (Object[] object : objectList) {
			
			BioNotifyTemp bioNotifytemp = new BioNotifyTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifytemp.setAppGroup(object[0].toString());
			}
			else
			{
				bioNotifytemp.setAppGroup("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifytemp.setAppName(object[1].toString());
			}
			else
			{
				bioNotifytemp.setAppName("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioNotifytemp.setExCategory(object[2].toString());
			}
			else
			{
				bioNotifytemp.setExCategory("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				bioNotifytemp.setExType(object[3].toString());
			}
			else
			{
				bioNotifytemp.setExType("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioNotifytemp.setStatus(object[4].toString());
			}
			else
			{
				bioNotifytemp.setStatus("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioNotifytemp.setCreatedDate(object[5].toString());
			}
			else
			{
				bioNotifytemp.setCreatedDate("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioNotifytemp.setUpdatedDate(object[6].toString());
			}
			else
			{
				bioNotifytemp.setUpdatedDate("");
			}
			
			if(object[7] != null && object[7].toString().trim() != "")
			{
				bioNotifytemp.setNotifyHistoryId(object[7].toString());
			}
			else
			{
				bioNotifytemp.setNotifyHistoryId("");
			}
			if(object[8] != null && object[8].toString().trim() != "")
			{
				bioNotifytemp.setBiogenTransId(object[8].toString());
			}
			else
			{
				bioNotifytemp.setBiogenTransId("");
			}
			
			bioNotifytemplist.add(bioNotifytemp);
		}
		logger.info("getNotification() completed");
		return bioNotifytemplist;
	}
	
	@PostMapping(path="/history/busearch", consumes="application/json", produces="application/json")
	public List<BioNotifyTemp> getNotificationsAndHistoryByBUSearch(@RequestBody BUSearch buSearch)
	{
		logger.info("getNotificationsAndHistoryByBUSearch() started");
		String buSearchParams = null;
		List<Object[]> objectList = null;
		List<BioNotifyTemp> bioNotifytemplist = null;
		System.out.println("BU search getNotificationsAndHistoryByBUSearch--->"+buSearch.toString());
		buSearchParams = buSearchController.geAppIdList(buSearch);
		System.out.println("buSearchParams:"+buSearchParams);
        bioNotifytemplist = new ArrayList<BioNotifyTemp>();
		
        if(buSearchParams == null || buSearchParams.isEmpty() || buSearchParams.trim() == "")
		{
			return this.getNotificationsAndHistory(buSearch.getDuration());
		}
        if(buSearchParams !=null && buSearchParams.length() > 0)
		{
			objectList =  bioNotifyService.getAllNotificationsAndHistoryByBUSearch(buSearchParams,buSearch.getDuration());
		
		for (Object[] object : objectList) {
			
			BioNotifyTemp bioNotifytemp = new BioNotifyTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifytemp.setAppGroup(object[0].toString());
			}
			else
			{
				bioNotifytemp.setAppGroup("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifytemp.setAppName(object[1].toString());
			}
			else
			{
				bioNotifytemp.setAppName("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioNotifytemp.setExCategory(object[2].toString());
			}
			else
			{
				bioNotifytemp.setExCategory("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				bioNotifytemp.setExType(object[3].toString());
			}
			else
			{
				bioNotifytemp.setExType("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioNotifytemp.setStatus(object[4].toString());
			}
			else
			{
				bioNotifytemp.setStatus("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioNotifytemp.setCreatedDate(object[5].toString());
			}
			else
			{
				bioNotifytemp.setCreatedDate("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioNotifytemp.setUpdatedDate(object[6].toString());
			}
			else
			{
				bioNotifytemp.setUpdatedDate("");
			}
			
			if(object[7] != null && object[7].toString().trim() != "")
			{
				bioNotifytemp.setNotifyHistoryId(object[7].toString());
			}
			else
			{
				bioNotifytemp.setNotifyHistoryId("");
			}
			if(object[8] != null && object[8].toString().trim() != "")
			{
				bioNotifytemp.setBiogenTransId(object[8].toString());
			}
			else
			{
				bioNotifytemp.setBiogenTransId("");
			}
			bioNotifytemplist.add(bioNotifytemp);
		}
	}
        logger.info("getNotificationsAndHistoryByBUSearch() completed");

        return bioNotifytemplist;
	}
	
	private List<BioNotifyTemp> getNotificationsAndHistory(Integer duration) {
		logger.info("getNotificationsAndHistory() started");

		List<Object[]> objectList = null;
		List<BioNotifyTemp> bioNotifytemplist = new ArrayList<BioNotifyTemp>();
		
		objectList =  bioNotifyService.getAllNotificationsAndHistory(duration);
		
		for (Object[] object : objectList) {
			
			BioNotifyTemp bioNotifytemp = new BioNotifyTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifytemp.setAppGroup(object[0].toString());
			}
			else
			{
				bioNotifytemp.setAppGroup("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifytemp.setAppName(object[1].toString());
			}
			else
			{
				bioNotifytemp.setAppName("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioNotifytemp.setExCategory(object[2].toString());
			}
			else
			{
				bioNotifytemp.setExCategory("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				bioNotifytemp.setExType(object[3].toString());
			}
			else
			{
				bioNotifytemp.setExType("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioNotifytemp.setStatus(object[4].toString());
			}
			else
			{
				bioNotifytemp.setStatus("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioNotifytemp.setCreatedDate(object[5].toString());
			}
			else
			{
				bioNotifytemp.setCreatedDate("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioNotifytemp.setUpdatedDate(object[6].toString());
			}
			else
			{
				bioNotifytemp.setUpdatedDate("");
			}
			
			if(object[7] != null && object[7].toString().trim() != "")
			{
				bioNotifytemp.setNotifyHistoryId(object[7].toString());
			}
			else
			{
				bioNotifytemp.setNotifyHistoryId("");
			}
			if(object[8] != null && object[8].toString().trim() != "")
			{
				bioNotifytemp.setBiogenTransId(object[8].toString());
			}
			else
			{
				bioNotifytemp.setBiogenTransId("");
			}
			
			bioNotifytemplist.add(bioNotifytemp);
		}
		logger.info("getNotificationsAndHistory() completed");
		
		
		return bioNotifytemplist;
	
	}

	@GetMapping("/excategory")
	public List<String> getExCategoryListgetExCategoryList()
	{
		logger.info("getExCategoryList() started");

		List<String> exCategoryList = null;
		exCategoryList =  bioNotifyService.getExCategoryList();
		logger.info("getExCategoryList() completed");
		return exCategoryList;
	}
	
	@GetMapping("/extype")
	public List<String> getExTypeList()
	{
		logger.info("getExTypeList() started");
		List<String> exTypeList = null;
		exTypeList =  bioNotifyService.getExTypeList();
		logger.info("getExTypeList() completed");
		return exTypeList;
	}
	
	@GetMapping("/bnhstatus")
	public List<String> getBNHStatusList()
	{
		List<String> bnhStatusList = null;
		bnhStatusList =  bioNotifyService.getBNHStatusList();
		logger.info("getNotification() completed");

		return bnhStatusList;
	}
	
	@GetMapping("/detail/{notifyHistoryId}")
	public List<BioNotifyHistoryDetails> getDetailedNotifyDetails(@PathVariable int notifyHistoryId)
	{
		logger.info("getDetailedNotifyDetails() started");

		List<Object[]> objectList = null;
		List<BioNotifyHistoryDetails> bioNotifyHistoryDetailsList = new ArrayList<BioNotifyHistoryDetails>();
		
		objectList =  bioNotifyService.getBioNotifyHistoryDetails(notifyHistoryId);
		
		for (Object[] object : objectList) {
			
			BioNotifyHistoryDetails bioNotifyHistoryDetails = new BioNotifyHistoryDetails();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifyHistoryDetails.setName(object[0].toString());
			}
			else
			{
				bioNotifyHistoryDetails.setName("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifyHistoryDetails.setValue(object[1].toString());
			}
			else
			{
				bioNotifyHistoryDetails.setValue("");
			}
			
			bioNotifyHistoryDetails.setValueClob("");
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				Clob clob = null;
				long len = 0;
				String clobData = null;
				
				try {
					
					clob = (Clob) object[2];
					
					if(clob != null)
					{
						len = clob.length();
						
						if(len > 0)
						{
							clobData =  clob.getSubString(1, (int) len);
							bioNotifyHistoryDetails.setValue(clobData);
						}
					}
					
				} catch (Exception exp) {
					
				} 
			}
			
			bioNotifyHistoryDetailsList.add(bioNotifyHistoryDetails);
		}
		logger.info("getDetailedNotifyDetails() completed");

		return bioNotifyHistoryDetailsList;
	}
	
	@GetMapping("/props/{notifyHistoryId}")
	public List<BioNotifyPropsTemp> getBioNotifyProps(@PathVariable int notifyHistoryId)
	{
		logger.info("getBioNotifyProps() started");

		List<Object[]> objectList = null;
		List<BioNotifyPropsTemp> bioNotifyPropsTempList = new ArrayList<BioNotifyPropsTemp>();
		
		objectList =  bioNotifyService.getBioNotifyProps(notifyHistoryId);
		
		for (Object[] object : objectList) {
			
			BioNotifyPropsTemp bioNotifyPropsTemp = new BioNotifyPropsTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioNotifyPropsTemp.setName(object[0].toString());
			}
			else
			{
				bioNotifyPropsTemp.setName("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioNotifyPropsTemp.setValue(object[1].toString());
			}
			else
			{
				bioNotifyPropsTemp.setValue("");
			}
			
			bioNotifyPropsTempList.add(bioNotifyPropsTemp);
		}
		logger.info("getBioNotifyProps() completed");
		return bioNotifyPropsTempList;
	}
	
	@GetMapping("/props")
	public List<BioNotifyProps> getAllBioNotifyProps()
	{
		logger.info("getAllBioNotifyProps() started");
		return bioNotifyService.getAllBioNotifyProps();
	}
	
	@GetMapping("/props/name")
	public List<String> getAllBioNotifyPropsName()
	{
		logger.info("getAllBioNotifyPropsName() started");
		return bioNotifyService.getAllBioNotifyPropsName();
	}
	
	@GetMapping("/notifyid/{appId}/{exCategory}/{exType}")
	public List<Integer> getNotifyIdByExCategoryAndExTypeAndAppId(@PathVariable int appId, @PathVariable String exCategory, @PathVariable String exType)
	{
		logger.info("getNotifyIdByExCategoryAndExTypeAndAppId started");
		List<Integer> notifyIdList = null;
		notifyIdList =  bioNotifyService.getNotifyIdByExCategoryAndExTypeAndAppId(appId, exCategory, exType);
		
		System.out.println("appId :: "+appId+" exCategory :: "+exCategory+" exType :: "+exType+" notifyId :: "+notifyIdList.toString());
		logger.info("getNotifyIdByExCategoryAndExTypeAndAppId completed");
		return notifyIdList;
	}
	
    
    @GetMapping("/excategory/extype/{appName}")
   	public BioNotifyPropsTemp getExCategoryAndExTypeByAppName(@PathVariable String appName)
   	{
    	logger.info("getExCategoryAndExTypeByAppName() started");

    	List<Object[]> objectList = null;
   		List<String> exCategoryList = new ArrayList<String>();
   		List<String> exTypeList = new ArrayList<String>();
   		
   		objectList =  bioNotifyService.getExCategoryAndExTypeByAppName(appName);
   		
   		for (Object[] object : objectList) {
   			
   			if(object[0] != null && object[0].toString().trim() != "")
   			{
   				if(!exCategoryList.contains(object[0].toString()))
   				{
   					exCategoryList.add(object[0].toString());
   				}
   			}
   			
   			if(object[1] != null && object[1].toString().trim() != "")
   			{
   				
   				if(!exTypeList.contains(object[1].toString()))
   				{
   					exTypeList.add(object[1].toString());
   				}
   			}
   		}
   		
   		BioNotifyPropsTemp bioNotifyPropsTemp = new BioNotifyPropsTemp();
   		
   		bioNotifyPropsTemp.setExCategoryList(exCategoryList);
   		bioNotifyPropsTemp.setExTypeList(exTypeList);
   		logger.info("getExCategoryAndExTypeByAppName() completed");
   		
   		return bioNotifyPropsTemp;
   	}
    
    @PostMapping(path="/props/save", consumes="application/json", produces="application/json")
	public boolean createBioNotifiyProps(@RequestBody BioNotifyPropsDaoTemp bioNotifyPropsDaoTemp)
	{
    	logger.info("getNotification() completed");
	
    	List<Integer> notifyIdList = null;
    	BioNotifyProps bioNotifyProps = null;
		notifyIdList =  bioNotifyService.getNotifyIdByExCategoryAndExTypeAndAppId(bioNotifyPropsDaoTemp.getAppId(), bioNotifyPropsDaoTemp.getExCategory(), bioNotifyPropsDaoTemp.getExType());
		
		if(notifyIdList != null && notifyIdList.size() > 0)
		{
			bioNotifyProps = new BioNotifyProps();
			
			bioNotifyProps.setNotifyId(notifyIdList.get(0));
			bioNotifyProps.setName(bioNotifyPropsDaoTemp.getName());
			bioNotifyProps.setValue(bioNotifyPropsDaoTemp.getValue());
	    
			return bioNotifyService.createBioNotifyprops(bioNotifyProps);
		}
		logger.info("getNotification() completed");

		return false;
	}
}
