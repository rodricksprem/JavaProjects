package com.biogen.eisutil.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioDefaultLOVs;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogBUApplicationEntity;
import com.biogen.eisutil.dao.BioLogBusinessUnitEntity;
import com.biogen.eisutil.dao.BioLogEnterpriseServiceEntity;
import com.biogen.eisutil.dao.BioLogEntity;
import com.biogen.eisutil.dao.BioLogIntegrationPatternEntity;
import com.biogen.eisutil.dao.BioLogSourceTargetEntity;
import com.biogen.eisutil.service.BioBusinessUnitService;
import com.biogen.eisutil.service.BioLogUserService;
import com.biogen.eisutil.util.BUSearchUtil;

@RestController
@RequestMapping("/bu")
public class BUSearchController {
	
	@Resource(name = "BioBusinessUnitService")
	private BioBusinessUnitService bioBusinessUnitService;
	
	@Resource(name = "BioLogUserService")
	private BioLogUserService bioLogUserService;
	
	public String geAppIdList(BUSearch buSearch)
	{
		String buSearchParam = null;
		List<Integer> appIdList = null;
		String appIdValue = "";
		
		buSearchParam = BUSearchUtil.getBUSearchWhereClause(buSearch);
		
		if(buSearchParam == null || buSearchParam.isEmpty() || buSearchParam.trim() == "")
		{
			return appIdValue;
		}
		
		appIdList = bioBusinessUnitService.getAppIdList(buSearchParam);
		
		for(int appId : appIdList)
		{
			if(appId != 0)
			{
				if(appIdValue.isEmpty())
				{
					appIdValue = String.valueOf(appId);
				}
				else
				{
					appIdValue = appIdValue + ","+String.valueOf(appId);
				}
			}
		}
		return appIdValue;
	}
	
	
	@GetMapping("/bunit")
    public List<BioLOVsData> getBUnit()
    {
		 User user  = null;
		 List<BioLOVsData> bioUserServ = new ArrayList<BioLOVsData>();
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioUserServ = bioLogUserService.getBUDataList(user.getUsername());
			 
		 }
		return bioUserServ;
    }
	
	@GetMapping("/BUDetails")
    public BioDefaultLOVs getBUDetails()
    {
		return bioBusinessUnitService.getInterfaceServiceDetails();
    }
	
	@PostMapping(path="/saveMasterData", consumes="application/json", produces="application/json")
	public boolean createMasterData(@RequestBody BioLOVsData bioLOVsData)	{
		System.out.println("bioLOVs Data:"+bioLOVsData);
		
		if("Entity".equals(bioLOVsData.getType())) {
			return this.createEntity(bioLOVsData);
		} else if("ES".equals(bioLOVsData.getType())) {
		
		return this.createEnterPriseService(bioLOVsData);
		} else if("Integration Pattern".equals(bioLOVsData.getType())) {
			
			return this.createIntegrationPattern(bioLOVsData);
			} else if("Source Type".equals(bioLOVsData.getType())) {
				
				return this.createSourceType(bioLOVsData,"S");
				} else if("Target Type".equals(bioLOVsData.getType())) {
					
					return this.createSourceType(bioLOVsData,"T");
					} else if("APPLICATION".equals(bioLOVsData.getType())) {
						
						return this.createNewApplication(bioLOVsData);
						}
		else {	
			return false;
		}
	}
	private boolean createSourceType(BioLOVsData bioLovsData, String type) {
		BioLogSourceTargetEntity data = new BioLogSourceTargetEntity();
		data.setSourceTargetName(bioLovsData.getName());
		data.setSourceTargetDescription(bioLovsData.getDescription());
		data.setSourceTargetStatus("ACTIVE");
		 
		 return bioBusinessUnitService.createSourceType(data);
	}
	
	private boolean createNewApplication(BioLOVsData bioLovsData) {
		BioLogBUApplicationEntity data = new BioLogBUApplicationEntity();
		data.setApplicationName(bioLovsData.getName());
		data.setApplicationDescription(bioLovsData.getDescription());
		data.setApplicationStatus("ACTIVE");
		 int buId = bioBusinessUnitService.getBUnit(bioLovsData.getStatus());
		if(buId == 0) {
			BioLOVsData buDataEntity = new BioLOVsData();
			buDataEntity.setName(bioLovsData.getStatus());
			buDataEntity.setDescription(bioLovsData.getStatus());
			BioLogBusinessUnitEntity bu = this.createBusinessUnit(buDataEntity);
			buId = bu.getBuID();
			buDataEntity = null;
		}
		 System.out.println("BU ID:"+buId);
		 data.setBuId(buId);
		 return bioBusinessUnitService.createNewApplication(data);
	 
	}
	
	private boolean createIntegrationPattern(BioLOVsData bioLovsData) {
		BioLogIntegrationPatternEntity data = new BioLogIntegrationPatternEntity();
		data.setPatternName(bioLovsData.getName());
		data.setPatternDescription(bioLovsData.getDescription());
		data.setPatternStatus("ACTIVE");
		 bioBusinessUnitService.createIntegrationPattern(data);
		 return true;
	}
	
	private BioLogBusinessUnitEntity createBusinessUnit(BioLOVsData bioLovsData) {
		BioLogBusinessUnitEntity data = new BioLogBusinessUnitEntity();
		data.setBuName(bioLovsData.getName());
		data.setBuDescription(bioLovsData.getDescription());
		data.setBuStatus("ACTIVE");
		 return bioBusinessUnitService.createBusinessUnit(data);
	}
	
	private boolean createEntity(BioLOVsData bioLovsData) {
		BioLogEntity bioLogEntity = new BioLogEntity();
		bioLogEntity.setEntityName(bioLovsData.getName());
		bioLogEntity.setEntityDescription(bioLovsData.getDescription());
		bioLogEntity.setEntityStatus("ACTIVE");
		 
		 return bioBusinessUnitService.createEntity(bioLogEntity);
	}
	
	
	private boolean createEnterPriseService(BioLOVsData bioLovsData) {
		BioLogEnterpriseServiceEntity data = new BioLogEnterpriseServiceEntity();
		data.setEsName(bioLovsData.getName());
		data.setEsDescription(bioLovsData.getDescription());
		data.setEsStatus("ACTIVE");
		 
		 return bioBusinessUnitService.createEnterPriseService(data);
	}
	
	@GetMapping("/app/name/{bunit}")
    public List<BioLOVsData> getAppNameByBUnit(@PathVariable String bunit)
    {
		return bioBusinessUnitService.getAppNameByBUnit(Integer.parseInt(bunit));
    }
	
	@GetMapping("/details/{type}")
    public List<BioLOVsData>  getDetailsByType(@PathVariable String type)
    {
		System.out.println("type Data:"+type);
		
		if("Entity".equals(type)) {
			return bioBusinessUnitService.getEntityDetails();
		} else if("ES".equals(type)) {
			return bioBusinessUnitService.getEnterpriseDetails();
		} else if("Integration Pattern".equals(type)) {
			
			return bioBusinessUnitService.getIntegrationPatternDetails();
			} else if("Source Type".equals(type)) {
				
				return bioBusinessUnitService.getSourceTypeDetails("S");
				} else if("Target Type".equals(type)) {
					
					return bioBusinessUnitService.getSourceTypeDetails("T");
					} else if("APPLICATION".equals(type)) {
						
						return bioBusinessUnitService.getBUApplicationDetails();
						} else if("BU".equals(type)) {
							
							return bioBusinessUnitService.getBUDetails();
							}  else  {	
			return null;
		}
   }
	
	@GetMapping("/entity/name/{bunit}/{appName}")
	public List<String> getEntityNameByBUnitAndAppName(@PathVariable String bunit, @PathVariable String appName)
	{
		return bioBusinessUnitService.getEntityNameByBUnitAndAppName(bunit, appName);
	}
	
	@GetMapping("/entity/name/{appName}")
	public List<BioLOVsData> getEntityNameByApplicationId(@PathVariable String appName)
	{
		System.out.println("getEntityNameByApplicationId--------------");
		return bioBusinessUnitService.getEntityDetailsByApplicationId(Integer.parseInt(appName));
	}
	
	@GetMapping("/es/name/{bunit}/{appName}/{entityname}")
	public List<String> getESNameByBUnitAndAppNameAndEntityName(@PathVariable String bunit, @PathVariable String appName, @PathVariable String entityname)
	{
		return bioBusinessUnitService.getESNameByBUnitAndAppNameAndEntityName(bunit, appName, entityname);
	}
	
	@GetMapping("/es/name/{entityname}")
	public List<BioLOVsData> getESNameByEntityName(@PathVariable String entityname)
	{
		return bioBusinessUnitService.getESDetailsByEntityId(Integer.parseInt(entityname));
	}
	
	
	@GetMapping("/interface/name/{bunit}/{appName}/{entity}")
	public List<AppNameTemp> getAppNameByAppGroupId(@PathVariable String bunit, @PathVariable String appName, @PathVariable String entity)
	{
		List<AppNameTemp> appNameTempList =  bioBusinessUnitService.getInterfaceNameByAppName(bunit, appName, entity);
		
		return appNameTempList;
	}

}
