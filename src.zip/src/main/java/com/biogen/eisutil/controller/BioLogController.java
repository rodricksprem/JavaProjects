package com.biogen.eisutil.controller;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import  java.sql.Clob;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioLogDetails;
import com.biogen.eisutil.model.BioLogDetailsTemp;
import com.biogen.eisutil.model.BioLogSearch;
import com.biogen.eisutil.model.BioLogTemp;
import com.biogen.eisutil.model.TargetSystemLogDetails;
import com.biogen.eisutil.service.BioLogAppGroupService;
import com.biogen.eisutil.service.BioLogApplicationService;
import com.biogen.eisutil.service.BioLogService;
import com.biogen.eisutil.service.BioNotifyService;
import com.biogen.eisutil.util.BioLogUtil;

@RestController
@RequestMapping("/log")
public class BioLogController {
	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioLogService")
	private BioLogService bioLogService;
	
	@Resource(name = "BioLogApplicationService")
	private BioLogApplicationService bioLogApplicationService;
	
	@Resource(name = "BioLogAppGroupService")
	private BioLogAppGroupService bioLogAppGroupService;
	
	@Resource(name = "BioNotifyService")
	private BioNotifyService bioNotifyService;
	
	@Autowired
	BUSearchController buSearchController;
	
	@GetMapping("/details")
	public List<BioLogTemp> getLogSerachDetails()
	{
		logger.info("getLogSerachDetails() started");
		
		List<BioLogTemp> bioLogTemplist = bioLogService.getLogDetailsByList();
		
		logger.debug("logging details list size:"+bioLogTemplist.size());
		logger.info("getLogSerachDetails() completed");
		
		return bioLogTemplist;
	}
	private List<BioLogTemp> getLogSerachDetails(Integer duration)
	{
		logger.info("getLogSerachDetails(Integer duration) started");
		
		List<BioLogTemp> bioLogTemplist = bioLogService.getLogDetailsByList(duration);
		
		logger.debug("logging details list size:"+bioLogTemplist.size());
		logger.info("getLogSerachDetails(Integer duration) completed");
		
		return bioLogTemplist;
	}
	@PostMapping(path="/adsearch/details", consumes="application/json", produces="application/json")
	public List<BioLogTemp> getLogByAdvancedSerach(@RequestBody BioLogSearch bioLogSearch)
	{
		logger.info("getLogByAdvancedSerach() started");
		
		String adSearchParams = null;
		String keyValueDetails = null;
		List<BioLogTemp> bioLogTemplist = null;
		logger.debug("bioLogSearch:"+bioLogSearch.toString());
		adSearchParams = BioLogUtil.getBioLogDetailsWhereClause(bioLogSearch);
		
		bioLogTemplist = new ArrayList<BioLogTemp>();
		logger.debug("adSearchParams:"+adSearchParams);
		keyValueDetails = BioLogUtil.getKeyValueDetails(bioLogSearch);
		if((adSearchParams == null || adSearchParams.isEmpty() || adSearchParams.trim() == "") && (keyValueDetails == null || keyValueDetails.isEmpty() || keyValueDetails.trim() == ""))
		{	
			return this.getLogSerachDetails();
		}
		
		if(adSearchParams == null || adSearchParams.isEmpty() || adSearchParams.trim() == "")
		{
			return this.getLogSerachDetails();
		}
		else
		{
			bioLogTemplist = bioLogService.getLogDetailsByAdvSearch(bioLogSearch);
		}
		logger.debug("logging details list size:"+bioLogTemplist.size());
		logger.info("getLogByAdvancedSerach() started");
		return bioLogTemplist;
	}
	
	@PostMapping(path="/busearch/details", consumes="application/json", produces="application/json")
	public List<BioLogTemp> getLogByBusinessunitSerach(@RequestBody BUSearch buSearch)
	{
		logger.info("getLogByBusinessunitSerach() started");
		String buSearchParams = null;
		List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();
		logger.debug("BU Search:"+buSearch.toString());
		buSearchParams = buSearchController.geAppIdList(buSearch);
		logger.debug("buSearchParams:"+buSearchParams);
		if(buSearchParams == null || buSearchParams.isEmpty() || buSearchParams.trim() == "")
		{
			return this.getLogSerachDetails(buSearch.getDuration());
		}
		else if(buSearchParams !=null && buSearchParams.length() > 0)
		{
			bioLogTemplist = bioLogService.getLogDetailsByBUSearch(buSearchParams,buSearch.getDuration());
		}
logger.debug("logging details list size:"+bioLogTemplist.size());
logger.info("getLogByBusinessunitSerach() completed");
		return bioLogTemplist;
	}
	
	
	@GetMapping("/key")
	public List<String> getKeyList()
	{
		logger.info("getKeyList() started");
		List<String> keyList = null;
		
		keyList =  bioLogService.getKey();
		logger.info("getKeyList() completed");
		
		return keyList;
	}
	
	@GetMapping("/key/{appName}")
	public List<String> getKeyListByAppName(@PathVariable String appName)
	{
		logger.info("getKeyListByAppName() started");
		List<String> keyList = null;
		
		if(appName != null && appName != "")
		{
			keyList =  bioLogService.getKeyByAppName(appName);
		}
		
		logger.info("getKeyListByAppName() completed");
		return keyList;
	}
	
	@GetMapping("/detail/{bioTransId}")
	public BioLogDetailsTemp getDetailedLogDetails(@PathVariable String bioTransId)
	{
		logger.info("getDetailedLogDetails() started");
		
		List<Object[]> objectList = null;
		
		BioLogDetailsTemp bioLogDetailsTemp = null;
		List<BioLogDetails> bioLogDetailsList = new ArrayList<BioLogDetails>();
		
		objectList =  bioLogService.getDetailedLogDetails(bioTransId);
		
		for (Object[] object : objectList) {
			
			BioLogDetails bioLogDetails = new BioLogDetails();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioLogDetails.setMessageCode(object[0].toString());
			}
			else
			{
				bioLogDetails.setMessageCode("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioLogDetails.setMessageDesc(object[1].toString());
			}
			else
			{
				bioLogDetails.setMessageDesc("");
			}
			
			if(object[2] != null && object[2].toString().trim() != "")
			{
				bioLogDetails.setLogLevel(object[2].toString());
			}
			else
			{
				bioLogDetails.setLogLevel("");
			}
			
			if(object[3] != null && object[3].toString().trim() != "")
			{
				Clob payLoadClob = null;
				long len = 0;
				String payLoadData = null;
				
				try {
					
					payLoadClob = (Clob) object[3];
					
					if(payLoadClob != null)
					{
						len = payLoadClob.length();
						
						if(len > 0)
						{
							payLoadData =  payLoadClob.getSubString(1, (int) len);
							bioLogDetails.setPayLoad(payLoadData);
						}
						else
						{
							bioLogDetails.setPayLoad("");
						}
					}
					else
					{
						bioLogDetails.setPayLoad("");
					}
					
				} catch (Exception exp) {
					logger.debug("EXP :: "+exp);
					bioLogDetails.setPayLoad("");
				} 
			}
			else
			{
				bioLogDetails.setPayLoad("");
			}
			
			if(object[4] != null && object[4].toString().trim() != "")
			{
				bioLogDetails.setServiceInvoker(object[4].toString());
			}
			else
			{
				bioLogDetails.setServiceInvoker("");
			}
			
			if(object[5] != null && object[5].toString().trim() != "")
			{
				bioLogDetails.setServiceStatus(object[5].toString());
			}
			else
			{
				bioLogDetails.setServiceStatus("");
			}
			
			if(object[6] != null && object[6].toString().trim() != "")
			{
				bioLogDetails.setServiceStartTime(object[6].toString());
			}
			else
			{
				bioLogDetails.setServiceStartTime("");
			}
			bioLogDetailsList.add(bioLogDetails);
		}
		
		List<TargetSystemLogDetails> targetSystemLogDetailsList = null;
		
		targetSystemLogDetailsList = this.getTargetSystemLogDetails(bioTransId);
		
		bioLogDetailsTemp = new BioLogDetailsTemp();
		
		bioLogDetailsTemp.setBioLogDetailsList(bioLogDetailsList);
		bioLogDetailsTemp.setTargetSystemLogDetailsList(targetSystemLogDetailsList);
		logger.info("getDetailedLogDetails() completed");
		
		return bioLogDetailsTemp;
	}
	
	@GetMapping("/targetSystemDetails/{bioTransId}")
	public BioLogDetailsTemp getTargetSystemDetails(@PathVariable String bioTransId)
	{
		logger.info("getTargetSystemDetails() started");
		
		BioLogDetailsTemp bioLogDetailsTemp = new BioLogDetailsTemp();
		
		List<TargetSystemLogDetails> targetSystemLogDetailsList = null;
		
		targetSystemLogDetailsList = this.getTargetSystemLogDetails(bioTransId);
		
		bioLogDetailsTemp.setTargetSystemLogDetailsList(targetSystemLogDetailsList);
		
		logger.info("getTargetSystemDetails() completed");
		
		
		return bioLogDetailsTemp;
	}
	
	private List<TargetSystemLogDetails> getTargetSystemLogDetails(String bioTransId)
	{

		logger.info("getTargetSystemLogDetails(String bioTransId) started ");
		
		
		List<BigDecimal> targetSystemIdList = null;
		List<Object[]> objectList2 = null;
		List<TargetSystemLogDetails> targetSystemLogDetailsList = new ArrayList<TargetSystemLogDetails>();
		
		targetSystemIdList = bioLogService.getBioLogTargetSystemIdByBioTransId(bioTransId);
		
		for (BigDecimal targetSystemId : targetSystemIdList) {
			
			TargetSystemLogDetails targetSystemLogDetails = null;
			if(targetSystemId.intValue() != 0)
			{
				int i = 0;
				
				objectList2 = bioLogService.getDetailedTargetSystemLogDetails(bioTransId, targetSystemId.intValue() );
				List<BioLogDetails> logDetailsList = new ArrayList<BioLogDetails>();
				targetSystemLogDetails = new TargetSystemLogDetails();

				for (Object[] object2 : objectList2) {
					
					BioLogDetails logDetails= new BioLogDetails();
					logDetails.setDefaultBioLogDetails();
					if(object2[0] != null && object2[0].toString().trim() != "")
					{
						logDetails.setServiceInvoker(object2[0].toString());
					}
										
					if(object2[1] != null && object2[1].toString().trim() != "")
					{
						logDetails.setMessageCode(object2[1].toString());
					}
					
					if(object2[2] != null && object2[2].toString().trim() != "")
					{
						logDetails.setMessageDesc(object2[2].toString());
					}
										
					if(object2[3] != null && object2[3].toString().trim() != "")
					{
						logDetails.setServiceStatus(object2[3].toString());
					}

					
					if(object2[4] != null && object2[4].toString().trim() != "")
					{
						logDetails.setServiceStartTime(object2[4].toString());
					}
					
					
					if(object2[5] != null && object2[5].toString().trim() != "")
					{
						logDetails.setLogLevel(object2[5].toString());
					}
										
					if(object2[6] != null && object2[6].toString().trim() != "")
					{
						logDetails.setKey(object2[6].toString());
					}
					
					if(object2[7] != null && object2[7].toString().trim() != "")
					{
						logDetails.setValue(object2[7].toString());
					}
					if(object2[8] != null && object2[8].toString().trim() != "")
					{
						
						Clob payLoadClob = null;
						long len = 0;
						String payLoadData = null;
						
						try {
							
							payLoadClob = (Clob) object2[8];
							
							if(payLoadClob != null)
							{
								len = payLoadClob.length();
								
								if(len > 0)
								{
									payLoadData =  payLoadClob.getSubString(1, (int) len);
									logDetails.setPayLoad(payLoadData);
								}
							}
							
						} catch (Exception exp) {
							logger.error("EXP :: "+exp);
							logDetails.setPayLoad("");
						} 
					}
					if(i == 0)
					{
						if(object2[9] != null && object2[9].toString().trim() != "")
						{
							targetSystemLogDetails.setTargetSystemName(object2[9].toString());
						}
						if(object2[10] != null && object2[10].toString().trim() != "")
						{
							targetSystemLogDetails.setTargetServiceStatus(object2[10].toString());
						}
						if(object2[11] != null && object2[11].toString().trim() != "")
						{
							targetSystemLogDetails.setTargetServiceStartTime(object2[11].toString());
						}
						if(object2[12] != null && object2[12].toString().trim() != "")
						{
							targetSystemLogDetails.setTargetServiceEndTime(object2[12].toString());
						}
					} else {
						logDetailsList.add(logDetails);
					}
										
					i++;
				}
				targetSystemLogDetails.setLogDetailsList(logDetailsList);
			}
			if( targetSystemLogDetails != null) {
				targetSystemLogDetailsList.add(targetSystemLogDetails);
			}
		}
		logger.info("getTargetSystemLogDetails(String bioTransId) completed");
		
		return targetSystemLogDetailsList;
	}
}
