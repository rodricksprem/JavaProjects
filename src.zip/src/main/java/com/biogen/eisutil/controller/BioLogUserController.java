package com.biogen.eisutil.controller;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.dao.BioLogUser;
import com.biogen.eisutil.model.BioLogUserData;
import com.biogen.eisutil.model.BioLogUserTemp;
import com.biogen.eisutil.model.BioLogUserTypeTemp;
import com.biogen.eisutil.service.BioLogUserService;
import com.biogen.eisutil.service.LDAPUserAuthenticatorService;

@RestController
@RequestMapping("/biolog")
public class BioLogUserController {

	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioLogUserService")
	private BioLogUserService bioLogUserService;
	
	@Resource(name = "LDAPUserAuthenticatorService")
	private LDAPUserAuthenticatorService ldapUserAuthenticatorService;
	
	 @GetMapping("/logout")
	  public String logout(HttpServletRequest request) {
		 	logger.info("logout() started");
		  if(request.getSession() != null) {
				request.getSession().invalidate();
				}	
		 	logger.info("logout() completed");
	    return "/logout";
	  }
	 
	@GetMapping("/networkUserName")
	public Optional<BioLogUser> getNetworkUserName(HttpServletRequest request)
	{
	 	logger.info("getNetworkUserName() started");
		 BioLogUser bioUser = new BioLogUser();
		 User user  = null;
		 Optional<BioLogUser> bioUserServ = null;
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioUserServ = bioLogUserService.getBioLogUser(user.getUsername());
		 }
		if( bioUserServ != null && bioUserServ.isPresent() ) {

			bioUser = bioUserServ.get();
		} else  {
			bioUser.setUserId("User");
			if( user != null) {
			bioUser.setUserId(user.getUsername());
			}
			bioUser.setUserType(2);
		}
		String hostName = request.getServerName();
		Optional<BioLogUser> userList = Optional.of(bioUser);
		logger.debug("Optioanl:"+userList);
		logger.info("getNetworkUserName() completed");
		return userList;
		
	}
	
	@GetMapping("/getHostName")
	public String getHostName() {
		logger.info("getHostName() started");
		java.net.InetAddress ip;
        String hostname="";
        try {
            ip = java.net.InetAddress.getLocalHost();
            hostname = ip.getHostAddress();
            logger.debug("Your current IP address : " + ip);
            System.out.println("Your current Hostname : " + hostname);
 
        } catch (java.net.UnknownHostException e) {
 
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        logger.info("getHostName() started");
        return hostname;
	}
	
	@GetMapping("/users")
	public List<BioLogUser> getUsers()
	{
		logger.info("getUsers() completed");
		return bioLogUserService.getBioLogUsers();
	}
	
	@GetMapping("/logOut/{userId}")
	public Optional<BioLogUser> logOut(@PathVariable String userId,HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException
	{
		logger.info("logout() started");
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		SecurityContextHolder.getContext().getAuthentication().setAuthenticated(false);
		
		BioLogUser bioUser = new BioLogUser();
		bioUser.setUserId(user.getUsername());
		bioUser.setUserType(1);
		SecurityContextHolder.createEmptyContext();
		SecurityContextHolder.clearContext();
		Optional<BioLogUser> userList = Optional.of(bioUser);
		logger.info("logout() started");
        return userList;

	}
	
	@GetMapping("/getName}")
	public Optional<String> logHostName( HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		logger.info("logHostName() started");
		
		
		
		logger.debug(""
				+ ""
				+ ""
				+ ":"+request.getRequestURI());
		
		String hostName = request.getServerName();
		Optional<String> optHostName = Optional.of(hostName);
		logger.info("logHostName() completed");
		return optHostName;
		
	}

	@GetMapping("/user/{userId}")
	public Optional<BioLogUser> getUser(@PathVariable String userId)
	{
		logger.info("getUser() started");
		boolean ldapResponse = ldapUserAuthenticatorService.isValidUser(new BioLogUser());
		logger.debug("LDAP authenticator response:"+ldapResponse);
		logger.info("getUser() completed");
		return bioLogUserService.getBioLogUser(userId);
	}
	
	@GetMapping("/all/biologusers")
	public List<BioLogUserTemp> getAllBioLogUsers()
	{
		logger.info("getAllBioLogUsers() completed");
		return  bioLogUserService.getUsersList();
	}
	
	
	@GetMapping("/user/type")
	public List<BioLogUserTypeTemp> getUserTypeList()
	{
		logger.info("getUserTypeList() started");
		List<Object[]> objectList = null;
		List<BioLogUserTypeTemp> bioLogUserTypeTempList = new ArrayList<BioLogUserTypeTemp>();
		
		objectList =  bioLogUserService.getUserTypeList();
		
		for (Object[] object : objectList) {
			
			BioLogUserTypeTemp bioLogUserTypeTemp = new BioLogUserTypeTemp();
			
			if(object[0] != null && object[0].toString().trim() != "")
			{
				bioLogUserTypeTemp.setUserTypeId(object[0].toString());
			}
			else
			{
				bioLogUserTypeTemp.setUserTypeId("");
			}
			
			if(object[1] != null && object[1].toString().trim() != "")
			{
				bioLogUserTypeTemp.setUserType(object[1].toString());
			}
			else
			{
				bioLogUserTypeTemp.setUserType("");
			}
			
			bioLogUserTypeTempList.add(bioLogUserTypeTemp);
		}
		logger.info("getUserTypeList() completed");
		return bioLogUserTypeTempList;
	}
	
	@PostMapping(path="/user/save", consumes="application/json", produces="application/json")
	public boolean createUser(@RequestBody BioLogUserData bioLogUser)
	{
		logger.info("createUser() started");
		boolean isNew = false;
		bioLogUser.setCreatedDate(new Timestamp(System.currentTimeMillis()));
		 User user  = null;
		Optional<BioLogUser> bioUserServ = bioLogUserService.getBioLogUser(bioLogUser.getUserId());
		BioLogUser userData = null;
		String createdUser ="Unknown";
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 createdUser = user.getUsername();
		 }
		if( bioUserServ != null && bioUserServ.isPresent() ) {
			logger.debug("user is exist");
			userData = bioUserServ.get();
			if(userData.getUserType() != bioLogUser.getUserType()) {
				userData.setUserType(bioLogUser.getUserType());
				bioLogUserService.saveUser(userData);
				logger.debug("user updated");
			}
		} else {
			logger.debug("user is does not exist, creating user");
			userData = new BioLogUser();
			userData.setUserId(bioLogUser.getUserId());
			userData.setUserType(bioLogUser.getUserType());
			userData.setEmailID("user@biogen.com");
			userData.setFirstName("User");
			userData.setLastName("User");
			logger.debug("user is does not exist, creating user:"+userData);
			isNew = bioLogUserService.saveUser(userData);
			logger.debug("user created successfully:"+isNew);
		}
		isNew = bioLogUserService.userBUMapping(bioLogUser);
		logger.debug("user mapping create flag:"+isNew);
		logger.info("createUser() completed");
		return isNew; 
	}
	@PostMapping(path="/user/delete", consumes="application/json", produces="application/json")
	public boolean deleteUser(@RequestBody BioLogUserData bioLogUser)
	{
		logger.info("deleteUser() started");
		logger.debug("====== "+bioLogUser.toString());
		boolean isNew = true;
		
		Optional<BioLogUser> bioUserServ = bioLogUserService.getBioLogUser(bioLogUser.getUserId());
		BioLogUser userData = null;
		String createdUser ="Unknown";
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 createdUser = user.getUsername();
		 }
		if( bioUserServ != null && bioUserServ.isPresent() ) {
			logger.debug("user is exist");
			userData = bioUserServ.get();
			bioLogUserService.deleteUser(userData);
			logger.debug("user deleted");
			
		} else {
			logger.debug("user is does not exist, so unable to delete user");
			isNew = false;
			logger.debug("user created successfully:"+isNew);
		}
		logger.info("deleteUser() completed");
		return isNew; 
	}
}
