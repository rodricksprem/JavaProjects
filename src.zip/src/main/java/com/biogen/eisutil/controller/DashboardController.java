package com.biogen.eisutil.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BarChartDataList;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.model.ChartData;
import com.biogen.eisutil.model.ChartDetails;
import com.biogen.eisutil.model.SankeyGraphNode;
import com.biogen.eisutil.service.BioBUAppESInfoService;
import com.biogen.eisutil.service.BioLogUserService;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {
	
	@Resource(name = "BioBUAppESInfoService")
	private BioBUAppESInfoService bioBUAppESInfoService;
	
	@Resource(name = "BioLogUserService")
	private BioLogUserService bioLogUserService;
	
	
	
	
	@GetMapping("/donut")
	public List<ChartData> getAllDonutChartData()
	{
		System.out.println("getAllDonutChartData---start time-----"+new Date());
		
		List<ChartData> donutChartList = new ArrayList<ChartData>();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			donutChartList =  bioBUAppESInfoService.getAllPieChartData(buDataList);
		}
		System.out.println("getAllDonutChartData----end time----"+new Date());
		return donutChartList;
	}
	
	@GetMapping("/dashboardDetails")
	public ChartDetails getAllGraphDetails()
	{
		System.out.println("getAllGraphDetails---start time-----"+new Date());
		ChartDetails chartDetails = new ChartDetails();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			chartDetails.setDonutChartList(bioBUAppESInfoService.getAllPieChartData(buDataList));
			System.out.println("donut chart details:"+new Date());
			chartDetails.setNotifyChartList(bioBUAppESInfoService.getNotificationBarChartData(buDataList));
			System.out.println("Notify chart details:"+new Date());
			chartDetails.setBarChartData(bioBUAppESInfoService.getAllBarChartData(buDataList));
			System.out.println("bar chart details:"+new Date());
		}
		System.out.println("getAllGraphDetails----end time----"+new Date());
		return chartDetails;
	}
	
    private List<BioLOVsData> getBUnit()
    {
		 User user  = null;
		 List<BioLOVsData> bioUserServ = new ArrayList<BioLOVsData>();
		 if(! "anonymousUser".equals(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString() )  ){
			 user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 bioUserServ = bioLogUserService.getBUDataList(user.getUsername());
			 
		 }
		 if( bioUserServ.size() >0 )
			 bioUserServ.remove(0);
		 
		return bioUserServ;
    }

	
	@GetMapping("/logging/bar")
	public BarChartDataList getLoggingBarChartData()
	{
		BarChartDataList barChartList = new BarChartDataList();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			barChartList =  bioBUAppESInfoService.getAllBarChartData(buDataList);
		}
		System.out.println("getLoggingBarChartData----end time----"+new Date());
		return barChartList;
	}
	
	@GetMapping("/notification/bar")
	public List<ChartData> getNotificationBarChartData()
	{
		List<ChartData> notificationBarChartList = new ArrayList<ChartData>();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			notificationBarChartList =  bioBUAppESInfoService.getNotificationBarChartData(buDataList);
		}
		System.out.println("getNotificationBarChartData----end time----"+new Date());
		return notificationBarChartList;
	}
	
	@PostMapping(path="/donut", consumes="application/json", produces="application/json")
	public List<ChartData> getAllDonutChartData(@RequestBody BUSearch buSearch){
		System.out.println("BU search Donut--->"+buSearch.toString());
		List<BioLOVsData> buDataList = this.getBUnit();
		return bioBUAppESInfoService.getDonutChartData(buSearch, buDataList);
	}
	
	@PostMapping(path="/logging/bar", consumes="application/json", produces="application/json")
	public BarChartDataList getLoggingBarChartData(@RequestBody BUSearch buSearch){
		System.out.println("BU search LoggingBar--->"+buSearch.toString());
		List<BioLOVsData> buDataList = this.getBUnit();
		return bioBUAppESInfoService.getBarChartData(buSearch, buDataList);
	}
	
	
	
	@PostMapping(path="/notification/bar", consumes="application/json", produces="application/json")
	public List<ChartData> getNotificationBarChartData(@RequestBody BUSearch buSearch){
		List<BioLOVsData> buDataList = this.getBUnit();

		System.out.println("BU search NotificationBar--->"+buSearch.toString());
		return bioBUAppESInfoService.getNotificationBarChartData(buSearch, buDataList);
	}
	
	@GetMapping(path="/graph/sankygraph")
	public List<SankeyGraphNode> getSankeyGraphData(){
		System.out.println("getSankeyGraphData ");
		
		
		List<SankeyGraphNode> sankeyGraphNodes = new ArrayList<SankeyGraphNode>();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			sankeyGraphNodes= bioBUAppESInfoService.getSankeyGraphData(buDataList);
		}
	
		return sankeyGraphNodes;
	}
	
	@PostMapping(path="/graph/sankygraph/search", consumes="application/json", produces="application/json")
	public List<SankeyGraphNode> getSankeyGraphData(@RequestBody BUSearch buSearch){
		System.out.println("getSankeyGraphData based on seach "+buSearch.toString());
		List<SankeyGraphNode> sankeyGraphNodes = new ArrayList<SankeyGraphNode>();
		List<BioLOVsData> buDataList = this.getBUnit();
		if(buDataList != null && buDataList.size() > 0 ) {
			sankeyGraphNodes= bioBUAppESInfoService.getSankeyGraphData(buSearch,buDataList);
		}
	
		
		return sankeyGraphNodes;
	}
	
}
