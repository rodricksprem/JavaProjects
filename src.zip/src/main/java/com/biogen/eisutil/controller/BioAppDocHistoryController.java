package com.biogen.eisutil.controller;

import java.lang.invoke.MethodHandles;
import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.service.BioAppDocHistoryService;

@RestController
@RequestMapping("/doc/history")
public class BioAppDocHistoryController {
	
	private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	
	@Resource(name = "BioAppDocHistoryService")
	private BioAppDocHistoryService bioAppDocHistoryService;
	
	@GetMapping("/details")
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetails()
	{
		logger.info("getAllBioAppDocHistoryDetails() started");
		
		List<BioAppDocHistoryTemp> bioAppDocHistoryTempList =  bioAppDocHistoryService.getAllBioAppDocHistoryDetails();
		logger.info("getAllBioAppDocHistoryDetails() completed");
		
		return bioAppDocHistoryTempList;
	}
	
	@GetMapping("/details/{appId}")
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetailsByAppId(@PathVariable Integer appId)
	{
		logger.info("getAllBioAppDocHistoryDetailsByAppId() started");
		
		List<BioAppDocHistoryTemp> bioAppDocHistoryTempList =  bioAppDocHistoryService.getAllBioAppDocHistoryDetailsByAppId(appId);
		
		logger.info("getAllBioAppDocHistoryDetailsByAppId() completed");
		
		return bioAppDocHistoryTempList;
	}
	
	@PostMapping(path="/details", consumes="application/json", produces="application/json")
	public List<BioAppDocHistoryTemp> getInterfaceDetails(@RequestBody BUSearch buSearch){
		
		logger.info("getInterfaceDetails() started "+buSearch.toString());
		if(buSearch != null &&  buSearch.getAppId()>0) {

			logger.info("getInterfaceDetails() completed");
				
			return this.getAllBioAppDocHistoryDetailsByAppId(buSearch.getAppId());
		} else {

			logger.info("getInterfaceDetails() completed");
			
			return bioAppDocHistoryService.getInterfaceDetails(buSearch);
		}
	}
	
	
	@PostMapping(path="/saveInterface", consumes="application/json", produces="application/json")
	public int createIntegrationDetails(@RequestBody BioAppDocHistoryTemp inputData)
	{
		logger.info("createIntegrationDetails() started "+inputData.toString());
		BioLogIntegrationDetailsEntity data = new BioLogIntegrationDetailsEntity(); 
		
	
		 data.setAppID(inputData.getAppId());
		 data.setFileID(inputData.getFileId());
		 data.setPatternID(inputData.getIntegrationPatternId());
		 BioLogIntegrationDetailsEntity result = bioAppDocHistoryService.createIntegrationDetails(data);

			logger.info("createIntegrationDetails() completed");
			
		 return result.getAppIntegrationID();
	}
	
}
