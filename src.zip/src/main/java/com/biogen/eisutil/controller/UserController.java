package com.biogen.eisutil.controller;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biogen.eisutil.dao.User;
import com.biogen.eisutil.service.UserService;

@RestController
@RequestMapping("/bio")
public class UserController {
	
	@Resource(name = "UserService")
	private UserService userService;
	
	@GetMapping("/users")
	public List<User> getUsers()
	{
		return userService.getUsers();
	}
	
	@GetMapping("/user/{id}")
	public Optional<User> getUser(@PathVariable Integer id)
	{
		return userService.getUserById(id);
	}
	
	@DeleteMapping("/user/{id}")
	public boolean deleteUser(@PathVariable Integer id)
	{
		userService.deleteUser(id);
		return true;
	}
	
	@PostMapping(path="/user", consumes="application/json", produces="application/json")
	public User createUser(@RequestBody User user)
	{
		return userService.createUser(user);
	}
	
	@PutMapping(path="/user", consumes="application/json", produces="application/json")
	public User updateUser(@RequestBody User user)
	{
		return userService.updateUser(user);
	}
}
