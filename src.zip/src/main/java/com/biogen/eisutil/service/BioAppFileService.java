package com.biogen.eisutil.service;

import java.util.Optional;
import com.biogen.eisutil.dao.BioAppFile;

public interface BioAppFileService {
	
	public Optional<BioAppFile> getBioAppFileByAppId(Integer id);
	
	public BioAppFile saveAppFile(BioAppFile bioAppFile);
	
}
