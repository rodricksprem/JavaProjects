package com.biogen.eisutil.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BioLogSearch;
import com.biogen.eisutil.model.BioLogTemp;
import com.biogen.eisutil.repo.BioLogInfoAttributesRepository;
import com.biogen.eisutil.repo.BioLogMainRepository;
import com.biogen.eisutil.repo.impl.BioLogCustomDAO;
import com.biogen.eisutil.service.BioLogService;

@Service("BioLogService")
public class BioLogServiceImpl implements BioLogService{
	
	@Autowired
	private BioLogMainRepository bioLogMainRepository;
	
	@Autowired
	private BioLogInfoAttributesRepository bioLogInfoAttributesRepository;

	@Autowired
	private BioLogCustomDAO bioLogCustomDAO;
	@Override
	public List<BioLogTemp> getLogDetailsByList() {
		return bioLogCustomDAO.getLogDetailsByList();
	}
	
	@Override
	public List<Object[]> getLogDetails() {
		return bioLogMainRepository.getLogDetails();
	}
	@Override
	public List<String> getKeyValueDetails(String bioTransactionId) {
		return bioLogInfoAttributesRepository.getKeyValueDetails(bioTransactionId);
	}
	
	@Override
	public List<String> getKeyValueDetails(String bioTransactionId, String keyValueDetails) {
		return bioLogInfoAttributesRepository.getKeyValueDetails(bioTransactionId, keyValueDetails);
	}

	@Override
	public List<Object[]> getLogDetailsByAdvancedSearch(String adSearchParams) {
		return bioLogMainRepository.getLogDetailsByAdvancedSearch(adSearchParams);
	}

	@Override
	public List<String> getKey() {
		return bioLogInfoAttributesRepository.getKey();
	}

	@Override
	public List<String> getKeyByAppName(String appName) {
		return bioLogInfoAttributesRepository.getKeyByAppName(appName);
	}

	@Override
	public List<Object[]> getDetailedLogDetails(String bioTransId) {
		return bioLogMainRepository.getDetailedLogDetails(bioTransId);
	}

	@Override
	public List<Object[]> getDetailedTargetSystemLogDetails(String bioTransId, int bioLogTargetSystemId) {
		return bioLogMainRepository.getDetailedTargetSystemLogDetails(bioTransId, bioLogTargetSystemId);
	}

	@Override
	public List<BigDecimal> getBioLogTargetSystemIdByBioTransId(String bioTransId) {
		return bioLogMainRepository.getBioLogTargetSystemIdByBioTransId(bioTransId);
	}

	@Override
	public List<Object[]> getLogDetailsByBusinessUnitSearch(String buSearchParams,Integer duration) {
		return bioLogMainRepository.getLogDetailsByBusinessUnitSearch(buSearchParams,duration);
	}
	
	@Override
	public List<BioLogTemp> getLogDetailsByBUSearch(String buSearchParams,Integer duration) {
		return bioLogCustomDAO.getLogDetailsByBUSearch(buSearchParams,duration);
	}
	
	@Override
	public List<BioLogTemp> getLogDetailsByAdvSearch(BioLogSearch bioLogSearch) {
		return bioLogCustomDAO.getLogDetailsByAdvSearch(bioLogSearch);
	}

	@Override
	public List<BioLogTemp> getLogDetailsByList(Integer duration) {
		
		return bioLogCustomDAO.getLogDetailsByList(duration);
	}

}
