package com.biogen.eisutil.service;

import java.util.List;
import java.util.Optional;

import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.dao.BioNotify;
import com.biogen.eisutil.dao.BioNotifyProps;

public interface BioNotifyService {
	
	public List<BioNotify> getAllNotifications();
	
	public Optional<BioNotify> getNotificationById(Integer id);
	
	public boolean deleteNotification(Integer id);
	
	public boolean createNotification(BioNotification bioNotification);
	
	public BioNotify updateNotification(BioNotify bioNotify);
	
	public List<Object[]> getAllNotificationsAndHistory();
	public List<Object[]> getAllNotificationsAndHistory(Integer duration);
	public List<Object[]> getAllNotificationsAndHistoryByAdSearch(String adSearchParams);
	
	public List<Object[]> getAllNotificationsAndHistoryByBUSearch(String buSearchParams,Integer duration);
    public List<String> getAppDetailsbyAppId(Integer appId);
	
	public List<String> getAppGroupNamebyAppId(Integer appId);
	
    public List<String> getExCategoryList();
	
	public List<String> getExTypeList();
	
	public List<String> getBNHStatusList();
	
	public List<Object[]> getBioNotifyHistoryDetails(int notifyHistoryId);
	
	public List<Object[]> getBioNotifyProps(int notifyHistoryId);
	
	public List<Object[]> getAllBioNotify();
	
	public List<BioNotifyProps> getAllBioNotifyProps();
	
	public List<String> getAllBioNotifyPropsName();
	
	public List<Integer> getNotifyIdByExCategoryAndExTypeAndAppId(int appId, String exCategory, String exType);
	
	public List<Object[]> getExCategoryAndExTypeByAppId(int appId);
	
	public List<Object[]> getExCategoryAndExTypeByAppName(String appName) ;
	
	public boolean createBioNotifyprops(BioNotifyProps bioNotifyProps);
	
	public boolean createNotification(List<BioNotification> bioNotificationList);
	
	public boolean updateNotification(List<BioNotification> bioNotificationList, String updatedBy);
}
