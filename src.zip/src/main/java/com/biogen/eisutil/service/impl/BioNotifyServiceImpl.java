package com.biogen.eisutil.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.dao.BioNotify;
import com.biogen.eisutil.dao.BioNotifyProps;
import com.biogen.eisutil.repo.BioNotifyPropsRepository;
import com.biogen.eisutil.repo.BioNotifyRepository;
import com.biogen.eisutil.service.BioNotifyService;

@Service("BioNotifyService")
public class BioNotifyServiceImpl implements BioNotifyService{
	
	@Autowired
	private BioNotifyRepository bioNotifyRepository;
	
	@Autowired
	private BioNotifyPropsRepository bioNotifyPropsRepository;
	
	@Override
	public List<BioNotify> getAllNotifications() {
		return bioNotifyRepository.findAll();
	}

	@Override
	public Optional<BioNotify> getNotificationById(Integer id) {
		return bioNotifyRepository.findById(id);
	}

	@Override
	public boolean deleteNotification(Integer id) {
		bioNotifyRepository.deleteById(id);
		return true;
	}

	@Override
	public boolean createNotification(BioNotification bioNotification) {
		boolean isNotifyCreated = false;
	
		return isNotifyCreated;
	}
	
	@Override
	public boolean createNotification(List<BioNotification> bioNotificationList) {
		BioNotify bioNotify = null;
		boolean isNotifyCreated = true;
		try {
		List<BioNotifyProps> notifyPropsList = new ArrayList<BioNotifyProps>();
		BioNotifyProps bioNotifyProps = null;
		for(BioNotification bioNotification:bioNotificationList) {
		bioNotify = new BioNotify();
		bioNotify.setAppId(bioNotification.getAppId());
		bioNotify.setExCategory(bioNotification.getExceptionCategory());
		bioNotify.setExType(bioNotification.getExceptionType());
		
		
		int notifyId = bioNotifyRepository.getNotifyId(bioNotification.getAppId(), bioNotification.getExceptionCategory(), bioNotification.getExceptionType());
			System.out.println("notifyId:"+notifyId);
			if( notifyId == 0 ) {
		BioNotify notifyDet=  bioNotifyRepository.save(bioNotify);
		notifyId = notifyDet.getId();
		System.out.println("new notifyId:"+notifyId);
			}
			if( notifyId > 0 ) {
				
				bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
				bioNotifyProps.setName("SERVICE_ACTIVE");
				bioNotifyProps.setValue(bioNotification.getNotificationEnabled());
				notifyPropsList.add(bioNotifyProps);
				bioNotifyProps = null;
				bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
				bioNotifyProps.setName("TO_EMAIL");
				bioNotifyProps.setValue(bioNotification.getToemail());
				notifyPropsList.add(bioNotifyProps);
				bioNotifyProps = null;
				bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
				if( bioNotification.getTemplate() != null && bioNotification.getTemplate().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("TEMPLATE");
					bioNotifyProps.setValue(bioNotification.getTemplate());
					notifyPropsList.add(bioNotifyProps);
				}
				bioNotifyProps = null;
				bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
				bioNotifyProps.setName("JOB_TYPE");
				bioNotifyProps.setValue(bioNotification.getNotificationType());
				notifyPropsList.add(bioNotifyProps);
				if( bioNotification.getAggregationEnabled() != null && bioNotification.getAggregationEnabled().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("AGGR_ENABLED");
					bioNotifyProps.setValue(bioNotification.getAggregationEnabled());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getAggregationCount() != null && bioNotification.getAggregationCount().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("AGGR_MIN");
					bioNotifyProps.setValue(bioNotification.getAggregationCount());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getThresholdEnabled() != null && bioNotification.getThresholdEnabled().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("THRESHOLD_ENABLED");
					bioNotifyProps.setValue(bioNotification.getThresholdEnabled());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getThresholdLimit() != null && bioNotification.getThresholdLimit().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("THRESHOLD_LIMIT");
					bioNotifyProps.setValue(bioNotification.getThresholdLimit());
					notifyPropsList.add(bioNotifyProps);
				}
					
				if( bioNotification.getFrequency() != null && bioNotification.getFrequency().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("JOB_FREQ");
					bioNotifyProps.setValue(bioNotification.getFrequency());
					notifyPropsList.add(bioNotifyProps);
				}
				
				if( bioNotification.getCcemail() != null && bioNotification.getCcemail().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("CC_EMAIL");
					bioNotifyProps.setValue(bioNotification.getCcemail());
					notifyPropsList.add(bioNotifyProps);
				}
			if( bioNotification.getFromEmail() != null && bioNotification.getFromEmail().length() > 0) {
					bioNotifyProps = null;
					bioNotifyProps = this.setDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					bioNotifyProps.setName("FROM_EMAIL");
					bioNotifyProps.setValue(bioNotification.getFromEmail());
					notifyPropsList.add(bioNotifyProps);
			}
			}
		}
			this.createBioNotifyprops(notifyPropsList);
		} catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
		
		
		return isNotifyCreated;
		
	}
	
	@Override
	public boolean updateNotification(List<BioNotification> bioNotificationList, String updatedBy) {
		BioNotify bioNotify = null;
		boolean isNotifyCreated = true;
		int notifyId = 0;
		try {
		List<BioNotifyProps> notifyPropsList = new ArrayList<BioNotifyProps>();
		BioNotifyProps bioNotifyProps = null;
		for(BioNotification bioNotification:bioNotificationList) {
		bioNotify = new BioNotify();

		if(bioNotification.getNotifyId()!=null && bioNotification.getNotifyId() > 0) {
			notifyId = bioNotification.getNotifyId();
			Optional<BioNotify> bioNotifyOpt = bioNotifyRepository.findById(notifyId);
			bioNotify = bioNotifyOpt.get();
			System.out.println("bioNotify:"+bioNotify);
		} else {
			bioNotify = new BioNotify();
			bioNotify.setAppId(bioNotification.getAppId());
		}
		 
		if( bioNotification.getExceptionCategory() !=null && bioNotification.getExceptionCategory().length() > 0 ) {
			bioNotify.setExCategory(bioNotification.getExceptionCategory());
		}
		if( bioNotification.getExceptionType() !=null && bioNotification.getExceptionType().length() > 0 ) {
			bioNotify.setExType(bioNotification.getExceptionType());
		}
		System.out.println("updateNotification-->notifyId:"+notifyId);
		
		if( (bioNotification.getExceptionCategory() != null && bioNotification.getExceptionCategory().length()>0) || (bioNotification.getExceptionType() != null && bioNotification.getExceptionType().length()>0)) {
			BioNotify notifyDet=  bioNotifyRepository.save(bioNotify);
		}
			if( notifyId > 0 ) {
				int notifyPropsId = 0;
				
				if( bioNotification.getNotificationEnabled() != null && bioNotification.getNotificationEnabled().length() > 0 ) {
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("SERVICE_ACTIVE", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
				bioNotifyProps.setName("SERVICE_ACTIVE");
				bioNotifyProps.setValue(bioNotification.getNotificationEnabled());
				notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getToemail() != null && bioNotification.getToemail().length() > 0 ) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("TO_EMAIL", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("TO_EMAIL");
					bioNotifyProps.setValue(bioNotification.getToemail());
				notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getTemplate() != null && bioNotification.getTemplate().length() > 0 ) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("TEMPLATE", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("TEMPLATE");
					bioNotifyProps.setValue(bioNotification.getTemplate());
				notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getNotificationType() != null && bioNotification.getNotificationType().length() > 0 ) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("JOB_TYPE", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("JOB_TYPE");
					bioNotifyProps.setValue(bioNotification.getNotificationType());
				notifyPropsList.add(bioNotifyProps);
				}				
				
				if( bioNotification.getAggregationEnabled() != null && bioNotification.getAggregationEnabled().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("AGGR_ENABLED", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("AGGR_ENABLED");
					bioNotifyProps.setValue(bioNotification.getAggregationEnabled());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getAggregationCount() != null && bioNotification.getAggregationCount().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("AGGR_MIN", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("AGGR_MIN");
					bioNotifyProps.setValue(bioNotification.getAggregationCount());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getThresholdEnabled() != null && bioNotification.getThresholdEnabled().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("THRESHOLD_ENABLED", notifyId);
					if(notifyPropsId != 0) {
						bioNotifyProps.setId(notifyPropsId);
					}
					bioNotifyProps.setName("THRESHOLD_ENABLED");
					bioNotifyProps.setValue(bioNotification.getThresholdEnabled());
					notifyPropsList.add(bioNotifyProps);
				}
				if( bioNotification.getThresholdLimit() != null && bioNotification.getThresholdLimit().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("THRESHOLD_LIMIT", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("THRESHOLD_LIMIT");
					bioNotifyProps.setValue(bioNotification.getThresholdLimit());
					notifyPropsList.add(bioNotifyProps);
				}
					
				if( bioNotification.getFrequency() != null && bioNotification.getFrequency().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("JOB_FREQ", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("JOB_FREQ");
					bioNotifyProps.setValue(bioNotification.getFrequency());
					notifyPropsList.add(bioNotifyProps);
				}
				
				if( bioNotification.getCcemail() != null && bioNotification.getCcemail().length() > 0) {
					notifyPropsId = 0;
					bioNotifyProps = null;
					bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
					notifyPropsId = bioNotifyRepository.getNotifyPropsId("CC_EMAIL", notifyId);
					if(notifyPropsId != 0)
						bioNotifyProps.setId(notifyPropsId);
					bioNotifyProps.setName("CC_EMAIL");
					bioNotifyProps.setValue(bioNotification.getCcemail());
					notifyPropsList.add(bioNotifyProps);
				}
			if( bioNotification.getFromEmail() != null && bioNotification.getFromEmail().length() > 0) {
				notifyPropsId = 0;
				bioNotifyProps = null;
				bioNotifyProps = this.setUpdateDefaultNotifyProps(bioNotifyProps,notifyId,bioNotification);
				notifyPropsId = bioNotifyRepository.getNotifyPropsId("FROM_EMAIL", notifyId);
				if(notifyPropsId != 0)
					bioNotifyProps.setId(notifyPropsId);
				bioNotifyProps.setName("FROM_EMAIL");
				bioNotifyProps.setValue(bioNotification.getFromEmail());
				notifyPropsList.add(bioNotifyProps);
			}
			}
		}
			this.updateBioNotifyprops(notifyPropsList, notifyId);
		} catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
		return isNotifyCreated;
		
	}
	
	private BioNotifyProps setDefaultNotifyProps(BioNotifyProps bioNotifyProps,int notifyId,BioNotification bioNotification) {
		bioNotifyProps = new BioNotifyProps();
		bioNotifyProps.setNotifyId(notifyId);
		return bioNotifyProps;
	}
	
	private BioNotifyProps setUpdateDefaultNotifyProps(BioNotifyProps bioNotifyProps,int notifyId,BioNotification bioNotification) {
		bioNotifyProps = new BioNotifyProps();
		bioNotifyProps.setNotifyId(notifyId);
		return bioNotifyProps;
	}

	@Override
	public BioNotify updateNotification(BioNotify bioNotify) {
		return bioNotifyRepository.save(bioNotify);
	}

	@Override
	public List<Object[]> getAllNotificationsAndHistory() {
		return bioNotifyRepository.getAllNotificationsAndHistory();
	}
	@Override
	public List<Object[]> getAllNotificationsAndHistory(Integer duration) {
		return bioNotifyRepository.getAllNotificationsAndHistory(duration);
	}


	@Override
	public List<String> getAppDetailsbyAppId(Integer appId) {
		return bioNotifyRepository.getAppDetailsbyAppId(appId);
	}

	@Override
	public List<String> getAppGroupNamebyAppId(Integer appId) {
		return bioNotifyRepository.getAppGroupNamebyAppId(appId);
	}

	@Override
	public List<String> getExCategoryList() {
		return bioNotifyRepository.getExCategoryList();
	}

	@Override
	public List<String> getExTypeList() {
		return bioNotifyRepository.getExTypeList();
	}

	@Override
	public List<String> getBNHStatusList() {
		return bioNotifyRepository.getBNHStatusList();
	}

	@Override
	public List<Object[]> getAllNotificationsAndHistoryByAdSearch(String adSearchParams) {
		return bioNotifyRepository.getAllNotificationsAndHistoryByAdSearch(adSearchParams);
	}

	@Override
	public List<Object[]> getBioNotifyHistoryDetails(int notifyHistoryId) {
		return bioNotifyRepository.getBioNotifyHistoryDetails(notifyHistoryId);
	}

	@Override
	public List<Object[]> getBioNotifyProps(int notifyHistoryId) {
		return bioNotifyRepository.getBioNotifyProps(notifyHistoryId);
	}

	@Override
	public List<Object[]> getAllBioNotify() {
		return bioNotifyRepository.getAllBioNotify();
	}

	@Override
	public List<BioNotifyProps> getAllBioNotifyProps() {
		return bioNotifyPropsRepository.findAll(OrderByCreatedDateDesc());
	}
	
	private Sort OrderByCreatedDateDesc() {
        return new Sort(Sort.Direction.DESC, "CreatedDate");
    }
	
	@Override
	public List<String> getAllBioNotifyPropsName() {
		return bioNotifyPropsRepository.findName();
	}

	@Override
	public List<Integer> getNotifyIdByExCategoryAndExTypeAndAppId(int appId, String exCategory, String exType) {
		return bioNotifyPropsRepository.getNotifyIdList(appId, exCategory, exType);
	}

	@Override
	public List<Object[]> getExCategoryAndExTypeByAppId(int appId) {
		return bioNotifyPropsRepository.getExCategoryAndExTypeByAppId(appId);
	}
	
	@Override
	public List<Object[]> getExCategoryAndExTypeByAppName(String appName) {
		return bioNotifyPropsRepository.getExCategoryAndExTypeByAppName(appName);
	}

	@Override
	public boolean createBioNotifyprops(BioNotifyProps bioNotifyProps) {
		return bioNotifyPropsRepository.save(bioNotifyProps) != null;
	}

	
	public boolean createBioNotifyprops(List<BioNotifyProps> bioNotifyPropsList) {
		boolean isSuccess = false;
		isSuccess = bioNotifyPropsRepository.saveAll(bioNotifyPropsList) != null;
		return isSuccess;
	}
	public boolean updateBioNotifyprops(List<BioNotifyProps> bioNotifyPropsList, Integer notifyId) {
		boolean isSuccess = false;

		isSuccess = bioNotifyPropsRepository.saveAll(bioNotifyPropsList) != null;
		return isSuccess;
	}

	@Override
	public List<Object[]> getAllNotificationsAndHistoryByBUSearch(String buSearchParams,Integer duration) {
		return bioNotifyRepository.getAllNotificationsAndHistoryByBUSearch(buSearchParams, duration);
	}

	
}
