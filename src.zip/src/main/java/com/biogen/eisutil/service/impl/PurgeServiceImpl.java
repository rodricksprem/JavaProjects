package com.biogen.eisutil.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.PurgeData;
import com.biogen.eisutil.model.PurgeDetailsData;
import com.biogen.eisutil.repo.impl.PurgeHistoryDAO;
import com.biogen.eisutil.service.PurgeService;

@Service("PurgeService")
public class PurgeServiceImpl implements PurgeService{
	
	@Autowired
	private PurgeHistoryDAO purgeHistoryDAO;

public List<PurgeData> getPurgeHistory(){
	System.out.println("PurgeServiceImpl.getPurgeHistoryDetails() -------------");
	return purgeHistoryDAO.getPurgeHistory();
}
	
	public List<PurgeDetailsData> getPurgeDetails(Integer id) {
		System.out.println("PurgeServiceImpl.getPurgeDetails() -------------");
		return purgeHistoryDAO.getPurgeDetails(id);
	}
}
