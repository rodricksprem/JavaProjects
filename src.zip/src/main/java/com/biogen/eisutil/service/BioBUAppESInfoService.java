package com.biogen.eisutil.service;

import java.util.List;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BarChartDataList;
import com.biogen.eisutil.dao.BioBUAppEntServiceEntity;
import com.biogen.eisutil.model.BioBusinessInfoData;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.model.BioLogApplicationData;
import com.biogen.eisutil.model.ChartData;
import com.biogen.eisutil.model.SankeyGraphNode;

public interface BioBUAppESInfoService {
	
	
	
	public List<ChartData> getDonutChartData(BUSearch buSearch, List<BioLOVsData> buDataList);
	public List<ChartData> getAllPieChartData(List<BioLOVsData> buDataList);
	
	public BarChartDataList getAllBarChartData(List<BioLOVsData> buDataList);
	
    public BarChartDataList getBarChartData(BUSearch buSearch, List<BioLOVsData> buDataList);
    
    
	public List<ChartData> getNotificationBarChartData(List<BioLOVsData> buDataList);
	
	public List<ChartData>  getNotificationBarChartData(BUSearch buSearch, List<BioLOVsData> buDataList);
	
	public boolean createBUAPP_ES_Info(List<BioBUAppEntServiceEntity> sourceEntityList, List<BioBUAppEntServiceEntity> targetEntityList);
	
	public List<BioBusinessInfoData> getDetailsByAppId(Integer appId);
	
	public List<BioBusinessInfoData> getBU_APPDetails();
	
	public boolean updateBUAPP_ES_Info(BioLogApplicationData bioLogApplicationData);
	
	public List<SankeyGraphNode> getSankeyGraphData(List<BioLOVsData> buDataList);

	public List<SankeyGraphNode> getSankeyGraphData(BUSearch buSearch, List<BioLOVsData> buDataList);
	
}
