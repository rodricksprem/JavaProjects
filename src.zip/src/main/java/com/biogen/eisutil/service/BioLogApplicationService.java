package com.biogen.eisutil.service;

import java.util.List;
import java.util.Optional;

import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.model.BioIntegrationDetails;
import com.biogen.eisutil.dao.BioLogAppGroup;
import com.biogen.eisutil.dao.BioLogAppType;
import com.biogen.eisutil.dao.BioLogApplication;
import com.biogen.eisutil.model.BioLogApplicationData;
import com.biogen.eisutil.dao.BioLogCRDetailsEntity;
import com.biogen.eisutil.dao.BioLogITPDDetailsEntity;
import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.dao.BioLogLevel;
import com.biogen.eisutil.model.BioNotification;

public interface BioLogApplicationService {
	
	public Optional<BioLogApplication> getBioLogApplicationById(Integer id);
	
	public List<Object[]> getAllApplicationDetails();
	
	public boolean updateApplication(BioLogApplicationData bioLogApplicationData);
	
	public List<Object[]> getAppNameList();
	
	public List<Object[]> getAppTypeList();
	
    public List<Object[]> getAppGroupList();
	
	public List<Object[]> getLogLevelList();
	
	public List<String> getServiceInvokerStatusList();
	
	public int saveApplication(BioLogApplicationData bioLogApplicationData);
	
	public boolean saveAppType(BioLogAppType bioLogAppType);
	
	public boolean saveAppGroup(BioLogAppGroup bioLogAppGroup);
	
	public boolean saveLogLevel(BioLogLevel bioLogLevel);
	
	public List<BioLogAppType> getAllBioLogAppTypeDetails();
	
	public List<BioLogAppGroup> getAllBioLogAppGroupDetails();
	
	public List<BioLogLevel> getAllBioLogLevelDetails();
	
	public List<Object[]> getAppNameByAppGroupId(String appGroupName);
	
	public BioLogIntegrationDetailsEntity createIntegrationDetails(BioLogIntegrationDetailsEntity data);
	
	public boolean createITPDDetails(List<BioLogITPDDetailsEntity> dataList);
	
	public BioLogCRDetailsEntity createCRDDetails(BioLogCRDetailsEntity data);
	
	public boolean createCRDDetails(List<BioLogCRDetailsEntity> dataList);
	
	public BioIntegrationDetails getIntegrationDetails(Integer appId);
	
	public List<BioNotification> getNotificationDetails(Integer appId);

	public boolean updateITPDDetails(List<BioAppDocHistoryTemp> inputDataList);
	
	public boolean updateCRDetails(List<BioAppDocHistoryTemp> inputDataList);
}
