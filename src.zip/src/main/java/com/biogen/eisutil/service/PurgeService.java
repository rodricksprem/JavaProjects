package com.biogen.eisutil.service;

import java.util.List;

import com.biogen.eisutil.model.PurgeData;
import com.biogen.eisutil.model.PurgeDetailsData;

public interface PurgeService {
	
	public List<PurgeData> getPurgeHistory();
	
	public List<PurgeDetailsData> getPurgeDetails(Integer id);
	
	

}
