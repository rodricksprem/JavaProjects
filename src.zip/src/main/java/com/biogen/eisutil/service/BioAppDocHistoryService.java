package com.biogen.eisutil.service;

import java.util.List;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;

public interface BioAppDocHistoryService {
	

		
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetails();
	
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetailsByAppId(Integer appId);
	
	public List<BioAppDocHistoryTemp> getInterfaceDetails(BUSearch buSearch);
	

	public BioLogIntegrationDetailsEntity createIntegrationDetails(BioLogIntegrationDetailsEntity data);
	
}
