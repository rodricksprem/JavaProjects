package com.biogen.eisutil.service;

import com.biogen.eisutil.dao.BioLogUser;

public interface LDAPUserAuthenticatorService {

	
	public boolean isValidUser(BioLogUser user);
	

}
