package com.biogen.eisutil.service;

import java.util.List;
import java.util.Optional;

import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogUser;
import com.biogen.eisutil.model.BioLogUserData;
import com.biogen.eisutil.model.BioLogUserTemp;

public interface BioLogUserService {
	
	public List<BioLogUser> getBioLogUsers();
	
	public List<BioLogUserTemp> getUsersList();
	
	public Optional<BioLogUser> getBioLogUser(String id);
	
	public List<Object[]> getUsers();
	
	public List<Object[]> getUserTypeList();
	
	public boolean saveUser(BioLogUser bioLogUser);
	public boolean deleteUser(BioLogUser bioLogUser);
	
	public boolean userBUMapping(BioLogUserData bioLogUser);
	
	public List<String> getBUName(String userId);
	
	public List<BioLOVsData> getBUDataList(String userId);

}
