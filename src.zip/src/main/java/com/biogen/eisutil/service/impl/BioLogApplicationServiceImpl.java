package com.biogen.eisutil.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.model.BioIntegrationDetails;
import com.biogen.eisutil.dao.BioLogAppGroup;
import com.biogen.eisutil.dao.BioLogAppType;
import com.biogen.eisutil.dao.BioLogApplication;
import com.biogen.eisutil.model.BioLogApplicationData;
import com.biogen.eisutil.dao.BioLogCRDetailsEntity;
import com.biogen.eisutil.dao.BioLogITPDDetailsEntity;
import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.dao.BioLogLevel;
import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.repo.BioLogAppGroupRepository;
import com.biogen.eisutil.repo.BioLogAppTypeRepository;
import com.biogen.eisutil.repo.BioLogApplicationRepository;
import com.biogen.eisutil.repo.BioLogCRDetailsRepository;
import com.biogen.eisutil.repo.BioLogITPDDetailsRepository;
import com.biogen.eisutil.repo.BioLogIntegrationDetailsRepository;
import com.biogen.eisutil.repo.BioLogLevelRepository;
import com.biogen.eisutil.repo.impl.BioLogCustomRepositoryImpl;
import com.biogen.eisutil.service.BioLogApplicationService;

@Service("BioLogApplicationService")
public class BioLogApplicationServiceImpl implements BioLogApplicationService{
	
	@Autowired
	private BioLogApplicationRepository bioLogApplicationRepository;
	
	@Autowired
	private BioLogAppTypeRepository bioLogAppTypeRepository;
	
	@Autowired
	private BioLogAppGroupRepository bioLogAppGroupRepository;
	
	@Autowired
	private BioLogLevelRepository bioLogLevelRepository;
	@Autowired
	BioLogCustomRepositoryImpl logCustomRepository;
	
	@Autowired
	BioLogIntegrationDetailsRepository bioLogIntegrationDetailsRepository;
	
	@Autowired
	BioLogITPDDetailsRepository bioLogITPDDetailsRepository; 
	
	@Autowired
	BioLogCRDetailsRepository bioLogCRDetailsRepository;
	
	@Override
	//fetch record from  BIO_LOG_APPLICATION  for given id
	public Optional<BioLogApplication> getBioLogApplicationById(Integer id) {
		return bioLogApplicationRepository.findById(id);
	}

	@Override
	//fetch all record from  BIO_LOG_APPLICATION  for given id
	public List<Object[]> getAllApplicationDetails() {
		return bioLogApplicationRepository.getAllApplicationDetails();
	}
	
	@Override
	//fetch application types from  BIO_LOG_APPLICATION  for given id
	public List<Object[]> getAppTypeList() {
		return bioLogApplicationRepository.getAppTypeList();
	}

	@Override
	public List<Object[]> getAppGroupList() {
		return bioLogApplicationRepository.getAppGroupList();
	}

	@Override
	public List<Object[]> getLogLevelList() {
		return bioLogApplicationRepository.getLogLevelList();
	}

	@Override
	public int saveApplication(BioLogApplicationData bioLogApplicationData) {
		//update BIO_LOG_APPLICATION
		
		int appId = logCustomRepository.getAppId(bioLogApplicationData.getAppName());
		if(appId == 0) {
			//generate Entity Object from Model and return it	
		BioLogApplication bioLogApplication = new BioLogApplication();
		bioLogApplication.setAppDesc(bioLogApplicationData.getAppDesc());
		bioLogApplication.setAppGroupId(bioLogApplicationData.getAppGroupId());
		bioLogApplication.setAppName(bioLogApplicationData.getAppName());
		bioLogApplication.setAppTypeId(bioLogApplicationData.getAppTypeId());
		bioLogApplication.setLoggerId(bioLogApplicationData.getLoggerId());
		try {
		BioLogApplication bioLogApp = bioLogApplicationRepository.save(bioLogApplication);
		//return the primary key of new created row from BIO_LOG_APPLICATION
		appId= bioLogApp.getAppId();
		} catch(Exception ex) {
			ex.printStackTrace();
			appId =0;
		}
		} else {
			appId=-1;
		}
		return appId;
	}

	@Override
	public boolean updateApplication(BioLogApplicationData bioLogApplicationData) {
		//update BIO_LOG_APPLICATION
		Optional<BioLogApplication> bioLogApplicationOptional = bioLogApplicationRepository.findById(bioLogApplicationData.getAppId());
		BioLogApplication bioLogApplication = bioLogApplicationOptional.get();
		 boolean isUpdate= false;
		 if(bioLogApplicationData.getAppDesc() != null && bioLogApplicationData.getAppDesc().length() >0 ) {
			 bioLogApplication.setAppDesc(bioLogApplicationData.getAppDesc());	 
			 isUpdate = true;
		 }
		 if(bioLogApplicationData.getAppTypeId() != null && bioLogApplicationData.getAppTypeId() !=0 ) {
			 bioLogApplication.setAppTypeId(bioLogApplicationData.getAppTypeId());
			 isUpdate = true;
		 }
		 if(bioLogApplicationData.getAppGroupId() != null && bioLogApplicationData.getAppGroupId() !=0 ) {
			 bioLogApplication.setAppGroupId(bioLogApplicationData.getAppGroupId());
			 isUpdate = true;
		 }
		 if(bioLogApplicationData.getLoggerId() != null && bioLogApplicationData.getLoggerId() !=0 ) {
			 bioLogApplication.setLoggerId(bioLogApplicationData.getLoggerId());
			 isUpdate = true;
		 }
		try {
			if(isUpdate) {
				bioLogApplication = bioLogApplicationRepository.save(bioLogApplication);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		
		}
		
		return isUpdate;
	}

	@Override
	public boolean saveAppType(BioLogAppType bioLogAppType) {
		return bioLogAppTypeRepository.save(bioLogAppType) != null;
	}

	@Override
	public boolean saveAppGroup(BioLogAppGroup bioLogAppGroup) {
		return bioLogAppGroupRepository.save(bioLogAppGroup) != null;
	}

	@Override
	public boolean saveLogLevel(BioLogLevel bioLogLevel) {
		return bioLogLevelRepository.save(bioLogLevel) != null;
	}

	@Override
	public List<BioLogAppType> getAllBioLogAppTypeDetails() {
		return bioLogAppTypeRepository.findAll(new Sort(Sort.Direction.DESC, "createdDate"));
	}

	@Override
	public List<BioLogAppGroup> getAllBioLogAppGroupDetails() {
		return bioLogAppGroupRepository.findAll(new Sort(Sort.Direction.DESC, "createdDate"));
	}

	@Override
	public List<BioLogLevel> getAllBioLogLevelDetails() {
		return bioLogLevelRepository.findAll(new Sort(Sort.Direction.DESC, "createdDate"));
	}

	@Override
	public List<Object[]> getAppNameList() {
		return bioLogApplicationRepository.getAppNameList();
	}

	@Override
	public List<String> getServiceInvokerStatusList() {
		return bioLogApplicationRepository.getServiceInvokerStatusList();
	}

	@Override
	public List<Object[]> getAppNameByAppGroupId(String appGroupName) {
		return bioLogApplicationRepository.getAppNameByAppGroupId(appGroupName);
	}
	
	@Override
	public BioLogIntegrationDetailsEntity createIntegrationDetails(BioLogIntegrationDetailsEntity data) {
		return bioLogIntegrationDetailsRepository.save(data);	
	}
	
	@Override
	public boolean createITPDDetails(List<BioLogITPDDetailsEntity> dataList) {
		boolean result = false;
		
			result = bioLogITPDDetailsRepository.saveAll(dataList) != null;	
		
		return result;
	}
	@Override
	public boolean updateITPDDetails(List<BioAppDocHistoryTemp> inputDataList) {
		BioLogITPDDetailsEntity data = null;
		boolean result = false;
		
		List<BioLogITPDDetailsEntity> dataList = new ArrayList<BioLogITPDDetailsEntity>();
	for(BioAppDocHistoryTemp ent :inputDataList) {
		if(ent.getSourceTypeId() != null && ent.getSourceTypeId() != 0) {
			//find the Instance of bio_etm_ITPD_DETAILS for the given primary key and add the data to it
			Optional<BioLogITPDDetailsEntity> dataOpt = bioLogITPDDetailsRepository.findById(ent.getSourceTypeId());
			data = dataOpt.get();
			if(ent.getItpdDescription() != null && ent.getItpdDescription().length() > 0)
				data.setItpdDescription(ent.getItpdDescription());
			if(ent.getItpdNo() != null && ent.getItpdNo().length() > 0)
				data.setItpdNumber(ent.getItpdNo());
			dataList.add(data);
			} else {
				//else create new Instance and set the details and add the data to it.
				data = new BioLogITPDDetailsEntity();
				 data.setAppIntegrationID(ent.getAppIntegrationId());
				 data.setItpdDescription(ent.getItpdDescription());
				 data.setItpdNumber(ent.getItpdNo());
				 dataList.add(data);
			}

		}
	result = bioLogITPDDetailsRepository.saveAll(dataList) != null;
	return result;
	}
	@Override
	public BioLogCRDetailsEntity createCRDDetails(BioLogCRDetailsEntity data) {
		return bioLogCRDetailsRepository.save(data);	
	}
	
	@Override
	public boolean updateCRDetails(List<BioAppDocHistoryTemp> inputDataList) {
	BioLogCRDetailsEntity data = null; 
	boolean result = false;
	List<BioLogCRDetailsEntity> dataList = new ArrayList<BioLogCRDetailsEntity>();
	for(BioAppDocHistoryTemp ent: inputDataList) {
		if(ent.getSourceTypeId() != null && ent.getSourceTypeId() !=0) {
			//find the Instance of bio_etm_CR_DETAILS for the given primary key
			Optional<BioLogCRDetailsEntity> dataOpt = bioLogCRDetailsRepository.findById(ent.getSourceTypeId());
			data = dataOpt.get();
		if(ent.getComments() != null && ent.getComments().length() > 0)
			data.setComments(ent.getComments());
		if(ent.getCrDescription() != null && ent.getCrDescription().length() > 0)
			data.setCrDescription(ent.getCrDescription());
		if(ent.getCrNo() != null && ent.getCrNo().length() > 0)
			data.setCrNumber(ent.getCrNo());
		if(ent.getImplementedDate() != null && ent.getImplementedDate().toString().length() > 0)
			data.setImplementationDate(ent.getImplementedDate());
		dataList.add(data);
		} else {
			data = new BioLogCRDetailsEntity();
			data.setAppIntegrationID(ent.getAppIntegrationId());
			data.setComments(ent.getComments());
			data.setCrDescription(ent.getCrDescription());
			data.setCrNumber(ent.getCrNo());
			data.setImplementationDate(ent.getImplementedDate());
			dataList.add(data);
		}
	}
	result  = bioLogCRDetailsRepository.saveAll(dataList) != null;
	return result;
	}
	
	@Override
	public boolean createCRDDetails(List<BioLogCRDetailsEntity> dataList) {
		boolean result = false;
			result = bioLogCRDetailsRepository.saveAll(dataList) != null;	
		return result;
	}
	
	@Override
	public BioIntegrationDetails getIntegrationDetails(Integer appId) {
		
		BioIntegrationDetails integrationDetails = new BioIntegrationDetails();
		List<Object[]> integrationList = bioLogApplicationRepository.getIntegrationDetails(appId);
		for (Object[] object : integrationList) {
			integrationDetails.setIntegrationId(Integer.parseInt(object[0].toString()));
		
			integrationDetails.setAppId(Integer.parseInt(object[1].toString()));
			if( object[2] != null && object[2].toString().trim() != "") {
				integrationDetails.setIntegrationPatternId(Integer.parseInt(object[2].toString()));
			}
			if(object[3] != null && object[3].toString().trim() != "") {
				integrationDetails.setFileId(Integer.parseInt(object[3].toString()));
			}
		}
		if( integrationDetails.getIntegrationId() != null && integrationDetails.getIntegrationId() != 0 ) {
			integrationDetails.setCrDetailsList(bioLogApplicationRepository.getCRDetails(integrationDetails.getIntegrationId()));
			integrationDetails.setItpdDetailsList(bioLogApplicationRepository.getITPDDetails(integrationDetails.getIntegrationId()));
		}
		return integrationDetails;
		
	}
	
	@Override
	public List<BioNotification> getNotificationDetails(Integer appId) {
		
		return bioLogApplicationRepository.getNotificationDetails(appId);
		
	}
	
}
