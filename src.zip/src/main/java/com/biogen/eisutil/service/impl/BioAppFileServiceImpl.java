package com.biogen.eisutil.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.dao.BioAppFile;
import com.biogen.eisutil.repo.BioAppFileRepository;
import com.biogen.eisutil.service.BioAppFileService;

@Service("BioAppFileService")
public class BioAppFileServiceImpl implements BioAppFileService{
	
	@Autowired
	private BioAppFileRepository bioAppFileRepository;
	
	@Override
	public Optional<BioAppFile> getBioAppFileByAppId(Integer id) {
		return bioAppFileRepository.findByAppId(id);
	}

	@Override
	public BioAppFile saveAppFile(BioAppFile bioAppFile) {
		
		return bioAppFileRepository.save(bioAppFile);
	}
}
