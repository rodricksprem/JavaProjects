package com.biogen.eisutil.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogUser;
import com.biogen.eisutil.dao.BioLogUserBUEntity;
import com.biogen.eisutil.model.BioLogUserData;
import com.biogen.eisutil.model.BioLogUserTemp;
import com.biogen.eisutil.repo.BioLogUserBURepository;
import com.biogen.eisutil.repo.BioLogUserRepository;
import com.biogen.eisutil.repo.impl.BioLogCustomDAO;
import com.biogen.eisutil.service.BioLogUserService;

@Service("BioLogUserService")
public class BioLogUserServiceImpl implements BioLogUserService{
	
	@Autowired
	BioLogUserRepository bioLogUserRepository;
	
	@Autowired
	BioLogUserBURepository bioLogUserBURepository;
	
	
	@Autowired
	private BioLogCustomDAO bioLogCustomDAO;
	@Override
	public List<BioLogUser> getBioLogUsers() {
		return bioLogUserRepository.findAll();
	}

	@Override
	public Optional<BioLogUser> getBioLogUser(String id) {
		return bioLogUserRepository.findById(id);
	}

	@Override
	public List<Object[]> getUsers() {
		return bioLogUserRepository.getUsers();
	}
	
	@Override
	public List<BioLogUserTemp> getUsersList() {
		return bioLogCustomDAO.getUsersList();
	}

	@Override
	public List<Object[]> getUserTypeList() {
		return bioLogUserRepository.getUserTypeList();
	}

	@Override
	public boolean saveUser(BioLogUser bioLogUser) {
		return bioLogUserRepository.save(bioLogUser) != null;
	}
	
	@Override
	public List<String> getBUName(String userId){
		List<Object[]> resultList =bioLogUserRepository.getBUName(userId);

		List<BioLOVsData> buDataList = new ArrayList<BioLOVsData>();
		BioLOVsData buData = null;
		List<String> buList = new ArrayList<String>();
		for (Object[] object1 :resultList) {
			buData = new BioLOVsData();
			if(object1[4] != null && object1[4].toString().trim() != "")
			{
				buList.add(object1[4].toString());
				buData.setName(object1[4].toString());
				System.out.println("Bu name:"+object1[4].toString());
			}
			if(object1[2] != null && object1[2].toString().trim() != "")
			{
				System.out.println("buID:"+Integer.parseInt(object1[2].toString()));
				buData.setId(Integer.parseInt(object1[2].toString()));
			}
			buDataList.add(buData);
		}
		return buList;
	}
	
	@Override
	public List<BioLOVsData> getBUDataList(String userId){
		List<Object[]> resultList =bioLogUserRepository.getBUName(userId);

		List<BioLOVsData> buDataList = new ArrayList<BioLOVsData>();
		BioLOVsData buData = new BioLOVsData();
		buData.setId(0);
		buData.setName("Business Unit");
		buDataList.add(buData);
		List<String> buList = new ArrayList<String>();
		for (Object[] object1 :resultList) {
			buData = new BioLOVsData();
			if(object1[4] != null && object1[4].toString().trim() != "")
			{
				buList.add(object1[4].toString());
				buData.setName(object1[4].toString());
				System.out.println("Bu name:"+object1[4].toString());
			}
			if(object1[2] != null && object1[2].toString().trim() != "")
			{
				buData.setId(Integer.parseInt(object1[2].toString()));
			}
			buDataList.add(buData);
		}
		return buDataList;
	}
	
	@Override
	public boolean userBUMapping(BioLogUserData bioLogUser) {
		boolean isSuccess = false;
		
			this.bioLogCustomDAO.deleteUserBUMappings(bioLogUser.getUserId());
		System.out.println("User BU Mapping records deleted successfully");
		BioLogUserBUEntity newBUData = null;
		List<BioLogUserBUEntity> userAddList = new ArrayList<BioLogUserBUEntity>();
		StringTokenizer st = new StringTokenizer(bioLogUser.getBuList(),",");
		int seqId=0;
		while (st.hasMoreTokens()) {
			seqId = 0;
			newBUData = new BioLogUserBUEntity();
			seqId = this.bioLogCustomDAO.getSequenceId();
			if( seqId > 0 ) {
				newBUData.setUserBUID(seqId);
			}
			newBUData.setUserId(bioLogUser.getUserId());
			newBUData.setBuID(Integer.parseInt(st.nextToken()));
			newBUData.setStatus(1);
			System.out.println("userBUData:"+newBUData);
			userAddList.add(newBUData);
		}
		System.out.println("userAddList size:"+userAddList.size());
		isSuccess = bioLogUserBURepository.saveAll(userAddList) != null;
		 return isSuccess;
	}

	@Override
	public boolean deleteUser(BioLogUser bioLogUser) {
		
		System.out.println("deleteUser");
		this.bioLogCustomDAO.deleteUserBUMappings(bioLogUser.getUserId());
		System.out.println("User BU Mapping records deleted successfully");
		 bioLogUserRepository.delete(bioLogUser);
		 return true;
	}
	
}
