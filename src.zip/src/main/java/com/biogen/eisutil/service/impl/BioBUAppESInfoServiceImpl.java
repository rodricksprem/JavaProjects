package com.biogen.eisutil.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BarChartDataList;
import com.biogen.eisutil.dao.BioBUAppEntServiceEntity;
import com.biogen.eisutil.model.BioBusinessInfoData;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.model.BioLogApplicationData;
import com.biogen.eisutil.model.ChartData;
import com.biogen.eisutil.model.SankeyGraphNode;
import com.biogen.eisutil.repo.BioLogBUAPP_ES_InfoRepository;
import com.biogen.eisutil.repo.impl.DashboardDAO;
import com.biogen.eisutil.service.BioBUAppESInfoService;


@Service("BioBUAppESInfoService")
public class BioBUAppESInfoServiceImpl implements BioBUAppESInfoService{
	

	@Autowired
	private BioLogBUAPP_ES_InfoRepository bioLogBUAPP_ES_InfoRepository;
	
	@Autowired
	private DashboardDAO dashboardDAO;
	
	private List<ChartData> removeChartData(List<ChartData> listChartData) {
		return listChartData.parallelStream().filter(chartData ->{
			if (chartData.getY() > 0)
				{
					//consider the chart data whose y axis value is > 0
					chartData.setData(removeChartData(chartData.getData()));
					return true;
				}else {
					//remove the chart data whose y axis value is 0
					return false;
				}
		}).collect(Collectors.toList());
		
	}

	@Override
	public List<ChartData> getAllPieChartData(List<BioLOVsData> buDataList){
		return this.removeChartData(dashboardDAO.getAllDonutChartData(buDataList));
		
	}
	
	private BarChartDataList removeBarData(BarChartDataList listBarData) {
		listBarData.setSuccessList(listBarData.getSuccessList().parallelStream().filter(chartData ->{
			if (chartData.getY() > 0)
				{
					//consider the bar data whose y axis value is > 0
					chartData.setDataList(removeBarData(chartData.getDataList()));
					return true;
				}else {
					//remove the bar data whose y axis value is 0
					return false;
				}
		}).collect(Collectors.toList()));
		listBarData.setFailureList(listBarData.getFailureList().parallelStream().filter(chartData ->{
			if (chartData.getY() > 0)
				{
					//consider the bar data whose y axis value is > 0
					chartData.setDataList(removeBarData(chartData.getDataList()));
					
					return true;
				}else {
					//remove the bar data whose y axis value is > 0
					
					return false;
				}
		}).collect(Collectors.toList()));
		return listBarData;
		
	}
	@Override
	public BarChartDataList getAllBarChartData(List<BioLOVsData> buDataList) {
		//consider the bar data whose y axis value is > 0 and remove the others
		
		return this.removeBarData( dashboardDAO.getAllBarChartData(buDataList));
		
	}
	
	
		
	@Override
	public List<ChartData> getNotificationBarChartData(List<BioLOVsData> buDataList) {
		//consider the bar data whose y axis value is > 0 and remove the others
		return this.removeChartData(dashboardDAO.getNotificationBarChartData(buDataList));
	}
	
	@Override
	public List<ChartData> getDonutChartData(BUSearch buSearch, List<BioLOVsData> buDataList) {
		//consider the  chart data whose y axis value is > 0 and remove the others

		List<ChartData> donutChartList = new ArrayList<ChartData>();
		if( buSearch.getEntServiceName() != null && buSearch.getEntServiceName().length()>0) {
			donutChartList = this.removeChartData(dashboardDAO.getDonutChartData(buSearch));
			} else	if( buSearch.getEntityName() != null) {
				donutChartList = this.removeChartData(dashboardDAO.getDonutChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch.getEntityName(), buSearch));
			}
		
		else	if( buSearch.getApplicationName() != null) {
			donutChartList = this.removeChartData(dashboardDAO.getDonutChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch));
		} else {
			donutChartList = this.removeChartData(dashboardDAO.getDonutChartData(buSearch.getBusinessUnit(),buSearch, buDataList));	
		}
		
		
		return donutChartList;
		
	}
	

	@Override
	public BarChartDataList getBarChartData(BUSearch buSearch, List<BioLOVsData> buDataList) {
		//consider the bar data whose y axis value is > 0 and remove the others
		BarChartDataList barChartList = new BarChartDataList();
		if( buSearch.getEntServiceName() != null && buSearch.getEntServiceName().length()>0) {
			barChartList = this.removeBarData(dashboardDAO.getBarChartData(buSearch));
		} else if( buSearch.getEntityName() != null ) {
			barChartList = this.removeBarData(dashboardDAO.getBarChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch.getEntityName(),buSearch));	
		} else
		if( buSearch.getApplicationName() != null ) {
			barChartList = this.removeBarData(dashboardDAO.getBarChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch));
		} else {
			barChartList = this.removeBarData(dashboardDAO.getBarChartData(buSearch.getBusinessUnit(),buSearch, buDataList));	
		}
		
		
		return barChartList;
	}


	@Override
	public List<ChartData>  getNotificationBarChartData(BUSearch buSearch, List<BioLOVsData> buDataList) {
		
		//consider the chart data whose y axis value is > 0 and remove the others

		List<ChartData> chartList = new ArrayList<ChartData>();
		
		if( buSearch.getEntServiceName() != null && buSearch.getEntServiceName().length()>0) {
			chartList = this.removeChartData(dashboardDAO.getNotificationBarChartData(buSearch));
		} else if( buSearch.getEntityName() != null) {
			chartList = this.removeChartData(dashboardDAO.getNotificationBarChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch.getEntityName(),buSearch));	
		}else if( buSearch.getApplicationName() != null) {
			chartList = this.removeChartData(dashboardDAO.getNotificationBarChartData(buSearch.getBusinessUnit(),buSearch.getApplicationName(),buSearch));
		} else {
			chartList = this.removeChartData(dashboardDAO.getNotificationBarChartData(buSearch.getBusinessUnit(),buSearch, buDataList));	
		}
		
		
		return chartList;
	}
	
	@Override
	//create and save all source and target entities
	public boolean createBUAPP_ES_Info(List<BioBUAppEntServiceEntity> sourceEntityList, List<BioBUAppEntServiceEntity> targetEntityList){
		boolean sourceStatus = false;
		sourceStatus = bioLogBUAPP_ES_InfoRepository.saveAll(sourceEntityList) != null;
		bioLogBUAPP_ES_InfoRepository.flush();
		boolean targetStatus = false;
		targetStatus = bioLogBUAPP_ES_InfoRepository.saveAll(targetEntityList) != null;
		bioLogBUAPP_ES_InfoRepository.flush();
	if( sourceStatus && targetStatus ) {
		return true;
		} else {
			return false;
		}
	}
	
	@Override

	//update and save all source and target entities
	public boolean updateBUAPP_ES_Info(BioLogApplicationData bioLogApplicationData){
		BioBUAppEntServiceEntity sourceDataEntity = null;
		BioBUAppEntServiceEntity targetDataEntity = null;
		List<BioBUAppEntServiceEntity> sourceEntityList = new ArrayList<BioBUAppEntServiceEntity>();
		List<BioBUAppEntServiceEntity> targetEntityList = new ArrayList<BioBUAppEntServiceEntity>();
		try {
			//source list
			for(BioLOVsData data:bioLogApplicationData.getSourceAppList()) {
				if(data.getId() != null && data.getId() != 0 )
				{
					Optional<BioBUAppEntServiceEntity>	sourceDataEntityOptional = bioLogBUAPP_ES_InfoRepository.findById(data.getId());
					sourceDataEntity = sourceDataEntityOptional.get();
					
				} else {
					sourceDataEntity = new BioBUAppEntServiceEntity();
					sourceDataEntity.setAppId(bioLogApplicationData.getAppId());
				}
			
			if ( data.getText() != null && data.getText().length() > 0 ) {
				sourceDataEntity.setBuID(Integer.parseInt(data.getText().substring(data.getText().indexOf(" ")+1,data.getText().length())));
					sourceDataEntity.setApplicationID(Integer.parseInt(data.getText().substring(0, data.getText().indexOf(" "))));
			}
			if( bioLogApplicationData.getEntity() != null && bioLogApplicationData.getEntity() != 0 ) {
				sourceDataEntity.setEntityID(bioLogApplicationData.getEntity());
			}
			if ( bioLogApplicationData.getEnterpriseService() != null && bioLogApplicationData.getEnterpriseService() !=0 ) {
				sourceDataEntity.setEntServiceID(bioLogApplicationData.getEnterpriseService());
			}
			if( data.getType() != null && data.getType().length() > 0) {
				sourceDataEntity.setSourceTargetTypeId(Integer.parseInt(data.getType()));
				sourceDataEntity.setSourceTargetTypeIndicator("S");
			}
			System.out.println("sourceDataEntity:"+sourceDataEntity);
			if(sourceDataEntity.getApplicationID() != null || sourceDataEntity.getBuID() != null || sourceDataEntity.getEntityID() != null || sourceDataEntity.getEntServiceID() !=null) {
				sourceEntityList.add(sourceDataEntity);
			}
			}
			//target list
			for(BioLOVsData data:bioLogApplicationData.getTargetAppList()) {
				if(data.getId() != null && data.getId() != 0 )
				{
					Optional<BioBUAppEntServiceEntity>	targetDataEntityOptional = bioLogBUAPP_ES_InfoRepository.findById(data.getId());
					targetDataEntity = targetDataEntityOptional.get();
					
				} else {
				targetDataEntity = new BioBUAppEntServiceEntity();
				targetDataEntity.setAppId(bioLogApplicationData.getAppId());
				}
				if ( data.getText() != null && data.getText().length() > 0 ) {
					targetDataEntity.setBuID(Integer.parseInt(data.getText().substring(data.getText().indexOf(" ")+1,data.getText().length())));
					targetDataEntity.setApplicationID(Integer.parseInt(data.getText().substring(0, data.getText().indexOf(" "))));
				}
				if( bioLogApplicationData.getEntity() != null && bioLogApplicationData.getEntity() != 0 ) {
					targetDataEntity.setEntityID(bioLogApplicationData.getEntity());
				}
				if (bioLogApplicationData.getEnterpriseService() != null && bioLogApplicationData.getEnterpriseService() !=0 ) {
					targetDataEntity.setEntServiceID(bioLogApplicationData.getEnterpriseService());
				}
				if( data.getType() != null && data.getType().length() > 0) {
					targetDataEntity.setSourceTargetTypeId(Integer.parseInt(data.getType()));
					targetDataEntity.setSourceTargetTypeIndicator("T");
				}
				if(targetDataEntity.getApplicationID() != null || targetDataEntity.getBuID() != null || targetDataEntity.getEntityID() != null || targetDataEntity.getEntServiceID() !=null) {
				targetEntityList.add(targetDataEntity);
			}
				}
			
	} catch(Exception ex) {
		ex.printStackTrace();
	}
		//save source and target list
		boolean sourceStatus = false;
		sourceStatus = bioLogBUAPP_ES_InfoRepository.saveAll(sourceEntityList) != null;
		boolean targetStatus = false;
		targetStatus = bioLogBUAPP_ES_InfoRepository.saveAll(targetEntityList) != null;
		//check is  source and target are successfully saved 
	if( sourceStatus && targetStatus ) {
		return true;
		} else {
			return false;
		}
	}
	
	@Override
	public List<BioBusinessInfoData> getDetailsByAppId(Integer appId) {
		return bioLogBUAPP_ES_InfoRepository.getDetailsByAppId(appId);
	}
	
	@Override
	public List<BioBusinessInfoData> getBU_APPDetails() {
		return bioLogBUAPP_ES_InfoRepository.getBU_APPDetails();
	}

	@Override
	public List<SankeyGraphNode> getSankeyGraphData( List<BioLOVsData> buDataList) {
		
		//search and present the sankey graph for the selected BUIDs
		
		List<SankeyGraphNode> sankeyGraphLst = dashboardDAO.getFullSankeyGrapDataList(buDataList,null);	
				
		 
		return sankeyGraphLst;
	}

	@Override
	public List<SankeyGraphNode> getSankeyGraphData(BUSearch buSearch, List<BioLOVsData> buDataList) {
		
		//search and present the sankey graph for the selected BUIDs and search parameters
		
		List<SankeyGraphNode> sankeyGraphLst = dashboardDAO.getSankeyGraphData(buSearch,buDataList);	
		
		 
		return sankeyGraphLst;
	}

}
