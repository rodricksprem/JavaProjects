package com.biogen.eisutil.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;

import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.repo.BioLogIntegrationDetailsRepository;
import com.biogen.eisutil.service.BioAppDocHistoryService;

@Service("BioAppDocHistoryService")
public class BioAppDocHistoryServiceImpl implements BioAppDocHistoryService {
	
	@Autowired
	BioLogIntegrationDetailsRepository bioLogIntegrationDetailsRepository;

	

	@Override
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetails() {
		return bioLogIntegrationDetailsRepository.getAllBioAppDocHistoryDetails();
	}

	@Override
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetailsByAppId(Integer appId) {
		return bioLogIntegrationDetailsRepository.getAllBioAppDocHistoryDetailsByAppId(appId);
	}
	
	@Override
	public List<BioAppDocHistoryTemp> getInterfaceDetails(BUSearch buSearch) {
	
		return bioLogIntegrationDetailsRepository.getInterfaceDetails(buSearch);
		
		
	}

	@Override
	public BioLogIntegrationDetailsEntity createIntegrationDetails(BioLogIntegrationDetailsEntity data) {
		return bioLogIntegrationDetailsRepository.save(data);	
	}
}
