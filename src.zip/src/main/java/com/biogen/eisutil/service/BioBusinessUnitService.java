package com.biogen.eisutil.service;

import java.util.List;

import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.BioDefaultLOVs;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogBUApplicationEntity;
import com.biogen.eisutil.dao.BioLogBusinessUnitEntity;
import com.biogen.eisutil.dao.BioLogEnterpriseServiceEntity;
import com.biogen.eisutil.dao.BioLogEntity;
import com.biogen.eisutil.dao.BioLogIntegrationPatternEntity;
import com.biogen.eisutil.dao.BioLogSourceTargetEntity;

public interface BioBusinessUnitService {
	
	public List<Integer> getAppIdList(String buSearchParam);
	
	public List<String> getBUnit();
	public Integer getBUnit(String bunitName);
	public List<String> getAppNameByBUnit(String bunit);
	
	public List<String> getEntityNameByBUnitAndAppName(String bunit, String appName);
	
	public List<String> getESNameByBUnitAndAppNameAndEntityName(String bunit, String appName, String entityname);

	public List<AppNameTemp> getInterfaceNameByAppName(String bunit, String appName, String entity);
	

	public BioDefaultLOVs getInterfaceServiceDetails();
	
	public boolean createEntity(BioLogEntity bioLogEntity);
	
	public boolean createEnterPriseService(BioLogEnterpriseServiceEntity data);
	
	public List<BioLOVsData> getEntityDetails();
	
	public List<BioLOVsData> getEnterpriseDetails();
	
	public List<BioLOVsData> getIntegrationPatternDetails();
	
	public List<BioLOVsData> getBUDetails();
	
	public BioLogIntegrationPatternEntity createIntegrationPattern(BioLogIntegrationPatternEntity data);
	
	public boolean createSourceType(BioLogSourceTargetEntity data);
	
	public boolean createNewApplication(BioLogBUApplicationEntity data);
	
	
	public List<BioLOVsData> getSourceTypeDetails(String type);
	
	public List<BioLOVsData> getBUApplicationDetails();
	
	public BioLogBusinessUnitEntity createBusinessUnit(BioLogBusinessUnitEntity data);

	public List<BioLOVsData> getAppNameByBUnit(Integer buId);
	
	public List<BioLOVsData> getEntityDetailsByApplicationId(Integer applicatinId);
	public List<BioLOVsData> getESDetailsByEntityId(Integer entityId);
}
