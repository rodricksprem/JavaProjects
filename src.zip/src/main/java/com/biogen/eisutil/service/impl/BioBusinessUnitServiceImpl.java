package com.biogen.eisutil.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.BioDefaultLOVs;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.dao.BioLogBUApplicationEntity;
import com.biogen.eisutil.dao.BioLogBusinessUnitEntity;
import com.biogen.eisutil.dao.BioLogEnterpriseServiceEntity;
import com.biogen.eisutil.dao.BioLogEntity;
import com.biogen.eisutil.dao.BioLogIntegrationPatternEntity;
import com.biogen.eisutil.dao.BioLogSourceTargetEntity;
import com.biogen.eisutil.repo.BioBUApplicationRepository;
import com.biogen.eisutil.repo.BioLogApplicationRepository;
import com.biogen.eisutil.repo.BioLogBusinessUnitRepository;
import com.biogen.eisutil.repo.BioLogEnterpriseServiceRepository;
import com.biogen.eisutil.repo.BioLogEntityRepository;
import com.biogen.eisutil.repo.BioLogIntegrationPatternRepository;
import com.biogen.eisutil.repo.BioLogSourceTargetRepository;
import com.biogen.eisutil.service.BioBusinessUnitService;

@Service("BioBusinessUnitService")
public class BioBusinessUnitServiceImpl implements BioBusinessUnitService{
	
	
	@Autowired
	private BioLogApplicationRepository bioLogApplicationRepository;
	
	@Autowired
	private BioLogEntityRepository bioLogEntityRepository; 
	
	@Autowired
	private BioLogEnterpriseServiceRepository bioLogEnterpriseServiceRepository;
	
	@Autowired
	BioLogIntegrationPatternRepository bioLogIntegrationPatternRepository;
	
	@Autowired
	BioBUApplicationRepository bioBUApplicationRepository;
	
	@Autowired
	BioLogBusinessUnitRepository bioLogBusinessUnitRepository;
	
	@Autowired
	BioLogSourceTargetRepository bioLogSourceTargetRepository;
	
	@Override
	public List<Integer> getAppIdList(String buSearchParam) {
		return bioBUApplicationRepository.getAppIdList(buSearchParam);
	}

	@Override
	public List<String> getAppNameByBUnit(String bunit) {
		return bioBUApplicationRepository.getAppNameByBUnit(bunit);
	}
	@Override
	public List<BioLOVsData> getEntityDetailsByApplicationId(Integer applicatinId) {
		return bioBUApplicationRepository.getEntityDetailsByApplicationId(applicatinId);
	}
	
	@Override
	public List<BioLOVsData> getESDetailsByEntityId(Integer entityId) {
		return bioBUApplicationRepository.getEnterpriseServiceDetails(entityId);
	}
	
	@Override
	public List<String> getEntityNameByBUnitAndAppName(String bunit, String appName) {
		return bioBUApplicationRepository.getEntityNameByBUnitAndAppName(bunit, appName);
	}
	
	@Override
	public List<BioLOVsData> getAppNameByBUnit(Integer buId) {
		return bioBUApplicationRepository.getApplicationDetailsByBUId(buId);
	}

	@Override
	public List<String> getESNameByBUnitAndAppNameAndEntityName(String bunit, String appName, String entityname) {
		return bioBUApplicationRepository.getESNameByBUnitAndAppNameAndEntityName(bunit, appName, entityname);
	}
	
	
	@Override
	public List<AppNameTemp> getInterfaceNameByAppName(String bunit, String appName, String entity){
		return bioLogApplicationRepository.getInterfaceNameByAppName(bunit, appName, entity);

	}
	
	@Override
	public List<String> getBUnit() {
		return bioBUApplicationRepository.getBUnit();
	}
	
	@Override
	public Integer getBUnit(String bunitName) {
		return bioBUApplicationRepository.getBUnit(bunitName);
	}
	
	@Override
	public List<BioLOVsData> getEntityDetails() {
	
		return bioBUApplicationRepository.getEntityDetails();
		
	}
	
	@Override
	public List<BioLOVsData> getBUDetails() {
	
		return bioBUApplicationRepository.getBUDetails();
		
	}
	
	@Override
	public List<BioLOVsData> getEnterpriseDetails(){
		return bioBUApplicationRepository.getEnterpriseServiceDetails();	
	}
	
	@Override
	public List<BioLOVsData> getIntegrationPatternDetails(){
		return bioBUApplicationRepository.getPatternDetails();	
	}
	
	@Override
	public List<BioLOVsData> getSourceTypeDetails(String type){
		return bioBUApplicationRepository.getSourceTargetTypeDetails();	
	}
	
	@Override
	public List<BioLOVsData> getBUApplicationDetails(){
		return bioBUApplicationRepository.getApplicationDetails();
	}
	
	@Override
	public BioDefaultLOVs getInterfaceServiceDetails() {
		//generate Model Object from Entity and return it
		BioDefaultLOVs defaultVal = new BioDefaultLOVs();
		
		defaultVal.setBuList(bioBUApplicationRepository.getBUDetails());
		defaultVal.setApplicationList(bioBUApplicationRepository.getApplicationDetails());
		defaultVal.setEntityList(bioBUApplicationRepository.getEntityDetails());
		defaultVal.setEsList(bioBUApplicationRepository.getEnterpriseServiceDetails());
		defaultVal.setPatternList(bioBUApplicationRepository.getPatternDetails());
		defaultVal.setSourceTargetTypeList(bioBUApplicationRepository.getSourceTargetTypeDetails());
		defaultVal.setBuAssociationList(bioLogBusinessUnitRepository.getBU_APPDetails());
		return defaultVal;
	}
	@Override
	public boolean createEntity(BioLogEntity bioLogEntity) {
		
		return bioLogEntityRepository.save(bioLogEntity) != null;
	}
	@Override
	public boolean createEnterPriseService(BioLogEnterpriseServiceEntity data) {
		return bioLogEnterpriseServiceRepository.save(data) != null;
	}
	@Override
	public BioLogIntegrationPatternEntity createIntegrationPattern(BioLogIntegrationPatternEntity data) {

		return this.bioLogIntegrationPatternRepository.save(data);
		
	}
	@Override
	public boolean createSourceType(BioLogSourceTargetEntity data) {
		return this.bioLogSourceTargetRepository.save(data) != null;
	}
	@Override
	public boolean createNewApplication(BioLogBUApplicationEntity data) {
		return this.bioBUApplicationRepository.save(data) != null;
	}
	@Override
	public BioLogBusinessUnitEntity createBusinessUnit(BioLogBusinessUnitEntity data) {
		return this.bioLogBusinessUnitRepository.save(data) ;
	}
	
}
