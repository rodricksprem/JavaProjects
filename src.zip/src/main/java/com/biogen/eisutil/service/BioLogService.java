package com.biogen.eisutil.service;

import java.math.BigDecimal;
import java.util.List;

import com.biogen.eisutil.model.BioLogSearch;
import com.biogen.eisutil.model.BioLogTemp;

public interface BioLogService {
	
	public List<BioLogTemp> getLogDetailsByList();
	 List<BioLogTemp> getLogDetailsByList(Integer duration);
	public List<Object[]> getLogDetails();
	public List<BioLogTemp> getLogDetailsByBUSearch(String buSearchParams, Integer duration);
	public List<String> getKeyValueDetails(String bioTransactionId);
	
	public List<String> getKeyValueDetails(String bioTransactionId, String keyValueDetails);
	
	public List<Object[]> getLogDetailsByAdvancedSearch(String adSearchParams);
	
	public List<Object[]> getLogDetailsByBusinessUnitSearch(String buSearchParams,Integer duration);
	
	public List<String> getKey();
	
	public List<String> getKeyByAppName(String appName);
	
	public List<Object[]> getDetailedLogDetails(String bioTransId);
	
    public List<Object[]> getDetailedTargetSystemLogDetails(String bioTransId, int bioLogTargetSystemId);
	
	public List<BigDecimal> getBioLogTargetSystemIdByBioTransId(String bioTransId);
	
	public List<BioLogTemp> getLogDetailsByAdvSearch(BioLogSearch bioLogSearch);
	
}
