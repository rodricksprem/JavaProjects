package com.biogen.eisutil.service.impl;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biogen.eisutil.dao.BioLogAppGroup;
import com.biogen.eisutil.repo.BioLogAppGroupRepository;
import com.biogen.eisutil.service.BioLogAppGroupService;

@Service("BioLogAppGroupService")
public class BioLogAppGroupServiceImpl implements BioLogAppGroupService{
	
	@Autowired
	private BioLogAppGroupRepository bioLogAppGroupRepository;
	
	@Override
	public Optional<BioLogAppGroup> getBioLogAppgroupById(Integer id) {
		return bioLogAppGroupRepository.findById(id);
	}
}
