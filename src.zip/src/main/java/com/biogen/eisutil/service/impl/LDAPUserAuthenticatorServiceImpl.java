package com.biogen.eisutil.service.impl;

import org.springframework.stereotype.Service;

import com.biogen.eisutil.dao.BioLogUser;
import com.biogen.eisutil.service.LDAPUserAuthenticatorService;

@Service("LDAPUserAuthenticatorService")
public class LDAPUserAuthenticatorServiceImpl implements LDAPUserAuthenticatorService{
	
	@Override
	public boolean isValidUser(BioLogUser user) {
		System.out.println("----LDAPUserAuthenticatorServiceImpl.isValidUser-------");
		return true;
	}
}
