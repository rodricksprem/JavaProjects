package com.biogen.eisutil.service;

import java.util.Optional;
import com.biogen.eisutil.dao.BioLogAppGroup;

public interface BioLogAppGroupService {
	
	public Optional<BioLogAppGroup> getBioLogAppgroupById(Integer id);

}
