package com.biogen.eisutil.service;

import java.util.List;
import java.util.Optional;

import com.biogen.eisutil.dao.User;

public interface UserService {
	
	public List<User> getUsers();
	
	public Optional<User> getUserById(Integer id);
	
	public boolean deleteUser(Integer id);
	
	public User createUser(User user);
	
	public User updateUser(User user);
	

}
