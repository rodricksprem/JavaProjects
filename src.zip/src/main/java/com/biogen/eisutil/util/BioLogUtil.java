package com.biogen.eisutil.util;

import java.util.stream.Collectors;

import com.biogen.eisutil.model.BioLogSearch;

public class BioLogUtil {
	
	public static String getBioLogDetailsWhereClause(BioLogSearch bioLogSearchParams)
	{
		String whereClause = "" ;
		
		if(bioLogSearchParams.getBioTransId() != null && !bioLogSearchParams.getBioTransId().isEmpty() && bioLogSearchParams.getBioTransId().trim() != "")
		{
			whereClause = "BLM.biogenTransId='"+bioLogSearchParams.getBioTransId()+"'";
		} else {
		
		if(bioLogSearchParams.getAppGroup() != null && !bioLogSearchParams.getAppGroup().isEmpty() && bioLogSearchParams.getAppGroup().trim() != "")
		{
			whereClause = "BLAG.appGroup='"+bioLogSearchParams.getAppGroup()+"'";
		}
		
		if(bioLogSearchParams.getAppName() != null && !bioLogSearchParams.getAppName().isEmpty() && bioLogSearchParams.getAppName().trim() != "")
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BLA.appName='"+bioLogSearchParams.getAppName()+"'";
			}
			else
			{
				whereClause = whereClause + " AND " + "BLA.appName='"+bioLogSearchParams.getAppName()+"'";
			}
		}
		
		
		if(bioLogSearchParams.getStatus() != null && bioLogSearchParams.getStatus().size()>0)
		{
			String serviceStatus= bioLogSearchParams.getStatus().stream().collect(Collectors.joining("','"));
			
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BLM.serviceStatus IN ('"+serviceStatus+"')";
			}
			else
			{
				whereClause = whereClause + " AND " + "BLM.serviceStatus IN ('"+serviceStatus+"')";
			}
		}
		
		if(bioLogSearchParams.getPeriod() != null && !bioLogSearchParams.getPeriod().isEmpty() && bioLogSearchParams.getPeriod().trim() != "")
		{
			
			try
			{
				if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
				{
					whereClause = "TRUNC(BLM.serviceStartTime) <= TRUNC(SYSDATE) AND TRUNC(BLM.serviceStartTime) > TRUNC(SYSDATE)-"+Integer.parseInt(bioLogSearchParams.getPeriod().trim());
				}
				else
				{
					whereClause = whereClause + " AND " + "TRUNC(BLM.serviceStartTime) <= TRUNC(SYSDATE) AND TRUNC(BLM.serviceStartTime) > TRUNC(SYSDATE)-"+Integer.parseInt(bioLogSearchParams.getPeriod().trim());
				}
			}
			catch(Exception exp)
			{
				System.out.println("BioLogUtil.getBioLogDetailsWhereClause() exp : "+exp);
				return whereClause;
			}
		}
		
		if(bioLogSearchParams.getStartDate() != null && !bioLogSearchParams.getStartDate().isEmpty() && bioLogSearchParams.getStartDate().trim() != "")
		{
			String startDate = bioLogSearchParams.getStartDate().trim().replace("T", " ");
			startDate = startDate.substring(0, startDate.length()-5);
			
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "cast(BLM.serviceStartTime as timestamp) >= TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
			else
			{
				whereClause = whereClause + " AND " + "cast(BLM.serviceStartTime as timestamp) >= TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
		}
		
		if(bioLogSearchParams.getEndDate() != null && !bioLogSearchParams.getEndDate().isEmpty() && bioLogSearchParams.getEndDate().trim() != "")
		{
			String endDate = bioLogSearchParams.getEndDate().trim().replace("T", " ");
			endDate = endDate.substring(0, endDate.length()-5);
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "cast(BLM.serviceStartTime as timestamp) <= TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
			else
			{
				whereClause = whereClause + " AND " + "cast(BLM.serviceStartTime as timestamp) <= TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
		}
		}
		return whereClause;
	}
	
	public static String getKeyValueDetails(BioLogSearch bioLogSearchParams)
	{
		String keyValueDetails = null;
		
		if(bioLogSearchParams.getKey() != null && !bioLogSearchParams.getKey().isEmpty() && bioLogSearchParams.getKey().trim() != "")
		{
			keyValueDetails = "KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE)=UPPER('"+bioLogSearchParams.getValue().trim()+"')";
		}
		
		return keyValueDetails;
	}
}
