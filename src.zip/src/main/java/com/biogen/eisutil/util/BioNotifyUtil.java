package com.biogen.eisutil.util;

import com.biogen.eisutil.model.BioNotifySearch;

public class BioNotifyUtil {
	
	public static String getBioNotifyDetailsWhereClause(BioNotifySearch bioNotifySearch)
	{
		String whereClause = null;
		if(bioNotifySearch.getBioTransId() != null && !bioNotifySearch.getBioTransId().isEmpty() && bioNotifySearch.getBioTransId().trim() != "")
		{
			whereClause = "BNH.bioGenTransId='"+bioNotifySearch.getBioTransId()+"'";
		}
		
		if(bioNotifySearch.getAppGroup() != null && !bioNotifySearch.getAppGroup().isEmpty() && bioNotifySearch.getAppGroup().trim() != "")
		{
			whereClause = "BLAG.appGroup='"+bioNotifySearch.getAppGroup()+"'";
		}
		
		if(bioNotifySearch.getAppName() != null && !bioNotifySearch.getAppName().isEmpty() && bioNotifySearch.getAppName().trim() != "")
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BLA.appName='"+bioNotifySearch.getAppName()+"'";
			}
			else
			{
				whereClause = whereClause + " AND " + "BLA.appName='"+bioNotifySearch.getAppName()+"'";
			}
		}
		
		if(bioNotifySearch.getStatus() != null && !bioNotifySearch.getStatus().isEmpty() && bioNotifySearch.getStatus().trim() != "")
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BNH.status='"+bioNotifySearch.getStatus()+"'";
			}
			else
			{
				whereClause = whereClause + " AND " + "BNH.status='"+bioNotifySearch.getStatus()+"'";
			}
		}
		
		if(bioNotifySearch.getExCategory() != null && !bioNotifySearch.getExCategory().isEmpty() && bioNotifySearch.getExCategory().trim() != "")
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BN.exCategory='"+bioNotifySearch.getExCategory()+"'";
			}
			else
			{
				whereClause = whereClause + " AND " + "BN.exCategory='"+bioNotifySearch.getExCategory()+"'";
			}
		}
		
		if(bioNotifySearch.getExType() != null && !bioNotifySearch.getExType().isEmpty() && bioNotifySearch.getExType().trim() != "")
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "BN.exType='"+bioNotifySearch.getExType()+"'";
			}
			else
			{
				whereClause = whereClause + " AND " + "BN.exType='"+bioNotifySearch.getExType()+"'";
			}
		}
		
		if(bioNotifySearch.getCreatedDate() != null && !bioNotifySearch.getCreatedDate().isEmpty() && bioNotifySearch.getCreatedDate().trim() != "")
		{
			String startDate = bioNotifySearch.getCreatedDate().trim().replace("T", " ");
			startDate = startDate.substring(0, startDate.length()-5);
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "TRUNC(BNH.createdDate) >= TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
			else
			{
				whereClause = whereClause + " AND " + "TRUNC(BNH.createdDate) >= TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
			}
		}
		
		if(bioNotifySearch.getUpdatedDate() != null && !bioNotifySearch.getUpdatedDate().isEmpty() && bioNotifySearch.getUpdatedDate().trim() != "")
		{
			String endDate = bioNotifySearch.getUpdatedDate().trim().replace("T", " ");
			endDate = endDate.substring(0, endDate.length()-5);
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "TRUNC(BNH.createdDate) <= TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')"; 
			}
			else
			{
				whereClause = whereClause + " AND " + "TRUNC(BNH.createdDate) <= TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')"; 
			}
		}
		
		return whereClause;
	}

}
