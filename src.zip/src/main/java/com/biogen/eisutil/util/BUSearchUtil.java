package com.biogen.eisutil.util;

import com.biogen.eisutil.model.BUSearch;

public class BUSearchUtil {
	
	public static String getBUSearchWhereClause(BUSearch buSearch)
	{
		String whereClause = null;
		
		if(buSearch.getBusinessUnit() != null && !buSearch.getBusinessUnit().isEmpty())
		{
			whereClause = "BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+"";
		}
		
		if(buSearch.getApplicationName() != null && !buSearch.getApplicationName().isEmpty())
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "application_id="+Integer.parseInt(buSearch.getApplicationName())+"";
			}
			else
			{
				whereClause = whereClause + " AND " + "application_id="+Integer.parseInt(buSearch.getApplicationName())+"";
			}
		}
		
		if(buSearch.getEntityName() != null && !buSearch.getEntityName().isEmpty())
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "entity_id="+Integer.parseInt(buSearch.getEntityName())+"";
			}
			else
			{
				whereClause = whereClause + " AND " + "entity_id="+Integer.parseInt(buSearch.getEntityName())+"";
			}
		}
		
		if(buSearch.getEntServiceName() != null && !buSearch.getEntServiceName().isEmpty())
		{
			if(whereClause == null || whereClause.isEmpty() || whereClause.trim() == "")
			{
				whereClause = "es_id="+Integer.parseInt(buSearch.getEntServiceName())+"";
			}
			else
			{
				whereClause = whereClause + " AND " + "es_id="+Integer.parseInt(buSearch.getEntServiceName())+"";
			}
		}
		
		return whereClause;
	}

}
