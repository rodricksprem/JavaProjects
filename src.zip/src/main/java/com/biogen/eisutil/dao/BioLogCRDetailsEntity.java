package com.biogen.eisutil.dao;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_CR_DETAILS")
@Getter
@Setter
public class BioLogCRDetailsEntity  extends Auditable<String>{

	@Override
	public String toString() {
		return "BioLogCRDetailsEntity [crID=" + crID + ", appIntegrationID=" + appIntegrationID + ", crNumber=" + crNumber
				+ ", crDescription=" + crDescription + ", implementationDate=" + implementationDate + ", comments=" + comments + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_CR_DETAILS_SEQ")
	@Column(name="CR_DETAILS_ID")
	private Integer crID;
	
	@Column(name="APP_INTEGRATION_ID")
	private Integer appIntegrationID;
	
	@Column(name="CR_NUMBER")
	private String crNumber;
	
	@Column(name="CR_DESCRIPTION")
	private String crDescription;
	
	@Column(name="IMPLEMENTATION_DATE")
	private Timestamp implementationDate;
	
	@Column(name="COMMENTS")
	private String comments;
	}
