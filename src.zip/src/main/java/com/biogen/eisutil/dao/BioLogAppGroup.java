package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_APP_GROUP")
@Getter
@Setter

public class BioLogAppGroup extends Auditable<String> {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "LOG_APPGROUP_ROWID")
	@Column(name="APP_GROUP_ID")
	private Integer appGroupId;
	
	@Column(name="APP_GROUP")
	private String appGroup;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	
}
