package com.biogen.eisutil.dao;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import java.sql.Timestamp;
import java.util.Date;


@Getter(AccessLevel.PROTECTED)
@Setter(AccessLevel.PROTECTED)
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public class Auditable<U>
{
    @CreatedBy
    @Column(name = "CREATED_BY")
    private U createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    private Timestamp createdDate;

    @LastModifiedBy
    @Column(name = "UPDATED_BY")
    private U lastModifiedBy;

    @LastModifiedDate
    @Column(name = "UPDATED_DATE")
    private Timestamp lastModifiedDate;

}
/*
@Column(name="CREATED_BY")
private String createdBy;

@Column(name="CREATED_DATE")
private Timestamp createdDate;

@Column(name="UPDATED_BY")
private String updatedBy;

@Column(name="UPDATED_DATE")
private Timestamp updatedDate;
*/