package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_INFO_ATTRIBUTES")
@Getter
@Setter
public class BioLogInfoAttributes  extends Auditable<String> {

	@Id
	@GeneratedValue
	@Column(name="ID")
	private Integer id;
	
	@Column(name="BIOGENTRANSID")
	private String biogenTransId;
	
	@Column(name="BIO_LOG_DETAIL_ID")
	private Integer bioLogDetailId;
	
	@Column(name="KEY")
	private String key;
	
	@Column(name="VALUE")
	private String value;
	
}
