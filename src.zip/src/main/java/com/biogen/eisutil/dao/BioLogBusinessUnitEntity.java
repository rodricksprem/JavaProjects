package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_businessunit")
@Getter
@Setter
public class BioLogBusinessUnitEntity  extends Auditable<String> {

	@Override
	public String toString() {
		return "BioLogBusinessUnitEntity [buID=" + buID + ", buName=" + buName + ", buStatus=" + buStatus
				+ ", buDescription=" + buDescription + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_BUSINESS_UNIT_SEQ")
	@Column(name="BU_ID")
	private Integer buID;
	
	@Column(name="BU_NAME")
	private String buName;
	
	@Column(name="BU_STATUS")
	private String buStatus;
	
	@Column(name="BU_Description")
	private String buDescription;
	}
