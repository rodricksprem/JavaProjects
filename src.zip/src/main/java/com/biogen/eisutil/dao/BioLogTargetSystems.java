package com.biogen.eisutil.dao;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_TARGET_SYSTEMS")
@Getter
@Setter
public class BioLogTargetSystems  extends Auditable<String>{

	@Id
	@GeneratedValue
	@Column(name="ID")
	private Integer id;
	
	@Column(name="BIOGENTRANSID")
	private String biogenTransId;
	
	@Column(name="TARGET_SYSTEM_NAME")
	private String targetSystemName;
	
	@Column(name="TARGET_SERVICE_STATUS")
	private String targetServiceStatus;
	
	@Column(name="TARGET_SERVICE_START_TIME")
	private Timestamp targetServiceStartTime;
	
	@Column(name="TARGET_SERVICE_END_TIME")
	private Timestamp targetServiceEndTime;
	

}
