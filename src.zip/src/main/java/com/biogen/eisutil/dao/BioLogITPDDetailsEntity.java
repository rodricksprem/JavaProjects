package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_ITPD_DETAILS")
@Getter
@Setter
public class BioLogITPDDetailsEntity  extends Auditable<String> {

	@Override
	public String toString() {
		return "BioLogITPDDetailsEntity [itpdID=" + itpdID + ", appIntegrationID=" + appIntegrationID + ", itpdNumber=" + itpdNumber
				+ ", itpdDescription=" + itpdDescription +  "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_ITPD_DETAILS_SEQ")
	@Column(name="ITPD_DETAILS_ID")
	private Integer itpdID;
	
	@Column(name="APP_INTEGRATION_ID")
	private Integer appIntegrationID;
	
	@Column(name="ITPD_NUMBER")
	private String itpdNumber;
	
	@Column(name="ITPD_DESCRIPTION")
	private String itpdDescription;
	}
