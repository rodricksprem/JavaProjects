package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_ETM_BU_APP_ES_INFO")
@Getter
@Setter

public class BioBUAppEntServiceEntity extends Auditable<String>{
	
	@Override
	public String toString() {
		return "BioBUAppEntServiceEntity [id=" + id + ", BU_ID=" + buID + ", applicationID=" + applicationID
				+ ", entityID=" + entityID + ", entServiceID=" + entServiceID + ", appId=" + appId + ",sourceTargetTypeId="+sourceTargetTypeId+","
						+ ",sourceTargetTypeIndicator="+sourceTargetTypeIndicator+ "]";
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_BU_APP_ES_INFO_SEQ")
	@Column(name="BU_APP_ES_ID")
	private Integer id;
	
	@Column(name="BU_ID")
	private Integer buID;
	
	@Column(name="APPLICATION_ID")
	private Integer applicationID;
	
	@Column(name="ENTITY_ID")
	private Integer entityID;
	
	@Column(name="ES_ID")
	private Integer entServiceID;
	
	@Column(name="APP_ID")
	private Integer appId;
	
	@Column(name="SOURCE_TARGET_TYPE_ID")
	private Integer sourceTargetTypeId;
	
	@Column(name="SOURCE_TARGET_TYPE_INDICATOR")
	private String sourceTargetTypeIndicator;
	
	
}
