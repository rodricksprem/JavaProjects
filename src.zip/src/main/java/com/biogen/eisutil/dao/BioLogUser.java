package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_USER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BioLogUser  extends Auditable<String>{
	
	@Id
    @Column(name="USER_ID")
	private String userId;
	
	@Column(name="USER_TYPE")
	private Integer userType;
	
	@Column(name="EMAIL_ID")
	private String emailID;
	
	@Column(name="FIRST_NAME")
	private String firstName;
	
	@Column(name="LAST_NAME")
	private String lastName;
	
	@Column(name="PASSWORD")
	private String password;
	
	
	@Override
	public String toString() {
		return "BioLogUser [userId=" + userId + ", userType=" + userType + ", emailID=" + emailID + ", firstName="
				+ firstName + ", lastName=" + lastName + ",password=" + password +"]";
	}
	
	
	
}
