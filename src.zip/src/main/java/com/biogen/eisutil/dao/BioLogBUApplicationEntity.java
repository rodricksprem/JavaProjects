package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_application")
@Getter
@Setter
public class BioLogBUApplicationEntity   extends Auditable<String>{

	@Override
	public String toString() {
		return "BioLogBUApplicationEntity [applicationID=" + applicationID + ", applicationName=" + applicationName + ", applicationStatus=" + applicationStatus
				+ ", applicationDescription=" + applicationDescription + " , buId="+buId+"]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_BU_APPLICATION_SEQ")
	@Column(name="APPLICATION_ID")
	private Integer applicationID;
	
	@Column(name="APPLICATION_NAME")
	private String applicationName;
	
	@Column(name="APPLICATION_STATUS")
	private String applicationStatus;
	
	@Column(name="APPLICATION_Description")
	private String applicationDescription;
	
	@Column(name="BU_ID")
	private Integer buId;
	}
