package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_NOTIFY_HISTORY")
@Getter
@Setter
public class BioNotifyHistory  extends Auditable<String> {
	
	@Id
	@GeneratedValue
    @Column(name="ID")
	private Integer id;
	
	@Column(name="BIOGENTRANSID")
	private String bioGenTransId;
	
	@Column(name="NOTIFY_ID")
	private Integer notifyId;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="RETRY_COUNT")
	private Integer retryCount;
	
	@Column(name="MESSAGE")
	private String message;
	
	
}
