package com.biogen.eisutil.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_USER_TYPE")
@Getter
@Setter
public class BioLogUserType  extends Auditable<String>{
	
	@Id
    @Column(name="USER_TYPE_ID")
	private Integer userTypeId;
	
	@Column(name="USER_TYPE")
	private String userType;
	
	@Column(name="DESCRIPTION")
	private String description;
	
}
