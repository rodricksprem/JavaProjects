package com.biogen.eisutil.dao;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "USERDETAILS")
@Getter
@Setter
@NoArgsConstructor
public class User{
	
	@Id
	
	private Integer id;
	private String fname;
	private String lname;
	
	
	public User(String fname, String lname) {
		this.fname = fname;
		this.lname = lname;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", fname=" + fname + ", lname=" + lname + "]";
	}
}
