package com.biogen.eisutil.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_NOTIFY")
@Getter
@Setter
public class BioNotify  extends Auditable<String>{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_NOTIFY_SEQ")
    @Column(name="ID")
	private Integer id;
	
	@Column(name="APP_ID")
	private Integer appId;
	
	@Column(name="EX_CATEGORY")
	private String exCategory;
	
	@Column(name="EX_TYPE")
	private String exType;

}
