package com.biogen.eisutil.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_LOGLEVEL")
@Getter
@Setter
public class BioLogLevel  extends Auditable<String>{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "LOG_LOGLEVEL_ROWID")
	@Column(name="LOGGER_ID")
	private Integer loggerId;
	
	@Column(name="LOGGER_LEVEL")
	private String loggerLevel;
	
	@Column(name="DESCRIPTION")
	private String description;
	

}
