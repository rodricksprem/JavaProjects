package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_SourceTargetType")
@Getter
@Setter
public class BioLogSourceTargetEntity  extends Auditable<String> {

	@Override
	public String toString() {
		return "BioLogSourceTargetEntity [ID=" + ID + ", sourceTargetName=" + sourceTargetName +", sourceTargetStatus=" + sourceTargetStatus
				+ ", sourceTargetDescription=" + sourceTargetDescription + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_SOURCE_TARGET_TYPE_SEQ")
	@Column(name="SOURCE_TARGET_TYPE_ID")
	private Integer ID;
	
	@Column(name="SOURCE_TARGET_NAME")
	private String sourceTargetName;
	
	@Column(name="SOURCE_TARGET_STATUS")
	private String sourceTargetStatus;
	
	@Column(name="SOURCE_TARGET_Description")
	private String sourceTargetDescription;
	
}
