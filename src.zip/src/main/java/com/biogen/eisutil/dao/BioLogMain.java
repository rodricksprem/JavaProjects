package com.biogen.eisutil.dao;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_MAIN")
@Getter
@Setter
public class BioLogMain  extends Auditable<String>{

	@Id
	@Column(name="BIOGENTRANSID")
	private String biogenTransId;
	
	@Column(name="APP_ID")
	private Integer appId;
	
	@Column(name="SERVICE_INVOKER")
	private String serviceInvoker;
	
	@Column(name="SERVICE_STATUS")
	private String serviceStatus;
	
	@Column(name="SERVICE_START_TIME")
	private Timestamp serviceStartTime;
	
	@Column(name="SERVICE_END_TIME")
	private Timestamp serviceEndTime;
	
}
