package com.biogen.eisutil.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_enterpriseservice")
@Getter
@Setter
public class BioLogEnterpriseServiceEntity  extends Auditable<String>{

	@Override
	public String toString() {
		return "BioLogEnterpriseServiceEntity [esID=" + esID + ", esName=" + esName + ", esStatus=" + esStatus
				+ ", esDescription=" + esDescription +  "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_ENTERPRISE_SERVICE_SEQ")
	@Column(name="ES_ID")
	private Integer esID;
	
	@Column(name="ES_NAME")
	private String esName;
	
	@Column(name="ES_STATUS")
	private String esStatus;
	
	@Column(name="ES_Description")
	private String esDescription;
	

	


}
