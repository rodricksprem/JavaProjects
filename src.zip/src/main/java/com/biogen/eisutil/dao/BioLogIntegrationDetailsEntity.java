package com.biogen.eisutil.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_APP_INTEGRATION_DETAILS")
@Getter
@Setter
public class BioLogIntegrationDetailsEntity  extends Auditable<String>{

	@Override
	public String toString() {
		return "BioLogIntegrationDetailsEntity [appIntegrationID=" + appIntegrationID + ", appID=" + appID + ", patternID=" + patternID
				+ ", fileID=" + fileID + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_INTEGRATION_DETAIL_SEQ")
	@Column(name="APP_INTEGRATION_ID")
	private Integer appIntegrationID;
	
	@Column(name="APP_ID")
	private Integer appID;
	
	@Column(name="PATTERN_ID")
	private Integer patternID;
	
	@Column(name="FILE_ID")
	private Integer fileID;
	



}
