package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_APP_TYPE")
@Getter
@Setter
public class BioLogAppType  extends Auditable<String> {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "LOG_APPTYPE_ROWID")
	@Column(name="APP_TYPE_ID")
	private Integer appTypeId;
	
	@Column(name="APP_TYPE")
	private String appType;
	
	@Column(name="DESCRIPTION")
	private String description;
	
}
