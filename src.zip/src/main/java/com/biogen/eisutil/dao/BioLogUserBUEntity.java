package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_ETM_USERBU_LINK")
@Getter
@Setter
public class BioLogUserBUEntity{

	@Override
	public String toString() {
		return "BioLogEntity [userBUID=" + userBUID + ", userId=" + userId + ", buID=" + buID +",status="+status
				+ "]";
	}

	@Id
	@Column(name="USER_BU_ID")
	private Integer userBUID;
	
	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="BU_ID")
	private Integer buID;

	@Column(name="STATUS")
	private Integer status;
	

}
