package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BIO_LOG_APPLICATION")
@Getter
@Setter
public class BioLogApplication  extends Auditable<String>{

	@Override
	public String toString() {
		return "BioLogApplication [appId=" + appId + ", appName=" + appName + ", appTypeId=" + appTypeId
				+ ", appGroupId=" + appGroupId + ", loggerId=" + loggerId + ", appDesc=" + appDesc + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "LOG_APPLICATION_ROWID")
	@Column(name="APP_ID")
	private Integer appId;
	
	@Column(name="APP_NAME")
	private String appName;
	
	@Column(name="APP_TYPE_ID")
	private Integer appTypeId;
	
	@Column(name="APP_GROUP_ID")
	private Integer appGroupId;
	
	@Column(name="LOGGER_ID")
	private Integer loggerId;
	
	@Column(name="APP_DESC")
	private String appDesc;
}
