package com.biogen.eisutil.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bio_etm_entity")
@Getter
@Setter
public class BioLogEntity  extends Auditable<String> {

	@Override
	public String toString() {
		return "BioLogEntity [entityID=" + entityID + ", entityName=" + entityName + ", entityStatus=" + entityStatus
				+ ", entityDescription=" + entityDescription +  "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "BIO_LOG_ENTITY_SEQ")
	@Column(name="ENTITY_ID")
	private Integer entityID;
	
	@Column(name="ENTITY_NAME")
	private String entityName;
	
	@Column(name="ENTITY_STATUS")
	private String entityStatus;
	
	@Column(name="ENTITY_Description")
	private String entityDescription;
	}
