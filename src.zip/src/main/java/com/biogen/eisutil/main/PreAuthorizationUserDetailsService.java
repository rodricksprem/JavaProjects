package com.biogen.eisutil.main;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;


public class PreAuthorizationUserDetailsService implements AuthenticationUserDetailsService
{
 

  public UserDetails loadUserDetails(Authentication token) throws UsernameNotFoundException
  {
    PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails tokenDetails =
        (PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails) token.getDetails();
    
    List<GrantedAuthority> grantedAuthorities =  tokenDetails.getGrantedAuthorities();
    
    String networkName= (String) token.getPrincipal();
    
 
    
    System.out.println("PreAuthorizationUserDetailsService--------Logged in network name:"+networkName);
    
      
        
    
    
    return new User(
        (String) token.getPrincipal(),
        "unused", true, true, true, true,
        tokenDetails.getGrantedAuthorities());
  }

}
