package com.biogen.eisutil.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.WebApplicationInitializer;

@SpringBootApplication
@ComponentScan({"com.biogen.eisutil.main","com.biogen.eisutil.config","com.biogen.eisutil.controller","com.biogen.eisutil.service.impl", "com.biogen.eisutil.repo.impl"})
@EntityScan("com.biogen.eisutil.dao")
@EnableJpaRepositories("com.biogen.eisutil.repo")
public class Application extends SpringBootServletInitializer implements WebApplicationInitializer 
{

	public static void main(String[] args) {
		System.setProperty("server.servlet.context-path", "/eisUtilWeb");
		SpringApplication.run(Application.class, args);
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}
}
