package com.biogen.eisutil.repo.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.repo.custom.BioLogInfoAttributesCustomRepository;

public class BioLogInfoAttributesCustomRepositoryImpl implements BioLogInfoAttributesCustomRepository{
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getKeyValueDetails(String bioTransactionId) {
		return this.entityManager.
				createNativeQuery("SELECT LISTAGG(KEY ||  ':' || VALUE, ' | ') WITHIN GROUP (ORDER BY BIOGENTRANSID) MESSAGE FROM BIO_LOG_INFO_ATTRIBUTES WHERE BIOGENTRANSID='"+bioTransactionId+"'").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getKeyValueDetails(String bioTransactionId, String keyValueDetails) {
		return this.entityManager.
				createNativeQuery("SELECT LISTAGG(KEY ||  ':' || VALUE, ' | ') WITHIN GROUP (ORDER BY BIOGENTRANSID) MESSAGE FROM BIO_LOG_INFO_ATTRIBUTES WHERE BIOGENTRANSID='"+bioTransactionId+"' AND "+keyValueDetails).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getKey() {
		return this.entityManager.
				createNativeQuery("SELECT DISTINCT KEY FROM BIO_LOG_INFO_ATTRIBUTES WHERE TRIM(KEY) IS NOT NULL").getResultList();

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getKeyByAppName(String appName) {
		return this.entityManager.
				createNativeQuery("SELECT DISTINCT BLIA.KEY FROM BIO_LOG_INFO_ATTRIBUTES BLIA JOIN BIO_LOG_APPLICATION BA ON BA.APP_ID=BLIA.APP_ID WHERE BA.APP_NAME='"+appName+"' AND TRIM(BLIA.KEY) IS NOT NULL").getResultList();

	}
}
