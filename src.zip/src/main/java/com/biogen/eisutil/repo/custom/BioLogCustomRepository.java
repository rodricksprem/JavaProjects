package com.biogen.eisutil.repo.custom;

import java.math.BigDecimal;
import java.util.List;

import com.biogen.eisutil.model.BioLogTemp;

public interface BioLogCustomRepository {
	
	public List<BioLogTemp> getLogDetailsByList();
	

	public List<Object[]> getLogDetails();
	
	
	public List<Object[]> getLogDetailsByAdvancedSearch(String adSearchParams);
	
	public List<Object[]> getLogDetailsByBusinessUnitSearch(String buSearchParams,Integer duration);
	
	public List<Object[]> getDetailedLogDetails(String bioTransId);
	
	public List<Object[]> getDetailedTargetSystemLogDetails(String bioTransId, int bioLogTargetSystemId);
	
	public List<BigDecimal> getBioLogTargetSystemIdByBioTransId(String bioTransId);
	
	public int getAppId(String appName);
}
