package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogSourceTargetEntity;
//for table bio_etm_SourceTargetType
public interface BioLogSourceTargetRepository extends JpaRepository<BioLogSourceTargetEntity, Integer> {

}
