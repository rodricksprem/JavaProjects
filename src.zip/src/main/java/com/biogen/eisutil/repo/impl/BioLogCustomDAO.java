package com.biogen.eisutil.repo.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.biogen.eisutil.model.BioLogSearch;
import com.biogen.eisutil.model.BioLogTemp;
import com.biogen.eisutil.model.BioLogUserTemp;
import com.biogen.eisutil.model.BusinessUnitData;

@org.springframework.transaction.annotation.Transactional
@Repository
public class BioLogCustomDAO {

	private final JdbcTemplate jdbcTemplate;
    @Autowired
    public BioLogCustomDAO(JdbcTemplate jdbcTemplate) {
	  this.jdbcTemplate = jdbcTemplate;
    }
    
    public List<BioLogUserTemp> getUsersList() {
    	Object[] params = new Object[0];
		StringBuffer query = new StringBuffer("SELECT BLU.user_Id, BLUT.user_Type, BLU.email_ID, BLU.first_Name, BLU.last_Name, BLU.created_Date, BLU.updated_Date,(SELECT LISTAGG(bum.bu_name||',') WITHIN GROUP (ORDER BY bu.USER_ID) FROM BIO_ETM_USERBU_LINK bu, Bio_etm_businessunit bum WHERE bu.USER_ID=blu.USER_ID and bum.bu_id= bu.bu_id) AS buNames FROM Bio_Log_User BLU, Bio_Log_User_Type BLUT where BLUT.user_Type_Id = BLU.user_Type Order By BLU.user_Id");

		final List<BioLogUserTemp> userList = new ArrayList<BioLogUserTemp>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
			BioLogUserTemp bioLogUserTemp = new BioLogUserTemp();
			bioLogUserTemp.setUserId(rs.getString(1));
			bioLogUserTemp.setUserType(rs.getString(2));
			bioLogUserTemp.setEmailID(rs.getString(3));
			bioLogUserTemp.setCreatedDate(rs.getString(6));
		
			bioLogUserTemp.setUpdatedDate(rs.getString(7));
		if(rs.getString(8) != null && rs.getString(8).length() > 0) {
			bioLogUserTemp.setBuStr(rs.getString(8).substring(0,rs.getString(8).length()-1));
		}else {
		bioLogUserTemp.setBuStr("");
		}
		bioLogUserTemp.setBuList(getBUList(rs.getString(1)));
		userList.add(bioLogUserTemp);
		}
			});
		}catch(Exception ex ) {
			ex.printStackTrace();
		}
	return userList;
	}
    
    public List<BusinessUnitData> getBUList(String userId) {
    	Object[] params = new Object[0];
		StringBuffer query = new StringBuffer("SELECT bu.bu_id ,bum.bu_name FROM BIO_ETM_USERBU_LINK bu, Bio_etm_businessunit bum WHERE bum.bu_id= bu.bu_id and bu.status = 1 and bu.USER_ID='"+userId+"'");

		final List<BusinessUnitData> userList = new ArrayList<BusinessUnitData>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
					BusinessUnitData bioLogUserTemp = new BusinessUnitData();
			bioLogUserTemp.setAppId(rs.getInt(1));
			bioLogUserTemp.setAppName(rs.getString(2));
			
		userList.add(bioLogUserTemp);
		}
			});
		}catch(Exception ex ) {
			ex.printStackTrace();
		}
	return userList;
	}
    
    
    public List<BioLogTemp> getLogDetailsByList() {
		Object[] params = new Object[0];
		String durationText="trunc(BLM.SERVICE_START_TIME) >= sysdate - "+ 1;
		StringBuffer query = new StringBuffer("select * from (select a.*, rownum r from ((SELECT   blm.biogentransid AS col_0_0_,  blag.app_group AS col_1_0_,  bla.app_name AS col_2_0_,  blm.service_invoker AS col_3_0_,  blm.service_status AS col_4_0_,  blm.service_start_time AS col_5_0_,  blm.service_end_time   AS col_6_0_,  sub.message            AS col_7_0_,  bnh.biogentransid      AS notificationExists from bio_log_main blm, bio_log_application bla, bio_log_app_group blag,bio_notify_history bnh,(select biogentransid, listagg(Key || ':' || Value, '|') within group (order by biogentransid) message from bio_log_info_attributes group by biogentransid) sub where "+durationText +" and bla.app_id=blm.app_id and bla.app_group_id = blag.app_group_id AND blm.biogentransid = sub.biogentransid (+) AND blm.biogentransid = bnh.biogentransid(+)) order by blm.service_start_time DESC) a where rownum <=100 ) where r >0");

		System.out.println(query);
		final List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
					
					BioLogTemp bioLogTemp = new BioLogTemp();
					if(rs.getString("col_0_0_") != null && rs.getString("col_0_0_").trim() != "")
					{
						bioLogTemp.setBioTransId(rs.getString("col_0_0_").trim());
					}
					if(rs.getString("col_1_0_") != null && rs.getString("col_1_0_").trim() != "")
					{
						bioLogTemp.setAppGroup(rs.getString("col_1_0_"));
					}
					else
					{
						bioLogTemp.setAppGroup("");
					}
					
					if(rs.getString("col_2_0_") != null && rs.getString("col_2_0_").trim() != "")
					{
						bioLogTemp.setAppName(rs.getString("col_2_0_"));
					}
					else
					{
						bioLogTemp.setAppName("");
					}
					
					if(rs.getString("col_3_0_") != null && rs.getString("col_3_0_").trim() != "")
					{
						bioLogTemp.setServiceInvoker(rs.getString("col_3_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvoker("");
					}
					
					if(rs.getString("col_4_0_") != null && rs.getString("col_4_0_").trim() != "")
					{
						bioLogTemp.setServiceInvokerStatus(rs.getString("col_4_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvokerStatus("");
					}
					
					if(rs.getString("col_5_0_") != null && rs.getString("col_5_0_").trim() != "")
					{
						bioLogTemp.setStartTime(rs.getString("col_5_0_"));
					}
					else
					{
						bioLogTemp.setStartTime("");
					}
					
		          
					if(rs.getString("col_6_0_") != null && rs.getString("col_6_0_").trim() != "")
					{
						bioLogTemp.setEndTime(rs.getString("col_6_0_"));
					}
					else
					{
						bioLogTemp.setEndTime("");
					}
					if ( bioLogTemp.getEndTime().isEmpty() ) {
						bioLogTemp.setServiceInvokerStatus("INPROGRESS");
					}
					if(rs.getString("col_7_0_") != null && rs.getString("col_7_0_").trim() != "" && rs.getString("col_7_0_").trim().length() > 1 )
					{
						bioLogTemp.setMessage(rs.getString("col_7_0_"));
					}
					else
					{
						bioLogTemp.setMessage("");
					}
					if(rs.getString("notificationExists") != null && rs.getString("notificationExists").trim() != "")
					{
						bioLogTemp.setNotificationSize(1);
					}
					else
					{
						bioLogTemp.setNotificationSize(0);
					}
					bioLogTemplist.add(bioLogTemp);
				}

	});
		
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return bioLogTemplist;
}
    public List<BioLogTemp> getLogDetailsByList(Integer duration) {
		Object[] params = new Object[0];
		String durationText="trunc(BLM.SERVICE_START_TIME) >= sysdate - "+ duration;
		StringBuffer query = new StringBuffer("select * from (select a.*, rownum r from ((SELECT   blm.biogentransid AS col_0_0_,  blag.app_group AS col_1_0_,  bla.app_name AS col_2_0_,  blm.service_invoker AS col_3_0_,  blm.service_status AS col_4_0_,  blm.service_start_time AS col_5_0_,  blm.service_end_time   AS col_6_0_,  sub.message            AS col_7_0_,  bnh.biogentransid      AS notificationExists from bio_log_main blm, bio_log_application bla, bio_log_app_group blag,bio_notify_history bnh,(select biogentransid, listagg(Key || ':' || Value, '|') within group (order by biogentransid) message from bio_log_info_attributes group by biogentransid) sub where "+durationText +" and bla.app_id=blm.app_id and bla.app_group_id = blag.app_group_id AND blm.biogentransid = sub.biogentransid (+) AND blm.biogentransid = bnh.biogentransid(+)) order by blm.service_start_time DESC) a ) where r >0");

		System.out.println(query);
		final List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
					
					BioLogTemp bioLogTemp = new BioLogTemp();
					if(rs.getString("col_0_0_") != null && rs.getString("col_0_0_").trim() != "")
					{
						bioLogTemp.setBioTransId(rs.getString("col_0_0_").trim());
					}
					if(rs.getString("col_1_0_") != null && rs.getString("col_1_0_").trim() != "")
					{
						bioLogTemp.setAppGroup(rs.getString("col_1_0_"));
					}
					else
					{
						bioLogTemp.setAppGroup("");
					}
					
					if(rs.getString("col_2_0_") != null && rs.getString("col_2_0_").trim() != "")
					{
						bioLogTemp.setAppName(rs.getString("col_2_0_"));
					}
					else
					{
						bioLogTemp.setAppName("");
					}
					
					if(rs.getString("col_3_0_") != null && rs.getString("col_3_0_").trim() != "")
					{
						bioLogTemp.setServiceInvoker(rs.getString("col_3_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvoker("");
					}
					
					if(rs.getString("col_4_0_") != null && rs.getString("col_4_0_").trim() != "")
					{
						bioLogTemp.setServiceInvokerStatus(rs.getString("col_4_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvokerStatus("");
					}
					
					if(rs.getString("col_5_0_") != null && rs.getString("col_5_0_").trim() != "")
					{
						bioLogTemp.setStartTime(rs.getString("col_5_0_"));
					}
					else
					{
						bioLogTemp.setStartTime("");
					}
					
		            
					if(rs.getString("col_6_0_") != null && rs.getString("col_6_0_").trim() != "")
					{
						bioLogTemp.setEndTime(rs.getString("col_6_0_"));
					}
					else
					{
						bioLogTemp.setEndTime("");
					}
					if ( bioLogTemp.getEndTime().isEmpty() ) {
						bioLogTemp.setServiceInvokerStatus("INPROGRESS");
					}
					if(rs.getString("col_7_0_") != null && rs.getString("col_7_0_").trim() != "" && rs.getString("col_7_0_").trim().length() > 1 )
					{
						bioLogTemp.setMessage(rs.getString("col_7_0_"));
					}
					else
					{
						bioLogTemp.setMessage("");
					}
					if(rs.getString("notificationExists") != null && rs.getString("notificationExists").trim() != "")
					{
						bioLogTemp.setNotificationSize(1);
					}
					else
					{
						bioLogTemp.setNotificationSize(0);
					}
					bioLogTemplist.add(bioLogTemp);
				}

	});
		
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return bioLogTemplist;
}
    
    public List<BioLogTemp>  getLogDetailsByAdvSearch(BioLogSearch bioLogSearchParams){
    	Object[] params = new Object[0];
		StringBuffer query = new StringBuffer("select * from (select a.*, rownum r from ((SELECT   blm.biogentransid AS col_0_0_,  blag.app_group AS col_1_0_,  bla.app_name AS col_2_0_,  blm.service_invoker AS col_3_0_,  blm.service_status AS col_4_0_,  blm.service_start_time AS col_5_0_,  blm.service_end_time   AS col_6_0_,  sub.message            AS col_7_0_,  bnh.biogentransid      AS notificationExists from bio_log_main blm, bio_log_application bla, bio_log_app_group blag,bio_notify_history bnh,(select biogentransid, listagg(Key || ':' || Value, '|') within group (order by biogentransid) message from bio_log_info_attributes ");
		String keyValueDetails=""; 
		if(bioLogSearchParams.getKey() != null && !bioLogSearchParams.getKey().isEmpty() && bioLogSearchParams.getKey().trim() != "")
		{
			
			if(bioLogSearchParams.getCondition().contentEquals("is")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE) = UPPER('"+bioLogSearchParams.getValue().trim()+"') group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("is not")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND NOT ( UPPER(VALUE) = UPPER('"+bioLogSearchParams.getValue().trim()+"')) group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("contains")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE) LIKE UPPER('%"+bioLogSearchParams.getValue().trim()+"%') group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("does not contain")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND NOT( UPPER(VALUE)  LIKE UPPER('%"+bioLogSearchParams.getValue().trim()+"%')) group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("ends with")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE) LIKE UPPER('%"+bioLogSearchParams.getValue().trim()+"') group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("begins with")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE) LIKE UPPER('"+bioLogSearchParams.getValue().trim()+"%') group by biogentransid";
					
			}else if(bioLogSearchParams.getCondition().contentEquals("in between")) {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE) LIKE UPPER('%"+bioLogSearchParams.getValue().trim()+"%') group by biogentransid";
					
			}else {
				keyValueDetails = " where KEY='"+bioLogSearchParams.getKey()+"' AND UPPER(VALUE)=UPPER('"+bioLogSearchParams.getValue().trim()+"') group by biogentransid";
			}
		}
		
		if(keyValueDetails.length()>0) {
			query.append(keyValueDetails);
		} else {
			query.append(" group by biogentransid ");
		}
		query.append(") sub where bla.app_id=blm.app_id");
		if(bioLogSearchParams.getBioTransId() != null && !bioLogSearchParams.getBioTransId().isEmpty() && bioLogSearchParams.getBioTransId().trim() != "")
		{
			query.append(" and blm.biogenTransId='"+bioLogSearchParams.getBioTransId().trim()+"'");
		} else {
			if(bioLogSearchParams.getAppGroup() != null && !bioLogSearchParams.getAppGroup().isEmpty() && bioLogSearchParams.getAppGroup().trim() != "")
			{
				query.append(" and blag.APP_GROUP='"+bioLogSearchParams.getAppGroup()+"'");
			}
			
			if(bioLogSearchParams.getAppName() != null && !bioLogSearchParams.getAppName().isEmpty() && bioLogSearchParams.getAppName().trim() != "")
			{
				
					query.append(" and bla.APP_NAME='"+bioLogSearchParams.getAppName()+"'");
				}
			if(bioLogSearchParams.getStatus() != null && !bioLogSearchParams.getStatus().isEmpty() && bioLogSearchParams.getStatus().size()>0)
			{
				System.out.println(bioLogSearchParams.getStatus().size());
				String serviceStatus= bioLogSearchParams.getStatus().stream().collect(Collectors.joining("','"));
				query.append(" and blm.SERVICE_STATUS IN ('"+serviceStatus+"')");
			}
			if((bioLogSearchParams.getStartDate() == null || bioLogSearchParams.getStartDate().isEmpty() || bioLogSearchParams.getStartDate().trim() == "") && (bioLogSearchParams.getEndDate() == null || bioLogSearchParams.getEndDate().isEmpty() || bioLogSearchParams.getEndDate().trim() == ""))
			{
				
				query.append(" and trunc(BLM.SERVICE_START_TIME) >= sysdate - "+ 1);
			}
			else 
			{
				if(bioLogSearchParams.getStartDate() != null && !bioLogSearchParams.getStartDate().isEmpty() && bioLogSearchParams.getStartDate().trim() != "")
			
				{
					String startDate = bioLogSearchParams.getStartDate().trim().replace("T", " ");
					startDate = startDate.substring(0, startDate.length()-5);
					query.append(" and cast(blm.SERVICE_START_TIME as timestamp) >= TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
				}
				if(bioLogSearchParams.getEndDate() != null && !bioLogSearchParams.getEndDate().isEmpty() && bioLogSearchParams.getEndDate().trim() != "")
				{
					String endDate = bioLogSearchParams.getEndDate().trim().replace("T", " ");
					endDate = endDate.substring(0, endDate.length()-5);
					query.append(" and cast(blm.SERVICE_START_TIME as timestamp) <= TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
				}
			}
			
		}
		if(keyValueDetails.length()>0) {
			query.append(" AND blm.biogentransid = sub.biogentransid ");
		} else {
			query.append(" AND blm.biogentransid = sub.biogentransid (+) ");
		}
		
		query.append(" and bla.app_group_id = blag.app_group_id  AND blm.biogentransid = bnh.biogentransid(+)) order by blm.service_start_time DESC) a where rownum <=2000 ) where r >0");

		System.out.println("query for logging serarch:"+query);
		final List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
					
					BioLogTemp bioLogTemp = new BioLogTemp();
					if(rs.getString("col_0_0_") != null && rs.getString("col_0_0_").trim() != "")
					{
						bioLogTemp.setBioTransId(rs.getString("col_0_0_").trim());
					}
					if(rs.getString("col_1_0_") != null && rs.getString("col_1_0_").trim() != "")
					{
						bioLogTemp.setAppGroup(rs.getString("col_1_0_"));
					}
					else
					{
						bioLogTemp.setAppGroup("");
					}
					
					if(rs.getString("col_2_0_") != null && rs.getString("col_2_0_").trim() != "")
					{
						bioLogTemp.setAppName(rs.getString("col_2_0_"));
					}
					else
					{
						bioLogTemp.setAppName("");
					}
					
					if(rs.getString("col_3_0_") != null && rs.getString("col_3_0_").trim() != "")
					{
						bioLogTemp.setServiceInvoker(rs.getString("col_3_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvoker("");
					}
					
					if(rs.getString("col_4_0_") != null && rs.getString("col_4_0_").trim() != "")
					{
						bioLogTemp.setServiceInvokerStatus(rs.getString("col_4_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvokerStatus("");
					}
					
					if(rs.getString("col_5_0_") != null && rs.getString("col_5_0_").trim() != "")
					{
						bioLogTemp.setStartTime(rs.getString("col_5_0_"));
					}
					else
					{
						bioLogTemp.setStartTime("");
					}
					
		            
					if(rs.getString("col_6_0_") != null && rs.getString("col_6_0_").trim() != "")
					{
						bioLogTemp.setEndTime(rs.getString("col_6_0_"));
					}
					else
					{
						bioLogTemp.setEndTime("");
					}
					if ( bioLogTemp.getEndTime().isEmpty() ) {
						bioLogTemp.setServiceInvokerStatus("INPROGRESS");
					}
					if(rs.getString("col_7_0_") != null && rs.getString("col_7_0_").trim() != "" && rs.getString("col_7_0_").trim().length() > 1 )
					{
						bioLogTemp.setMessage(rs.getString("col_7_0_"));
					}
					else
					{
						bioLogTemp.setMessage("");
					}
					if(rs.getString("notificationExists") != null && rs.getString("notificationExists").trim() != "")
					{
						bioLogTemp.setNotificationSize(1);
					}
					else
					{
						bioLogTemp.setNotificationSize(0);
					}
					bioLogTemplist.add(bioLogTemp);
				}

	});
		
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return bioLogTemplist;

    }
    
	public List<BioLogTemp> getLogDetailsByBUSearch(String buSearchParams,Integer duration) {
		Object[] params = new Object[0];
		String durationText=" BLM.SERVICE_START_TIME >= sysdate - "+ duration;
		
		StringBuffer query = new StringBuffer("select * from (select a.*, rownum r from ((SELECT   blm.biogentransid AS col_0_0_,  blag.app_group AS col_1_0_,  bla.app_name AS col_2_0_,  blm.service_invoker AS col_3_0_,  blm.service_status AS col_4_0_,  blm.service_start_time AS col_5_0_,  blm.service_end_time   AS col_6_0_,  sub.message            AS col_7_0_,  bnh.biogentransid      AS notificationExists from bio_log_main blm, bio_log_application bla, bio_log_app_group blag,bio_notify_history bnh,(select biogentransid, listagg(Key || ':' || Value, '|') within group (order by biogentransid) message from bio_log_info_attributes group by biogentransid) sub where "+durationText + " and bla.app_id=blm.app_id and bla.app_group_id = blag.app_group_id AND blm.biogentransid = sub.biogentransid (+) AND blm.app_id in ("+buSearchParams+") AND blm.biogentransid = bnh.biogentransid(+)) order by blm.service_start_time DESC) a where rownum <=2000 ) where r >0");
		System.out.println("getLogDetailsByBUSearch "+query);
		final List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();
		try
		{
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
		
					
					BioLogTemp bioLogTemp = new BioLogTemp();
					if(rs.getString("col_0_0_") != null && rs.getString("col_0_0_").trim() != "")
					{
						bioLogTemp.setBioTransId(rs.getString("col_0_0_").trim());
					}
					if(rs.getString("col_1_0_") != null && rs.getString("col_1_0_").trim() != "")
					{
						bioLogTemp.setAppGroup(rs.getString("col_1_0_"));
					}
					else
					{
						bioLogTemp.setAppGroup("");
					}
					
					if(rs.getString("col_2_0_") != null && rs.getString("col_2_0_").trim() != "")
					{
						bioLogTemp.setAppName(rs.getString("col_2_0_"));
					}
					else
					{
						bioLogTemp.setAppName("");
					}
					
					if(rs.getString("col_3_0_") != null && rs.getString("col_3_0_").trim() != "")
					{
						bioLogTemp.setServiceInvoker(rs.getString("col_3_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvoker("");
					}
					
					if(rs.getString("col_4_0_") != null && rs.getString("col_4_0_").trim() != "")
					{
						bioLogTemp.setServiceInvokerStatus(rs.getString("col_4_0_"));
					}
					else
					{
						bioLogTemp.setServiceInvokerStatus("");
					}
					
					if(rs.getString("col_5_0_") != null && rs.getString("col_5_0_").trim() != "")
					{
						bioLogTemp.setStartTime(rs.getString("col_5_0_"));
					}
					else
					{
						bioLogTemp.setStartTime("");
					}
					
		          
					if(rs.getString("col_6_0_") != null && rs.getString("col_6_0_").trim() != "")
					{
						bioLogTemp.setEndTime(rs.getString("col_6_0_"));
					}
					else
					{
						bioLogTemp.setEndTime("");
					}
					if ( bioLogTemp.getEndTime().isEmpty() ) {
						bioLogTemp.setServiceInvokerStatus("INPROGRESS");
					}
					if(rs.getString("col_7_0_") != null && rs.getString("col_7_0_").trim() != "" && rs.getString("col_7_0_").trim().length() > 1 )
					{
						bioLogTemp.setMessage(rs.getString("col_7_0_"));
					}
					else
					{
						bioLogTemp.setMessage("");
					}
					if(rs.getString("notificationExists") != null && rs.getString("notificationExists").trim() != "")
					{
						bioLogTemp.setNotificationSize(1);
					}
					else
					{
						bioLogTemp.setNotificationSize(0);
					}
					bioLogTemplist.add(bioLogTemp);
				}

	});
		
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return bioLogTemplist;
}
	
	
	public void deleteNotifyProps(Integer notifyId) {
		
		this.jdbcTemplate.execute("delete FROM BIO_NOTIFY_PROPS where NOTIFY_ID="+notifyId+"");
		
		
	}
	
public void deleteUserBUMappings(String userId) {
		
		this.jdbcTemplate.execute("delete FROM BIO_ETM_USERBU_LINK where user_id='"+userId+"'");
		
	}

public int getSequenceId(){
	String query = "select BIO_USER_BU_SEQ_ID.nextval from dual ";
	Object[] params = new Object[0];
	
	SqlRowSet rs = jdbcTemplate.queryForRowSet(query, params);
	BigDecimal seqId = new BigDecimal(0);
	if (rs.next()){
		seqId = rs.getBigDecimal(1);
	}
	System.out.println(">>> getSequenceId seq Id"+ seqId);
	return seqId.intValue();
}
}
