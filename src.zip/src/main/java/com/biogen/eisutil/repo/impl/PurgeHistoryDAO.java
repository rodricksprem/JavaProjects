package com.biogen.eisutil.repo.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import com.biogen.eisutil.model.PurgeData;
import com.biogen.eisutil.model.PurgeDetailsData;
@org.springframework.transaction.annotation.Transactional

@Repository
public class PurgeHistoryDAO {

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public PurgeHistoryDAO(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<PurgeDetailsData>  getPurgeDetails(Integer id){
		System.out.println("PurgeHistoryDAO.getPurgeHistory() -------------");
		final List<PurgeDetailsData> purgeDataList = new ArrayList<PurgeDetailsData>();
		StringBuffer query = null;
		Object[] params = new Object[0];
			query = new StringBuffer("select pd.PURGE_ID,pd.PURGE_DETAIL_ID,la.app_name,lg.app_group,pd.LOG_INFO_COUNT,pd.NOTIFY_INFO_COUNT from Bio_etm_purge_detail pd,BIO_log_app_group lg,bio_log_application la where la.app_id = pd.app_id and la.app_group_id = lg.app_group_id and purge_id ="+id);
			query.append("order by pd.app_id desc");
			try {
			
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PurgeDetailsData purgeData  = new PurgeDetailsData();
						purgeData.setPurgeId(rs.getInt("PURGE_ID"));
						purgeData.setAppName(rs.getString("APP_Name"));
						purgeData.setAppGroupName(rs.getString("app_group"));
						purgeData.setLogCount(rs.getInt("LOG_INFO_COUNT"));
						purgeData.setNotifyCount(rs.getInt("NOTIFY_INFO_COUNT"));
						purgeData.setPurgeDetailId(rs.getInt("PURGE_DETAIL_ID"));
						
						purgeDataList.add(purgeData);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			System.out.println("purgeHistory list size:"+purgeDataList.size());
		return purgeDataList;
	}
	
	public List<PurgeData> getPurgeHistory() {
		System.out.println("PurgeHistoryDAO.getPurgeHistory() -------------");
		final List<PurgeData> purgeDataList = new ArrayList<PurgeData>();
		StringBuffer query = null;
		Object[] params = new Object[0];
			query = new StringBuffer("select PURGE_ID,PURGE_STATUS,PURGE_REMARKS,PURGE_START_DATE,PURGE_END_DATE,CREATED_BY,CREATED_DATE from Bio_etm_purge_main order by purge_start_date desc");
			try {
				
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						PurgeData purgeData  = new PurgeData();
						purgeData.setPurgeId(rs.getInt("PURGE_ID"));
						purgeData.setPurgeStatus(rs.getString("PURGE_STATUS"));
						purgeData.setPurgeRemarks(rs.getString("PURGE_REMARKS"));
						purgeData.setPurgeStartDate(rs.getTimestamp("PURGE_START_DATE"));
						purgeData.setPurgeEndDate(rs.getTimestamp("PURGE_END_DATE"));
						purgeData.setExecutedBy(rs.getString("CREATED_BY"));
						purgeData.setExecutedDate(rs.getTimestamp("CREATED_DATE"));
						
						purgeDataList.add(purgeData);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			System.out.println("purgeHistory list size:"+purgeDataList.size());
		return purgeDataList;
	}

}
