package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogUserType;
//for table BIO_LOG_USER_TYPE
public interface BioLogUserTypeRepository extends JpaRepository<BioLogUserType, Integer> {

}
