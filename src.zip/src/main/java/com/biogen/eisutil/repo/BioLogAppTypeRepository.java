package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioLogAppType;
//for table BIO_LOG_APP_TYPE
public interface BioLogAppTypeRepository extends JpaRepository<BioLogAppType, Integer> {

}
