package com.biogen.eisutil.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioAppFile;

//for table BIO_APP_FILE
public interface BioAppFileRepository extends JpaRepository<BioAppFile, Integer> {

	public Optional<BioAppFile> findByAppId(Integer id);

}
