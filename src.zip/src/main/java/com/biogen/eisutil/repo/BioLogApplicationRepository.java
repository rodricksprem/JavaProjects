package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioLogApplication;
import com.biogen.eisutil.repo.custom.BioLogApplicationCustomRepository;
//for table BIO_LOG_APPLICATION
public interface BioLogApplicationRepository extends JpaRepository<BioLogApplication, Integer>, BioLogApplicationCustomRepository {

}
