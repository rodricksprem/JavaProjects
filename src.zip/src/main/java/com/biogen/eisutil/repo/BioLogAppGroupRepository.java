package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogAppGroup;
// for table BIO_LOG_APP_GROUP
public interface BioLogAppGroupRepository extends JpaRepository<BioLogAppGroup, Integer> {

}
