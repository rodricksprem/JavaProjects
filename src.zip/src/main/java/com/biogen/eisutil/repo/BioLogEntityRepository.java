package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogEntity;
//for table bio_etm_entity
public interface BioLogEntityRepository extends JpaRepository<BioLogEntity, Integer> {

}
