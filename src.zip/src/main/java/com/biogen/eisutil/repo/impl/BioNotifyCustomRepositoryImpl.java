package com.biogen.eisutil.repo.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.repo.custom.BioNotifyCustomRepository;



public class BioNotifyCustomRepositoryImpl implements BioNotifyCustomRepository{
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAllNotificationsAndHistory() {
		List<Object[]> notifyHistoryList = new ArrayList();
		notifyHistoryList = this.entityManager.
				createQuery("SELECT BLAG.appGroup, BLA.appName, BN.exCategory, BN.exType, BNH.status, BNH.createdDate, BNH.updatedDate, BNH.id, BNH.bioGenTransId " + 
						"FROM BioNotify BN   JOIN BioNotifyHistory BNH ON "
						+ " BN.createdDate >= sysdate - 1 and BN.id = BNH.notifyId JOIN BioLogApplication BLA ON BLA.createdDate >= cast(sysdate - 1 as timestamp) and BLA.appId = BN.appId "
						+ "JOIN BioLogAppGroup BLAG ON"
						+ " BLAG.createdDate >= cast(sysdate - 1 as timestamp) and "
						+ "BLAG.appGroupId = BLA.appGroupId  Order By BNH.createdDate DESC"). getResultList();
		
		System.out.println(".....");
			return notifyHistoryList;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAllNotificationsAndHistory(Integer duration) {
		List<Object[]> notifyHistoryList = new ArrayList();
		notifyHistoryList = this.entityManager.
				createQuery("SELECT BLAG.appGroup, BLA.appName, BN.exCategory, BN.exType, BNH.status, BNH.createdDate, BNH.updatedDate, BNH.id, BNH.bioGenTransId " + 
						"FROM BioNotify BN   JOIN BioNotifyHistory BNH ON "
						+ " BN.createdDate >= sysdate - "+ duration +" and BN.id = BNH.notifyId JOIN BioLogApplication BLA ON BLA.createdDate >= cast(sysdate - "+ duration +" as timestamp) and BLA.appId = BN.appId "
						+ "JOIN BioLogAppGroup BLAG ON"
						+ " BLAG.createdDate >= cast(sysdate - "+ duration +" as timestamp) and "
						+ "BLAG.appGroupId = BLA.appGroupId  Order By BNH.createdDate DESC"). getResultList();
		
		System.out.println(".....");
		
			return notifyHistoryList;
		
	}	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAllNotificationsAndHistoryByAdSearch(String adSearchParams) {
		return this.entityManager.
				createQuery("SELECT BLAG.appGroup, BLA.appName, BN.exCategory, BN.exType, BNH.status, BNH.createdDate, BNH.updatedDate, BNH.id, BNH.bioGenTransId " + 
						"FROM BioNotify BN JOIN BioNotifyHistory BNH ON BN.id = BNH.notifyId JOIN BioLogApplication BLA ON BLA.appId = BN.appId JOIN BioLogAppGroup BLAG ON BLAG.appGroupId = BLA.appGroupId Where "+adSearchParams+" Order By BNH.createdDate DESC").
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAppDetailsbyAppId(Integer appId) {
		return this.entityManager.
				createQuery("Select APP_NAME, APP_GROUP_ID from BIO_LOG_APPLICATION Where APP_ID="+appId).
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAppGroupNamebyAppId(Integer appGroupId) {
		return this.entityManager.
				createQuery("Select Distinct APP_GROUP from BIO_LOG_APP_GROUP Where APP_GROUP_ID="+appGroupId).
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getExCategoryList() {
		return this.entityManager.
				createQuery("SELECT DISTINCT exCategory FROM BioNotify WHERE TRIM(exCategory) IS NOT NULL").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getExTypeList() {
		return this.entityManager.
				createQuery("SELECT DISTINCT exType FROM BioNotify WHERE TRIM(exType) IS NOT NULL").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getBNHStatusList() {
		return this.entityManager.
				createQuery("SELECT DISTINCT status FROM BioNotifyHistory WHERE TRIM(status) IS NOT NULL").
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getBioNotifyHistoryDetails(int notifyHistoryId) {
		return this.entityManager.
				createNativeQuery("SELECT NAME, VALUE, VALUE_CLOB FROM BIO_NOTIFY_HISTORY_PROPS WHERE NOTIFY_HISTORY_ID="+notifyHistoryId).
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getBioNotifyProps(int notifyHistoryId) {
		return this.entityManager.
				createNativeQuery("SELECT BNP.NAME, BNP.VALUE FROM BIO_NOTIFY_PROPS BNP JOIN BIO_NOTIFY_HISTORY BNH ON BNP.NOTIFY_ID = BNH.NOTIFY_ID WHERE BNH.ID="+notifyHistoryId+" AND BNP.NAME IN ('FROM_EMAIL','TO_EMAIL','CC_EMAIL')").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAllBioNotify() {
		return this.entityManager.
				createNativeQuery("SELECT BLA.APP_NAME, BN.EX_CATEGORY, BN.EX_TYPE, BN.CREATED_BY, BN.CREATED_DATE, BN.UPDATED_BY, BN.UPDATED_DATE FROM BIO_NOTIFY BN JOIN BIO_LOG_APPLICATION BLA ON BLA.APP_ID = BN.APP_ID ORDER BY BN.CREATED_DATE DESC").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAllNotificationsAndHistoryByBUSearch(String buSearchParams,Integer duration) {
		return this.entityManager.
				createQuery("SELECT BLAG.appGroup, BLA.appName, BN.exCategory, BN.exType, BNH.status, BNH.createdDate, BNH.updatedDate, BNH.id, BNH.bioGenTransId " + 
						"FROM BioNotify BN JOIN BioNotifyHistory BNH ON BN.id = BNH.notifyId JOIN BioLogApplication BLA ON BLA.appId = BN.appId JOIN BioLogAppGroup BLAG ON BLAG.appGroupId = BLA.appGroupId Where  trunc(BNH.createdDate) > sysdate - "+duration+" AND BN.appId IN ("+buSearchParams+") Order By BNH.createdDate DESC").
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int getNotifyId(Integer appId, String exCategory, String exType) {
		StringBuilder query = new StringBuilder("select id from Bio_notify where app_id="+appId);
		query.append(" and ex_category='"+exCategory+"' and ex_type='"+exType+"'");
		List<Object> countList = this.entityManager.createNativeQuery(query.toString()).getResultList();
		int notifyId = 0;
		if(countList.size()>0) {
			notifyId = Integer.parseInt(countList.get(0).toString());
		}
		return notifyId;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int deleteNotifyProps(Integer notifyId) {
		int count = this.entityManager.createNativeQuery("delete  FROM BIO_NOTIFY_PROPS where NOTIFY_ID="+notifyId+"").executeUpdate();
		this.entityManager.flush();
		this.entityManager.clear();
		return count;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int getNotifyPropsId(String propName,Integer notifyId) {
		StringBuilder query = new StringBuilder("select id from BIO_NOTIFY_PROPS where notify_id="+notifyId+" and name='"+propName+"'");
		
		List<Object> countList = this.entityManager.createNativeQuery(query.toString()).getResultList();
		int notifyPropsId = 0;
		if(countList.size()>0) {
			notifyPropsId = Integer.parseInt(countList.get(0).toString());
		}

		return notifyPropsId;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int getFileId(Integer appId) {
		StringBuilder query = new StringBuilder("select Id from BIO_APP_File where app_id="+appId);
		
		List<Object> countList = this.entityManager.createNativeQuery(query.toString()).getResultList();
		int fileId = 0;
		if(countList.size()>0) {
			fileId = Integer.parseInt(countList.get(0).toString());
		}

		return fileId;
	}
	

}
