package com.biogen.eisutil.repo.custom;

import java.util.List;
//interface for custom repository implementation to manipulate table BIO_NOTIFY_PROPS
public interface BioNotifyPropsCustomRepository {
	
	public List<String> findName();
	
	public List<Integer> getNotifyIdList(int appId, String exCategory, String exType);
	
	public List<Object[]> getExCategoryAndExTypeByAppId(int appId);
	
	public List<Object[]> getExCategoryAndExTypeByAppName(String appName);
}
