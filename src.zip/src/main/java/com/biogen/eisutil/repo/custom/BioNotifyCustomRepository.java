package com.biogen.eisutil.repo.custom;

import java.util.List;
//interface for custom repository implementation to manipulate table BIO_NOTIFY
public interface BioNotifyCustomRepository {
	
	public List<Object[]> getAllNotificationsAndHistory();
	
	public List<Object[]> getAllNotificationsAndHistoryByAdSearch(String adSearchParams);
	
	public List<Object[]> getAllNotificationsAndHistoryByBUSearch(String buSearchParams, Integer duration);
	
	public List<String> getAppDetailsbyAppId(Integer appId);
	
	public List<String> getAppGroupNamebyAppId(Integer appId);
	
	public List<String> getExCategoryList();
	
	public List<String> getExTypeList();
	
	public List<String> getBNHStatusList();
	
	public List<Object[]> getBioNotifyHistoryDetails(int notifyHistoryId);
	
	public List<Object[]> getBioNotifyProps(int notifyHistoryId);
	
	public List<Object[]> getAllBioNotify();
	
	public int getNotifyId(Integer appId, String exCategory, String exType);
	
	public int deleteNotifyProps(Integer notifyId);
	
	public int getNotifyPropsId(String propName,Integer notifyId);
	
	public int getFileId(Integer appId);

	List<Object[]> getAllNotificationsAndHistory(Integer duration);
}
