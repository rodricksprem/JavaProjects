package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogITPDDetailsEntity;
//for table bio_etm_ITPD_DETAILS
public interface BioLogITPDDetailsRepository extends JpaRepository<BioLogITPDDetailsEntity, Integer> {

}
