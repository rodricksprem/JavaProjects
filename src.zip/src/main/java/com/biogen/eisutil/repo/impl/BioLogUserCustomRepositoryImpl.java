package com.biogen.eisutil.repo.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.BioLogUserTemp;
import com.biogen.eisutil.repo.custom.BioLogUserCustomRepository;

public class BioLogUserCustomRepositoryImpl implements BioLogUserCustomRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUsers() {
		return this.entityManager.createQuery(
				"SELECT BLU.userId, BLUT.userType, BLU.emailID, BLU.firstName, BLU.lastName, BLU.createdDate, BLU.updatedDate FROM BioLogUser BLU JOIN BioLogUserType BLUT ON BLUT.userTypeId = BLU.userType Order By BLU.createdDate Desc")
				.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLogUserTemp> getUsersList() {
		List<Object[]> objectList = this.entityManager.createQuery(
				"SELECT BLU.userId, BLUT.userType, BLU.emailID, BLU.firstName, BLU.lastName, BLU.createdDate, BLU.updatedDate FROM BioLogUser BLU JOIN BioLogUserType BLUT ON BLUT.userTypeId = BLU.userType Order By BLU.userId")
				.getResultList();
		List<BioLogUserTemp> userList = new ArrayList<BioLogUserTemp>();
	for (Object[] object : objectList) {
		
		BioLogUserTemp bioLogUserTemp = new BioLogUserTemp();
		
		if(object[0] != null && object[0].toString().trim() != "")
		{
			bioLogUserTemp.setUserId(object[0].toString());
		}
		else
		{
			bioLogUserTemp.setUserId("");
		}
		
		if(object[1] != null && object[1].toString().trim() != "")
		{
			bioLogUserTemp.setUserType(object[1].toString());
		}
		else
		{
			bioLogUserTemp.setUserType("");
		}
		
		if(object[2] != null && object[2].toString().trim() != "")
		{
			bioLogUserTemp.setEmailID(object[2].toString());
		}
		else
		{
			bioLogUserTemp.setEmailID("");
		}
		
		if(object[3] != null && object[3].toString().trim() != "")
		{
			bioLogUserTemp.setFirstName(object[3].toString());
		}
		else
		{
			bioLogUserTemp.setFirstName("");
		}
		
		if(object[4] != null && object[4].toString().trim() != "")
		{
			bioLogUserTemp.setLastName(object[4].toString());
		}
		else
		{
			bioLogUserTemp.setLastName("");
		}
		
		if(object[5] != null && object[5].toString().trim() != "")
		{
			bioLogUserTemp.setCreatedDate(object[5].toString());
		}
		else
		{
			bioLogUserTemp.setCreatedDate("");
		}
		
		if(object[6] != null && object[6].toString().trim() != "")
		{
			bioLogUserTemp.setUpdatedDate(object[6].toString());
		}
		else
		{
			bioLogUserTemp.setUpdatedDate("");
		}
		List<Object[]> buList =this.getBUName(bioLogUserTemp.getUserId());

		StringBuilder buStr = new StringBuilder();
		for (Object[] object1 : buList) {
			if(object1[4] != null && object1[4].toString().trim() != "")
			{
				buStr.append(object1[4].toString()).append(",");
			}
		}
		if(buStr.toString().length() >0) {
			bioLogUserTemp.setBuStr(buStr.substring(0,buStr.length()-1));
		}else {
		bioLogUserTemp.setBuStr(buStr.toString());
		}
		userList.add(bioLogUserTemp);
		}
	return userList;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUserTypeList() {
		return this.entityManager.
				createQuery("SELECT userTypeId,userType FROM BioLogUserType").
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int deleteUserBUMapping(String userId) {
		int count = this.entityManager.createNativeQuery("delete  FROM BIO_ETM_USERBU_LINK where UPPER(USER_ID)=UPPER('"+userId+"')").executeUpdate();
		this.entityManager.flush();
		this.entityManager.clear();
		return count;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public int updateUserBUMapping(String userId) {
		int count = this.entityManager.createNativeQuery("upate BIO_ETM_USERBU_LINK set status=0 where UPPER(USER_ID)=UPPER('"+userId+"')").executeUpdate();
		this.entityManager.flush();
		this.entityManager.clear();
		return count;
	}
	
	@Override
	public List<Object[]> getUserMapList(String userId) {
		return this.entityManager.createNativeQuery("SELECT USER_BU_ID, USER_ID, BU_ID, STATUS FROM BIO_ETM_USERBU_LINK where UPPER(USER_ID)=UPPER('"+userId+"') and status = 1").getResultList();
	}
	
	@Override
	public List<Object[]> getBUName(String userId) {
		return this.entityManager.createNativeQuery("SELECT bum.USER_BU_ID, bum.USER_ID, bum.BU_ID, bum.STATUS,bu.bu_name FROM BIO_ETM_USERBU_LINK bum, Bio_etm_businessunit bu where bum.bu_id= bu.bu_id and bum.status = 1 and UPPER(bum.USER_ID)=UPPER('"+userId+"') order by bu.bu_name").getResultList();
	}
	
}
