package com.biogen.eisutil.repo.custom;

import java.util.List;

import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.BioCRDetailsData;
import com.biogen.eisutil.model.BioITPDDetailsData;
import com.biogen.eisutil.model.BioNotification;
//interface for custom repository implementation to manipulate table BIO_LOG_APPLICATION
public interface BioLogApplicationCustomRepository {
	
	public List<Object[]> getIntegrationDetails(Integer appId);
	
	public List<Object[]> getAllApplicationDetails();
	
	public List<Object[]> getAppTypeList();
	
	public List<Object[]> getAppGroupList();
	
	public List<Object[]> getLogLevelList();
	
	public List<Object[]> getAppNameList();
	
	public List<String> getServiceInvokerStatusList();
	
	public List<Object[]> getAppNameByAppGroupId(String appGroupName);
	
	public List<AppNameTemp> getInterfaceNameByAppName(String bunit, String appName, String entity);
	
	public List<BioCRDetailsData> getCRDetails(Integer appIntegrationId);
	
	public List<BioITPDDetailsData> getITPDDetails(Integer appIntegrationId);
	
	public List<BioNotification> getNotificationDetails(Integer appId);
}
