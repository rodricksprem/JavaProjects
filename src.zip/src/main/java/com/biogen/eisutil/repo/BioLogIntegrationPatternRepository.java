package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogIntegrationPatternEntity;

public interface BioLogIntegrationPatternRepository extends JpaRepository<BioLogIntegrationPatternEntity, Integer> {

}
