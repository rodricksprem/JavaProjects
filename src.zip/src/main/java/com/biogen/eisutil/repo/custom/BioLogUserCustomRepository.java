package com.biogen.eisutil.repo.custom;

import java.util.List;

import com.biogen.eisutil.model.BioLogUserTemp;
//interface for custom repository implementation to manipulate table BIO_LOG_USER
public interface BioLogUserCustomRepository {
	
	public List<Object[]> getUsers();
	
	public List<Object[]> getUserTypeList();
	
	public int deleteUserBUMapping(String userId);
	
	public int updateUserBUMapping(String userId);
	
	public List<Object[]> getUserMapList(String userId);
	
	public List<BioLogUserTemp> getUsersList();
	
	public List<Object[]> getBUName(String userId);
}
