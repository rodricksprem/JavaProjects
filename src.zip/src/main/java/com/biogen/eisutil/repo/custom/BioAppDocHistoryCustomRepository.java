package com.biogen.eisutil.repo.custom;

import java.util.List;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;
//interface for custom repository implementation BIO_APP_FILE
public interface BioAppDocHistoryCustomRepository {
	
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetails();
	
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetailsByAppId(Integer appId);
	
	public List<BioAppDocHistoryTemp> getInterfaceDetails(BUSearch buSearch);

}
