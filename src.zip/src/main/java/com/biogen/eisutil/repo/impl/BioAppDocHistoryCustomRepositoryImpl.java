package com.biogen.eisutil.repo.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BioAppDocHistoryTemp;
import com.biogen.eisutil.repo.custom.BioAppDocHistoryCustomRepository;
//operate on  BIO_APP_FILE table 
public class BioAppDocHistoryCustomRepositoryImpl implements BioAppDocHistoryCustomRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetails() {
		List<BioAppDocHistoryTemp> bioAppDocHistoryTempList = new ArrayList<BioAppDocHistoryTemp>();
		String myCimsURL = "https://mycims.biogen.com/edocslink/default.aspx?docid=";
		
		// get the ITPD document id  , credential details  based on the appid , so that ITPD document can be view from mycims  
		List<Object[]> docInfoList = this.entityManager.createNativeQuery("    SELECT  bla.app_name, badh.app_integration_id,    badh.pattern_id,    ip.pattern_name,    ip.pattern_description,    (SELECT id        FROM            bio_app_file        WHERE            app_id = badh.app_id    ) AS file_id,    badh.created_date,    badh.app_id,    (        SELECT            LISTAGG(appl.application_name             || ';')WITHIN GROUP(ORDER BY bu.application_id)        FROM            bio_etm_bu_app_es_info bu,            bio_etm_application appl,            bio_etm_source_target_type st        WHERE                app_id = badh.app_id            AND                bu.application_id =appl.application_id            AND                bu.source_target_type_id =st.source_target_type_id            AND                bu.source_target_type_indicator = 'S'    ) AS sourceapplicatin,    (        SELECT            LISTAGG(appl.application_name             || ';') WITHIN GROUP(ORDER BY bu.application_id)        FROM            bio_etm_bu_app_es_info bu,           bio_etm_application appl,            bio_etm_source_target_type st        WHERE               app_id = badh.app_id            AND                bu.application_id = appl.application_id            AND                bu.source_target_type_id =st.source_target_type_id            AND                bu.source_target_type_indicator = 'T'    ) AS targetapplicatin,    (        SELECT            LISTAGG(cr_number             || '('\r\n" + 
				"|| implementation_date             || ')'             || ';') WITHIN GROUP(ORDER BY app_integration_id)        FROM            bio_etm_cr_details        WHERE            app_integration_id =badh.app_integration_id    ) AS crdetails,    (        SELECT           LISTAGG(itpd_number             || ';') WITHIN GROUP(ORDER BY app_integration_id)        FROM            bio_etm_itpd_details        WHERE            app_integration_id = badh.app_integration_id    ) AS itpddetails,    (        SELECT            LISTAGG(st.source_target_name             || ';') WITHIN GROUP(ORDER BY application_id)        FROM            bio_etm_bu_app_es_info bu,           bio_etm_source_target_type st        WHERE                app_id = badh.app_id            AND                bu.source_target_type_id =st.source_target_type_id            AND               bu.source_target_type_indicator = 'S'    ) AS sourcetype,    (        SELECT            LISTAGG(st.source_target_name             || ';') WITHIN GROUP(ORDER BY application_id)        FROM           bio_etm_bu_app_es_info bu,            bio_etm_source_target_type st        WHERE                app_id = badh.app_id AND bu.source_target_type_id = st.source_target_type_id AND bu.source_target_type_indicator = 'T'    ) AS targettype FROM   bio_app_integration_details badh    JOIN bio_log_application bla ON bla.app_id =badh.app_id    JOIN bio_etm_integration_pattern ip ON badh.pattern_id =ip.pattern_id").getResultList();
			docInfoList.stream().forEach(object -> {
				StringBuilder itpd = new StringBuilder();;
				String value="";
				String stValue = "";
				int i = 0;
				int j = 0;
				StringBuilder str = new StringBuilder();
		
				BioAppDocHistoryTemp bioAppDoc = new BioAppDocHistoryTemp();
				
				bioAppDoc.setAppName(object[0].toString());
				if(object[1] != null) {
					bioAppDoc.setAppIntegrationId(Integer.parseInt(object[1].toString()));
				} else {
					bioAppDoc.setAppIntegrationId(0);
				}
				if(object[2] != null) {
					bioAppDoc.setIntegrationPatternId(Integer.parseInt(object[2].toString()));
				} else {
					bioAppDoc.setIntegrationPatternId(0);
				}
				if(object[3] != null) {
					bioAppDoc.setIntegrationPatternName(object[3].toString());
				} else {
					bioAppDoc.setIntegrationPatternName("");
				}
				
				if(object[5] != null) {
					bioAppDoc.setFileId(Integer.parseInt(object[5].toString()));
				} else {
					bioAppDoc.setFileId(0);
				}
			
				if(object[6] !=null) {
					bioAppDoc.setCreatedDate(object[6].toString());
				} else {
					bioAppDoc.setCreatedDate("");
				}
				
		
			bioAppDoc.setAppId(Integer.parseInt(object[7].toString()));
			if(object[8] !=null) {
				bioAppDoc.setSourceSystem(object[8].toString());
				if(bioAppDoc.getSourceSystem().length()>0)
					bioAppDoc.setSourceSystem(bioAppDoc.getSourceSystem().substring(0, bioAppDoc.getSourceSystem().length()-1));

			} else {
				bioAppDoc.setSourceSystem("");
			}
			if(object[9] !=null) {
				bioAppDoc.setTargetSystem(object[9].toString());
				if(bioAppDoc.getTargetSystem().length()>0)
					bioAppDoc.setTargetSystem(bioAppDoc.getTargetSystem().substring(0, bioAppDoc.getTargetSystem().length()-1));
			} else {
				bioAppDoc.setTargetSystem("");
			}
			if(object[10] !=null) {
				StringTokenizer st = new StringTokenizer(object[10].toString(),";");
				str = new StringBuilder();
				while (st.hasMoreTokens()) {
					stValue = st.nextToken();
					i=stValue.indexOf("(");
					j=stValue.indexOf(")");
					if(j-i ==1) {
						str.append(stValue.substring(0,i));
					} else {
						str.append(stValue);
					}
					str.append(";");
				}
				stValue = "";
				if(str.length() >1)
				 stValue = str.substring(0, str.length()-1);
				bioAppDoc.setCrNo(stValue);
				
			} else {
				bioAppDoc.setCrNo("");
			}
			if(object[11] !=null) {
				StringTokenizer st = new StringTokenizer(object[11].toString(),";");
				while (st.hasMoreTokens()) {
					stValue = st.nextToken();
					value = myCimsURL + stValue; 
					// below html code is done so that from UI , while user clicks on ITPD number , control will be taken to mycims document
				itpd.append("<a class=\"view_btn\" href='"+value);
				itpd.append("' target=\"_blank\">");
				itpd.append(stValue +"</a>");
				itpd.append(";");
				}
				if ( itpd.length() >0 ) {
					bioAppDoc.setItpdNo(itpd.substring(0, itpd.length()-1));
				}
			} else {
				bioAppDoc.setItpdNo("");
			}
			if(object[12] !=null) {
				bioAppDoc.setSourceType(object[12].toString());
				if(bioAppDoc.getSourceType().length()>0)
					bioAppDoc.setSourceType(bioAppDoc.getSourceType().substring(0, bioAppDoc.getSourceType().length()-1));
			} else {
				bioAppDoc.setSourceType("");
			}
			if(object[13] !=null) {
				bioAppDoc.setTargetType(object[13].toString());
				if(bioAppDoc.getTargetType().length()>0)
					bioAppDoc.setTargetType(bioAppDoc.getTargetType().substring(0, bioAppDoc.getTargetType().length()-1));
			} else {
				bioAppDoc.setTargetType("");
			}
			bioAppDocHistoryTempList.add(bioAppDoc);
			});
		return bioAppDocHistoryTempList;
	}
	

	

	@SuppressWarnings("unchecked")
	@Override
	// Get all the documents for the given appid
	public List<BioAppDocHistoryTemp> getAllBioAppDocHistoryDetailsByAppId(Integer appId) {
		List<BigDecimal> idsList = new ArrayList<BigDecimal>();
		idsList.add(new BigDecimal(appId));
		return this.getInterfaceDetails(idsList);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BioAppDocHistoryTemp> getInterfaceDetails(BUSearch buSearch) {
		List<BioAppDocHistoryTemp> bioAppDocHistoryList = new ArrayList<BioAppDocHistoryTemp>();
	
		List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
		// get  appid based on the various input provided in search option such as buisness unit , entity name etc.,
			if(buSearch.getEntityName() != null && ! buSearch.getEntityName().isEmpty() ) {
			appIdsList = this.entityManager.createNativeQuery("select distinct(app_id) from bio_etm_bu_app_es_info where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+" AND APPLICATION_ID="+Integer.parseInt(buSearch.getApplicationName())+" AND ENTITY_ID="+Integer.parseInt(buSearch.getEntityName())+"").getResultList();
			} else if( buSearch.getApplicationName() != null && ! buSearch.getApplicationName().isEmpty()) {
				appIdsList = this.entityManager.createNativeQuery("select distinct(app_id) from bio_etm_bu_app_es_info where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+" AND APPLICATION_ID="+Integer.parseInt(buSearch.getApplicationName())+"").getResultList();
			} else if( buSearch.getBusinessUnit() != null && ! buSearch.getBusinessUnit().isEmpty()) {
				appIdsList = this.entityManager.createNativeQuery("select distinct(app_id) from bio_etm_bu_app_es_info where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+"").getResultList();				
			}
			if(! appIdsList.isEmpty()) {
				//if appid list is not empty , use it to get the ITPD documents 
				bioAppDocHistoryList = this.getInterfaceDetails(appIdsList); 
			}
			// List of itpd documents (ids)
			return bioAppDocHistoryList;
	}
	
	private List<BioAppDocHistoryTemp> getInterfaceDetails(List<BigDecimal> appIdsList) {
		List<BioAppDocHistoryTemp> bioAppDocHistoryTempList = new ArrayList<BioAppDocHistoryTemp>();
		String myCimsURL = "https://mycims.biogen.com/edocslink/default.aspx?docid=";
		appIdsList.stream().forEach(ids->{	
			List<Object[]> docInfoList = this.entityManager.createNativeQuery("SELECT bla.app_name, badh.APP_INTEGRATION_ID, badh.PATTERN_ID, IP.PATTERN_NAME, IP.PATTERN_Description, badh.FILE_ID, FIL.FILE_NAME, badh.created_date, badh.app_id," + 
					"(SELECT LISTAGG(appl.application_name ||';') WITHIN GROUP (ORDER BY bu.application_id) FROM BIO_ETM_BU_APP_ES_INFO bu,  bio_etm_application appl,  BIO_ETM_SOURCE_TARGET_TYPE st WHERE app_id=badh.app_id and bu.application_id=appl.application_id and bu.SOURCE_TARGET_TYPE_ID=st.SOURCE_TARGET_TYPE_ID and bu.SOURCE_TARGET_TYPE_INDICATOR='S') AS sourceApplicatin," + 
					"(SELECT LISTAGG(appl.application_name ||';') WITHIN GROUP (ORDER BY bu.application_id) FROM BIO_ETM_BU_APP_ES_INFO bu,  bio_etm_application appl,  BIO_ETM_SOURCE_TARGET_TYPE st WHERE app_id=badh.app_id and bu.application_id=appl.application_id and bu.SOURCE_TARGET_TYPE_ID=st.SOURCE_TARGET_TYPE_ID and bu.SOURCE_TARGET_TYPE_INDICATOR='T') AS targetApplicatin," + 
					"(SELECT LISTAGG(CR_NUMBER||'('||IMPLEMENTATION_DATE||')'||';') WITHIN GROUP (ORDER BY APP_INTEGRATION_ID) FROM  bio_etm_CR_DETAILS WHERE APP_INTEGRATION_ID=badh.APP_INTEGRATION_ID) AS crDetails," + 
					"(SELECT LISTAGG(ITPD_NUMBER||';' ) WITHIN GROUP (ORDER BY APP_INTEGRATION_ID) FROM  bio_etm_ITPD_DETAILS WHERE APP_INTEGRATION_ID=badh.APP_INTEGRATION_ID) AS itpdDetails," + 
					"(SELECT LISTAGG(st.SOURCE_TARGET_NAME || ';') WITHIN GROUP (ORDER BY application_id) FROM BIO_ETM_BU_APP_ES_INFO bu,  BIO_ETM_SOURCE_TARGET_TYPE st WHERE app_id=badh.app_id and bu.SOURCE_TARGET_TYPE_ID=st.SOURCE_TARGET_TYPE_ID and bu.SOURCE_TARGET_TYPE_INDICATOR='S') as sourceType," + 
					"(SELECT LISTAGG(st.SOURCE_TARGET_NAME || ';') WITHIN GROUP (ORDER BY application_id) FROM BIO_ETM_BU_APP_ES_INFO bu,  BIO_ETM_SOURCE_TARGET_TYPE st WHERE app_id=badh.app_id and bu.SOURCE_TARGET_TYPE_ID=st.SOURCE_TARGET_TYPE_ID and bu.SOURCE_TARGET_TYPE_INDICATOR='T') as targetType"+ 
					" FROM   BIO_APP_INTEGRATION_DETAILS badh JOIN  bio_log_application bla ON bla.app_id = badh.app_id   JOIN  bio_etm_integration_pattern IP ON BADH.PATTERN_ID = IP.PATTERN_ID JOIN  BIO_APP_FILE FIL ON BADH.FILE_ID = FIL.ID WHERE badh.app_id ="+ids).getResultList();
			StringBuilder itpd = null;
			String value="";
			String stValue = "";
			for (Object[] object : docInfoList) {
				BioAppDocHistoryTemp  bioAppDoc = new BioAppDocHistoryTemp();
				itpd = new StringBuilder();
				bioAppDoc.setAppName(object[0].toString());
				if(object[1] != null) {
					bioAppDoc.setAppIntegrationId(Integer.parseInt(object[1].toString()));
				} else {
					bioAppDoc.setAppIntegrationId(0);
				}
				if(object[2] != null) {
					bioAppDoc.setIntegrationPatternId(Integer.parseInt(object[2].toString()));
				} else {
					bioAppDoc.setIntegrationPatternId(0);
				}
				if(object[3] != null) {
					bioAppDoc.setIntegrationPatternName(object[3].toString());
				} else {
					bioAppDoc.setIntegrationPatternName("");
				}
			
				if(object[5] != null) {
					bioAppDoc.setFileId(Integer.parseInt(object[5].toString()));
				} else {
					bioAppDoc.setFileId(0);
				}
			
				if(object[7] !=null) {
					bioAppDoc.setCreatedDate(object[7].toString());
				} else {
					bioAppDoc.setCreatedDate("");
				}
				if(object[7] !=null) {
					bioAppDoc.setCreatedDate(object[7].toString());
				} else {
					bioAppDoc.setCreatedDate("");
				}
		
			bioAppDoc.setAppId(Integer.parseInt(object[8].toString()));
			if(object[9] !=null) {
				bioAppDoc.setSourceSystem(object[9].toString());
			} else {
				bioAppDoc.setSourceSystem("");
			}
			if(object[10] !=null) {
				bioAppDoc.setTargetSystem(object[10].toString());
			} else {
				bioAppDoc.setTargetSystem("");
			}
			if(object[11] !=null) {
				bioAppDoc.setCrNo(object[11].toString());
			} else {
				bioAppDoc.setCrNo("");
			}
			if(object[12] !=null) {

				StringTokenizer st = new StringTokenizer(object[12].toString(),";");
				while (st.hasMoreTokens()) {
					stValue = st.nextToken();
					value = myCimsURL + stValue;
				itpd.append("<a class=\"view_btn\" href='"+value);
				itpd.append("' target=\"_blank\">");
				itpd.append(stValue +"</a>");
				itpd.append(";");
				}
				if ( itpd.length() >0 ) {
					bioAppDoc.setItpdNo(itpd.substring(0, itpd.length()-1));
				}
			} else {
				bioAppDoc.setItpdNo("");
			}
			if(object[13] !=null) {
				bioAppDoc.setSourceType(object[13].toString());
			} else {
				bioAppDoc.setSourceType("");
			}
			if(object[14] !=null) {
				bioAppDoc.setTargetType(object[14].toString());
			} else {
				bioAppDoc.setTargetType("");
			}
			bioAppDocHistoryTempList.add(bioAppDoc);
			}
		});
		System.out.println("bioAppDocHistoryTempList size:"+bioAppDocHistoryTempList.size());
		return bioAppDocHistoryTempList;
		}
	}
