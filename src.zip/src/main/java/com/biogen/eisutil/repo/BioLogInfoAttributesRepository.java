package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogInfoAttributes;
import com.biogen.eisutil.repo.custom.BioLogInfoAttributesCustomRepository;
//for table BIO_LOG_INFO_ATTRIBUTES
public interface BioLogInfoAttributesRepository extends JpaRepository<BioLogInfoAttributes, Integer>, BioLogInfoAttributesCustomRepository {

}
