package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioLogUser;
import com.biogen.eisutil.repo.custom.BioLogUserCustomRepository;
//for table BIO_LOG_USER
public interface BioLogUserRepository extends JpaRepository<BioLogUser, String>, BioLogUserCustomRepository {

}
