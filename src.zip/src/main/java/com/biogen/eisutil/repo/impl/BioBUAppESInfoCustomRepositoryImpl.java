package com.biogen.eisutil.repo.impl;

import java.util.ArrayList;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.BioBusinessInfoData;
import com.biogen.eisutil.repo.custom.BioBUAppESInfoCustomRepository;

//operate on table BIO_ETM_BU_APP_ES_INFO
public class BioBUAppESInfoCustomRepositoryImpl implements BioBUAppESInfoCustomRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<BioBusinessInfoData> getDetailsByAppId(Integer appId) {
		List<BioBusinessInfoData> bioLovs =  new ArrayList<BioBusinessInfoData>();
		// get Ent.Application Id , BUID , Application Id , entity id , source/target indicator for given app id
		List<Object[]> resultList = this.entityManager.createNativeQuery("select BU_APP_ES_ID, BU_ID, APPLICATION_ID, ENTITY_ID, ES_ID, APP_ID,SOURCE_TARGET_TYPE_ID, SOURCE_TARGET_TYPE_INDICATOR from BIO_ETM_BU_APP_ES_INFO WHERE app_id="+appId).getResultList();
		resultList.parallelStream().forEach(object-> {
			BioBusinessInfoData data = new BioBusinessInfoData();
			
			data.setBusinessId(Integer.parseInt(object[0].toString()));
			
			if(object[1] != null && object[1].toString().trim() != "") { 
				data.setBuId(Integer.parseInt(object[1].toString()));
			}
			if( object[2] != null && object[2].toString().trim() != "") {
				data.setApplicationId(Integer.parseInt(object[2].toString()));
			}
			if(object[3] != null && object[3].toString().trim() != "") {
				data.setEntityId(Integer.parseInt(object[3].toString()));
			}
			if(object[4] != null && object[4].toString().trim() != "") {
				data.setEsId(Integer.parseInt(object[4].toString()));
			}
			data.setAppId(Integer.parseInt(object[5].toString()));
			if(object[6] != null && object[6].toString().trim() != "") {
				data.setSourceTargetTypeId(Integer.parseInt(object[6].toString()));
			}
			if(object[7] != null && object[7].toString().trim() != "") {
				data.setSourceTargetTypeInd(object[7].toString());
			} else {
				
			}
			bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioBusinessInfoData> getBU_APPDetails() {
		List<BioBusinessInfoData> bioLovs =  new ArrayList<BioBusinessInfoData>();
		// get Ent.Application Id , BUID , Application Id , entity id , source/target indicator for given app id
		List<Object[]> resultList = this.entityManager.createNativeQuery("select BU_APP_ES_ID, BU_ID, APPLICATION_ID, ENTITY_ID, ES_ID, APP_ID,SOURCE_TARGET_TYPE_ID from BIO_ETM_BU_APP_ES_INFO").getResultList();
			resultList.stream().forEach(object-> {
			BioBusinessInfoData data = new BioBusinessInfoData();
			
			data.setBusinessId(Integer.parseInt(object[0].toString()));
			
			if(object[1] != null && object[1].toString().trim() != "") { 
				data.setBuId(Integer.parseInt(object[1].toString()));
			}
			if( object[2] != null && object[2].toString().trim() != "") {
				data.setApplicationId(Integer.parseInt(object[2].toString()));
			}
			if(object[3] != null && object[3].toString().trim() != "") {
				data.setEntityId(Integer.parseInt(object[3].toString()));
			}
			if(object[4] != null && object[4].toString().trim() != "") {
				data.setEsId(Integer.parseInt(object[4].toString()));
			}
			if(object[5] != null && object[5].toString().trim() != "") {
				data.setAppId(Integer.parseInt(object[5].toString()));
			}
			data.setAppId(Integer.parseInt(object[5].toString()));
			if(object[6] != null && object[6].toString().trim() != "") {
				data.setSourceTargetTypeId(Integer.parseInt(object[6].toString()));
			}
			bioLovs.add(data);
		});
		return bioLovs;		
	}

}
