package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogEnterpriseServiceEntity;
//for table bio_etm_enterpriseservice
public interface BioLogEnterpriseServiceRepository extends JpaRepository<BioLogEnterpriseServiceEntity, Integer> {

}
