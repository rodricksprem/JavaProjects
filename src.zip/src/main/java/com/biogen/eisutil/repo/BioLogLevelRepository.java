package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioLogLevel;
//for table BIO_LOG_LOGLEVEL
public interface BioLogLevelRepository extends JpaRepository<BioLogLevel, Integer> {

}
