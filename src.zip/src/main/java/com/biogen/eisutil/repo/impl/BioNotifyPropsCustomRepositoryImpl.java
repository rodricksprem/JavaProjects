package com.biogen.eisutil.repo.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.repo.custom.BioNotifyPropsCustomRepository;

public class BioNotifyPropsCustomRepositoryImpl implements BioNotifyPropsCustomRepository{
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findName() {
		return this.entityManager.
				createQuery("Select Distinct name from BioNotifyProps").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getNotifyIdList(int appId, String exCategory, String exType) {
		return this.entityManager.
				createQuery("Select id from BioNotify Where appId="+appId+" And exCategory='"+exCategory+"' And exType='"+exType+"'").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getExCategoryAndExTypeByAppId(int appId) {
		return this.entityManager.
				createQuery("Select exCategory, exType from BioNotify Where appId="+appId).
					getResultList();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getExCategoryAndExTypeByAppName(String appName) {
		return this.entityManager.
				createNativeQuery("Select bn.ex_Category, bn.ex_Type from Bio_Notify bn, bio_log_application bla Where bn.app_Id = bla.app_id and bla.app_name='"+appName+"'").
					getResultList();
	}
}
