package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.User;
//for table USERDETAILS
public interface UserRepository extends JpaRepository<User, Integer>{

}
