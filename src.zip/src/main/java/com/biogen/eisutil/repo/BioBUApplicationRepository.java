package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogBUApplicationEntity;
import com.biogen.eisutil.repo.custom.BioBUAppEntServiceNameCustomRepository;
//for table BIO_ETM_BU_APP_ES_INFO
public interface BioBUApplicationRepository extends JpaRepository<BioLogBUApplicationEntity, Integer>,BioBUAppEntServiceNameCustomRepository {

}
