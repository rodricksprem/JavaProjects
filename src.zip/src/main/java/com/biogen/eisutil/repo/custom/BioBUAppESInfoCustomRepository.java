package com.biogen.eisutil.repo.custom;

import java.util.List;

import com.biogen.eisutil.model.BioBusinessInfoData;
//interface for custom repository implementation to manipulate bio_etm_enterpriseservice table
public interface BioBUAppESInfoCustomRepository {
	
		
	public List<BioBusinessInfoData> getDetailsByAppId(Integer appId);
	
	public List<BioBusinessInfoData> getBU_APPDetails();
}
