package com.biogen.eisutil.repo.custom;

import java.util.List;

import com.biogen.eisutil.model.BioLOVsData;
//interface for custom repository manipulation  in table BIO_ETM_BU_APP_ES_INFO
public interface BioBUAppEntServiceNameCustomRepository {
	
	public List<Integer> getAppIdList(String buSearchParam);
	
	public List<String> getBUnit();
	
	public Integer getBUnit(String bunitName);
	
	public List<BioLOVsData> getBUDetails();
	
	public List<BioLOVsData> getApplicationDetails();
	
	public List<String> getAppNameByBUnit(String bunit);
	
	public List<BioLOVsData> getEntityDetails();
	
	public List<BioLOVsData> getEnterpriseServiceDetails();
	
	public List<BioLOVsData> getPatternDetails();
	
	
	
	public List<String> getEntityNameByBUnitAndAppName(String bunit, String appName);
	
	public List<String> getESNameByBUnitAndAppNameAndEntityName(String bunit, String appName, String entityname);
	
	public List<BioLOVsData> getApplicationDetailsByBUId(Integer buId);
	
	public List<BioLOVsData> getEntityDetailsByApplicationId(Integer applicatinId);
	
	public List<BioLOVsData> getEnterpriseServiceDetails(Integer entityId);
	
	public List<BioLOVsData> getSourceTargetTypeDetails();
}
