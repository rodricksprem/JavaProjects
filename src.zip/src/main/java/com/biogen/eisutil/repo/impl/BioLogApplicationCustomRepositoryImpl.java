package com.biogen.eisutil.repo.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.AppNameTemp;
import com.biogen.eisutil.model.BioCRDetailsData;
import com.biogen.eisutil.model.BioITPDDetailsData;
import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.repo.custom.BioLogApplicationCustomRepository;
// operates on BIO_LOG_APPLICATION table
public class BioLogApplicationCustomRepositoryImpl implements BioLogApplicationCustomRepository{
	
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	//select the records from 
	public List<Object[]> getAllApplicationDetails() {
		// get app details from BIO_LOG_APPLICATION
		return this.entityManager.
				createQuery("SELECT BLAG.appGroup, BLA.appName, BLAT.appType, BLL.loggerLevel, BLA.createdDate, BLA.updatedDate, BLA.appId " + 
						"FROM BioLogApplication BLA JOIN BioLogAppType BLAT ON " + 
						"BLA.appTypeId = BLAT.appTypeId JOIN BioLogAppGroup BLAG ON " + 
						"BLA.appGroupId = BLAG.appGroupId JOIN BioLogLevel BLL ON BLL.loggerId = BLA.loggerId Order By BLA.createdDate Desc").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAppTypeList() {
		// get apptypeid and app type from BIO_LOG_APP_TYPE
		return this.entityManager.
				createQuery("SELECT appTypeId,appType FROM BioLogAppType order by upper(appType)").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAppGroupList() {
		// get appgroupid  and app group type from BIO_LOG_APP_GROUP
		return this.entityManager.
				createQuery("SELECT appGroupId,appGroup FROM BioLogAppGroup order by upper(appGroup)").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getLogLevelList() {
		// get loggerid , logger level from BIO_LOG_LOGLEVEL
		return this.entityManager.
				createQuery("SELECT loggerId,loggerLevel FROM BioLogLevel order by upper(loggerLevel)").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAppNameList() {
		//get appid , appname from BIO_LOG_APPLICATION
		return this.entityManager.
				createQuery("SELECT appId,appName FROM BioLogApplication order by upper(appName)").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getServiceInvokerStatusList() {
		//get service status from BIO_LOG_MAIN
		return this.entityManager.
				createQuery("SELECT Distinct serviceStatus FROM BioLogMain WHERE TRIM(serviceStatus) IS NOT NULL").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getAppNameByAppGroupId(String appGroupName) {
		//get appid , appname from BIO_LOG_APPLICATION for the given appgroup
		return this.entityManager.
		        createNativeQuery("SELECT BLA.APP_ID, BLA.APP_NAME FROM BIO_LOG_APPLICATION BLA JOIN BIO_LOG_APP_GROUP BLAG ON BLAG.APP_GROUP_ID = BLA.APP_GROUP_ID WHERE BLAG.APP_GROUP='"+appGroupName+"' ORDER BY upper(BLA.APP_NAME) ASC").getResultList();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AppNameTemp> getInterfaceNameByAppName(String bunit, String appName, String entity) {
		List<AppNameTemp> bioLovs =  new ArrayList<AppNameTemp>();
		//get appid , appname from BIO_LOG_APPLICATION for the given bunit id, app id , entity id
		List<Object[]> resultList = this.entityManager.createNativeQuery("SELECT distinct(BLA.APP_ID), BLA.APP_NAME FROM BIO_LOG_APPLICATION BLA JOIN BIO_ETM_BU_APP_ES_INFO BLAG ON BLAG.app_id = BLA.app_id WHERE BLAG.BU_ID="+Integer.parseInt(bunit)+" AND  BLAG.APPLICATION_ID="+Integer.parseInt(appName)+" AND  BLAG.ENTITY_ID="+Integer.parseInt(entity)+" ORDER BY upper(BLA.APP_NAME) ASC").getResultList();
		AppNameTemp initaldata = new AppNameTemp();
		initaldata.setAppId("0");
		initaldata.setAppName("Interface Name");
		bioLovs.add(initaldata);
		resultList.forEach(object -> { 
			AppNameTemp	data = new AppNameTemp();
			data.setAppId(object[0].toString());
			
				data.setAppName(object[1].toString());
				bioLovs.add(data);
		});
		return bioLovs;	
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getIntegrationDetails(Integer appId) {
		return this.entityManager.	
		        createNativeQuery("select baid.APP_INTEGRATION_ID, baid.APP_ID, baid.PATTERN_ID,(SELECT id FROM bio_app_file WHERE app_id = baid.app_id) AS file_id from BIO_APP_INTEGRATION_DETAILS baid where  baid.app_id="+appId).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioITPDDetailsData> getITPDDetails(Integer appIntegrationId) {
		// get the TTPD details
		List<Object[]> result = entityManager.createNativeQuery("select ITPD_DETAILS_ID, APP_INTEGRATION_ID, ITPD_NUMBER, ITPD_DESCRIPTION from BIO_ETM_ITPD_DETAILS where  APP_INTEGRATION_ID="+appIntegrationId).getResultList();
		
		List<BioITPDDetailsData> itpdList = new ArrayList<BioITPDDetailsData>();
		result.stream().forEach(object-> {
			BioITPDDetailsData data  = new BioITPDDetailsData();
			data.setItpdID(Integer.parseInt(object[0].toString()));
			data.setAppIntegrationID(Integer.parseInt(object[1].toString()));
			if( object[2] != null && object[2].toString().trim() != "") {
				data.setItpdNumber(object[2].toString());
			}
			if(object[3] != null && object[3].toString().trim() != "") {
				data.setItpdDescription(object[3].toString());
			}
			itpdList.add(data);
		});
		return itpdList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioCRDetailsData> getCRDetails(Integer appIntegrationId) {
		// get CR details for the app_integration_id
		List<Object[]> result = entityManager.createNativeQuery("select CR_DETAILS_ID, APP_INTEGRATION_ID, CR_NUMBER, CR_DESCRIPTION, COMMENTS, IMPLEMENTATION_DATE from BIO_ETM_CR_DETAILS where  APP_INTEGRATION_ID="+appIntegrationId).getResultList();
		
		List<BioCRDetailsData> crList = new ArrayList<BioCRDetailsData>();
		
		result.stream().forEach(object ->{
			BioCRDetailsData data = new BioCRDetailsData();
			
			data.setCrID(Integer.parseInt(object[0].toString()));
			data.setAppIntegrationID(Integer.parseInt(object[1].toString()));
			if( object[2] != null && object[2].toString().trim() != "") {
				data.setCrNumber(object[2].toString());
			}
			if(object[3] != null && object[3].toString().trim() != "") {
				data.setCrDescription(object[3].toString());
			}
			if(object[4] != null && object[4].toString().trim() != "") {
				data.setComments(object[4].toString());
			}
			if(object[5] != null && object[5].toString().trim() != "") {
				data.setImplementationDate(object[5].toString());
			}
			crList.add(data);
			
	});
		return crList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioNotification> getNotificationDetails(Integer appId) {
		//get notification details for the given app id
		List<Object[]> result = entityManager.createNativeQuery("select ID,APP_ID, EX_CATEGORY, EX_TYPE from BIO_NOTIFY where APP_ID="+appId).getResultList();
		
		List<BioNotification> notifyList = new ArrayList<BioNotification>();
		
		
		result.stream().forEach(object-> {
		
			BioNotification data = new BioNotification();
			
			data.setNotifyId(Integer.parseInt(object[0].toString()));
			data.setAppId(Integer.parseInt(object[1].toString()));
			data.setExceptionCategory(object[2].toString());
			data.setExceptionType(object[3].toString());
			data.setNotificationType("");
			data.setThresholdEnabled("");
			data.setThresholdLimit("");
			data.setNotificationEnabled("");
			data.setFrequency("");
			data.setAggregationEnabled("");
			data.setAggregationCount("");
			data.setFromEmail("");
			data.setCcemail("");
			data.setToemail("");
			data.setTemplate("");
			//also iterate over varioud notification properties such as thershold limit for the given notification id and add it to the record
			List<Object[]> notifyPropResult = entityManager.createNativeQuery("select ID, NOTIFY_ID, NAME, VALUE from BIO_NOTIFY_PROPS where notify_id="+data.getNotifyId()).getResultList();
			notifyPropResult.stream().forEach(notifyObj ->{
				data.setNotifyPropsId(Integer.parseInt(notifyObj[0].toString()));
				if( notifyObj[2] != null && "SERVICE_ACTIVE".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setNotificationEnabled(notifyObj[3].toString());
					else 
						data.setNotificationEnabled("");
				}
				if(notifyObj[2] != null && "AGGR_ENABLED".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="")
						data.setAggregationEnabled(notifyObj[3].toString());
					else
						data.setAggregationEnabled("");
				}
				if(notifyObj[2] != null && "AGGR_MIN".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="")
						data.setAggregationCount(notifyObj[3].toString());
					else 
						data.setAggregationCount("");
				}
				if(notifyObj[2] != null && "THRESHOLD_ENABLED".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="")
						data.setThresholdEnabled(notifyObj[3].toString());
					else 
						data.setThresholdEnabled("");
				}
				if(notifyObj[2] != null && "THRESHOLD_LIMIT".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="")
						data.setThresholdLimit(notifyObj[3].toString());
					else 
						data.setThresholdLimit("");
				}
				if(notifyObj[2] != null && "JOB_TYPE".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setNotificationType(notifyObj[3].toString());
					else 
						data.setNotificationType("");
				}
				if(notifyObj[2] != null && "JOB_FREQ".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="")
						data.setFrequency(notifyObj[3].toString());
					else 
						data.setFrequency("");
				}
				if(notifyObj[2] != null && "FROM_EMAIL".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setFromEmail(notifyObj[3].toString());
					else 
						data.setFromEmail("");
				}
				if(notifyObj[2] != null && "CC_EMAIL".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setCcemail(notifyObj[3].toString());
					else 
						data.setCcemail("");
				}
				if(notifyObj[2] != null && "TO_EMAIL".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setToemail(notifyObj[3].toString());
					else 
						data.setToemail("");
				}
				if(notifyObj[2] != null && "TEMPLATE".equals(notifyObj[2].toString())) {
					if(notifyObj[3] != null && notifyObj[3] !="") 
						data.setTemplate(notifyObj[3].toString());
					else 
						data.setTemplate("");
				}
			});
			notifyList.add(data);
	});
		return notifyList;
	}

}
