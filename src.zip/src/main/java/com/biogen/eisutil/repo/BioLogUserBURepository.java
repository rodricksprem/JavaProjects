package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogUserBUEntity;
//for table BIO_ETM_USERBU_LINK
public interface BioLogUserBURepository extends JpaRepository<BioLogUserBUEntity, Integer> {

}
