package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogIntegrationDetailsEntity;
import com.biogen.eisutil.repo.custom.BioAppDocHistoryCustomRepository;
//for table BIO_APP_INTEGRATION_DETAILS
public interface BioLogIntegrationDetailsRepository extends JpaRepository<BioLogIntegrationDetailsEntity, Integer>, BioAppDocHistoryCustomRepository {

}
