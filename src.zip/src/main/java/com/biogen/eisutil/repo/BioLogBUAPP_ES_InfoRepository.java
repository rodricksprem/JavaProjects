package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioBUAppEntServiceEntity;
import com.biogen.eisutil.repo.custom.BioBUAppESInfoCustomRepository;
//for table BIO_ETM_BU_APP_ES_INFO
public interface BioLogBUAPP_ES_InfoRepository extends JpaRepository<BioBUAppEntServiceEntity, Integer>,BioBUAppESInfoCustomRepository {

}
