package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogCRDetailsEntity;
//for table bio_etm_CR_DETAILS
public interface BioLogCRDetailsRepository extends JpaRepository<BioLogCRDetailsEntity, Integer> {

}
