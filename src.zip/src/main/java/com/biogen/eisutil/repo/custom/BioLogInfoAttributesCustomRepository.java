package com.biogen.eisutil.repo.custom;

import java.util.List;
//interface for custom repository implementation to manipulate table BIO_LOG_INFO_ATTRIBUTES
public interface BioLogInfoAttributesCustomRepository {
	
	public List<String> getKeyValueDetails(String bioTransactionId);
	
	public List<String> getKeyValueDetails(String bioTransactionId, String keyValueDetails);
	
	public List<String> getKey();
	
	public List<String> getKeyByAppName(String appName);

}
