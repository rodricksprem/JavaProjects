package com.biogen.eisutil.repo.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.repo.custom.BioBUAppEntServiceNameCustomRepository;
// operate on bio_etm_enterpriseservice table
public class BioBUAppEntServiceNameCustomRepositoryImpl implements BioBUAppEntServiceNameCustomRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	// get list of unique appid for the given search params
	public List<Integer> getAppIdList(String buSearchParam) {
		return this.entityManager.
				createQuery("SELECT Distinct appId FROM BioBUAppEntServiceEntity Where "+buSearchParam).
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	//get list of unique businessunit , ignore null entries
	public List<String> getBUnit() {
		return this.entityManager.
				createQuery("SELECT Distinct businessUnit FROM BioBusinessUnitAppEntServiceName Where TRIM(businessUnit) IS NOT NULL order by upper(businessUnit)").
					getResultList();
	}
	

	@SuppressWarnings("unchecked")
	@Override
	//select list of business unit id 
	public Integer getBUnit(String bunitName) {
		List<BigDecimal> countList = this.entityManager. 
				createNativeQuery("SELECT BU_ID FROM BIO_ETM_BUSINESSUNIT Where UPPER(BU_NAME) ='"+bunitName.toUpperCase()+"'").
				getResultList();
		Integer buId =0;
		if(countList.size()>0) {
			buId = countList.get(0).intValue();
		}
		return buId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getBUDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get active buisness unit details
		List<Object[]> resultList = this.entityManager.createNativeQuery("select BU_ID, BU_NAME,BU_STATUS, BU_DESCRIPTION from bio_etm_businessunit WHERE bu_status='ACTIVE' AND BU_NAME IS NOT NULL ORDER BY BU_NAME").getResultList();
	
		resultList.stream().forEach(object -> {
			BioLOVsData data = new BioLOVsData();
			data.setId(Integer.parseInt(object[0].toString()));
			
				data.setName(object[1].toString());
			
			
				data.setStatus(object[2].toString());
			
				data.setDescription(object[3].toString());
				bioLovs.add(data);
		});
		
		return bioLovs;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getApplicationDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get active application details
		List<Object[]> resultList = this.entityManager.createNativeQuery("select APPLICATION_ID, APPLICATION_NAME,APPLICATION_STATUS, APPLICATION_Description, BU_ID from bio_etm_application WHERE APPLICATION_STATUS='ACTIVE' AND APPLICATION_NAME IS NOT NULL ORDER BY APPLICATION_NAME").getResultList();
		
		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			data.setId(Integer.parseInt(object[0].toString()));
			
				data.setName(object[1].toString());
			
			
				data.setStatus(object[2].toString());
			
				data.setDescription(object[3].toString());
				data.setRefId(Integer.parseInt(object[4].toString()));
				
				data.setText(object[0].toString()+" "+object[4].toString());
				bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getApplicationDetailsByBUId(Integer buId) {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get active application details for the given BuId
		List<Object[]> resultList = this.entityManager.createNativeQuery("select APPLICATION_ID, APPLICATION_NAME,APPLICATION_STATUS, APPLICATION_Description, BU_ID from bio_etm_application WHERE APPLICATION_STATUS='ACTIVE' AND APPLICATION_NAME IS NOT NULL AND BU_ID="+buId+" ORDER BY APPLICATION_NAME").getResultList();
		BioLOVsData initaldata = new BioLOVsData();
		initaldata.setId(0);
		initaldata.setName("Application");
		bioLovs.add(initaldata);
		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			data.setId(Integer.parseInt(object[0].toString()));
			
				data.setName(object[1].toString());
			
			
				data.setStatus(object[2].toString());
			
				data.setDescription(object[3].toString());
				data.setRefId(Integer.parseInt(object[4].toString()));
				
				data.setText(object[0].toString()+" "+object[4].toString());
				bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getEntityDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get all active entity details
		List<Object[]> resultList = this.entityManager.createNativeQuery("select ENTITY_ID, ENTITY_NAME,ENTITY_STATUS, ENTITY_Description from bio_etm_entity WHERE ENTITY_STATUS='ACTIVE' AND ENTITY_NAME IS NOT NULL ORDER BY ENTITY_NAME").getResultList();
		
		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			data.setId(Integer.parseInt(object[0].toString()));
			
				data.setName(object[1].toString());
			
			
				data.setStatus(object[2].toString());
			
				data.setDescription(object[3].toString());
				bioLovs.add(data);
		});
		return bioLovs;		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getEnterpriseServiceDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get all Enterprice service details 
		List<Object[]> resultList = this.entityManager.createNativeQuery("select ES_ID, ES_NAME,ES_STATUS, ES_Description from bio_etm_enterpriseservice WHERE ES_STATUS='ACTIVE' AND ES_NAME IS NOT NULL ORDER BY ES_NAME").getResultList();

		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			
			data.setId(Integer.parseInt(object[0].toString()));
			
			data.setName(object[1].toString());
			
			data.setStatus(object[2].toString());
			
			data.setDescription(object[3].toString());
			
			bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getPatternDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		List<Object[]> resultList = this.entityManager.createNativeQuery("select pattern_ID, Pattern_NAME,pattern_STATUS, pattern_Description from bio_etm_integration_pattern WHERE pattern_STATUS='ACTIVE' AND Pattern_NAME IS NOT NULL ORDER BY Pattern_NAME").getResultList();

		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			
			data.setId(Integer.parseInt(object[0].toString()));
			
			data.setName(object[1].toString());
			
			data.setStatus(object[2].toString());
			
			data.setDescription(object[3].toString());
			
			bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getSourceTargetTypeDetails() {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		List<Object[]> resultList = this.entityManager.createNativeQuery("select Source_Target_type_ID, Source_Target_NAME,Source_Target_STATUS, Source_Target_Description from bio_etm_source_target_type WHERE Source_Target_STATUS='ACTIVE' AND Source_Target_NAME IS NOT NULL ORDER BY Source_Target_NAME").getResultList();

		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();
			
			data.setId(Integer.parseInt(object[0].toString()));
			
			data.setName(object[1].toString());
			
			data.setStatus(object[2].toString());
			
			data.setDescription(object[3].toString());
			
			bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAppNameByBUnit(String bunit) {
		//get Application Name for the given bunit id
		return this.entityManager.
				createQuery("SELECT Distinct applicationName FROM BioBusinessUnitAppEntServiceName Where businessUnit='"+bunit+"' And TRIM(applicationName) IS NOT NULL order by upper(applicationName)").
					getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getEntityNameByBUnitAndAppName(String bunit, String appName) {
		//get Entity Details for the given application name
		return this.entityManager.
				createQuery("SELECT Distinct entityName FROM BioBusinessUnitAppEntServiceName Where businessUnit='"+bunit+"' And applicationName='"+appName+"' And TRIM(entityName) IS NOT NULL order by upper(entityName)").
					getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getEntityDetailsByApplicationId(Integer applicationId) {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		//get Entity Details for the given application id
		List<Object[]> resultList = this.entityManager.createNativeQuery("select distinct be.ENTITY_ID, be.ENTITY_NAME,be.ENTITY_STATUS, be.ENTITY_Description from bio_etm_entity be,bio_etm_bu_app_es_info bu WHERE ENTITY_STATUS='ACTIVE' AND ENTITY_NAME IS NOT NULL AND be.ENTITY_ID = BU.ENTITY_ID AND bu.APPLICATION_ID =" +applicationId+" ORDER BY ENTITY_NAME").getResultList();
		BioLOVsData initaldata = new BioLOVsData();
		initaldata.setId(0);
		initaldata.setName("Entity");
		bioLovs.add(initaldata);
		resultList.stream().forEach(object-> {
			BioLOVsData data = new BioLOVsData();	
			data.setId(Integer.parseInt(object[0].toString()));
			
				data.setName(object[1].toString());
			
			
				data.setStatus(object[2].toString());
			
				data.setDescription(object[3].toString());
				bioLovs.add(data);
		});
		return bioLovs;		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BioLOVsData> getEnterpriseServiceDetails(Integer entityId) {
		List<BioLOVsData> bioLovs =  new ArrayList<BioLOVsData>();
		// get EnterpriseServiceDetails for the given Entity id
		List<Object[]> resultList = this.entityManager.createNativeQuery("select bes.ES_ID, bes.ES_NAME,bes.ES_STATUS, bes.ES_Description from bio_etm_enterpriseservice bes WHERE ES_STATUS='ACTIVE' AND ES_NAME IS NOT NULL AND bes.es_ID in (select distinct(es_ID) from bio_etm_bu_app_es_info where entity_ID = "+entityId+") ORDER BY ES_NAME").getResultList();
		BioLOVsData initaldata = new BioLOVsData();
		initaldata.setId(0);
		initaldata.setName("Enterprise Service");
		bioLovs.add(initaldata);
		for (Object[] object : resultList) {
			BioLOVsData data = new BioLOVsData();
			
			data.setId(Integer.parseInt(object[0].toString()));
			
			data.setName(object[1].toString());
			
			data.setStatus(object[2].toString());
			
			data.setDescription(object[3].toString());
			
			bioLovs.add(data);
		}
		return bioLovs;		
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getESNameByBUnitAndAppNameAndEntityName(String bunit, String appName, String entityname) {
		return this.entityManager.
				createQuery("SELECT Distinct entServiceName FROM BioBusinessUnitAppEntServiceName Where businessUnit='"+bunit+"' And applicationName='"+appName+"' And entityName='"+entityname+"' And TRIM(entServiceName) IS NOT NULL order by upper(entServiceName)").
					getResultList();
	}
	
}
