package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioNotify;
import com.biogen.eisutil.repo.custom.BioNotifyCustomRepository;
//for table BIO_NOTIFY
public interface BioNotifyRepository extends JpaRepository<BioNotify, Integer>,BioNotifyCustomRepository {

	
}
