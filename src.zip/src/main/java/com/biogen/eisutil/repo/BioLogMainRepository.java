package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioLogMain;
import com.biogen.eisutil.repo.custom.BioLogCustomRepository;
//for table BIO_LOG_MAIN
public interface BioLogMainRepository extends JpaRepository<BioLogMain, String>, BioLogCustomRepository {

}
