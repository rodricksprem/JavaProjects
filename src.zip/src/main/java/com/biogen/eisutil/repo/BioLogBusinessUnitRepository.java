package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biogen.eisutil.dao.BioLogBusinessUnitEntity;
import com.biogen.eisutil.repo.custom.BioBUAppESInfoCustomRepository;
//for table bio_etm_businessunit
public interface BioLogBusinessUnitRepository extends JpaRepository<BioLogBusinessUnitEntity, Integer>,BioBUAppESInfoCustomRepository {

}
