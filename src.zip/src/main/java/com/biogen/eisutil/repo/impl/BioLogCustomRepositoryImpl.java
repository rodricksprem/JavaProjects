package com.biogen.eisutil.repo.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.biogen.eisutil.model.BioLogTemp;
import com.biogen.eisutil.repo.custom.BioLogCustomRepository;

public class BioLogCustomRepositoryImpl implements BioLogCustomRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<BioLogTemp> getLogDetailsByList() {
				List<Object[]> logDetailsList = new ArrayList<Object[]>();
		logDetailsList = this.entityManager.createQuery("select col_0_0_,col_1_0_,col_2_0_,col_3_0_,col_4_0_,col_5_0_,col_6_0_,col_7_0_ from (select a.col_0_0_,col_1_0_,col_2_0_,col_3_0_,col_4_0_,col_5_0_,col_6_0_, col_7_0_, rownum r from ((SELECT   blm.biogentransid AS col_0_0_,  blag.app_group AS col_1_0_,  bla.app_name AS col_2_0_,  blm.service_invoker AS col_3_0_,  blm.service_status AS col_4_0_,  blm.service_start_time AS col_5_0_,  blm.service_end_time   AS col_6_0_,  sub.message            AS col_7_0_,  bnh.biogentransid      AS notificationExists from bio_log_main blm, bio_log_application bla, bio_log_app_group blag,bio_notify_history bnh,(select biogentransid, listagg(Key || ':' || Value, '|') within group (order by biogentransid) message from bio_log_info_attributes group by biogentransid) sub where bla.app_id=blm.app_id and bla.app_group_id = blag.app_group_id AND blm.biogentransid = sub.biogentransid AND blm.biogentransid = bnh.biogentransid(+)) order by blm.service_start_time DESC) a where rownum <=30 ) where r >0").getResultList();


		List<BioLogTemp> bioLogTemplist = new ArrayList<BioLogTemp>();

		for (Object[] object : logDetailsList) {
					
					BioLogTemp bioLogTemp = new BioLogTemp();
					if(object[0] != null && object[0].toString().trim() != "")
					{
						bioLogTemp.setBioTransId(object[0].toString().trim());
					}
					if(object[1] != null && object[1].toString().trim() != "")
					{
						bioLogTemp.setAppGroup(object[1].toString());
					}
					else
					{
						bioLogTemp.setAppGroup("");
					}
					
					if(object[2] != null && object[2].toString().trim() != "")
					{
						bioLogTemp.setAppName(object[2].toString());
					}
					else
					{
						bioLogTemp.setAppName("");
					}
					
					if(object[3] != null && object[3].toString().trim() != "")
					{
						bioLogTemp.setServiceInvoker(object[3].toString());
					}
					else
					{
						bioLogTemp.setServiceInvoker("");
					}
					
					if(object[4] != null && object[4].toString().trim() != "")
					{
						bioLogTemp.setServiceInvokerStatus(object[4].toString());
					}
					else
					{
						bioLogTemp.setServiceInvokerStatus("");
					}
					
					if(object[5] != null && object[5].toString().trim() != "")
					{
						bioLogTemp.setStartTime(object[5].toString());
					}
					else
					{
						bioLogTemp.setStartTime("");
					}
					
		          
					if(object[6] != null && object[6].toString().trim() != "")
					{
						bioLogTemp.setEndTime(object[6].toString());
					}
					else
					{
						bioLogTemp.setEndTime("");
					}
					if ( bioLogTemp.getEndTime().isEmpty() ) {
						bioLogTemp.setServiceInvokerStatus("INPROGRESS");
					}
					if(object[7] != null && object[7].toString().trim() != "")
					{
						bioLogTemp.setMessage(object[7].toString());
					}
					else
					{
						bioLogTemp.setMessage("");
					}
					if(object[8] != null && object[8].toString().trim() != "")
					{
						bioLogTemp.setNotificationSize(1);
					}
					else
					{
						bioLogTemp.setNotificationSize(0);
					}
					bioLogTemplist.add(bioLogTemp);
				}
		return bioLogTemplist;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getLogDetails() {
		
		
		List<Object[]> logDetailsList = new ArrayList<Object[]>();
		logDetailsList = this.entityManager.createQuery(
				"SELECT BLM.biogenTransId, BLAG.appGroup, BLA.appName, BLM.serviceInvoker, BLM.serviceStatus, BLM.serviceStartTime, BLM.serviceEndTime FROM BioLogMain BLM JOIN BioLogApplication BLA ON BLA.appId = BLM.appId JOIN BioLogAppGroup BLAG ON BLAG.appGroupId = BLA.appGroupId  Order By BLM.serviceStartTime  DESC").getResultList();
			if(logDetailsList != null && logDetailsList.size() >30) {
				return logDetailsList.subList(0, 30);
			} else  {
				return logDetailsList;
			}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getLogDetailsByAdvancedSearch(String adSearchParams) {
		return this.entityManager.createQuery(
				"SELECT BLM.biogenTransId, BLAG.appGroup, BLA.appName, BLM.serviceInvoker, BLM.serviceStatus, BLM.serviceStartTime, BLM.serviceEndTime FROM BioLogMain BLM JOIN BioLogApplication BLA ON BLA.appId = BLM.appId JOIN BioLogAppGroup BLAG ON BLAG.appGroupId = BLA.appGroupId Where "+adSearchParams+" Order By BLM.serviceStartTime DESC")
				.getResultList();
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getDetailedLogDetails(String bioTransId) {
		return this.entityManager.createNativeQuery(
				"SELECT BLD.MESSAGE_CODE, BLD.MESSAGE_DESCRIPTION, BLL.LOGGER_LEVEL, BLP.LOG_PAYLOAD, BLD.SERVICE_INVOKER, BLD.STATUS, BLD.RECEIVED_TIME FROM " + 
				"BIO_LOG_DETAIL BLD LEFT JOIN BIO_LOG_PAYLOAD BLP ON BLD.ID=BLP.BIO_LOG_DETAIL_ID JOIN BIO_LOG_LOGLEVEL BLL ON BLL.LOGGER_ID = BLD.LOG_LEVEL WHERE " + 
				"BLD.BIOGENTRANSID = '"+bioTransId+"' AND BLD.TARGET_SYSTEM_ID = 0 ORDER BY BLD.RECEIVED_TIME ASC")
				.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getDetailedTargetSystemLogDetails(String bioTransId, int bioLogTargetSystemId) {
		return this.entityManager.createNativeQuery(
				"SELECT BLD.SERVICE_INVOKER, BLD.MESSAGE_CODE, BLD.MESSAGE_DESCRIPTION, BLD.STATUS, BLD.RECEIVED_TIME, BLL.LOGGER_LEVEL, BLIA.KEY ,BLIA.VALUE, BLP.LOG_PAYLOAD," + 
				"BLTS.TARGET_SYSTEM_NAME, BLTS.TARGET_SERVICE_STATUS, BLTS.TARGET_SERVICE_START_TIME, BLTS.TARGET_SERVICE_END_TIME FROM " + 
				"BIO_LOG_DETAIL BLD LEFT JOIN BIO_LOG_PAYLOAD BLP ON BLD.ID=BLP.BIO_LOG_DETAIL_ID " + 
				"JOIN BIO_LOG_LOGLEVEL BLL ON BLL.LOGGER_ID = BLD.LOG_LEVEL LEFT JOIN BIO_LOG_INFO_ATTRIBUTES BLIA ON BLIA.BIO_LOG_DETAIL_ID=BLD.ID " + 
				"JOIN BIO_LOG_TARGET_SYSTEMS BLTS ON BLTS.ID = BLD.TARGET_SYSTEM_ID WHERE " + 
				"BLD.BIOGENTRANSID = '"+bioTransId+"' AND BLD.TARGET_SYSTEM_ID ="+bioLogTargetSystemId+" ORDER BY BLD.RECEIVED_TIME ASC")
				.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BigDecimal> getBioLogTargetSystemIdByBioTransId(String bioTransId) {
		return this.entityManager.createNativeQuery(
				"SELECT DISTINCT TARGET_SYSTEM_ID FROM BIO_LOG_DETAIL WHERE BIOGENTRANSID='"+bioTransId+"' AND TARGET_SYSTEM_ID != 0 ORDER BY TARGET_SYSTEM_ID ASC")
				.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getLogDetailsByBusinessUnitSearch(String buSearchParams,Integer duration) {
		return this.entityManager.createQuery(
				"SELECT BLM.biogenTransId, BLAG.appGroup, BLA.appName, BLM.serviceInvoker, BLM.serviceStatus, BLM.serviceStartTime, BLM.serviceEndTime FROM BioLogMain BLM JOIN BioLogApplication BLA ON BLA.appId = BLM.appId JOIN BioLogAppGroup BLAG ON BLAG.appGroupId = BLA.appGroupId Where trunc(BLM.serviceStartTime) < sysdate - "+duration +" and BLM.appId IN ("+buSearchParams+") Order By BLM.serviceStartTime DESC")
				.getResultList();
	}
	
	@Override
	public int getAppId(String appName) {
		//get appid for the given app name
		StringBuilder query = new StringBuilder("select app_id from Bio_Log_application where UPPER(app_name)=UPPER('"+appName+"')");
		List<Object> countList = this.entityManager.createNativeQuery(query.toString()).getResultList();
		int appId = 0;
		if(countList.size()>0) {
			appId = Integer.parseInt(countList.get(0).toString());
		}
		return appId;
	}
}
