package com.biogen.eisutil.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.biogen.eisutil.dao.BioNotifyProps;
import com.biogen.eisutil.repo.custom.BioNotifyPropsCustomRepository;

//for table BIO_NOTIFY_PROPS
public interface BioNotifyPropsRepository extends JpaRepository<BioNotifyProps, Integer>, BioNotifyPropsCustomRepository {
	
}
