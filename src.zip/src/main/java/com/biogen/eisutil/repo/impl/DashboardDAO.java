package com.biogen.eisutil.repo.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import com.biogen.eisutil.model.BUSearch;
import com.biogen.eisutil.model.BarChart;
import com.biogen.eisutil.model.BarChartDataList;
import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.model.ChartData;
import com.biogen.eisutil.model.CountData;
import com.biogen.eisutil.model.Counter;
import com.biogen.eisutil.model.SankeyGraphCount;
import com.biogen.eisutil.model.SankeyGraphNode;

@org.springframework.transaction.annotation.Transactional
@Repository
public class DashboardDAO {

	private final JdbcTemplate jdbcTemplate;
	private final int defaultDuration = 7;
    private HashMap<String,String> buisnessUnitHashMap = new HashMap<String,String>();
    private HashMap<String,String> applicationHashMap = new HashMap<String,String>();
    private HashMap<String,String> entityNameHashMap = new HashMap<String,String>();
    private boolean isDurationNeedToBeConsidered ;
    
    @Autowired
	public DashboardDAO(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
    @Value("${app.failedStausValues}")
    private String failedStatus;
	public List<ChartData> getAllDonutChartData(List<BioLOVsData> buDataList) {

		final List<ChartData> donutChartList = new ArrayList<ChartData>();
		Object[] params = new Object[0];
		buDataList.parallelStream().forEach(data -> {
			
	
		StringBuffer	query = new StringBuffer(
					"SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE BLM.SERVICE_START_TIME >= sysdate- "+defaultDuration +" and BLM.APP_ID IN \r\n" + 
					"							(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID= " +data.getId()+ 
					"							)) AS APP_COUNT,  \r\n" + 
					"                            (SELECT round(MEDIAN(sysdate + (service_end_time- service_start_time)*24*60*60 - sysdate),3) \r\n" + 
					"                            FROM BIO_LOG_MAIN BLM  WHERE BLM.SERVICE_START_TIME >= sysdate- "+defaultDuration+" and BLM.APP_ID IN \r\n" + 
					"							(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID= " + data.getId()+ 
					"							)) AS MEDIAN_VAL                      \r\n" + 
					"                            FROM bio_etm_bu_app_es_info BBAEI where BBAEI.BU_ID =");
			query.append(data.getId());
			final List<Integer> countList = new ArrayList<Integer>();
		
			final List<BigDecimal> medVal = new ArrayList<BigDecimal>(); 
			try {

				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(2) > 0) {
							countList.add(rs.getInt(2));
						}
						if( rs.getFloat(3) > 0 ) {
							medVal.add(rs.getBigDecimal(3));
						}
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			ChartData chartData = new ChartData();
			chartData.setName(data.getName());
			chartData.setId(data.getName());
			if (countList.size() > 0) {
				chartData.setDrilldown(data.getName());
				chartData.setY(countList.get(0));
			} else {
				chartData.setY(0);
			}
			chartData.setAvgTime(-1);
		
			chartData.setData(this.getDonutChartData(data.getId().toString(), new BUSearch(), new ArrayList<BioLOVsData>()));
			System.out.println(chartData.toString());
			donutChartList.add(chartData);
		});

		return donutChartList;
	}
	
	public List<ChartData> getAllDonutChartDataByDate(List<BioLOVsData> buDataList,  BUSearch buSearch) {

		final List<ChartData> donutChartList = new ArrayList<ChartData>();
		Object[] params = new Object[0];
		String searchDate = "";
		String queryDateString ="";
		
		if (buSearch.getStartDate() != null && buSearch.getStartDate().length() > 0) {
			
				String startDate = buSearch.getStartDate().trim().replace("T", " ");
				System.out.println(buSearch.getStartDate());
				startDate = startDate.substring(0, startDate.length() - 5);
				queryDateString =
						" and trunc(BLM.service_start_time)>=TO_DATE('" + startDate + "','YYYY-MM-DD HH24:MI:SS')";
				searchDate = buSearch.getStartDate();
			}
			if (buSearch.getEndDate() != null && buSearch.getEndDate().length() > 0) {
				System.out.println(buSearch.getEndDate());
				String endDate = buSearch.getEndDate().trim().replace("T", " ");
				endDate = endDate.substring(0, endDate.length() - 5);
				if (searchDate.equals(buSearch.getEndDate())) {
					queryDateString =
							" and trunc(BLM.service_start_time)<TO_DATE('" + endDate + "','YYYY-MM-DD HH24:MI:SS')+1";
					
				} else {
					queryDateString =
							" and trunc(BLM.service_start_time)<=TO_DATE('" + endDate + "','YYYY-MM-DD HH24:MI:SS')";
				}
			}
		
		
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
			queryDateString =
					" and BLM.service_start_time >= sysdate - "+buSearch.getDuration();
			}
		final String queryParam = queryDateString;
		
		buDataList.parallelStream().forEach(data-> {
			StringBuffer query = new StringBuffer(
					"SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE BLM.APP_ID IN " + 
					"							(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID= " +data.getId()+ 
					"							) ");
			
			query.append(queryParam);
			query.append(") AS APP_COUNT,  " + 
					"                            (SELECT round(MEDIAN(sysdate + (service_end_time- service_start_time)*24*60*60 - sysdate),3) " + 
					"                            FROM BIO_LOG_MAIN BLM WHERE BLM.APP_ID IN " + 
					"							(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID= " + data.getId()+ 
					"							)");
			query.append(queryParam);
			query.append(") AS MEDIAN_VAL " + 
					"                            FROM bio_etm_bu_app_es_info BBAEI where BBAEI.BU_ID =");
			query.append(data.getId());
			final List<Integer> countList = new ArrayList<Integer>();
			System.out.println("query:"+query);
			final List<BigDecimal> medVal = new ArrayList<BigDecimal>(); 
			try {

				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(2) > 0) {
							countList.add(rs.getInt(2));
						}
						if( rs.getFloat(3) > 0 ) {
							medVal.add(rs.getBigDecimal(3));
						}
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			ChartData chartData = new ChartData();
			chartData.setName(data.getName());
			chartData.setId(data.getName());
			if (countList.size() > 0) {
				chartData.setDrilldown(data.getName());
				chartData.setY(countList.get(0));
			} else {
				chartData.setY(0);
			}
			chartData.setAvgTime(-1);
		
			chartData.setData(this.getDonutChartData(data.getId().toString(), buSearch, new ArrayList<BioLOVsData>()));
			System.out.println(chartData.toString());
			donutChartList.add(chartData);
		});

		return donutChartList;
	}

	public List<ChartData> getDonutChartData(String busUnit, BUSearch buSearch, List<BioLOVsData> buDataList) {
		final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
		List<BioLOVsData> appList = new ArrayList<BioLOVsData>();
		StringBuffer query = new StringBuffer();
		
		Object[] params = new Object[0];
		if (busUnit != null && busUnit.length() > 0) {
			 query = new StringBuffer(
					"select distinct(APPLICATION_ID),(SELECT APPLICATION_NAME FROM bio_etm_application BA WHERE BA.APPLICATION_ID = BU.APPLICATION_ID) AS APPLICATION_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU.BU_Id=");
			query.append(busUnit);
			query.append(" AND source_target_type_indicator in ('S','T') ");
			System.out.println(query);
			try {
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						BioLOVsData data = new BioLOVsData();
						data.setId(rs.getInt(1));
						data.setName(rs.getString(2));
						newAppList.add(data);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			appList = newAppList;
			final List<ChartData> donutChartList = new ArrayList<ChartData>();
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			
			appList.parallelStream().forEach(data -> {
				StringBuffer newQuery = new StringBuffer();
				
				
				String busnUnit = busUnit;
				final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
				if (busnUnit != null && busnUnit.length() > 0) {
					newQuery= new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="
							+ Integer.parseInt(busnUnit) + " AND APPLICATION_ID=" + data.getId() + " AND source_target_type_indicator in ('S','T') ");
				} else {
					 busnUnit = data.getId().toString();
					 newQuery= new StringBuffer( "select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID=" + data.getId() + "");
				}
				 System.out.println("getDonutChartData query:"+newQuery.toString());

				try {
					jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							appIdsList.add(rs.getBigDecimal("app_id"));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				ChartData chartData = new ChartData();
				chartData.setName(data.getName());
				chartData.setDrilldown(data.getName());
				chartData.setId(data.getName());
				chartData.setData(new ArrayList<ChartData>());
				if (!appIdsList.isEmpty()) {
					List<String> newappIdList = new ArrayList<String>();
					for (BigDecimal ids : appIdsList) {
						newappIdList.add(String.valueOf(ids));
					}
					String appIds = String.join(",", newappIdList);
					newQuery= new StringBuffer("select count(biogentransid),  round(MEDIAN(sysdate + (service_end_time- service_start_time)*24*60*60 - sysdate),3) as medVal from bio_log_main where app_id in (");
					newQuery.append(appIds).append(")");
					String searchDate = "";
					
					if (buSearch.getStartDate() != null && buSearch.getStartDate().length() > 0) {
							String startDate = buSearch.getStartDate().trim().replace("T", " ");
							startDate = startDate.substring(0, startDate.length() - 5);
							newQuery.append(
									" and trunc(service_start_time)>=TO_DATE('" + startDate + "','YYYY-MM-DD HH24:MI:SS')");
							searchDate = buSearch.getStartDate();
							
					}
					if (buSearch.getEndDate() != null && buSearch.getEndDate().length() > 0) {
							String endDate = buSearch.getEndDate().trim().replace("T", " ");
							endDate = endDate.substring(0, endDate.length() - 5);
							
							if (searchDate.equals(buSearch.getEndDate())) {
								newQuery.append(
										" and trunc(service_start_time)<TO_DATE('" + endDate + "','YYYY-MM-DD HH24:MI:SS')+1");
							} else {
								newQuery.append(
										" and trunc(service_start_time)<=TO_DATE('" + endDate + "','YYYY-MM-DD HH24:MI:SS')");
							}
					}
					
					
			
					
			if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
				newQuery.append(
					" and trunc(service_start_time) > sysdate - "+buSearch.getDuration());
			}
					
					System.out.println("total logging query by application:"+newQuery.toString());

					try {
						final List<Integer> countList = new ArrayList<Integer>();
						final List<BigDecimal> medVal = new ArrayList<BigDecimal>();
						jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
							public void processRow(ResultSet rs) throws SQLException {

								if (rs.getInt(1) > 0) {
									countList.add(rs.getInt(1));
								}
								if( rs.getFloat(2) > 0 ) {
									medVal.add(rs.getBigDecimal(2));
								}
							}
						});
						if (countList.size() > 0) {
							chartData.setY(countList.get(0));
						} else
							chartData.setY(0);
						chartData.setAvgTime(-1);
					
					} catch (Exception ex) {
						ex.printStackTrace();
					}

				}

				chartData.setData(this.getDonutChartData(busnUnit, data.getId().toString(), buSearch));
				chartData.toString();
				donutChartList.add(chartData);

			});
			return donutChartList;
		} else {
			System.out.println("buisness unit is not provided");
			return this.getAllDonutChartDataByDate(buDataList, buSearch);
		}
		
	}
	
	public List<ChartData> getDonutChartData(String busUnit, String appName, BUSearch buSearch) {
		final List<BioLOVsData> appList = new ArrayList<BioLOVsData>();
		Object[] params = new Object[0];
	
		StringBuffer query = new StringBuffer("select distinct(ENTITY_ID),(SELECT ENTITY_NAME FROM bio_etm_entity BA WHERE BA.ENTITY_ID = BU.ENTITY_ID) AS ENTITY_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" and entity_id is not null  AND source_target_type_indicator in ('S','T') ");
		System.out.println("1st query query:"+query);
		
		try {
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					BioLOVsData data = new BioLOVsData();

					data.setId(rs.getInt(1));
					data.setName(rs.getString(2));
					appList.add(data);
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		final List<ChartData> donutChartList = new ArrayList<ChartData>();
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		appList.parallelStream().forEach(obj ->{
			final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
			StringBuffer newQuery = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+obj.getId()+" AND source_target_type_indicator in ('S','T') ");
			System.out.println("entity name:"+obj.getName()+"------newQuery:"+newQuery);
			try {
				jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						appIdsList.add(rs.getBigDecimal("app_id"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			ChartData chartData = new ChartData();
			chartData.setName(obj.getName());
			chartData.setId(obj.getName());
			chartData.setData(new ArrayList<ChartData>());

			if(! appIdsList.isEmpty()) {
			List<String> newappIdList = new ArrayList<String>();
			for(BigDecimal ids: appIdsList){
				newappIdList.add(String.valueOf(ids));
			}
			String appIds = String.join(",", newappIdList);
			
			newQuery = new StringBuffer("select count(biogentransid), round(MEDIAN(sysdate + (service_end_time- service_start_time)*24*60*60 - sysdate),3) as medVal from bio_log_main where app_id in (").append(appIds).append(")");
			String searchDate ="";
			
			
			if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
				String startDate = buSearch.getStartDate().trim().replace("T", " ");
				startDate = startDate.substring(0, startDate.length()-5);
				newQuery.append(" and trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
				searchDate = buSearch.getStartDate();
				
			}
			if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
				String endDate = buSearch.getEndDate().trim().replace("T", " ");
				endDate = endDate.substring(0, endDate.length()-5);
				
				if(searchDate.equals(buSearch.getEndDate())) {
					newQuery.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
				} else {
					newQuery.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
				}
			}
	
		if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
			newQuery.append(
				" and trunc(service_start_time) > sysdate - "+buSearch.getDuration());
		}
				
				System.out.println("total logging query by Entity  -:"+newQuery.toString());
			try {
				final List<Integer> countList = new ArrayList<Integer>();
				final List<BigDecimal> medVal = new ArrayList<BigDecimal>();
				jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(1) > 0) {
							countList.add(rs.getInt(1));
						}
						if( rs.getFloat(2) > 0 ) {
							medVal.add(rs.getBigDecimal(2));
						}
					}
				});
				if (countList.size() > 0) {
					chartData.setY(countList.get(0));
				} else
					chartData.setY(0);
				if (medVal.size() > 0) {
					chartData.setAvgTime(medVal.get(0).floatValue());
				} else {
					chartData.setAvgTime(0);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			}
	        chartData.toString();			
			donutChartList.add(chartData);			
		});
		return donutChartList;
	}
	
	public List<ChartData> getDonutChartData(String busUnit, String appName, String entity, BUSearch buSearch) {
		final List<BioLOVsData> appList = new ArrayList<BioLOVsData>();
		StringBuffer query = new StringBuffer();
		Object[] params = new Object[0];
		query = new StringBuffer("select distinct(ES_ID),(SELECT ES_NAME FROM bio_etm_enterpriseservice BA WHERE BA.ES_ID = BU.ES_ID) AS ES_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+"");
		try {
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					BioLOVsData data = new BioLOVsData();

					data.setId(rs.getInt(1));
					data.setName(rs.getString(2));
					appList.add(data);
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
		final List<ChartData> donutChartList = new ArrayList<ChartData>();
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		
		appList.parallelStream().forEach(obj-> {
			StringBuffer newQuery =  new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+" AND ES_ID="+obj.getId() +"");
			try {
				jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						appIdsList.add(rs.getBigDecimal("app_id"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			ChartData chartData = new ChartData();
			chartData.setName(obj.getName());
			
			chartData.setId(obj.getName());
			chartData.setData(new ArrayList<ChartData>());
			if(! appIdsList.isEmpty()) {
			List<String> newappIdList = new ArrayList<String>();
			for(BigDecimal ids: appIdsList){
				newappIdList.add(String.valueOf(ids));
			}
			String appIds = String.join(",", newappIdList);
			newQuery = new StringBuffer("select count(biogentransid) from bio_log_main where app_id in (").append(appIds).append(")");
			String searchDate ="";
				if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
					String startDate = buSearch.getStartDate().trim().replace("T", " ");
					startDate = startDate.substring(0, startDate.length()-5);
					newQuery.append(" and trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					searchDate = buSearch.getStartDate();
					
				}
				if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
					String endDate = buSearch.getEndDate().trim().replace("T", " ");
					endDate = endDate.substring(0, endDate.length()-5);
					
					if(searchDate.equals(buSearch.getEndDate())) {
						newQuery.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
					} else {
						newQuery.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					}
				}
				
			
				
				
				if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
					newQuery.append(
							" and trunc(service_start_time) > sysdate - "+buSearch.getDuration());
					}
			
			try {
				final List<Integer> countList = new ArrayList<Integer>();
				jdbcTemplate.query(newQuery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(1) > 0) {
							countList.add(rs.getInt(1));
						}
					}
				});
				if (countList.size() > 0) {
					chartData.setY(countList.get(0));
				} else
					chartData.setY(0);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			}
			chartData.toString();
			donutChartList.add(chartData);
		});
		return donutChartList;
	}
	
	public List<ChartData> getDonutChartData(BUSearch buSearch) {
		
		
		Object[] params = new Object[0];
		final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
		final List<ChartData> donutChartList = new ArrayList<ChartData>();
		StringBuffer query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+" AND APPLICATION_ID="+Integer.parseInt(buSearch.getApplicationName())+" AND ENTITY_ID="+Integer.parseInt(buSearch.getEntityName())+" AND ES_ID="+Integer.parseInt(buSearch.getEntServiceName()) +"");
		try {
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					appIdsList.add(rs.getBigDecimal("app_id"));
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
				isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
				if(! appIdsList.isEmpty()) {
				
					
				appIdsList.parallelStream().forEach(appId->{
					ChartData chartData = new ChartData();
					chartData.setData(new ArrayList<ChartData>());
					StringBuffer newquery = new StringBuffer("select app_name from BIO_LOG_APPLICATION where app_id="+appId);
					try {
						final List<String> appNameList = new ArrayList<String>();
						jdbcTemplate.query(newquery.toString(), params, new RowCallbackHandler() {
							public void processRow(ResultSet rs) throws SQLException {
								appNameList.add(rs.getString(1));
							}
						});
							chartData.setName(appNameList.get(0));
							chartData.setId(appNameList.get(0));
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					newquery = new StringBuffer("select count(biogenTransid) from bio_log_main where app_id=").append(appId);
					String searchDate ="";
					
						if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
							String startDate = buSearch.getStartDate().trim().replace("T", " ");
							startDate = startDate.substring(0, startDate.length()-5);
							newquery.append(" and trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
							searchDate = buSearch.getStartDate();
							

						}
						if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
							String endDate = buSearch.getEndDate().trim().replace("T", " ");
							endDate = endDate.substring(0, endDate.length()-5);
							
							if(searchDate.equals(buSearch.getEndDate())) {
								newquery.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
							} else {
								newquery.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
							}
						}
						
						
						
						if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
							newquery.append(
									" and trunc(service_start_time) > sysdate - "+buSearch.getDuration());
							}
					
					try {
						final List<Integer> countList = new ArrayList<Integer>();
						jdbcTemplate.query(newquery.toString(), params, new RowCallbackHandler() {
							public void processRow(ResultSet rs) throws SQLException {

								if (rs.getInt(1) > 0) {
									countList.add(rs.getInt(1));
								}
							}
						});
						if (countList.size() > 0) {
							chartData.setY(countList.get(0));
						} else
							chartData.setY(0);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					chartData.toString();
					donutChartList.add(chartData);
				});	
				
				}
				
			return donutChartList;
		}
	
	public BarChartDataList getAllBarChartData(List<BioLOVsData> buDataList) {
		final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
		final List<BarChart> failBarChartList = new ArrayList<BarChart>();
		BarChartDataList barChartList = new BarChartDataList();
		
		Object[] params = new Object[0];
		System.out.println( " failedStatus "+this.failedStatus);
		buDataList.parallelStream().forEach(data -> {
			StringBuffer query = new StringBuffer("SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE BLM.SERVICE_START_TIME >= sysdate - "+ defaultDuration+" AND BLM.SERVICE_STATUS='SUCCESS' AND BLM.APP_ID IN " + 
						"(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID ="+data.getId()+")) AS SC," + 
						"(SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE BLM.SERVICE_START_TIME >= sysdate - "+defaultDuration +" AND BLM.SERVICE_STATUS IN ("+this.failedStatus+")  AND BLM.APP_ID IN " + 
						"(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID)) AS FC FROM bio_etm_bu_app_es_info BBAEI where BU_ID IN("+data.getId()+")");
		
		final List<Integer> sucCountList = new ArrayList<Integer>();
		final List<Integer> failCountList = new ArrayList<Integer>();
		System.out.println("query "+query);
		try {

			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					if (rs.getInt(2) > 0) {
						sucCountList.add(rs.getInt(2));
					}
					if (rs.getInt(3) > 0) {
						failCountList.add(rs.getInt(3));
					}

				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		BarChart sucChartData = new BarChart();
		BarChart failChartData = new BarChart();
		sucChartData.setName(data.getName());
		failChartData.setName(data.getName());
		sucChartData.setId(data.getName());
		failChartData.setId(data.getName());
		if (sucCountList.size() > 0) {
			sucChartData.setDrilldown(data.getName());
			sucChartData.setY(sucCountList.get(0));
		} else
			sucChartData.setY(0);
		if (failCountList.size() > 0) {
			failChartData.setDrilldown(data.getName().concat(" FAILED"));
			failChartData.setY(failCountList.get(0));
		} else
			failChartData.setY(0);
		BarChartDataList barChartSubList = getBarChartData(data.getId().toString(), new BUSearch(), new ArrayList<BioLOVsData>());
		sucChartData.setDataList(barChartSubList);
		failChartData.setDataList(barChartSubList);
		sucBarChartList.add(sucChartData);
		failBarChartList.add(failChartData);
		
	});
barChartList.setSuccessList(sucBarChartList);
barChartList.setFailureList(failBarChartList);
	return barChartList;
		
	}
	
	public BarChartDataList getAllBarChartDataByDate(List<BioLOVsData> buDataList, BUSearch buSearch) {
		final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
		final List<BarChart> failBarChartList = new ArrayList<BarChart>();
		BarChartDataList barChartList = new BarChartDataList();
		
		Object[] params = new Object[0];
		String searchDate ="";
		String tempqueryDateStrSuc = "";
		String tempqueryDateStrFail = "";
		
			if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
				String startDate = buSearch.getStartDate().trim().replace("T", " ");
				startDate = startDate.substring(0, startDate.length()-5);
				tempqueryDateStrSuc = "   trunc(BLM.service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
				tempqueryDateStrFail = "  trunc(BLM.service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
				searchDate = buSearch.getStartDate();
		
			}
			if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
				String endDate = buSearch.getEndDate().trim().replace("T", " ");
				endDate = endDate.substring(0, endDate.length()-5);
		
				if(searchDate.equals(buSearch.getEndDate())) {
					tempqueryDateStrSuc = " and trunc(BLM.service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1";
					tempqueryDateStrFail = " and trunc(BLM.service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1";
				} else {
					tempqueryDateStrSuc = " and trunc(BLM.service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
					tempqueryDateStrFail = " and trunc(BLM.service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
				}
			}
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			
			if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
				tempqueryDateStrSuc=
						" BLM.service_start_time >= sysdate - "+buSearch.getDuration();
				tempqueryDateStrFail =
						" BLM.service_start_time >= sysdate - "+buSearch.getDuration();
				}
		String queryDateStrSuc = tempqueryDateStrSuc;
		String queryDateStrFail = tempqueryDateStrFail;
			
		buDataList.parallelStream().forEach(data -> {
		
		StringBuffer query  = new StringBuffer("SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+queryDateStrSuc.toString() +" AND SERVICE_STATUS='SUCCESS' AND BLM.APP_ID IN " + 
						"(SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID ="+data.getId()+") ");
		query.append( ") AS SC,(SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+queryDateStrFail.toString() +" AND SERVICE_STATUS IN ("+this.failedStatus+") AND BLM.APP_ID IN (SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID)");
		query.append(") AS FC FROM bio_etm_bu_app_es_info BBAEI where BU_ID IN("+data.getId()+")");
			System.out.println("barChart query:"+query);		
		final List<Integer> sucCountList = new ArrayList<Integer>();
		final List<Integer> failCountList = new ArrayList<Integer>();
		try {

			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					if (rs.getInt(2) > 0) {
						sucCountList.add(rs.getInt(2));
					}
					if (rs.getInt(3) > 0) {
						failCountList.add(rs.getInt(3));
					}

				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		BarChart sucChartData = new BarChart();
		BarChart failChartData = new BarChart();
		sucChartData.setName(data.getName());
		failChartData.setName(data.getName());
		sucChartData.setId(data.getName());
		failChartData.setId(data.getName());
		if (sucCountList.size() > 0) {
			sucChartData.setDrilldown(data.getName());
			sucChartData.setY(sucCountList.get(0));
		} else
			sucChartData.setY(0);
		if (failCountList.size() > 0) {
			failChartData.setDrilldown(data.getName().concat(" FAILED"));
			failChartData.setY(failCountList.get(0));
		} else
			failChartData.setY(0);
		BarChartDataList barChartSubList = getBarChartData(data.getId().toString(), buSearch, new ArrayList<BioLOVsData>());
		sucChartData.setDataList(barChartSubList);
		failChartData.setDataList(barChartSubList);
		sucBarChartList.add(sucChartData);
		failBarChartList.add(failChartData);
		
	});
		barChartList.setSuccessList(sucBarChartList);
barChartList.setFailureList(failBarChartList);
	return barChartList;
		
	}
	
	public BarChartDataList getBarChartData(String busUnit,BUSearch buSearch, List<BioLOVsData> buDataList) {
		
		List<BioLOVsData> appList = new ArrayList<BioLOVsData>();
		final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
		final List<BarChart> failBarChartList = new ArrayList<BarChart>();
		final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
		Object[] params = new Object[0];
		BarChartDataList barChartList = new BarChartDataList();
		if(busUnit!= null && busUnit.length() > 0) {
			StringBuffer tempquery = new StringBuffer("select distinct(APPLICATION_ID),(SELECT APPLICATION_NAME FROM bio_etm_application BA WHERE BA.APPLICATION_ID = BU.APPLICATION_ID) AS APPLICATION_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU.BU_Id="+Integer.parseInt(busUnit)+"");
			try {
				jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						BioLOVsData data = new BioLOVsData();
						data.setId(rs.getInt(1));
						data.setName(rs.getString(2));
						newAppList.add(data);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			appList = newAppList;
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			appList.parallelStream().forEach(data-> {
				String busnUnit = busUnit;
				final List<Integer> sucCountList = new ArrayList<Integer>();
				final List<Integer> failCountList = new ArrayList<Integer>();
				final List<BigDecimal>  appIdsList = new ArrayList<BigDecimal>();
				StringBuffer query = new StringBuffer();
				if(busUnit!= null && busUnit.length() > 0) {
					query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+data.getId()+"");
				} else {
					busnUnit = data.getId().toString();
					query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+data.getId()+"");
				}
				try {
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							appIdsList.add(rs.getBigDecimal("app_id"));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				if(! appIdsList.isEmpty()) {
					List<String> newappIdList = new ArrayList<String>();
					for(BigDecimal ids: appIdsList){
						newappIdList.add(String.valueOf(ids));
					}
					String appIds = String.join(",", newappIdList);
					StringBuilder querySuc = new StringBuilder();
					StringBuilder queryFail = new StringBuilder();
					String searchDate ="";
						
					if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
						String startDate = buSearch.getStartDate().trim().replace("T", " ");
						startDate = startDate.substring(0, startDate.length()-5);
						querySuc.append(" trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
						queryFail.append(" trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
						searchDate = buSearch.getStartDate();
		
					}
					if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
						String endDate = buSearch.getEndDate().trim().replace("T", " ");
						endDate = endDate.substring(0, endDate.length()-5);
		
						if(searchDate.equals(buSearch.getEndDate())) {
							querySuc.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
							queryFail.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
						} else {
						querySuc.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
						queryFail.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
						}
					}
					
					
					
					if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
						querySuc.append(
								"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
						queryFail.append(
								"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
						}
					
		
					querySuc = new StringBuilder("select count(biogentransid) from bio_log_main where "+querySuc.toString() +" and SERVICE_STATUS='SUCCESS' and app_id in (").append(appIds).append(")");
					queryFail = new StringBuilder("select count(biogentransid) from bio_log_main where "+queryFail.toString() +"  and  SERVICE_STATUS IN ("+this.failedStatus+") and app_id in (").append(appIds).append(")");
					
					System.out.println("querySuc "+querySuc);
					System.out.println("querySuc "+queryFail);
					try {
						jdbcTemplate.query(querySuc.toString(), params, new RowCallbackHandler() {
							public void processRow(ResultSet rs) throws SQLException {
								if (rs.getInt(1) > 0) {
									sucCountList.add(rs.getInt(1));
								}
							}
						});
						jdbcTemplate.query(queryFail.toString(), params, new RowCallbackHandler() {
							public void processRow(ResultSet rs) throws SQLException {
								if (rs.getInt(1) > 0) {
									failCountList.add(rs.getInt(1));
								}
							}
						});
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					
				}
				BarChart sucChartData = new BarChart();
				BarChart failChartData = new BarChart();
				sucChartData.setName(data.getName());
				failChartData.setName(data.getName());
				sucChartData.setId(data.getName());
				failChartData.setId(data.getName());
				sucChartData.setDataList(new BarChartDataList());
				failChartData.setDataList(new BarChartDataList());
				if (sucCountList.size() > 0) {
					sucChartData.setDrilldown(data.getName());
					sucChartData.setY(sucCountList.get(0));
				} else
					sucChartData.setY(0);
				if (failCountList.size() > 0) {
					failChartData.setDrilldown(data.getName().concat(" FAILED"));
					failChartData.setY(failCountList.get(0));
				} else
					failChartData.setY(0);
				
				BarChartDataList barChartSubList = getBarChartData(busUnit, data.getId().toString(), buSearch);
				sucChartData.setDataList(barChartSubList);
			
				sucBarChartList.add(sucChartData);
				failBarChartList.add(failChartData);
			});
			
			barChartList.setSuccessList(sucBarChartList);
			barChartList.setFailureList(failBarChartList);
				return barChartList;
			
		} else {
			System.out.println("no buisness unit");
			return this.getAllBarChartDataByDate(buDataList, buSearch);
		}
		
		
	}
	
	public BarChartDataList getBarChartData(String busUnit, String appName, BUSearch buSearch) {
		final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
		final List<BarChart> failBarChartList = new ArrayList<BarChart>();
		BarChartDataList barChartList = new BarChartDataList();
		final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
		Object[] params = new Object[0];
		
		StringBuffer tempquery = new StringBuffer("select distinct(ENTITY_ID),(SELECT ENTITY_NAME FROM bio_etm_entity BA WHERE BA.ENTITY_ID = BU.ENTITY_ID) AS ENTITY_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" and entity_id is not null");
		
		try {
			jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					BioLOVsData data = new BioLOVsData();
					data.setId(rs.getInt(1));
					data.setName(rs.getString(2));
					newAppList.add(data);
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		newAppList.forEach(data-> {
			StringBuffer query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+data.getId()+"");
			final List<Integer> sucCountList = new ArrayList<Integer>();
			final List<Integer> failCountList = new ArrayList<Integer>();
			final List<BigDecimal>  appIdsList = new ArrayList<BigDecimal>();
			try {
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						appIdsList.add(rs.getBigDecimal("app_id"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			if(! appIdsList.isEmpty()) {
				List<String> newappIdList = new ArrayList<String>();
				for(BigDecimal ids: appIdsList){
					newappIdList.add(String.valueOf(ids));
				}
				String appIds = String.join(",", newappIdList);
				StringBuilder querySuc = new StringBuilder();
				StringBuilder queryFail = new StringBuilder();
				String searchDate = buSearch.getStartDate();
				if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
					String startDate = buSearch.getStartDate().trim().replace("T", " ");
					startDate = startDate.substring(0, startDate.length()-5);
					querySuc.append(" trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					queryFail.append(" trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					
			
				}
				if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
					String endDate = buSearch.getEndDate().trim().replace("T", " ");
					endDate = endDate.substring(0, endDate.length()-5);

					if(searchDate.equals(buSearch.getEndDate())) {
						querySuc.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
						queryFail.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
					} else {
					querySuc.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					queryFail.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					}
				}
				
				
				
				
				if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
					querySuc.append(
							"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
					queryFail.append(
							"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
					}

				

				querySuc = new StringBuilder("select count(biogentransid) from bio_log_main where "+querySuc.toString() +" and  SERVICE_STATUS='SUCCESS' and app_id in (").append(appIds).append(")");
				queryFail = new StringBuilder("select count(biogentransid) from bio_log_main where "+queryFail.toString() +" and SERVICE_STATUS IN ("+this.failedStatus+") and app_id in (").append(appIds).append(")");
				System.out.println(querySuc);
				System.out.println(queryFail);
				try {
					jdbcTemplate.query(querySuc.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								sucCountList.add(rs.getInt(1));
							}
						}
					});
					jdbcTemplate.query(queryFail.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								failCountList.add(rs.getInt(1));
							}
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			BarChart sucChartData = new BarChart();
			BarChart failChartData = new BarChart();
			sucChartData.setName(data.getName());
			failChartData.setName(data.getName());
			sucChartData.setId(data.getName());
			failChartData.setId(data.getName());
			sucChartData.setDataList(new BarChartDataList());
			failChartData.setDataList(new BarChartDataList());
			if (sucCountList.size() > 0) {
				sucChartData.setY(sucCountList.get(0));
			} else
				sucChartData.setY(0);
			if (failCountList.size() > 0) {
				failChartData.setY(failCountList.get(0));
			} else
				failChartData.setY(0);
			sucBarChartList.add(sucChartData);
			failBarChartList.add(failChartData);
			
		});
		barChartList.setSuccessList(sucBarChartList);
		barChartList.setFailureList(failBarChartList);
			return barChartList;
	}
	
public BarChartDataList getBarChartData(String busUnit, String appName, String entity, BUSearch buSearch) {
		
		
	final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
	final List<BarChart> failBarChartList = new ArrayList<BarChart>();
	BarChartDataList barChartList = new BarChartDataList();
	final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
	StringBuffer tempquery = null;
	Object[] params = new Object[0];
	
	tempquery = new StringBuffer("select distinct(ES_ID),(SELECT ES_NAME FROM bio_etm_enterpriseservice BA WHERE BA.ES_ID = BU.ES_ID) AS ES_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+"");
		
	try {
		jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {

				BioLOVsData data = new BioLOVsData();
				data.setId(rs.getInt(1));
				data.setName(rs.getString(2));
				newAppList.add(data);
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
	
		newAppList.parallelStream().forEach(data-> {
			final List<Integer> sucCountList = new ArrayList<Integer>();
			final List<Integer> failCountList = new ArrayList<Integer>();
			StringBuffer query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+" AND ES_ID="+data.getId() +"");
			final List<BigDecimal>  appIdsList = new ArrayList<BigDecimal>();
			try {
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						appIdsList.add(rs.getBigDecimal("app_id"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			if(! appIdsList.isEmpty()) {
				List<String> newappIdList = new ArrayList<String>();
				for(BigDecimal ids: appIdsList){
					newappIdList.add(String.valueOf(ids));
				}
				
				String appIds = String.join(",", newappIdList);
				String searchDate ="";
				StringBuilder querySuc = new StringBuilder("");
				StringBuilder queryFail = new StringBuilder("");
				
				if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
					String startDate = buSearch.getStartDate().trim().replace("T", " ");
					startDate = startDate.substring(0, startDate.length()-5);
					querySuc.append("  trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					queryFail.append("  trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					searchDate = buSearch.getStartDate();
				}
				if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
					String endDate = buSearch.getEndDate().trim().replace("T", " ");
					endDate = endDate.substring(0, endDate.length()-5);
					if(searchDate.equals(buSearch.getEndDate())) {
						querySuc.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
						queryFail.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
					} else {
					querySuc.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					queryFail.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					}
					
				}
				
				if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
					querySuc.append(
							"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
					queryFail.append(
							" trunc(service_start_time) > sysdate - "+buSearch.getDuration());
					}


				 querySuc = new StringBuilder("select count(biogentransid) from bio_log_main where "+querySuc.toString() +" and SERVICE_STATUS='SUCCESS' and app_id in (").append(appIds).append(")");
				queryFail = new StringBuilder("select count(biogentransid) from bio_log_main where "+queryFail.toString() +" and  SERVICE_STATUS IN ("+this.failedStatus+") and app_id in (").append(appIds).append(")");
							try {
					jdbcTemplate.query(querySuc.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								sucCountList.add(rs.getInt(1));
							}
						}
					});
					jdbcTemplate.query(queryFail.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								failCountList.add(rs.getInt(1));
							}
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				
			}
			BarChart sucChartData = new BarChart();
			BarChart failChartData = new BarChart();
			sucChartData.setName(data.getName());
			failChartData.setName(data.getName());
			sucChartData.setId(data.getName());
			failChartData.setId(data.getName());
			sucChartData.setDataList(new BarChartDataList());
			failChartData.setDataList(new BarChartDataList());
			if (sucCountList.size() > 0) {
				sucChartData.setY(sucCountList.get(0));
			} else
				sucChartData.setY(0);
			if (failCountList.size() > 0) {
				failChartData.setY(failCountList.get(0));
			} else
				failChartData.setY(0);
			sucBarChartList.add(sucChartData);
			failBarChartList.add(failChartData);
		});
		barChartList.setSuccessList(sucBarChartList);
		barChartList.setFailureList(failBarChartList);
			return barChartList;
	}


public BarChartDataList getBarChartData(BUSearch buSearch) {
	
	final List<BarChart> sucBarChartList = new ArrayList<BarChart>();
	final List<BarChart> failBarChartList = new ArrayList<BarChart>();
	BarChartDataList barChartList = new BarChartDataList();
	Object[] params = new Object[0];
	final List<Integer> sucCountList = new ArrayList<Integer>();
	final List<Integer> failCountList = new ArrayList<Integer>();
	final List<BigDecimal>  appIdsList = new ArrayList<BigDecimal>();
	StringBuffer tempquery = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+" AND APPLICATION_ID="+Integer.parseInt(buSearch.getApplicationName())+" AND ENTITY_ID="+Integer.parseInt(buSearch.getEntityName())+" AND ES_ID="+Integer.parseInt(buSearch.getEntServiceName()) +"");
	try {
		jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				appIdsList.add(rs.getBigDecimal("app_id"));
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		if(! appIdsList.isEmpty()) {
			
			appIdsList.parallelStream().forEach(ids->{
				StringBuffer query = new StringBuffer("select app_name from BIO_LOG_APPLICATION where app_id="+ids);
				final List<String> appNameList = new ArrayList<String>();
				try {
					
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							appNameList.add(rs.getString(1));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				String searchDate ="";
				StringBuilder querySuc = new StringBuilder();
				StringBuilder queryFail = new StringBuilder();
				if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
						String startDate = buSearch.getStartDate().trim().replace("T", " ");
						startDate = startDate.substring(0, startDate.length()-5);
						querySuc.append("  trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
						queryFail.append("  trunc(service_start_time)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
						searchDate = buSearch.getStartDate();
					}
					if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
						String endDate = buSearch.getEndDate().trim().replace("T", " ");
						endDate = endDate.substring(0, endDate.length()-5);
						if(searchDate.equals(buSearch.getEndDate())) {
							querySuc.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
							queryFail.append(" and trunc(service_start_time)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
						} else {
						querySuc.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
						queryFail.append(" and trunc(service_start_time)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
						}
					}
					
					if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
						querySuc.append(
								"  trunc(service_start_time) > sysdate - "+buSearch.getDuration());
						queryFail.append(
								" trunc(service_start_time) > sysdate - "+buSearch.getDuration());
						}
				
				querySuc = new StringBuilder("select count(biogentransid) from bio_log_main where "+ querySuc.toString() + " and  SERVICE_STATUS='SUCCESS' and app_id ="+ids);
				queryFail = new StringBuilder("select count(biogentransid) from bio_log_main where "+ queryFail.toString()+" and SERVICE_STATUS IN ("+this.failedStatus+") and app_id ="+ids);
				try {
					jdbcTemplate.query(querySuc.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								sucCountList.add(rs.getInt(1));
							}
						}
					});
					jdbcTemplate.query(queryFail.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							if (rs.getInt(1) > 0) {
								failCountList.add(rs.getInt(1));
							}
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				BarChart sucChartData = new BarChart();
				BarChart failChartData = new BarChart();
				sucChartData.setName(appNameList.get(0));
				failChartData.setName(appNameList.get(0));
				sucChartData.setId(appNameList.get(0));
				failChartData.setId(appNameList.get(0));
				sucChartData.setDataList(new BarChartDataList());
				failChartData.setDataList(new BarChartDataList());
				if (sucCountList.size() > 0) {
					sucChartData.setY(sucCountList.get(0));
				} else
					sucChartData.setY(0);
				if (failCountList.size() > 0) {
					failChartData.setY(failCountList.get(0));
				} else
					failChartData.setY(0);
				sucBarChartList.add(sucChartData);
				failBarChartList.add(failChartData);
			});
			barChartList.setSuccessList(sucBarChartList);
			barChartList.setFailureList(failBarChartList);
		}
	return barChartList;
}

	public List<ChartData> getNotificationBarChartData(List<BioLOVsData> buDataList) {
		
	final List<ChartData> notificationChartList = new ArrayList<ChartData>();
	Object[] params = new Object[0];
	
		buDataList.parallelStream().forEach(data-> {
		StringBuffer	query = new StringBuffer("SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_NOTIFY_HISTORY BNH WHERE   trunc(BNH.CREATED_DATE) > sysdate - "+defaultDuration+" AND BNH.NOTIFY_ID IN " + 
						"(SELECT DISTINCT ID FROM BIO_NOTIFY WHERE APP_ID IN (SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID ="+data.getId()+") )) AS NC " + 
						"FROM bio_etm_bu_app_es_info BBAEI where BBAEI.BU_ID ="+data.getId()+" ORDER BY NC DESC");
		final List<Integer> countList = new ArrayList<Integer>();
		try {
			
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					if (rs.getInt(2) > 0) {
						countList.add(rs.getInt(2));
					}

				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		ChartData chartData = new ChartData();
		chartData.setName(data.getName());

		chartData.setId(data.getName());
		if (countList.size() > 0) {
			chartData.setDrilldown(data.getName());
			chartData.setY(countList.get(0));
		} else
			chartData.setY(0);
		chartData.setData(getNotificationBarChartData(data.getId().toString(), new BUSearch(), new ArrayList<BioLOVsData>()));
		notificationChartList.add(chartData);
	});

		return notificationChartList;
	}
	
	public List<ChartData> getNotificationBarChartDataByDate(List<BioLOVsData> buDataList, BUSearch buSearch) {
		
		final List<ChartData> notificationChartList = new ArrayList<ChartData>();
		Object[] params = new Object[0];
		String searchDate ="";
		String queryDateStr = "";
			if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
				String startDate = buSearch.getStartDate().trim().replace("T", " ");
				startDate = startDate.substring(0, startDate.length()-5);
				queryDateStr = " and trunc(CREATED_DATE)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
				searchDate = buSearch.getStartDate();

			}
			if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
				String endDate = buSearch.getEndDate().trim().replace("T", " ");
				endDate = endDate.substring(0, endDate.length()-5);

				if(searchDate.equals(buSearch.getEndDate())) {
					queryDateStr = " and trunc(CREATED_DATE)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1";
				} else {
					queryDateStr = " and trunc(CREATED_DATE)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
				}
			}
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			
			if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
				queryDateStr =
						" and trunc(CREATED_DATE) > sysdate - "+buSearch.getDuration();
			
				}
			final String finalQueryParams = queryDateStr;
			buDataList.parallelStream().forEach(data-> {
				StringBuffer query = new StringBuffer("SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_NOTIFY_HISTORY BNH WHERE BNH.NOTIFY_ID IN " + 
							"(SELECT DISTINCT ID FROM BIO_NOTIFY WHERE APP_ID IN (SELECT DISTINCT APP_ID FROM bio_etm_bu_app_es_info WHERE BU_ID = BBAEI.BU_ID and BU_ID ="+data.getId()+"))");
				query.append(finalQueryParams);
				query.append(") AS NC	FROM bio_etm_bu_app_es_info BBAEI where BBAEI.BU_ID ="+data.getId()+" ORDER BY NC DESC");
			final List<Integer> countList = new ArrayList<Integer>();
			try {

				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(2) > 0) {
							countList.add(rs.getInt(2));
						}

					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			ChartData chartData = new ChartData();
			chartData.setName(data.getName());

			chartData.setId(data.getName());
			if (countList.size() > 0) {
				chartData.setDrilldown(data.getName());
				chartData.setY(countList.get(0));
			} else
				chartData.setY(0);
			chartData.setData(getNotificationBarChartData(data.getId().toString(), buSearch, new ArrayList<BioLOVsData>()));
			notificationChartList.add(chartData);
		});

			return notificationChartList;
		}
	
	public List<ChartData> getNotificationBarChartData(String busUnit, BUSearch buSearch, List<BioLOVsData> buDataList) {
		
		final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
		List<BioLOVsData> appList = new ArrayList<BioLOVsData>();
		Object[] params = new Object[0];
		if(busUnit!= null && busUnit.length() > 0) {
			StringBuffer tempquery = new StringBuffer("select distinct(APPLICATION_ID),(SELECT APPLICATION_NAME FROM bio_etm_application BA WHERE BA.APPLICATION_ID = BU.APPLICATION_ID) AS APPLICATION_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU.BU_Id="+Integer.parseInt(busUnit)+"");
			try {
				jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						BioLOVsData data = new BioLOVsData();
						data.setId(rs.getInt(1));
						data.setName(rs.getString(2));
						newAppList.add(data);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			appList = newAppList;
			final List<ChartData> chartList = new ArrayList<ChartData>();
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			appList.parallelStream().forEach(data-> {
				final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
				StringBuffer query = new StringBuffer();
				String busnewUnit= busUnit;
				if(busnewUnit!= null && busnewUnit.length() > 0) {
					query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busnewUnit)+" AND APPLICATION_ID="+data.getId() +"");
				} else {
					busnewUnit = data.getId().toString();
					query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+data.getId()+"");
				}
				try {
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							appIdsList.add(rs.getBigDecimal("app_id"));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				
				ChartData chartData = new ChartData();
				chartData.setName(data.getName());
				chartData.setDrilldown(data.getName());
				chartData.setId(data.getName());
				chartData.setData(new ArrayList<ChartData>());
				if(! appIdsList.isEmpty()) {
				List<String> newappIdList = new ArrayList<String>();
				for(BigDecimal ids: appIdsList){
					newappIdList.add(String.valueOf(ids));
				}
				String appIds = String.join(",", newappIdList);
				query = new StringBuffer("select ID from BIO_NOTIFY where app_id in ("+appIds+")");
				final List<BigDecimal> notifyIdsList = new ArrayList<BigDecimal>();
				try {
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							notifyIdsList.add(rs.getBigDecimal("ID"));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				
				if(! notifyIdsList.isEmpty()) {
				newappIdList.clear();
				for(BigDecimal ids: notifyIdsList){
					newappIdList.add(String.valueOf(ids));
				}
				appIds = String.join(",", newappIdList);
				query= new StringBuffer("select count(ID) from BIO_NOTIFY_HISTORY where notify_id in (").append(appIds).append(")");
				String searchDate ="";
				
				
						if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
						String startDate = buSearch.getStartDate().trim().replace("T", " ");
						startDate = startDate.substring(0, startDate.length()-5);
						query.append(" and trunc(CREATED_DATE)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
						searchDate = buSearch.getStartDate();
				
					}
					if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
						String endDate = buSearch.getEndDate().trim().replace("T", " ");
						endDate = endDate.substring(0, endDate.length()-5);
				
						if(searchDate.equals(buSearch.getEndDate())) {
							query.append(" and trunc(CREATED_DATE)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
						} else {
							query.append(" and trunc(CREATED_DATE)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
						}
					}
					
					if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
						query.append(" and trunc(CREATED_DATE) > sysdate - "+buSearch.getDuration());
						}
				try {
					final List<Integer> countList = new ArrayList<Integer>();
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {

							if (rs.getInt(1) > 0) {
								countList.add(rs.getInt(1));
							}
						}
					});
					if (countList.size() > 0) {
						chartData.setY(countList.get(0));
					} else
						chartData.setY(0);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				}
				}
				chartData.setData(this.getNotificationBarChartData(busnewUnit, data.getId().toString(), buSearch));
				chartList.add(chartData);

			});
			return chartList;
		} else {
			return this.getNotificationBarChartDataByDate(buDataList, buSearch);
			}
		
		
	}

public 	List<ChartData> getNotificationBarChartData(String busUnit, String appName, BUSearch buSearch) {
		
	final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
	StringBuffer tempquery = null;
	Object[] params = new Object[0];
	tempquery = new StringBuffer("select distinct(ENTITY_ID),(SELECT ENTITY_NAME FROM bio_etm_entity BA WHERE BA.ENTITY_ID = BU.ENTITY_ID) AS ENTITY_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" and entity_id is not null");
		
			try {
				jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						BioLOVsData data = new BioLOVsData();
						data.setId(rs.getInt(1));
						data.setName(rs.getString(2));
						newAppList.add(data);
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		
		final List<ChartData> chartList = new ArrayList<ChartData>();
		isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
		
		
		newAppList.parallelStream().forEach(obj-> {
			final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
			StringBuffer query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+obj.getId()+"");
			try {
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						appIdsList.add(rs.getBigDecimal("app_id"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			ChartData chartData = new ChartData();
			chartData.setName(obj.getName());
			chartData.setId(obj.getName());
			chartData.setData(new ArrayList<ChartData>());
			if(! appIdsList.isEmpty()) {
			List<String> newappIdList = new ArrayList<String>();
			for(BigDecimal ids: appIdsList){
				newappIdList.add(String.valueOf(ids));
			}
			String appIds = String.join(",", newappIdList);
			query = new StringBuffer("select ID from BIO_NOTIFY where app_id in ("+appIds+")");
			final List<BigDecimal> notifyIdsList = new ArrayList<BigDecimal>();
			try {
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {
						notifyIdsList.add(rs.getBigDecimal("ID"));
					}
				});
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			if(! notifyIdsList.isEmpty()) {
			newappIdList.clear();
			for(BigDecimal ids: notifyIdsList){
				newappIdList.add(String.valueOf(ids));
			}
			appIds = String.join(",", newappIdList);
			query = new StringBuffer("select count(ID) from BIO_NOTIFY_HISTORY where notify_id in (").append(appIds).append(")");
			String searchDate ="";
				if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
					String startDate = buSearch.getStartDate().trim().replace("T", " ");
					startDate = startDate.substring(0, startDate.length()-5);
					query.append(" and trunc(CREATED_DATE)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
					searchDate = buSearch.getStartDate();
		
				}
				if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
					String endDate = buSearch.getEndDate().trim().replace("T", " ");
					endDate = endDate.substring(0, endDate.length()-5);
		
					if(searchDate.equals(buSearch.getEndDate())) {
						query.append(" and trunc(CREATED_DATE)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
					} else {
						query.append(" and trunc(CREATED_DATE)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
					}
				}
				if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
					
					query.append(" and trunc(CREATED_DATE) > sysdate - "+buSearch.getDuration());
					
				}
				
				
			
			try {
				final List<Integer> countList = new ArrayList<Integer>();
				jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
					public void processRow(ResultSet rs) throws SQLException {

						if (rs.getInt(1) > 0) {
							countList.add(rs.getInt(1));
						}
					}
				});
				if (countList.size() > 0) {
					chartData.setY(countList.get(0));
				} else
					chartData.setY(0);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			}
			}
			chartList.add(chartData);
		});
		return chartList;
	}

public List<ChartData> getNotificationBarChartData(String busUnit, String appName, String entity, BUSearch buSearch) {
	
	final List<BioLOVsData> newAppList = new ArrayList<BioLOVsData>();
	Object[] params = new Object[0];
	StringBuffer tempquery = new StringBuffer("select distinct(ES_ID),(SELECT ES_NAME FROM bio_etm_enterpriseservice BA WHERE BA.ES_ID = BU.ES_ID) AS ES_NAME from BIO_ETM_BU_APP_ES_INFO BU where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+"");
	try {
		jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {

				BioLOVsData data = new BioLOVsData();
				data.setId(rs.getInt(1));
				data.setName(rs.getString(2));
				newAppList.add(data);
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
	List<ChartData> chartList = new ArrayList<ChartData>();
	isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
	newAppList.parallelStream().forEach(obj-> {
		StringBuffer query = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(busUnit)+" AND APPLICATION_ID="+Integer.parseInt(appName)+" AND ENTITY_ID="+Integer.parseInt(entity)+" AND ES_ID="+obj.getId() +"");
		try {
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					appIdsList.add(rs.getBigDecimal("app_id"));
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		ChartData chartData = new ChartData();
		chartData.setName(obj.getName());
		chartData.setId(obj.getName());
		chartData.setData(new ArrayList<ChartData>());
		if(! appIdsList.isEmpty()) {
		List<String> newappIdList = new ArrayList<String>();
		for(BigDecimal ids: appIdsList){
			newappIdList.add(String.valueOf(ids));
		}
		String appIds = String.join(",", newappIdList);
		query = new StringBuffer("select ID from BIO_NOTIFY where app_id in ("+appIds+")");
		final List<BigDecimal> notifyIdsList = new ArrayList<BigDecimal>();
		try {
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					notifyIdsList.add(rs.getBigDecimal("ID"));
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		if(! notifyIdsList.isEmpty()) {
		newappIdList.clear();
		for(BigDecimal ids: notifyIdsList){
			newappIdList.add(String.valueOf(ids));
		}
		appIds = String.join(",", newappIdList);
		query = new StringBuffer("select count(ID) from BIO_NOTIFY_HISTORY where notify_id in (").append(appIds).append(")");
		String searchDate ="";
	
		
			if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
				String startDate = buSearch.getStartDate().trim().replace("T", " ");
				startDate = startDate.substring(0, startDate.length()-5);
				query.append(" and trunc(CREATED_DATE)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
				searchDate = buSearch.getStartDate();
		
			}
			if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
				String endDate = buSearch.getEndDate().trim().replace("T", " ");
				endDate = endDate.substring(0, endDate.length()-5);
		
				if(searchDate.equals(buSearch.getEndDate())) {
					query.append(" and trunc(CREATED_DATE)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
				} else {
					query.append(" and trunc(CREATED_DATE)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
				}
			}
			if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
				
				query.append(" and trunc(CREATED_DATE) > sysdate - "+buSearch.getDuration());
				
			}
		try {
			final List<Integer> countList = new ArrayList<Integer>();
			jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {

					if (rs.getInt(1) > 0) {
						countList.add(rs.getInt(1));
					}
				}
			});
			if (countList.size() > 0) {
				chartData.setY(countList.get(0));
			} else
				chartData.setY(0);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		}
		}
		chartList.add(chartData);
	});
	return chartList;
}

public List<ChartData> getNotificationBarChartData(BUSearch buSearch) {
	
	StringBuffer tempquery = null;
	Object[] params = new Object[0];
	final List<BigDecimal> appIdsList = new ArrayList<BigDecimal>();
	final List<ChartData> chartList = new ArrayList<ChartData>();
	tempquery = new StringBuffer("select app_id from BIO_ETM_BU_APP_ES_INFO where BU_ID="+Integer.parseInt(buSearch.getBusinessUnit())+" AND APPLICATION_ID="+Integer.parseInt(buSearch.getApplicationName())+" AND ENTITY_ID="+Integer.parseInt(buSearch.getEntityName())+" AND ES_ID="+Integer.parseInt(buSearch.getEntServiceName()) +"");
	try {
		jdbcTemplate.query(tempquery.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				appIdsList.add(rs.getBigDecimal("app_id"));
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	ChartData chartData = new ChartData();
	chartData.setData(new ArrayList<ChartData>());
		if(! appIdsList.isEmpty()) {
			List<String> newappIdList = new ArrayList<String>();
			isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
			appIdsList.parallelStream().forEach(appId->{
				StringBuffer query = new StringBuffer("select ID from BIO_NOTIFY where app_id ="+appId);
				final List<BigDecimal> notifyIdsList = new ArrayList<BigDecimal>();
				try {
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							notifyIdsList.add(rs.getBigDecimal("ID"));
						}
					});
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				query = new StringBuffer("select app_name from BIO_LOG_APPLICATION where app_id="+appId);
				try {
					final List<String> appNameList = new ArrayList<String>();
					jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
						public void processRow(ResultSet rs) throws SQLException {
							appNameList.add(rs.getString(1));
						}
					});
						chartData.setName(appNameList.get(0));
						chartData.setId(appNameList.get(0));
				} catch (Exception ex) {
					ex.printStackTrace();
				}
						if(! notifyIdsList.isEmpty()) {
								newappIdList.clear();
									for(BigDecimal notifyids: notifyIdsList){
										newappIdList.add(String.valueOf(notifyids));
									}
									String notifyIds = String.join(",", newappIdList);
									query = new StringBuffer("select count(ID) from BIO_NOTIFY_HISTORY where notify_id in (").append(notifyIds).append(")");
									String searchDate ="";
									
										if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
											String startDate = buSearch.getStartDate().trim().replace("T", " ");
											startDate = startDate.substring(0, startDate.length()-5);
											query.append(" and trunc(CREATED_DATE)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')");
											searchDate = buSearch.getStartDate();
											
										}
										if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
											String endDate = buSearch.getEndDate().trim().replace("T", " ");
											endDate = endDate.substring(0, endDate.length()-5);
											if(searchDate.equals(buSearch.getEndDate())) {
												query.append(" and trunc(CREATED_DATE)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1");
											} else {
												query.append(" and trunc(CREATED_DATE)<=TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')");
											}
										}
										
										if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
											 
											query.append(" and trunc(CREATED_DATE) > sysdate - "+buSearch.getDuration());
											
										}
									try {
										final List<Integer> countList = new ArrayList<Integer>();
										jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
											public void processRow(ResultSet rs) throws SQLException {

												if (rs.getInt(1) > 0) {
													countList.add(rs.getInt(1));
												}
											}
										});
										if (countList.size() > 0) {
											chartData.setY(countList.get(0));
										} else
											chartData.setY(0);
									} catch (Exception ex) {
										ex.printStackTrace();
									}
			
						}
						chartList.add(chartData);
			});
	}
		return chartList;
}
private List<List<SankeyGraphCount>> generateSaneyGraphCount(List<BioLOVsData> buDataList,BUSearch buSearch){
	
final List<List<SankeyGraphCount>> listOfSankyGraphList = new ArrayList<List<SankeyGraphCount>>();
	
	HashMap<Integer,BioLOVsData> hashMap = new HashMap<Integer,BioLOVsData>();
	for (BioLOVsData data : buDataList) {
		hashMap.put(data.getId(), data);
	}
	
	 hashMap.forEach( (key,data) -> {
		
		 StringBuffer query = new StringBuffer("select Distinct(ENTITY_ID) from BIO_ETM_BU_APP_ES_INFO where BU_ID="+key + " and entity_id is not NULL ");
		 List<String> entityIdList = new ArrayList<String>();
		 try {
			jdbcTemplate.query(query.toString(),  new RowCallbackHandler() {
				
				public void processRow(ResultSet rs) throws SQLException {
					entityIdList.add(rs.getObject(1,String.class));
					 
				
				}
			});
		
		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 if(entityIdList.size()>0) {
		String entityIdParams = String.join(",",entityIdList);
		if(buSearch==null) {
		listOfSankyGraphList.add(this.getSankeyGraphData(entityIdParams,new BUSearch()));
		}else {
			listOfSankyGraphList.add(this.getSankeyGraphData(entityIdParams,buSearch));
		}
		 }
		
	 });
	 return listOfSankyGraphList;
}
public List<SankeyGraphNode> getFullSankeyGrapDataList(List<BioLOVsData> buDataList,BUSearch buSearch) {

	
	List<SankeyGraphNode> sankeyGraphNodes= new ArrayList<>();
	List<List<SankeyGraphCount>> listOfSankyGraphList = generateSaneyGraphCount(buDataList,buSearch);	
	if(listOfSankyGraphList.size()>0) {
		sankeyGraphNodes= generateSankeyGraphList(listOfSankyGraphList);
	}
	return sankeyGraphNodes;
	
}
public List<SankeyGraphNode> getSankeyGraphData(BUSearch buSearch, List<BioLOVsData> buDataList) {
	
    List<List<SankeyGraphCount>> listOfSankyGraphList = new ArrayList<List<SankeyGraphCount>>();
    List<List<SankeyGraphCount>> filteredList= new ArrayList<List<SankeyGraphCount>>();
	
	List<SankeyGraphNode> sankeyGraphNodes= new ArrayList<>();
	 if(buSearch.getEntityName()!=null && buSearch.getEntityName().length()>0) {
		 listOfSankyGraphList= generateSaneyGraphCount(buDataList,buSearch);
		 if(listOfSankyGraphList.size()>0) {
		
			  listOfSankyGraphList.forEach(listOfSankeyGraph -> {
				System.out.println(buSearch.getEntityName()+ " size before filtering .... "+listOfSankeyGraph.size()); 
				
				List<SankeyGraphCount> collectedList =listOfSankeyGraph.parallelStream().filter(t-> Integer.parseInt(buSearch.getEntityName())==t.getEntityId()).collect(Collectors.toList());
				System.out.println(" size after filtering .... "+collectedList.size());
				filteredList.add(collectedList);
			  });
			 
		 }
		
		
	 }else if(buSearch.getApplicationName()!=null && buSearch.getApplicationName().length()>0) {
		 listOfSankyGraphList= generateSaneyGraphCount(buDataList,buSearch);
		 if(listOfSankyGraphList.size()>0) {
		
			  listOfSankyGraphList.forEach(listOfSankeyGraph -> {
				  System.out.println(buSearch.getApplicationName()+ " size before filtering .... "+listOfSankeyGraph.size()); 
				  listOfSankeyGraph.parallelStream().forEach(t->System.out.println(t.getSourceBUApplicationID()));
				  listOfSankeyGraph.parallelStream().forEach(t->System.out.println(t.getSourceAppID()));
				List<SankeyGraphCount> collectedList =listOfSankeyGraph.parallelStream().filter(t-> (Integer.parseInt(buSearch.getApplicationName())== t.getSourceBUApplicationID() || Integer.parseInt(buSearch.getApplicationName())==t.getTargetBUApplicationID())).collect(Collectors.toList());
				System.out.println(" size after filtering .... "+collectedList.size());
				filteredList.add(collectedList);
			  });
			 
		 }
		 
	 }else if(buSearch.getBusinessUnit()!=null && buSearch.getBusinessUnit().length()>0) {
		 listOfSankyGraphList= generateSaneyGraphCount(buDataList,buSearch);
		 if(listOfSankyGraphList.size()>0) {
		
			  listOfSankyGraphList.forEach(listOfSankeyGraph -> {
				  System.out.println(buSearch.getBusinessUnit()+" size before filtering .... "+listOfSankeyGraph.size()); 	
				List<SankeyGraphCount> collectedList =listOfSankeyGraph.parallelStream().filter(t-> (Integer.parseInt(buSearch.getBusinessUnit())==t.getSourceBUID() || Integer.parseInt(buSearch.getBusinessUnit())==t.getTargetBUID())).collect(Collectors.toList());
				System.out.println(" size after filtering .... "+collectedList.size());
				filteredList.add(collectedList);
				
			  });
			 
		 }
		}
	 if(filteredList.size()>0) {
				sankeyGraphNodes= generateSankeyGraphList(filteredList);
			}
				 
	 else {
		 sankeyGraphNodes= getFullSankeyGrapDataList(buDataList,buSearch);
	 }
	 
		return sankeyGraphNodes;
}
private void setCounter(Counter tempCounter,CountData countData) {
	
	 tempCounter.setSuccessCount(countData.getSuccessCount());
	 tempCounter.setFailureCount(countData.getFailureCount());
	 tempCounter.setTotalCount(countData.getFailureCount()+countData.getSuccessCount());
	 
}
private List<SankeyGraphCount> getSankeyGraphData(String entityIdParams,BUSearch buSearch) {


	StringBuffer query = null;
	Object[] params = new Object[0];
	
	List<SankeyGraphCount> sankeyGraphList = new ArrayList<SankeyGraphCount>();
	
	query = new StringBuffer("select a.bu_id as sourceBUID, a.application_id as sourceApplicationId, a.app_ID as sourceAppId, a.entity_id as sourceEntityId , a.source_target_type_indicator as source_indicator,\r\n" + 
			" b.bu_id as targetBUID, b.application_id as targetApplicationId, b.app_ID as targetAppId, b.entity_id as targetEntityId ,  b.source_target_type_indicator as target_indicator \r\n" + 
			" from BIO_ETM_BU_APP_ES_INFO a , BIO_ETM_BU_APP_ES_INFO b   where a.entity_id in ("+entityIdParams+" ) and a.entity_id = b.entity_id and a.source_target_type_indicator='S' and b.source_target_type_indicator ='T'  order by a.application_id \r\n" + 
			"");
	System.out.println(query);
	try {
		jdbcTemplate.query(query.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ResultSet tempRS = rs;
				SankeyGraphCount sankeyGraph = new SankeyGraphCount(); 
				
					Integer entityId = tempRS.getObject("sourceEntityId", Integer.class);
					sankeyGraph.setEntityId(entityId);
					
					getEntityName(entityId, sankeyGraph);
					
					getBUIDName(tempRS.getObject("sourceBUID", String.class), "S", sankeyGraph);
					getBUApplicationName(tempRS.getObject("sourceApplicationId", String.class),"S", sankeyGraph);
					sankeyGraph.setSourceAppID(tempRS.getObject("sourceAppId", String.class));
					getBUApplicationName(tempRS.getObject("targetApplicationId", String.class),"T", sankeyGraph);
					getBUIDName(tempRS.getObject("targetBUID", String.class), "T", sankeyGraph);
					sankeyGraph.setTargetAppID(tempRS.getObject("targetAppId", String.class));
					sankeyGraphList.add(sankeyGraph);
				
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	String searchDate=null;
	String durationText="BLM.SERVICE_START_TIME > sysdate - "+ defaultDuration;
	if( buSearch.getStartDate() != null && buSearch.getStartDate().length()>0 ) {
		String startDate = buSearch.getStartDate().trim().replace("T", " ");
		startDate = startDate.substring(0, startDate.length()-5);
		durationText =" trunc(BLM.SERVICE_START_TIME)>=TO_DATE('"+startDate+"','YYYY-MM-DD HH24:MI:SS')";
		searchDate = buSearch.getStartDate();
		
	}
	if( buSearch.getEndDate() != null && buSearch.getEndDate().length()>0 ) {
		String endDate = buSearch.getEndDate().trim().replace("T", " ");
		endDate = endDate.substring(0, endDate.length()-5);
		if(searchDate.equals(buSearch.getEndDate())) {
			durationText +=" and trunc(BLM.SERVICE_START_TIME)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')+1";
		} else {
			
			durationText +=" and trunc(BLM.SERVICE_START_TIME)<TO_DATE('"+endDate+"','YYYY-MM-DD HH24:MI:SS')";
		}
	}
	isStartAndEndDateToBeConsidered(buSearch.getDuration(), buSearch.getStartDate(), buSearch.getEndDate());
	
	if(isDurationNeedToBeConsidered()) { //   DaySelection Need to Be Considered
		 
		durationText="BLM.SERVICE_START_TIME > sysdate - "+ buSearch.getDuration();
		
	}
    final String durationFinal = durationText;
	sankeyGraphList.parallelStream().forEach(sankeyGraph-> {

		
		String sourceBUID_APPIDCountQuery = new String("SELECT DISTINCT BBAEI.BU_ID, (SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+ durationFinal+" AND BLM.SERVICE_STATUS='SUCCESS' AND BLM.APP_ID IN ("+ sankeyGraph.getSourceAppID() +" ) AND BU_ID ="+sankeyGraph.getSourceBUID()+") AS SC,"
		+ 
				"(SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+ durationFinal+" AND BLM.SERVICE_STATUS IN ("+this.failedStatus+")  AND BLM.APP_ID IN (" + sankeyGraph.getSourceAppID() +" ) AND BU_ID ="+sankeyGraph.getSourceBUID()+") AS FC ," +
				"(SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+ durationFinal+" AND BLM.SERVICE_STATUS='SUCCESS' AND BLM.APP_ID IN ("+ sankeyGraph.getTargetAppID() +" ) AND BU_ID ="+sankeyGraph.getSourceBUID()+") AS TargetSC ," +
				"(SELECT COUNT(*) FROM BIO_LOG_MAIN BLM WHERE "+ durationFinal+" AND BLM.SERVICE_STATUS IN ("+this.failedStatus+")  AND BLM.APP_ID IN (" + sankeyGraph.getTargetAppID() +" ) AND BU_ID ="+sankeyGraph.getSourceBUID()+") AS TargetFC "
						+ "FROM bio_etm_bu_app_es_info BBAEI where BU_ID IN("+sankeyGraph.getSourceBUID()+") AND ENTITY_ID IN  ("+ sankeyGraph.getEntityId() +") and APPLICATION_ID IN ("+sankeyGraph.getSourceBUApplicationID()+")"
								+ "");
	
		
		
		
		System.out.println( " sourceBUID_APPIDCountQuery "+sourceBUID_APPIDCountQuery);
		CountData countData = executeGetCountQuery(sourceBUID_APPIDCountQuery, params);
		
		System.out.println( " Source BUID "+sankeyGraph.getSourceBUIDName()+ " -  Source APPlication "+sankeyGraph.getSourceBUApplicationName());
		System.out.println( " sourceBUID_APPIDCountQuery "+countData.getSuccessCount()+ " - "+countData.getFailureCount());
		System.out.println( " sourceBUID_APPIDCountQuery "+countData.getTargetSuccessCount()+ " - "+countData.getTargetFailureCount());
			
		 Counter tempCounter = sankeyGraph.getSourceBUApplicationCounter();
		 setCounter(tempCounter, countData);
		 tempCounter = sankeyGraph.getEntityCounter();
		 setCounter(tempCounter, countData);
		 tempCounter = sankeyGraph.getTargetBUApplicationCounter();
		 setCounter(tempCounter, countData);
		 tempCounter = sankeyGraph.getTargetBUIDCounter();
		 setCounter(tempCounter, countData);
	});
	return sankeyGraphList;
}
private CountData executeGetCountQuery(String queryString,Object[] params) {
	CountData countData = new CountData();
	try {
		jdbcTemplate.query(queryString.toString(), params, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				ResultSet tempRS = rs;
				countData.setSuccessCount(((BigDecimal)tempRS.getObject(2)).longValue());
				countData.setFailureCount(((BigDecimal)tempRS.getObject(3)).longValue());
				countData.setTargetSuccessCount(((BigDecimal)tempRS.getObject(4)).longValue());
				countData.setTargetFailureCount(((BigDecimal)tempRS.getObject(5)).longValue());
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	return countData;
}
private void getBUIDName(String id,String indicatorFlag,SankeyGraphCount sankeyGraph) {

	if(buisnessUnitHashMap.containsKey(id)){
		if(indicatorFlag.contains("S")) {
			  sankeyGraph.setSourceBUID(Integer.parseInt(id));
			  
			  Counter tempCounter = sankeyGraph.getSourceBUIDName()!=null?sankeyGraph.getSourceBUIDCounter():new Counter();
			  tempCounter.set_name( ((String)buisnessUnitHashMap.get(id)));
			  sankeyGraph.setSourceBUIDName((String)buisnessUnitHashMap.get(id));
			  sankeyGraph.setSourceBUIDCounter(tempCounter);
			 
		  }else {
			  sankeyGraph.setTargetBUID(Integer.parseInt(id));
			  Counter tempCounter = sankeyGraph.getTargetBUIDName()!=null?sankeyGraph.getTargetBUIDCounter():new Counter();
			  tempCounter.set_name( ((String)buisnessUnitHashMap.get(id)));
			  sankeyGraph.setTargetBUIDName(((String)buisnessUnitHashMap.get(id)));
			  sankeyGraph.setTargetBUIDCounter(tempCounter);
		  }
	}else {
		
	
	StringBuffer query = new StringBuffer("select BU_NAME from BIO_ETM_BUSINESSUNIT where BU_ID="+id);
	try {
	
		jdbcTemplate.query(query.toString(),  new RowCallbackHandler() {
			
			public void processRow(ResultSet rs) throws SQLException {
				buisnessUnitHashMap.put(id, rs.getString(1));
			  if(indicatorFlag.contains("S")) {
				  sankeyGraph.setSourceBUID(Integer.parseInt(id));
				  Counter tempCounter = sankeyGraph.getSourceBUIDName()!=null?sankeyGraph.getSourceBUIDCounter():new Counter();
				  tempCounter.set_name( rs.getString(1));
				  sankeyGraph.setSourceBUIDName(rs.getString(1));
				  sankeyGraph.setSourceBUIDCounter(tempCounter);
				 
			  }else {
				  sankeyGraph.setTargetBUID(Integer.parseInt(id));
				  Counter tempCounter = sankeyGraph.getTargetBUIDName()!=null?sankeyGraph.getTargetBUIDCounter():new Counter();
				  tempCounter.set_name(rs.getString(1));
				  sankeyGraph.setTargetBUIDName(rs.getString(1));
				  sankeyGraph.setTargetBUIDCounter(tempCounter);
			  }
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	}
}

private void getBUApplicationName(String applicationId,String indicatorFlag,SankeyGraphCount sankeyGraph) {

	if(applicationHashMap.containsKey(applicationId)){
		if(indicatorFlag.contains("S")) {
			sankeyGraph.setSourceBUApplicationID(Integer.parseInt(applicationId));
			Counter tempCounter = sankeyGraph.getSourceBUApplicationName()!=null?sankeyGraph.getSourceBUApplicationCounter():new Counter();
			  tempCounter.set_name((String)applicationHashMap.get(applicationId));
			  sankeyGraph.setSourceBUApplicationName((String)applicationHashMap.get(applicationId));
			  sankeyGraph.setSourceBUApplicationCounter(tempCounter);
			  
			
			 
		  }else {
			  sankeyGraph.setTargetBUApplicationID(Integer.parseInt(applicationId));
			  Counter tempCounter = sankeyGraph.getTargetBUApplicationName()!=null?sankeyGraph.getTargetBUApplicationCounter():new Counter();
			  tempCounter.set_name((String)applicationHashMap.get(applicationId));
			  sankeyGraph.setTargetBUApplicationName((String)applicationHashMap.get(applicationId));
			  sankeyGraph.setTargetBUApplicationCounter(tempCounter);
		
		  }
	}else {
	
	StringBuffer query = new StringBuffer("select APPLICATION_NAME from BIO_ETM_APPLICATION where APPLICATION_ID="+applicationId);
	try {
		jdbcTemplate.query(query.toString(),  new RowCallbackHandler() {
			
			public void processRow(ResultSet rs) throws SQLException {
				applicationHashMap.put(applicationId,rs.getString(1));
			
			  if(indicatorFlag.contains("S")) {
				  sankeyGraph.setSourceBUApplicationID(Integer.parseInt(applicationId));
				  Counter tempCounter = sankeyGraph.getSourceBUApplicationName()!=null?sankeyGraph.getSourceBUApplicationCounter():new Counter();
				  tempCounter.set_name(rs.getString(1));
				  sankeyGraph.setSourceBUApplicationName(rs.getString(1));
				  sankeyGraph.setSourceBUApplicationCounter(tempCounter);
				 
			  }else {
				  sankeyGraph.setTargetBUApplicationID(Integer.parseInt(applicationId));
				  Counter tempCounter = sankeyGraph.getSourceBUApplicationName()!=null?sankeyGraph.getSourceBUApplicationCounter():new Counter();
				  tempCounter.set_name(rs.getString(1));
				  sankeyGraph.setTargetBUApplicationName(rs.getString(1));
				  sankeyGraph.setTargetBUApplicationCounter(tempCounter);
			  }
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	}
}


private void getEntityName(Integer entityId,SankeyGraphCount sankeyGraph) {

	if(entityNameHashMap.containsKey(Integer.toString(entityId))){
		
		Counter tempCounter = sankeyGraph.getEntityName()!=null?sankeyGraph.getEntityCounter():new Counter();
		tempCounter.set_name(entityNameHashMap.get(Integer.toString(entityId)));
		sankeyGraph.setEntityName(entityNameHashMap.get(Integer.toString(entityId)));
		sankeyGraph.setEntityCounter(tempCounter);
	}else {
	StringBuffer query = new StringBuffer("select ENTITY_NAME from BIO_ETM_ENTITY where ENTITY_ID="+entityId);
	try {
		jdbcTemplate.query(query.toString(),  new RowCallbackHandler() {
			
			public void processRow(ResultSet rs) throws SQLException {
			      entityNameHashMap.put(Integer.toString(entityId), rs.getString(1));
			      Counter tempCounter = sankeyGraph.getEntityName()!=null?sankeyGraph.getEntityCounter():new Counter();
				  tempCounter.set_name(rs.getString(1));
				  sankeyGraph.setEntityName(rs.getString(1));
				sankeyGraph.setEntityCounter(tempCounter);
				  
			}
		});
	} catch (Exception ex) {
		ex.printStackTrace();
	}
	}
}
private Collector<SankeyGraphCount, ?, Map<String, List<SankeyGraphCount>>> groupByAPPName() {
    return Collectors.groupingBy(SankeyGraphCount::getSourceBUApplicationName);
}
private Collector<SankeyGraphCount, ?, Map<String, List<SankeyGraphCount>>> groupByEntityName() {
    return Collectors.groupingBy(SankeyGraphCount::getEntityName);
}
private Collector<SankeyGraphCount, ?, Map<String, List<SankeyGraphCount>>> groupByTargetAPPName() {
    return Collectors.groupingBy(SankeyGraphCount::getTargetBUApplicationName);
}


private Collector<SankeyGraphCount, ?, Map<String, List<SankeyGraphCount>>> groupByTargetBUName() {
    return Collectors.groupingBy(SankeyGraphCount::getTargetBUIDName);
}

private List<SankeyGraphNode> generateSankeyGraphList(List<List<SankeyGraphCount>> listOfSankyGraphList) {
	System.out.println(listOfSankyGraphList.size());
	List<SankeyGraphNode> sankeyGraphNodes= new ArrayList<>();
	
	
	for(List<SankeyGraphCount> listSankeyGraph:listOfSankyGraphList) {
		
		
		System.out.println(listSankeyGraph.size());
		final Map<String, Map<String ,List<SankeyGraphCount>>> sourceBU_APPGroupList= listSankeyGraph.stream().collect(
				Collectors.groupingBy(SankeyGraphCount::getSourceBUIDName,groupByAPPName()));
		sourceBU_APPGroupList.forEach((buidkey,e)-> {
			System.out.println("BUID : " + buidkey);
			e.forEach((appidkey,items) -> {
				
				 System.out.println("--------------------- APP ID Key: " + appidkey);
				  
				  items.forEach(item -> {
				  System.out.println(" ---------------------Source Application Name "+item.
				  getSourceBUApplicationName());
				  System.out.println(" ----------------------Entity count "+item.
				  getSourceBUApplicationCounter().getTotalCount());
				  });
				long weight =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getSourceBUApplicationCounter().getTotalCount()));
				long successCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getSourceBUApplicationCounter().getSuccessCount()));
				long failureCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getSourceBUApplicationCounter().getFailureCount()));
				
				if(weight>0)
				sankeyGraphNodes.add(new SankeyGraphNode(""+buidkey+"", ""+appidkey+"", weight,successCount,failureCount));
			});
			
		});
		
		final Map<String, Map<String ,List<SankeyGraphCount>>> sourceAPP_EntityGroupList= listSankeyGraph.stream().collect(
				Collectors.groupingBy(SankeyGraphCount::getSourceBUApplicationName,groupByEntityName()));
		sourceAPP_EntityGroupList.forEach((appidkey,e)-> {
			System.out.println("APPID : " + appidkey);
			e.forEach((entityKey,items) -> {
				 System.out.println("--------------------- Entity ID Key: " + entityKey);
				  
				  items.forEach(item -> {
				  System.out.println(" ---------------------Entity Name "+item.
				  getEntityName());
				  System.out.println(" ----------------------Entity count "+item.
				  getEntityCounter().getTotalCount());
				  });
				long weight =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getEntityCounter().getTotalCount()));
				long successCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getEntityCounter().getSuccessCount()));
				long failureCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getEntityCounter().getFailureCount()));
		
				if(weight>0)
				sankeyGraphNodes.add(new SankeyGraphNode(""+appidkey+"", ""+entityKey+"", weight,successCount,failureCount));
				});
				
		});
		
		
		final Map<String, Map<String ,List<SankeyGraphCount>>> targetEntity_APPGroupList= listSankeyGraph.stream().collect(
				Collectors.groupingBy(SankeyGraphCount::getEntityName,groupByTargetAPPName()));
		targetEntity_APPGroupList.forEach((entityIDKey,e)-> {
			System.out.println("Entity ID : " + entityIDKey);
			e.forEach((targetappkey,items) -> {
	
				long weight =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUApplicationCounter().getTotalCount()));
				long successCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUApplicationCounter().getSuccessCount()));
				long failureCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUApplicationCounter().getFailureCount()));
				
				if(weight>0)
				sankeyGraphNodes.add(new SankeyGraphNode(""+entityIDKey+"", " "+targetappkey+"", weight,successCount,failureCount));
				});
				
		});
		
		
		final Map<String, Map<String ,List<SankeyGraphCount>>> targetAPP_BUIDGroupList= listSankeyGraph.stream().collect(
				Collectors.groupingBy(SankeyGraphCount::getTargetBUApplicationName,groupByTargetBUName()));
		targetAPP_BUIDGroupList.forEach((targetapidKey,e)-> {
			System.out.println("Target APP ID : " + targetapidKey);
			e.forEach((targetbuidkey,items) -> {
		
				long weight =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUIDCounter().getTotalCount()));
				long successCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUIDCounter().getSuccessCount()));
				long failureCount =  items.stream()
						   .collect(Collectors.summingLong(e1-> e1.getTargetBUIDCounter().getFailureCount()));
				
				if(weight>0)
				sankeyGraphNodes.add(new SankeyGraphNode(" "+targetapidKey+"", " "+targetbuidkey+"", weight,successCount,failureCount));
				
				});
				
		});
		
		
	    
		
		
		
		
	  
	   
	}
	return sankeyGraphNodes;
}


public void isStartAndEndDateToBeConsidered(int daysSelected, String startDate, String endDate) {
	System.out.println("isStartAndEndDateToBeConsidered");
	if(startDate!=null&& startDate.length()>0 && endDate!=null && endDate.length()>0) {
	LocalDate _startDate = LocalDate.parse(startDate,DateTimeFormatter.ISO_DATE_TIME);
	System.out.println(_startDate);
	LocalDate _endDate = LocalDate.parse(endDate, DateTimeFormatter.ISO_DATE_TIME);
	System.out.println(_endDate);
	Period period = Period.between(_startDate,_endDate);
	long p2 = ChronoUnit.DAYS.between(_startDate,_endDate );
	System.out.println(p2);
	if (p2 > daysSelected) {
		System.out.println(" number of date "+ p2+"selected is greater than daysselected "+daysSelected);
		this.setDurationNeedToBeConsidered(false); // Start Date and End date Selection Need to Be considered
		
	}else {
		this.setDurationNeedToBeConsidered(true); // DaysSelection Need to Be considered
	}
	}else { // DaysSelection Need to Be considered
		this.setDurationNeedToBeConsidered(true);
	}
	
}

public boolean isDurationNeedToBeConsidered() {
	return isDurationNeedToBeConsidered;
}

public void setDurationNeedToBeConsidered(boolean isDurationNeedToBeConsidered) {
	this.isDurationNeedToBeConsidered = isDurationNeedToBeConsidered;
}

}
