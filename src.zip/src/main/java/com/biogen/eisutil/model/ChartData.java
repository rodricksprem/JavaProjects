package com.biogen.eisutil.model;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ChartData {
	
	String name;
	int y;
	String id;
	float avgTime;
	String drilldown;
	List<ChartData> data ;
	
	
	
}
