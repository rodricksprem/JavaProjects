package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SankeyGraphCount  {

	private int entityId;
	private String entityName;
	private Counter entityCounter;
	private int sourceBUID;
	private String sourceBUIDName;
	private Counter sourceBUIDCounter;
	private int sourceBUApplicationID;
	private String sourceBUApplicationName;
	private Counter sourceBUApplicationCounter;
	private int targetBUApplicationID;
	private String targetBUApplicationName;
	private Counter targetBUApplicationCounter;
	private int targetBUID;
	private String targetBUIDName;	
	private Counter targetBUIDCounter;
	private String sourceAppID;
	private String targetAppID;
	
	@Override
	public String toString() {
		return "SankeyGraph [entityId=" + entityId + ", entityName=" + entityName + ", sourceBUID=" + sourceBUID
				+ ", sourceBUIDName=" + sourceBUIDName + ", sourceBUApplication=" + sourceBUApplicationID
				+ ", sourceBUApplicationName=" + sourceBUApplicationName + ", targetBUApplication="
				+ targetBUApplicationID + ", targetBUApplicationName=" + targetBUApplicationName + ", targetBUID="
				+ targetBUID + ", targetBUIDName=" + targetBUIDName + "]";
	}
	
	
		
}
