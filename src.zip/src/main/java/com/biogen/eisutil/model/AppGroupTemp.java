package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AppGroupTemp {
	private String appGroupId;
	private String appGroup;
	
}
