package com.biogen.eisutil.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

public class BioAppDocHistoryTemp {

	private Integer appId;
	private Integer integrationPatternId;
	private String integrationPatternName;
	private Integer sourceTypeId;
	private Integer targetTypeId;
	private Integer fileId;
	private Integer appIntegrationId;
	private String appName;
	private String itpdNo;
	private String crNo;
	private String itpdDescription;
	private String crDescription;
	private String comments;
	private Timestamp implementedDate;
	private String createdBy;
	private String createdDate;
	private String sourceSystem;
	private String targetSystem;
	private String sourceType;
	private String targetType;
	
	@Override
	public String toString() {
		return "BioAppDocHistoryTemp [appIntegrationID=" + appIntegrationId + ", appID=" + appId + ", patternID=" + integrationPatternId
				+ ", sourceTypeID=" + sourceTypeId + ", targetTypeID=" + targetTypeId
				+ ", fileID=" + fileId + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", itpdNO=" + itpdNo + ", itpdDescription="
				+ itpdDescription + ",crNO="+crNo+",cr description="+crDescription+",comments="+comments+",implementationDate="+implementedDate+"]";
	}
	
}
