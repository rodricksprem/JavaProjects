package com.biogen.eisutil.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class BioCRDetailsData {

	@Override
	public String toString() {
		return "BioLogCRDetailsEntity [crID=" + crID + ", appIntegrationID=" + appIntegrationID + ", crNumber=" + crNumber
				+ ", crDescription=" + crDescription + ", implementationDate=" + implementationDate + ", comments=" + comments + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate="
				+ updatedDate + "]";
	}

	private Integer crID;
	
	private Integer appIntegrationID;
	
	private String crNumber;
	
	private String crDescription;
	
	private String implementationDate;
	
	private String comments;
	
	private String createdBy;
	
	private Timestamp createdDate;
	
	private String updatedBy;
	
	private Timestamp updatedDate;

}
