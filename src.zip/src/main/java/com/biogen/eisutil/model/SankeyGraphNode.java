package com.biogen.eisutil.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SankeyGraphNode {

	private String source;
	private String destination;
	private long weight=1;
	private long total=0;
	private long successCount=0;
	private long failureCount=0;
	public SankeyGraphNode(String source, String destination,long total,long successCount,long failureCount) {
		
		this.source=source;
		this.destination=destination;
		this.weight=total;
		this.total=total;
		this.successCount=successCount;
		this.failureCount=failureCount;
		
	}
	@Override
	public String toString() {
		return "['"+ source + "','" + destination + "'," + weight+ "," + total +"],";
	}
	
	
}
