package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServerResponse {
	private Integer id;
	private String status;
	private String errorCode;
	private String errorDescription;
	
	
}
