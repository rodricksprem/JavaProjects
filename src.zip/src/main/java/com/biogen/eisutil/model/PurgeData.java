package com.biogen.eisutil.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PurgeData {
	
	int purgeId;
	String purgeStatus;
	String purgeRemarks;
	Timestamp purgeStartDate;
	Timestamp purgeEndDate;
	String executedBy;
	Timestamp executedDate;
			
}
