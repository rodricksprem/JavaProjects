package com.biogen.eisutil.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioNotifyPropsTemp {
	private String name;
	private String value;
	private List<String> exCategoryList;
	private List<String> exTypeList;
	}
