package com.biogen.eisutil.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioLogUserData {
	
	private String userId;
	

	private Integer userType;
	

	private String emailID;
	

	private String firstName;
	

	private String lastName;
	

	private String createdBy;
	

	private Date createdDate;
	

	private Date updatedDate;
	

	private String password;
	

	private String updatedBy;
	
	private String buList;
	
}
