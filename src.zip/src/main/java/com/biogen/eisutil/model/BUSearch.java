package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BUSearch {
	
	private String businessUnit;
	private String applicationName;
	private String entityName;
	private String entServiceName;
	private Integer duration=7;
	private String startDate;
	private String endDate;
	private Integer appId;
		public String toString() {
		return "businessUnit:"+businessUnit+";applicationName:"+applicationName+";entityName:"+entityName+";entServiceName:"+entServiceName+";appId:"+appId+";startDate:"+startDate+";endDate:"+endDate+";duration:"+duration;
	}
}
