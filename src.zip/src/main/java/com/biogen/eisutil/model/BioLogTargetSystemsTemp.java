package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioLogTargetSystemsTemp {
	private String id;
	private String serviceInvokerStatus;
	
}
