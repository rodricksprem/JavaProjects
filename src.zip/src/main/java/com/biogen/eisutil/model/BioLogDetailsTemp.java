package com.biogen.eisutil.model;

import java.util.List;

import com.biogen.eisutil.model.TargetSystemLogDetails;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioLogDetailsTemp {
	
	List<BioLogDetails> bioLogDetailsList;
	List<TargetSystemLogDetails> targetSystemLogDetailsList;
	
}
