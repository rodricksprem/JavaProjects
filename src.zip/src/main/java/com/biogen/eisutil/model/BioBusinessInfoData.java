package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class BioBusinessInfoData {
	
	private Integer businessId;
	private Integer buId;
	private Integer applicationId;
	private Integer entityId;
	private Integer esId;
	private Integer sourceTargetTypeId;
	private Integer appId;
	private String sourceTargetTypeInd;
	public Integer getBusinessId() {
		return businessId;
	}
	public void setBusinessId(Integer businessId) {
		this.businessId = businessId;
	}
	public Integer getBuId() {
		return buId;
	}
	public void setBuId(Integer buId) {
		this.buId = buId;
	}
	public Integer getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public Integer getEsId() {
		return esId;
	}
	public void setEsId(Integer esId) {
		this.esId = esId;
	}
	public Integer getSourceTargetTypeId() {
		return sourceTargetTypeId;
	}
	public void setSourceTargetTypeId(Integer sourceTargetTypeId) {
		this.sourceTargetTypeId = sourceTargetTypeId;
	}
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	public String getSourceTargetTypeInd() {
		return sourceTargetTypeInd;
	}
	public void setSourceTargetTypeInd(String sourceTargetTypeInd) {
		this.sourceTargetTypeInd = sourceTargetTypeInd;
	}
}
