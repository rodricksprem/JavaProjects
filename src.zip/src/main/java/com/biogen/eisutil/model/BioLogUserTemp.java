package com.biogen.eisutil.model;

import java.util.List;

import com.biogen.eisutil.model.BusinessUnitData;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioLogUserTemp {
	private String userId;
	private String userType;
	private String emailID;
	private String firstName;
	private String lastName;
	private String createdDate;
	private String updatedDate;
	private String buStr;
	private List<BusinessUnitData> buList;
	
}
