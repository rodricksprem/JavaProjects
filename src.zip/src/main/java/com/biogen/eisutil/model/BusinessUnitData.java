package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BusinessUnitData {
	private int appId;
	private String appName;
	
}
