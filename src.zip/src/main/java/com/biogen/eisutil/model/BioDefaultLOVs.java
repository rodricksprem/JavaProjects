package com.biogen.eisutil.model;

import java.util.List;

import com.biogen.eisutil.model.BioLOVsData;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

public class BioDefaultLOVs {
	
	List<BioLOVsData> buList;
	List<BioLOVsData> applicationList;
	List<BioLOVsData> entityList;
	List<BioLOVsData> esList;
	List<BioLOVsData> patternList;
	List<BioLOVsData> sourceList;
	List<BioLOVsData> targetList;
	List<BioLOVsData> sourceTargetTypeList;
	List<BioBusinessInfoData> buAssociationList;
	
}

