package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioNotifyHistoryDetails {
	private String name;
	private String value;
	private String valueClob;
	}
