package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioLogTemp {
	private String bioTransId;
	private String appGroup;
	private String appName;

	private String serviceInvoker;
	private String serviceInvokerStatus;
	private String startTime;
	private String endTime;
	private String message;
	private int notificationSize;
	
}
