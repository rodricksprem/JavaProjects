package com.biogen.eisutil.model;

import java.util.List;



import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChartDetails {
	
	List<ChartData> donutChartList;
	List<ChartData> notifyChartList;
	BarChartDataList barChartData;

	
}
