package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioNotifyTemp {
	private String notifyHistoryId;
	private String appGroup;
	private String appName;
	private String exCategory;
	private String exType;
	private String status;
	private String createdDate;
	private String updatedDate;
	private String biogenTransId;
	}
