package com.biogen.eisutil.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioNotification {

	public String toString() {
		return "BioLogApplication [appId=" + appId + ", exceptionCategory=" + exceptionCategory + ", exceptionType=" + exceptionType
				+ ", notificationEnabled=" + notificationEnabled + ", toemail=" + toemail + ", fromEmail=" + fromEmail + ", ccemail=" + ccemail + ", template="
				+ template + ", notificationType=" + notificationType + ",notifyId="+notifyId+",notifyPropsId="+notifyPropsId+", frequency=" + frequency + ", thresholdEnabled="
				+ thresholdEnabled +",thresholdLimit="+thresholdLimit+",aggregationEnabled="+aggregationEnabled+",aggregationCount="+aggregationCount+",createdBy="+createdBy+"]";
	}

	private Integer notifyId;
	private Integer notifyPropsId;
	private Integer appId;
    private String exceptionCategory;
    private String exceptionType;
    private String notificationEnabled;
    private String fromEmail;
    private String toemail;
    private String ccemail;
    private String template;
    private String notificationType;
    private String frequency;
    private String thresholdEnabled;
    private String thresholdLimit;
    private String aggregationEnabled;
    private String aggregationCount;
    private String createdBy;
    private Timestamp createdDate;
	private String updatedBy;
	private Timestamp updatedDate;
}
