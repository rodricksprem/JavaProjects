package com.biogen.eisutil.model;

import java.util.List;
import java.util.stream.Collectors;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioLogSearch {
	private String appGroup;
	private String appName;
	private String key;
	private String value;
	private String period;
	private String startDate;
	private String endDate;
	private List<String> status;
	private String bioTransId;
	private String condition;
	
		@Override
	public String toString() {
		
		return "BioLogSearch [appGroup=" + appGroup + ", appName=" + appName + ", key=" + key + ", value=" + value
				+ ", period=" + period + ", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status.stream()
                .collect(Collectors.joining(","))
				+ ", bioTransId=" + bioTransId + ", condition=" + condition + "]";
	}
	
	
}
