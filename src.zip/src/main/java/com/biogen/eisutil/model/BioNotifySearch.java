package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioNotifySearch {
	private String appGroup;
	private String appName;
	private String exCategory;
	private String exType;
	private String status;
	private String createdDate;
	private String updatedDate;
	private String bioTransId;
	
}
