package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioNotifyCategory {
	
	private String appName;
	private String exCategory;
	private String exType;
	private String createdBy;
	private String createdDate;
	private String updatedBy;
	private String updatedDate;

}
