package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CountData {
	private long successCount;
	private long failureCount;
	private long totalCount;
	private long targetSuccessCount;
	private long targetFailureCount;
	private long  targetTotalCount;
	
}
