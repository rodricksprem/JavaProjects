package com.biogen.eisutil.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TargetSystemLogDetails {
	

	private String targetSystemName;
	private String targetServiceStatus;
	private String targetServiceStartTime;
	private String targetServiceEndTime;
	
	private List<BioLogDetails> logDetailsList;
	}
