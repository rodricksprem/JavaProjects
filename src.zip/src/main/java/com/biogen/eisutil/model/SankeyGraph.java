package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SankeyGraph  {

	private int entityId;
	private String entityName;
	private int sourceBUID;
	private String sourceBUIDName;
	private int sourceBUApplication;
	private String sourceBUApplicationName;
	
	private int targetBUApplication;
	private String targetBUApplicationName;
	private int targetBUID;
	private String targetBUIDName;
	private String sourceAppID;
	private String targetAppID;
		
	@Override
	public String toString() {
		return "SankeyGraph [entityId=" + entityId + ", entityName=" + entityName + ", sourceBUID=" + sourceBUID
				+ ", sourceBUIDName=" + sourceBUIDName + ", sourceBUApplication=" + sourceBUApplication
				+ ", sourceBUApplicationName=" + sourceBUApplicationName + ", targetBUApplication="
				+ targetBUApplication + ", targetBUApplicationName=" + targetBUApplicationName + ", targetBUID="
				+ targetBUID + ", targetBUIDName=" + targetBUIDName + "]";
	}
	
	
		
}
