package com.biogen.eisutil.model;

import com.biogen.eisutil.model.BarChartDataList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class BarChart {
	
	String name;
	int y;
	String id;
	String drilldown;
	BarChartDataList dataList;
	
	
}
