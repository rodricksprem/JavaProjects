package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DonutChart {
	
	String appName;
	int appCount;
}
