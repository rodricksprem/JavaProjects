package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Counter {

	private String _name;
	private long totalCount;
	private long successCount;
	private long failureCount;
}

