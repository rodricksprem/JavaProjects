package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogLevelTemp {
	private String loggerId;
	private String loggerLevel;
	
}
