package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PurgeDetailsData {
	
	private int purgeDetailId;
	private int purgeId;
	private int logCount;
	private int notifyCount;
	private String appName;
	private String appGroupName;
	
		
}
