package com.biogen.eisutil.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NotificationBarChart implements Comparable<NotificationBarChart> {

	String appName;
	int appCount;
	int percentage;
	
	
	@Override
	public int compareTo(NotificationBarChart o) {
		
		int result = 0;
		if ( this.appCount > o.appCount )
			result = -1;
		else 
			result = 1;
		return result;
	}
}
