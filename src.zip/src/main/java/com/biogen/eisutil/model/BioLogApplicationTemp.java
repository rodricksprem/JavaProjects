package com.biogen.eisutil.model;

public class BioLogApplicationTemp {
	private Integer appId;
	private String appGroup;
	private String appName;
	private String appType;
	private String logLevel;
	private String createdDate;
	private String updatedDate;
	
	public String getAppGroup() {
		return appGroup;
	}
	public void setAppGroup(String appGroup) {
		this.appGroup = appGroup;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getLogLevel() {
		return logLevel;
	}
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	
	
}
