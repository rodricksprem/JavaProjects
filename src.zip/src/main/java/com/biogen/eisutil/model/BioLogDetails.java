package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioLogDetails {
	
	private String serviceInvoker;
	private String serviceStatus;
	private String messageCode;
	private String messageDesc;
	private String logLevel;
	private String payLoad;
	private String key;
	private String value;
	private String serviceStartTime;
	
	public void setDefaultBioLogDetails(){
		this.serviceInvoker = "";
		this.serviceStatus = "";
		this.messageCode = "";
		this.messageDesc = "";
		this.logLevel = "";
		this.payLoad = "";
		this.key = "";
		this.value = "";
		this.serviceStartTime = "";
	}
		
}
