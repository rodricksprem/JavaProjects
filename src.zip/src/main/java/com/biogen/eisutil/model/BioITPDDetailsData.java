package com.biogen.eisutil.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class BioITPDDetailsData {

	@Override
	public String toString() {
		return "BioLogITPDDetailsEntity [itpdID=" + itpdID + ", appIntegrationID=" + appIntegrationID + ", itpdNumber=" + itpdNumber
				+ ", itpdDescription=" + itpdDescription + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate="
				+ updatedDate + "]";
	}

	private Integer itpdID;
	
	private Integer appIntegrationID;
	

	private String itpdNumber;
	

	private String itpdDescription;
	
	private String createdBy;
	
	private Timestamp createdDate;
	
	private String updatedBy;
	
	private Timestamp updatedDate;

}
