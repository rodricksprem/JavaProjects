package com.biogen.eisutil.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioNotifyPropsDaoTemp {

	private Integer appId;
	private String exCategory;
	private String exType;
	private String name;
	private String value;
	private Date createdDate;
	private Date updatedDate;
	private String createdBy;
	private String updatedBy;
	
}
