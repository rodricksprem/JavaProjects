package com.biogen.eisutil.model;

import java.sql.Timestamp;
import java.util.List;

import com.biogen.eisutil.model.BioLOVsData;
import com.biogen.eisutil.model.BioNotification;
import com.biogen.eisutil.model.ServerResponse;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class BioLogApplicationData {

	public String toString() {
		return "BioLogApplication [appId=" + appId + ", appName=" + appName + ", appTypeId=" + appTypeId
				+ ", appGroupId=" + appGroupId + ", loggerId=" + loggerId + ", appDesc=" + appDesc + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate="
				+ updatedDate +",entity="+entity+",enterpriseService="+enterpriseService+",sourceBU="+sourceBu+",sourceApplication="+sourceApplication+",targetBu="+targetBu+",targetApplication="+targetApplication+",source AppList:"+sourceAppList.toString()+",targetApplist:"+targetAppList.toString() +"]";
	}

	private Integer appId;
	
	private String appName;
	
	private Integer appTypeId;
	
	private Integer appGroupId;

	private Integer loggerId;

	private String appDesc;

	private String createdBy;
	
	private Timestamp createdDate;

	private String updatedBy;
	
	private Timestamp updatedDate;
	
	private Integer entity;
	
	private Integer enterpriseService;
	
	private String sourceBu;
	
	private String targetBu;
	
	private String sourceApplication;
	
	private String targetApplication;

	private ServerResponse serverResponse;
	
	private List<BioLOVsData> sourceAppList;

	private List<BioLOVsData> targetAppList;
	
	List<BioBusinessInfoData> businessInfoDataList;
	
	List<BioNotification> notificationList;
	BioIntegrationDetails integrationDetails;
	
}
