package com.biogen.eisutil.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BioLOVsData {

	public String toString() {
		return "BioLOVsData [Id=" + id + ", Name=" + name + ", description=" + description
				+ ", status=" + status + ", type="+type+", refId="+refId+",text="+text+"]";
	}

	private Integer id;
	
	private String name;
	
	private String description;
	
	private String status;

	private String type;
	
	private Integer refId;
	
	private String text;
	
}
