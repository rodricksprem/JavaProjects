package com.biogen.eisutil.model;

import java.util.List;

import com.biogen.eisutil.model.BioITPDDetailsData;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

public class BioIntegrationDetails {

	private Integer integrationId;
	private Integer appId;
	private Integer integrationPatternId;
	private Integer fileId;
	private List<BioITPDDetailsData> itpdDetailsList;
	private List<BioCRDetailsData> crDetailsList;
		
	
	@Override
	public String toString() {
		return "BioAppDocHistoryTemp [integrationId=" + integrationId + ", appID=" + appId + ", patternID=" + integrationPatternId
				+ ", fileID=" + fileId +"]";
	}

		
}
