(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	var module = __webpack_require__(id);
	return module;
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet ></router-outlet>\n<!-- <ng4-loading-spinner> </ng4-loading-spinner> -->\n<ng4-loading-spinner [threshold]=\"200\" [timeout]=\"40000000\"></ng4-loading-spinner>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'app';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_logout_logout_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/logout/logout.component */ "./src/app/components/logout/logout.component.ts");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _components_side_bar_side_bar_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/side-bar/side-bar.component */ "./src/app/components/side-bar/side-bar.component.ts");
/* harmony import */ var _components_dash_board_dash_board_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/dash-board/dash-board.component */ "./src/app/components/dash-board/dash-board.component.ts");
/* harmony import */ var _components_dash_board_content_dash_board_content_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/dash-board-content/dash-board-content.component */ "./src/app/components/dash-board-content/dash-board-content.component.ts");
/* harmony import */ var _components_notification_notification_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/notification/notification.component */ "./src/app/components/notification/notification.component.ts");
/* harmony import */ var _components_logging_logging_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/logging/logging.component */ "./src/app/components/logging/logging.component.ts");
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./service/user.service */ "./src/app/service/user.service.ts");
/* harmony import */ var _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./service/bio-notify.service */ "./src/app/service/bio-notify.service.ts");
/* harmony import */ var _service_bio_log_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./service/bio-log.service */ "./src/app/service/bio-log.service.ts");
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
/* harmony import */ var ag_grid_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ag-grid-angular */ "./node_modules/ag-grid-angular/main.js");
/* harmony import */ var ag_grid_angular__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(ag_grid_angular__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ng2-charts/ng2-charts */ "./node_modules/ng2-charts/ng2-charts.js");
/* harmony import */ var ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var angular_morris_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! angular-morris-js */ "./node_modules/angular-morris-js/esm5/angular-morris-js.js");
/* harmony import */ var _components_user_user_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/user/user.component */ "./src/app/components/user/user.component.ts");
/* harmony import */ var _components_log_details_model_log_details_model_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/log-details-model/log-details-model.component */ "./src/app/components/log-details-model/log-details-model.component.ts");
/* harmony import */ var _components_notification_details_model_notification_details_model_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components/notification-details-model/notification-details-model.component */ "./src/app/components/notification-details-model/notification-details-model.component.ts");
/* harmony import */ var _components_app_info_app_info_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components/app-info/app-info.component */ "./src/app/components/app-info/app-info.component.ts");
/* harmony import */ var _components_interface_design_model_interface_design_model_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components/interface-design-model/interface-design-model.component */ "./src/app/components/interface-design-model/interface-design-model.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _service_GlobalErrorHandler__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./service/GlobalErrorHandler */ "./src/app/service/GlobalErrorHandler.ts");
/* harmony import */ var _components_general_instruction_general_instruction_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./components/general-instruction/general-instruction.component */ "./src/app/components/general-instruction/general-instruction.component.ts");
/* harmony import */ var _components_error_page_error_page_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./components/error-page/error-page.component */ "./src/app/components/error-page/error-page.component.ts");
/* harmony import */ var _service_force_direct_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./service/force-direct.service */ "./src/app/service/force-direct.service.ts");
/* harmony import */ var _components_new_interface_new_interface_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./components/new-interface/new-interface.component */ "./src/app/components/new-interface/new-interface.component.ts");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ng-multiselect-dropdown */ "./node_modules/ng-multiselect-dropdown/fesm5/ng-multiselect-dropdown.js");
/* harmony import */ var ng2_completer__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ng2-completer */ "./node_modules/ng2-completer/esm5/ng2-completer.js");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _components_data_purge_data_purge_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./components/data-purge/data-purge.component */ "./src/app/components/data-purge/data-purge.component.ts");
/* harmony import */ var _components_data_purge_details_data_purge_details_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./components/data-purge-details/data-purge-details.component */ "./src/app/components/data-purge-details/data-purge-details.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







































var appRoutes = [
    //{path:'', component:LoginComponent},
    { path: 'error', component: _components_error_page_error_page_component__WEBPACK_IMPORTED_MODULE_28__["ErrorPageComponent"] },
    { path: 'logout', component: _components_logout_logout_component__WEBPACK_IMPORTED_MODULE_6__["LogoutComponent"] },
    { path: '', component: _components_dash_board_dash_board_component__WEBPACK_IMPORTED_MODULE_9__["DashBoardComponent"] },
    { path: 'dbtemp', component: _components_dash_board_dash_board_component__WEBPACK_IMPORTED_MODULE_9__["DashBoardComponent"] },
    { path: 'notification', component: _components_notification_notification_component__WEBPACK_IMPORTED_MODULE_11__["NotificationComponent"] },
    { path: 'logging', component: _components_logging_logging_component__WEBPACK_IMPORTED_MODULE_12__["LoggingComponent"] },
    { path: 'user', component: _components_user_user_component__WEBPACK_IMPORTED_MODULE_20__["UserComponent"] },
    { path: 'appinfo', component: _components_app_info_app_info_component__WEBPACK_IMPORTED_MODULE_23__["AppInfoComponent"] },
    { path: 'generalInstruction', component: _components_general_instruction_general_instruction_component__WEBPACK_IMPORTED_MODULE_27__["GeneralInstructionComponent"] },
    { path: 'newInterface', component: _components_new_interface_new_interface_component__WEBPACK_IMPORTED_MODULE_30__["NewInterfaceComponent"] },
    { path: 'dataPurge', component: _components_data_purge_data_purge_component__WEBPACK_IMPORTED_MODULE_36__["DataPurgeComponent"] },
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _components_logout_logout_component__WEBPACK_IMPORTED_MODULE_6__["LogoutComponent"],
                _components_header_header_component__WEBPACK_IMPORTED_MODULE_7__["HeaderComponent"],
                _components_side_bar_side_bar_component__WEBPACK_IMPORTED_MODULE_8__["SideBarComponent"],
                _components_dash_board_dash_board_component__WEBPACK_IMPORTED_MODULE_9__["DashBoardComponent"],
                _components_dash_board_content_dash_board_content_component__WEBPACK_IMPORTED_MODULE_10__["DashBoardContentComponent"],
                _components_notification_notification_component__WEBPACK_IMPORTED_MODULE_11__["NotificationComponent"],
                _components_logging_logging_component__WEBPACK_IMPORTED_MODULE_12__["LoggingComponent"],
                _components_user_user_component__WEBPACK_IMPORTED_MODULE_20__["UserComponent"],
                _components_log_details_model_log_details_model_component__WEBPACK_IMPORTED_MODULE_21__["LogDetailsModelComponent"],
                _components_notification_details_model_notification_details_model_component__WEBPACK_IMPORTED_MODULE_22__["NotificationDetailsModelComponent"],
                _components_app_info_app_info_component__WEBPACK_IMPORTED_MODULE_23__["AppInfoComponent"],
                _components_interface_design_model_interface_design_model_component__WEBPACK_IMPORTED_MODULE_24__["InterfaceDesignModelComponent"],
                _components_general_instruction_general_instruction_component__WEBPACK_IMPORTED_MODULE_27__["GeneralInstructionComponent"],
                _components_error_page_error_page_component__WEBPACK_IMPORTED_MODULE_28__["ErrorPageComponent"],
                _components_new_interface_new_interface_component__WEBPACK_IMPORTED_MODULE_30__["NewInterfaceComponent"],
                _components_data_purge_data_purge_component__WEBPACK_IMPORTED_MODULE_36__["DataPurgeComponent"],
                _components_data_purge_details_data_purge_details_component__WEBPACK_IMPORTED_MODULE_37__["DataPurgeDetailsComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_34__["BrowserAnimationsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_3__["JsonpModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_33__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_33__["OwlNativeDateTimeModule"],
                ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_35__["Ng4LoadingSpinnerModule"].forRoot(),
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(appRoutes, { useHash: true } // <-- debugging purposes only
                ),
                ag_grid_angular__WEBPACK_IMPORTED_MODULE_17__["AgGridModule"].withComponents([]),
                ng2_charts_ng2_charts__WEBPACK_IMPORTED_MODULE_18__["ChartsModule"],
                angular_morris_js__WEBPACK_IMPORTED_MODULE_19__["MorrisJsModule"],
                ng2_completer__WEBPACK_IMPORTED_MODULE_32__["Ng2CompleterModule"],
                ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_31__["NgMultiSelectDropDownModule"].forRoot()
            ],
            providers: [
                _service_GlobalErrorHandler__WEBPACK_IMPORTED_MODULE_26__["GlobalErrorHandler"],
                { provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ErrorHandler"], useClass: _service_GlobalErrorHandler__WEBPACK_IMPORTED_MODULE_26__["GlobalErrorHandler"] }, _service_user_service__WEBPACK_IMPORTED_MODULE_13__["UserService"], _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_14__["BioNotifyService"], _service_bio_log_service__WEBPACK_IMPORTED_MODULE_15__["BioLogService"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_16__["AppConstantService"], _angular_common__WEBPACK_IMPORTED_MODULE_25__["DatePipe"], _service_force_direct_service__WEBPACK_IMPORTED_MODULE_29__["ForceDirectService"]
            ],
            // providers: [UserService,BioNotifyService,BioLogService,AppConstantService,DatePipe],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/app-info/app-info.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/app-info/app-info.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/app-info/app-info.component.html":
/*!*************************************************************!*\
  !*** ./src/app/components/app-info/app-info.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper interfaceDetails\">\n\t<ol class=\"breadcrumb\">\n\t\t<li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n\t\t<li class=\"breadcrumb-item\">Interface Details</li>\n\t</ol>\n\t<!-- Main content -->\n\t<section class=\"content\">\n\t\t<div class=\"row\">\n\t\t\t\t<form #appInfoForm=\"ngForm\" (ngSubmit)=\"getAppInfo(appInfoForm.value)\" class=\"form-horizontal\"\n\t\t\t\t\t\t\t\t\t\t\t\trole=\"form\">\n\t\t\t<div class=\"loggingSearchingBox\">\n\t\t\t\t<div class=\"fieldBox\">\n\t\t\t\t\t\t<select class=\"form-control\" id=\"buint\" name=\"buint\" [(ngModel)]='defBU' [value]='defBU'\n\t\t\t\t\t\t(change)=\"onBUChange($event.target.value)\" ngModel>\n\t\t\t\t\t\t<option *ngFor=\"let bunit of bunitList\" value={{bunit.id}}>{{bunit.name}}</option>\n\t\t\t\t\t</select>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"fieldBox\">\n\t\t\t\t\t\t<select class=\"form-control\" id=\"buAppName\" name=\"buAppName\" [(ngModel)]='defBUAppName' [value]='defBUAppName' \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t(change)=\"onBUAppNameChange($event.target.value)\" ngModel>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option *ngFor=\"let buAppName of buAppNameList\" value={{buAppName.id}}>{{buAppName.name}}</option>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</select>\t\n\t\t\t\t\t</div>\n                  <div class=\"fieldBox\">\n\t\t\t\t\t\t\t\t\t<select class=\"form-control\" id=\"entity\" name=\"entity\" [(ngModel)]='defBUEntity'\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  (change)=\"onEntityChange($event.target.value)\" ngModel>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <option *ngFor=\"let entity of entityList\" value={{entity.id}}>{{entity.name}}</option>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</select>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"fieldBox\">\n\t\t\t\t\t\t\t\t<select class=\"form-control \" id=\"appName\" name=\"appName\"  [(ngModel)]='defBUInterfaceName'>\n\t\t\t\t\t\t\t\t\t\t<option *ngFor=\"let appName of appNameList\" value={{appName.appId}}>{{appName.appName}}\n\t\t\t\t\t\t\t\t\t\t</option>\n\t\t\t\t\t\t\t\t\t</select>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class=\"searchBtnBox\">\n\t\t\t\t\t\t\t\t\t<button type=\"submit\" id=\"appInfoSearch\" class=\"btn btn-primary\" name=\"appInfoSearch\">Search &nbsp;<i class=\"fa fa-search\"\n\t\t\t\t\t\t\t\t\t\taria-hidden=\"true\"></i></button>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t</form>\n\t\t\t<div class=\"col-sm-12\">\n\n\t\t\t\t<div class=\"main_tab logsrch\" style=\"margin-top:-10px !important\">\n\t\t\t\t\t<div id=\"tab\" class=\"tabs tabs-style-tzoid\">\n\n\n\t\t\t\t\t\t<div class=\"table_color3 col-md-12\" style=\"padding:0 !important; margin:0 !important\">\n\n\t\t\t\t\t\t\t<div class=\"tab-content\">\n\t\t\t\t\t\t\t\t<div id=\"menu1\" class=\"tab-pane fade in active\">\n\n\t\t\t\t\t\t\t\t\t<div class=\"container-fluid\">\n\n\t\t\t\t\t\t\t\t\t\t<ag-grid-angular style=\"height: 530px;\" class=\"col6-Grid ag-theme-balham\" [rowData]=\"rowData\"\n\t\t\t\t\t\t\t\t\t\t\t[rowHeight]=\"30\" [columnDefs]=\"columnDefs\" [enableSorting]=\"true\" [enableFilter]=\"true\"\n\t\t\t\t\t\t\t\t\t\t\t[suppressRowClickSelection]=\"true\" [debug]=\"true\" [enableColResize]=\"true\"\n\t\t\t\t\t\t\t\t\t\t\t[enableRangeSelection]=\"true\" [paginationAutoPageSize]=\"false\" [pagination]=\"true\"\n\t\t\t\t\t\t\t\t\t\t\t[paginationPageSize]=15 (cellClicked)=\"onCellClicked($event)\" (rowClicked)=\"onRowClicked($event)\">\n\t\t\t\t\t\t\t\t\t\t</ag-grid-angular>\n\t\t\t\t\t\t\t\t\t\t<div style=\"width:100%\"></div>\n\t\t\t\t\t\t\t\t\t</div>\n\n\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<!-- <div id=\"menu2\" class=\"tab-pane fade\" >\n\n\t\t\t<img id=\"pfimg\" name=\"pfimg\" src=\"http://10.240.8.62:7001/file/show\" width=\"1000\" height=\"323\" />\n\t\t\t\n\t\t</div> -->\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class=\"app_btn\">\n\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-primary downloadBtn\" data-toggle=\"modal\"\n\t\t\t\t\t\t\t\t\tdata-target=\"#myModal\">Create App Info</button>\n\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t</div>\n\n\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t\t<!-- /.row -->\n\n\t</section>\n\t<!-- /.content -->\n</div>\n\n<!-- <app-app-info-form-model></app-app-info-form-model> -->\n<app-interface-design-model [appId]=appId></app-interface-design-model>"

/***/ }),

/***/ "./src/app/components/app-info/app-info.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/app-info/app-info.component.ts ***!
  \***********************************************************/
/*! exports provided: AppInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppInfoComponent", function() { return AppInfoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _dao_app_name_temp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../dao/app-name-temp */ "./src/app/dao/app-name-temp.ts");
/* harmony import */ var _service_application_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/application.service */ "./src/app/service/application.service.ts");
/* harmony import */ var _service_bio_app_doc_history_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/bio-app-doc-history.service */ "./src/app/service/bio-app-doc-history.service.ts");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _dao_busearch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../dao/busearch */ "./src/app/dao/busearch.ts");
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_7__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var AppInfoComponent = /** @class */ (function () {
    function AppInfoComponent(spinnerService, _bioAppDocHistoryService, _applicationService, _businessUnitService) {
        this.spinnerService = spinnerService;
        this._bioAppDocHistoryService = _bioAppDocHistoryService;
        this._applicationService = _applicationService;
        this._businessUnitService = _businessUnitService;
        this.rowData = [];
        this.columnDefs = [];
        this.appNameList = [];
        this.entityList = [];
        this.status = "";
        this.appId = 0;
        this.bunitList = [];
        this.buAppNameList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.busearch = null;
        this.entitytemp = "";
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUInterfaceName = "0";
    }
    AppInfoComponent.prototype.setDefaultValues = function () {
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUInterfaceName = "0";
    };
    AppInfoComponent.prototype.setDefaultValue = function (name) {
        if (name == "Application") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
        }
        if (name == "Entity") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
        }
        if (name == "Interface Name") {
            var data = new _dao_app_name_temp__WEBPACK_IMPORTED_MODULE_1__["AppNameTemp"]();
            data.appId = "0";
            data.appName = "Interface Name";
            this.appNameList.push(data);
        }
        if (name == "ALL") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
            var appdata = new _dao_app_name_temp__WEBPACK_IMPORTED_MODULE_1__["AppNameTemp"]();
            appdata.appId = "0";
            appdata.appName = "Interface Name";
            this.appNameList.push(appdata);
        }
    };
    AppInfoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.spinnerService.show();
        this.columnDefs = [
            { headerName: 'App ID', field: 'appId', hide: true },
            { headerName: 'Interface Name', field: 'appName', class: 'columSize', editable: true, width: 180 },
            { headerName: 'Source System', field: 'sourceSystem', class: 'columSize', editable: true, width: 120 },
            { headerName: 'Source Type', field: 'sourceType', class: 'columSize', editable: true, width: 120 },
            { headerName: 'Target System', field: 'targetSystem', class: 'columSize', editable: true, width: 120 },
            { headerName: 'Target Type', field: 'targetType', class: 'columSize', editable: true, width: 120 },
            { headerName: 'Pattern', field: 'integrationPatternName', class: 'columSize', editable: true, width: 120,
                cellRenderer: function (params) {
                    var pattern = params.data.integrationPatternName;
                    var html = '<a data-toggle="modal" data-target="#interfaceDesignModal" href="#">' + pattern + '</a>';
                    return html;
                }
            },
            { headerName: 'ITPD Ref#', field: 'itpdNo', class: 'columSize', width: 150,
                cellRenderer: function (params) {
                    return params.value;
                }
            },
            { headerName: 'CR Ref#', field: 'crNo', class: 'columSize', width: 150 },
            { headerName: 'CreatedDate', field: 'createdDate', hide: true, },
        ];
        this.overlayLoadingTemplate =
            '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
        this._businessUnitService.getBUnit().subscribe(function (bunitListValues) {
            //  console.log("bunitListValues : "+bunitListValues);
            _this.bunitList = bunitListValues;
            _this.setDefaultValue("ALL");
        }), function (error) {
            console.log(error);
        };
        this._bioAppDocHistoryService.getAllBioAppDocHistory().subscribe(function (bioAppDocHistory) {
            console.log("bioAppDocHistory : " + bioAppDocHistory);
            _this.rowData = bioAppDocHistory;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    AppInfoComponent.prototype.onGridReady = function (params) {
        this.gridApi = params.api;
        this.gridApi.showLoadingOverlay();
    };
    AppInfoComponent.prototype.onBUChange = function (bunit) {
        var _this = this;
        console.log("bunit:" + bunit);
        this.buAppNameList = [];
        this.entityList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.setDefaultValues();
        this.setDefaultValue("Entity");
        this.setDefaultValue("Enterprise Service");
        this.setDefaultValue("Interface Name");
        console.log("this.defBUAPPname:" + this.defBUAppName);
        if (bunit != null && bunit != 0) {
            this.bunitTemp = bunit;
            this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
                _this.buAppNameList = buAppNameListValues;
            }), function (error) {
                console.log(error);
            };
        }
    };
    AppInfoComponent.prototype.onBUAppNameChange = function (buAppName) {
        var _this = this;
        this.entityList = [];
        this.buAppNameTemp = "";
        this.entitytemp = "";
        // this.buAppNameTemp = buAppName;
        this.setDefaultValues();
        console.log("this.defBUAppName:" + this.defBUAppName);
        if (buAppName != "" && buAppName != "0") {
            this.buAppNameTemp = buAppName;
            this._businessUnitService.getEntityNameByApplicationId(buAppName).subscribe(function (entityListValues) {
                _this.entityList = entityListValues;
                _this.setDefaultValue("Enterprise Service");
                _this.setDefaultValue("Interface Name");
            }), function (error) {
                console.log(error);
            };
        }
        else {
            this.setDefaultValue("Entity");
            this.setDefaultValue("Interface Name");
        }
    };
    AppInfoComponent.prototype.onEntityChange = function (entity) {
        var _this = this;
        this.entitytemp = "";
        if (entity != "") {
            this.entitytemp = entity;
            this._businessUnitService.getInterfaceNameByEntity(this.bunitTemp, this.buAppNameTemp, entity).subscribe(function (appNameListValues) {
                console.log(appNameListValues);
                _this.appNameList = appNameListValues;
            }), function (error) {
                console.log(error);
            };
        }
    };
    AppInfoComponent.prototype.getAppInfo = function (appInfo) {
        var _this = this;
        var buint = document.getElementById('buint').value;
        var buAppName = document.getElementById('buAppName').value;
        var entity = document.getElementById('entity').value;
        var appId = document.getElementById('appName').value;
        this.busearch = new _dao_busearch__WEBPACK_IMPORTED_MODULE_5__["BUSearch"]();
        if (buint != "" && buint != "0") {
            this.busearch.businessUnit = buint;
        }
        if (buAppName != "" && buAppName != "0") {
            this.busearch.applicationName = buAppName;
        }
        if (entity != "" && entity != "0") {
            this.busearch.entityName = entity;
        }
        this.busearch.appId = 0;
        if (appId != "" && appId != "0") {
            this.busearch.appId = appId;
        }
        console.log("buSearch:" + JSON.stringify(this.busearch));
        this._bioAppDocHistoryService.getAllBioAppDocHistoryBySearch(this.busearch).subscribe(function (bioAppDocHistory) {
            console.log("bioAppDocHistory : " + bioAppDocHistory);
            _this.rowData = bioAppDocHistory;
        }), function (error) {
            console.log(error);
        };
    };
    AppInfoComponent.prototype.onCellClicked = function (event) {
        console.log("onCellClicked " + event.colDef.headerName);
        if (event.colDef.headerName == "Pattern") {
            this.status = "Pattern";
        }
    };
    AppInfoComponent.prototype.onRowClicked = function (event) {
        this.appId = 0;
        console.log("onRowClicked === " + event.data.appId);
        if (this.status == "Pattern") {
            this.appId = event.data.appId;
        }
    };
    AppInfoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-app-info',
            template: __webpack_require__(/*! ./app-info.component.html */ "./src/app/components/app-info/app-info.component.html"),
            styles: [__webpack_require__(/*! ./app-info.component.css */ "./src/app/components/app-info/app-info.component.css")]
        }),
        __metadata("design:paramtypes", [ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_7__["Ng4LoadingSpinnerService"], _service_bio_app_doc_history_service__WEBPACK_IMPORTED_MODULE_3__["BioAppDocHistoryService"], _service_application_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationService"], _service_business_unit_service__WEBPACK_IMPORTED_MODULE_4__["BusinessUnitService"]])
    ], AppInfoComponent);
    return AppInfoComponent;
}());



/***/ }),

/***/ "./src/app/components/dash-board-content/dash-board-content.component.css":
/*!********************************************************************************!*\
  !*** ./src/app/components/dash-board-content/dash-board-content.component.css ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/dash-board-content/dash-board-content.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/components/dash-board-content/dash-board-content.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper dashboard\">\n\n  <ol class=\"breadcrumb\">\n    <!-- <li class=\"breadcrumb-item\"><a href=\"#\">Home</a></li> -->\n    <li class=\"breadcrumb-item\">Dashboard</li>\n  </ol>\n  <section class=\"content\">\n      <div class=\"row\">\n          <form #buSearchForm=\"ngForm\" (ngSubmit)=\"buSearch(buSearchForm.value)\" class=\"form-horizontal \"\n                          role=\"form\">\n                          <div id=\"successStatus\" style=\"color: green;\"></div>\n        <div class=\"searchingBox\">\n         <div class=\"fieldBox\">\n              <select class=\"form-control\" id=\"buint\" name=\"buint\" [(ngModel)]='defBU' [value]='defBU'\n              (change)=\"onBUChange($event.target.value)\" ngModel>\n\n              <option *ngFor=\"let bunit of bunitList\" value={{bunit.id}}>{{bunit.name}}</option>\n              \n            </select>\n          </div>\n          <div class=\"fieldBox\">\n              <select class=\"form-control \" id=\"buAppName\" name=\"buAppName\"  [(ngModel)]='defBUAppName' [value]='defBUAppName' \n              (change)=\"onBUAppNameChange($event.target.value)\" ngModel>\n              <option *ngFor=\"let buAppName of buAppNameList\" value={{buAppName.id}}>{{buAppName.name}}</option>\n            </select>\n          </div>\n          <div class=\"fieldBox\">\n              <select class=\"form-control \" id=\"entity\" name=\"entity\" [(ngModel)]='defBUEntity'\n              (change)=\"onEntityChange($event.target.value)\" ngModel>\n              <option *ngFor=\"let entity of entityList\" value={{entity.id}}>{{entity.name}}</option>\n            </select>\n          </div>\n          <div class=\"fieldBox\">\n              <select class=\"form-control \" id=\"es\" name=\"es\" [(ngModel)]='defBUes' ngModel>\n                  <option *ngFor=\"let es of esList\" value={{es.id}}>{{es.name}}</option>\n                </select>\n          </div>\n           <div class=\"fieldBox\"  > <!--style=\"width:30px !important\" -->\n            <select class=\"form-control \" id=\"duration\" name=\"duration\" [(ngModel)]=\"defDuration\" ngModel>\n              <option value='0' disabled>Days</option>\n              <option value='1'>today</option>\n            <option value='7'>7 days</option>\n            <option value='15'>15 days</option>\n            <option value='30'>30 days</option>\n            <option value='60'>60 days</option>\n            <option value='90'>90 days</option>\n          </select>\n        </div>\n          <div class=\"fieldBox datepick\">\n            <input [owlDateTime]=\"dt1\" id=\"startDate\"  [max]=\"maxDate\" name=\"startDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt1\" placeholder=\"Start Date Time\"  ngModel>\n            <owl-date-time #dt1></owl-date-time>\n        </div>\n        <div class=\"fieldBox datepick\">\n          <input [owlDateTime]=\"dt2\" id=\"endDate\" [max]=\"maxDate\" name=\"endDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt2\" placeholder=\"End Date Time\" ngModel>\n          <owl-date-time #dt2></owl-date-time>\n      </div>\n         <!-- <div class=\"fieldBox datepick\">\n              <input type=\"datetime-local\" id=\"startDate\" name=\"startDate\" [ngModel]=\"filterDateFrom | date:'yyyy-MM-ddTHH:mm'\"  width=\"170\" ngModel>\n          </div>\n           <div class=\"fieldBox datepick\">\n              <input class=\"unstyled\" type=\"date\" id=\"endDate\" name=\"endDate\" placeholder=\"End Date\" width=\"170\"\n              ngModel>\n          </div> -->\n          <div class=\"searchBtnBox\">\n              <button type=\"submit\" id=\"buSearchBtn\" class=\"btn btn-primary\" name=\"buSearchBtn\">\n                  &nbsp;<i class=\"fa fa-search\" aria-hidden=\"true\"></i></button>\n          </div>\n        </div>\n        </form>\n        <div class=\"clearfix\"></div>\n      </div>\n\n    <div class=\"row\">\n      <div class=\"col-md-12\">\n\n\n      </div>\n     \n\n\n      <div class=\"col-md-6 graphs\">\n        <div class=\"panel panel-default\">\n          <div class=\"panel-heading\">\n            <span><i class=\"fa fa-chart-pie\"></i>&nbsp;Logging</span>\n           <!-- <span onclick=\"popShow()\" class=\"spanHover\"><i class=\"fa fa-arrows-alt pull-right\"></i>\n              </span>  -->\n             \n          </div>\n          <div class=\"panel-body graphPanelHeight\" style=\"padding: 0px !important\">\n                  <!-- <div id=\"dialog\" title=\"Dialog Title\" style=\"display:none\"> Some text</div>  \n      <p id=\"dialog_link\">Open Dialog</p>  -->\n            <!-- <div *ngIf=\"chartAreaData?.length > 0\"> -->\n\n                <div #containerElement style=\"min-width: 310px; height: 350px; margin: 0 auto\"></div>\n              <!-- <div id=\"graph_donut\" mk-morris-js [options]=\"chartDonutOptions\" [data]=\"chartAreaData\" type=\"Donut\" >\n              </div>-->\n\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-6 graphs\">\n        <div class=\"panel panel-default\">\n          <div class=\"panel-heading\">\n            <span> <i class=\"fa fa-bar-chart-o\"></i>&nbsp;Transaction</span>\n            <!-- <a href=\"\" data-toggle=\"modal\" onclick=\"removeModel()\" data-target=\"#transactionModal\">\n              <span><i\n                  class=\"fa fa-arrows-alt pull-right\"></i> </span>\n                </a>  -->\n          </div>\n          <div class=\"panel-body chart-responsive graphPanelHeight\" style=\"padding: 0px !important\">\n\n           <div #containerElementTransaction style=\"min-width: 310px; height: 350px; margin: 0 auto\"></div>\n              <!-- <div *ngIf=\"barChartData?.length > 0 \" style=\"display: block; max-width: 100%;  height: 350px\">\n                <canvas baseChart height=\"70\" width=\"100\" [datasets]=\"barChartData\" [labels]=\"barChartLabels\"\n                  [options]=\"barChartOptions\" [legend]=\"barChartLegend\" [chartType]=\"barChartType\"\n                  (chartHover)=\"chartHovered($event)\" (chartClick)=\"chartClicked($event)\"></canvas>\n              </div> -->\n                     </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"col-md-6 col-sm-4 col-xs-12 graphs\">\n\n        <div class=\"panel panel-default\">\n          <div class=\"panel-heading\">\n            <span> <i class=\"fa fa-align-left\"></i>&nbsp;Notification</span>\n            <!-- <a href=\"\" data-toggle=\"modal\" onclick=\"removeModel()\" data-target=\"#notificationModal\"><span><i\n                  class=\"fa fa-arrows-alt pull-right\"></i> </span> </a> -->\n\n          </div>\n          <div class=\"panel-body graphPanelHeight\" style=\"padding: 0px !important\">\n            \n              <div #containerElementNotification style=\"min-width: 310px; height: 350px; margin: 0 auto\"></div>\n          <!--    <div *ngFor=\"let notificationBar of notificationBarChartList  | slice:0:10;\">\n                <div class=\"widget_summary\">\n                  <div class=\"w_left w_25\">\n                    <span>{{notificationBar.appName}}</span>\n                  </div>\n                  <div class=\"w_center w_55\">\n                    <div class=\"progress\">\n                       <div>{{notificationBar.percentage}}</div>\n                      <div id=\"{{notificationBar.appName}}\" class=\"progress-bar bg-green\" role=\"progressbar\"\n                        aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\"\n                        style.width=\"{{notificationBar.percentage}}%\">\n                        <span class=\"sr-only\">60% Complete</span>\n                      </div>\n                    </div>\n                  </div>\n                  <div class=\"w_right w_20\">\n                    <span>{{notificationBar.appCount}}</span>\n                  </div>\n                  <div class=\"clearfix\"></div>\n                </div>\n              </div> -->\n           \n          </div>\n        </div>\n      </div>\n\n\n      <div class=\"col-md-6 col-sm-4 col-xs-12 graphs\">\n        <div class=\"panel panel-default\">\n          <div class=\"panel-heading\">\n            <span class=\"iconRotate\"> <i class=\"fa fa-sitemap\"></i>&nbsp;Relationship</span>\n\n            <!-- <a href=\"\" data-toggle=\"modal\"  data-target=\"#interfaceModal\"><span><i\n                  class=\"fa fa-arrows-alt pull-right\"></i> </span> </a> -->\n\n          </div>\n          <div class=\"panel-body graphPanelHeight \" style=\"padding: 0px !important\">\n            <!-- <div id=\"directedGraph1\" class=\"directedGraph for_right_box\" #directedGraph1></div> -->\n            <!-- <div #containerElementNetwork style=\"min-width: 310px; height: 370px; margin: 0 auto\"></div> -->\n            <!-- <div class=\"d3-chart\" #chart ></div> -->\n          <div #containerElementSankey style=\"min-width: 310px; height: 350px; margin: 0 auto\">\n          </div>\n        </div>\n      </div>\n  \n    </div>\n  </div>\n    <!-- <div style=\"height:500px; width:600px; display:block; position: absolute; top:50px; z-index: 9999; background: white; border:1px solid #ccc; \">\n        <div *ngIf=\"chartAreaData?.length > 0\">\n            <div id=\"graph_donut\" mk-morris-js [options]=\"chartDonutOptions\" [data]=\"chartAreaData\" type=\"Donut\">\n            </div>\n\n    </div>\n  </div> -->\n    <!--Logging status Modal -->\n<!-- \n    <div class=\"overlay\" style=\"display:none\"></div>\n    <div style=\"visibility:hidden\" id=\"customModal\">\n      <div class=\"modal-header\">\n        <span><i class=\"fa fa-chart-pie\"></i>&nbsp;Logging</span>\n       <span  class=\"spanHover\" onclick=\"popClose()\"><i class=\"fa fa-window-close pull-right\"></i>\n        </span> \n      </div>\n        <div *ngIf=\"chartAreaData?.length > 0\">\n            <div id=\"graph_donut\" mk-morris-js [options]=\"chartDonutOptions\" [data]=\"chartAreaData\" type=\"Donut\" >\n            </div>\n          </div>\n    </div>\n       -->\n    <!--Transaction Status Modal -->\n    <!-- <div id=\"transactionModal\" class=\"modal fade\" role=\"dialog\">\n      <div class=\"modal-dialog\">\n\n        <div class=\"modal-content\">\n          <div class=\"modal-body graphs\" style=\"padding:0px !important\">\n              <div class=\"panel panel-default\">\n                  <div class=\"panel-heading\">\n                    <span> <i class=\"fa fa-bar-chart-o\"></i>&nbsp;Transaction</span>\n                    <a href=\"\" data-toggle=\"modal\" onclick=\"removeModel()\" data-target=\"#transactionModal\"><span><i class=\"fa fa-window-close pull-right\"></i>\n                    </span> </a>\n                  </div>\n              <div class=\"panel-body chart-responsive graphPanelHeight\">\n                  <div>\n                    <div *ngIf=\"barChartData?.length > 0\" style=\"display: block; max-width: 100%;  height: 350px\">\n                      <canvas baseChart height=\"70\" width=\"100\" [datasets]=\"barChartData\" [labels]=\"barChartLabels\"\n                        [options]=\"barChartOptions\" [legend]=\"barChartLegend\" [chartType]=\"barChartType\"\n                        (chartHover)=\"chartHovered($event)\" (chartClick)=\"chartClicked($event)\"></canvas>\n                    </div>\n                  </div>\n      \n                </div>\n        </div>\n      </div>\n        \n        \n</div>\n      </div>\n    </div>\n\n  \n    <div id=\"notificationModal\" class=\"modal fade\" role=\"dialog\">\n      <div class=\"modal-dialog\">\n     \n        <div class=\"modal-content\">\n          <div class=\"modal-body graphs\" style=\"padding:0px !important\">\n              <div class=\"panel panel-default\">\n                  <div class=\"panel-heading\">\n                    <span> <i class=\"fa fa-align-left\"></i>&nbsp;Notification</span>\n                   \n                    <a href=\"\" data-toggle=\"modal\" onclick=\"removeModel()\" data-target=\"#notificationModal\"><span><i class=\"fa fa-window-close pull-right\"></i>\n                    </span> </a>\n                  </div>\n              <div class=\"panel-body graphPanelHeight\">\n                <div class=\"x_content\">\n                     <div *ngFor=\"let notificationBar of notificationBarChartList  | slice:0:10;\">\n                    <div class=\"widget_summary\">\n                      <div class=\"w_left w_25\">\n                        <span>{{notificationBar.appName}}</span>\n                      </div>\n                      <div class=\"w_center w_55\">\n                        <div class=\"progress\">\n                        \n                          <div id=\"{{notificationBar.appName}}\" class=\"progress-bar bg-green\" role=\"progressbar\"\n                            aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\"\n                            style.width=\"{{notificationBar.percentage}}%\">\n                            <span class=\"sr-only\">60% Complete</span>\n                          </div>\n                        </div>\n                      </div>\n                      <div class=\"w_right w_20\">\n                        <span>{{notificationBar.appCount}}</span>\n                      </div>\n                   \n                    </div>\n                  </div>\n                </div>\n              </div>\n              </div>\n          </div>\n      \n            <button type=\"button\" class=\"btn btn-primary downloadBtn\" data-dismiss=\"modal\">Close</button>\n          </div> \n        </div>\n\n      </div>\n    </div>\n  -->\n\n   <!-- <div id=\"interfaceModal\" class=\"modal fade\" role=\"dialog\">\n    <div class=\"modal-dialog\">\n\n         <div class=\"modal-content\">\n           <div class=\"modal-body graphs\" style=\"padding:0px !important\">\n               <div class=\"panel panel-default\">\n                      <div class=\"panel-heading\">\n                        <span class=\"iconRotate\"> <i class=\"fa fa-sitemap\"></i>&nbsp;Relationship</span>\n                        <a href=\"\" data-toggle=\"modal\" onclick=\"removeModel()\" data-target=\"#interfaceModal\"><span><i class=\"fa fa-window-close pull-right\"></i>\n                        </span> </a>\n                      </div>\n                      <div class=\"panel-body graphPanelHeight \" style=\"padding: 0px !important\"> -->\n                        <!-- <div id=\"directedGraph1\" class=\"directedGraph for_right_box\" #directedGraph1></div>\n                        <div #containerElementNetwork style=\"min-width: 310px; height: 370px; margin: 0 auto\"></div> -->\n                        <!-- <div class=\"d3-chart\" id=\"chart1\" ></div>\n                      \n                    </div>\n         </div>\n       </div>\n </div>\n       </div>\n</div> -->\n  </section>"

/***/ }),

/***/ "./src/app/components/dash-board-content/dash-board-content.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/components/dash-board-content/dash-board-content.component.ts ***!
  \*******************************************************************************/
/*! exports provided: DashBoardContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBoardContentComponent", function() { return DashBoardContentComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_dashboard_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/dashboard.service */ "./src/app/service/dashboard.service.ts");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _dao_busearch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../dao/busearch */ "./src/app/dao/busearch.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! highcharts */ "./node_modules/highcharts/highcharts.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(highcharts__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var highcharts_modules_sankey__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! highcharts/modules/sankey */ "./node_modules/highcharts/modules/sankey.js");
/* harmony import */ var highcharts_modules_sankey__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_sankey__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var highcharts_highcharts_more_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! highcharts/highcharts-more.js */ "./node_modules/highcharts/highcharts-more.js");
/* harmony import */ var highcharts_highcharts_more_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(highcharts_highcharts_more_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! highcharts/modules/drilldown */ "./node_modules/highcharts/modules/drilldown.js");
/* harmony import */ var highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var highcharts_modules_no_data_to_display__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! highcharts/modules/no-data-to-display */ "./node_modules/highcharts/modules/no-data-to-display.js");
/* harmony import */ var highcharts_modules_no_data_to_display__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_no_data_to_display__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! highcharts/modules/exporting */ "./node_modules/highcharts/modules/exporting.js");
/* harmony import */ var highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var src_app_service_relationshipsGraphService__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/service/relationshipsGraphService */ "./src/app/service/relationshipsGraphService.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



//import { ForceDirectService } from '../../service/force-direct.service';








highcharts_modules_sankey__WEBPACK_IMPORTED_MODULE_9___default()(highcharts__WEBPACK_IMPORTED_MODULE_8__);
highcharts_highcharts_more_js__WEBPACK_IMPORTED_MODULE_10___default()(highcharts__WEBPACK_IMPORTED_MODULE_8__);

highcharts_modules_drilldown__WEBPACK_IMPORTED_MODULE_11___default()(highcharts__WEBPACK_IMPORTED_MODULE_8__);

highcharts_modules_no_data_to_display__WEBPACK_IMPORTED_MODULE_12___default()(highcharts__WEBPACK_IMPORTED_MODULE_8__);
// Load the exporting module.


// Initialize exporting module.
highcharts_modules_exporting__WEBPACK_IMPORTED_MODULE_13___default()(highcharts__WEBPACK_IMPORTED_MODULE_8__);
var DashBoardContentComponent = /** @class */ (function () {
    function DashBoardContentComponent(_userSessionService, spinnerService, _businessUnitService, _dashboardService, _router, relationshipService) {
        this._userSessionService = _userSessionService;
        this.spinnerService = spinnerService;
        this._businessUnitService = _businessUnitService;
        this._dashboardService = _dashboardService;
        this._router = _router;
        this.relationshipService = relationshipService;
        this.bunitList = [];
        this.buAppNameList = [];
        this.d3AppNameList = [];
        this.entityList = [];
        this.d3entityList = [];
        this.esList = [];
        this.d3esList = [];
        this.chartAreaData = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.busearch = null;
        this.barChartAppName = [];
        this.barChartSC = [];
        this.barChartFC = [];
        this.barCount = 0;
        this.per = 66;
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
        this.defDuration = "7";
        this.maxDate = new Date();
        // interfaceNodesList:Array<InterfaceNodes>=[];
        // interfaceLinksList:Array<InterfaceLinks>=[];
        this.buInterfaceNodesList = [];
        this.buInterfaceLinksList = [];
        this.sucChartDataList = [];
        this.failChartDataList = [];
        this.donutChartData = {};
        this.notifyChartData = {};
        this.loggingChartData = {};
        this.networkChartData = {};
    }
    DashBoardContentComponent.prototype.clickableLogging = function () {
        var chartSubData = [];
        //this.networkChartData = [];
        for (var _i = 0, _a = this.donutChartData; _i < _a.length; _i++) {
            var drill = _a[_i];
            var subCharData = [];
            // console.log("drill:"+JSON.stringify(drill));
            //this.networkChartData.push(['Start', drill.name]) ;
            for (var _b = 0, _c = drill.data; _b < _c.length; _b++) {
                var applicationData = _c[_b];
                //subCharData.push([data.name, data.y]) ;
                var appData = {};
                var entCharData = [];
                appData.name = applicationData.name;
                appData.y = applicationData.y;
                appData.avgTime = applicationData.avgTime;
                appData.drilldown = applicationData.drilldown;
                subCharData.push(appData);
                // this.networkChartData.push([drill.name, applicationData.name]) ;
                for (var _d = 0, _e = applicationData.data; _d < _e.length; _d++) {
                    var entityData = _e[_d];
                    //subCharData.push([data.name, data.y]) ;
                    var entData = {};
                    entData.name = entityData.name;
                    entData.y = entityData.y;
                    entData.avgTime = entityData.avgTime;
                    // this.networkChartData.push([ applicationData.name,entityData.name]) ;
                    //appData.drilldown = applicationData.name
                    entCharData.push(entData);
                }
                entCharData =
                    {
                        name: applicationData.name,
                        id: applicationData.id,
                        colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                        data: entCharData
                    };
                chartSubData.push(entCharData);
            }
            subCharData =
                {
                    name: drill.name,
                    id: drill.id,
                    colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                    data: subCharData
                };
            chartSubData.push(subCharData);
        }
        highcharts__WEBPACK_IMPORTED_MODULE_8__["chart"](this.containerPieChart.nativeElement, {
            // Created pie chart using Highchart
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45
                }
            },
            title: {
                text: ''
            },
            /*subtitle: {
              text: '3D donut in Highcharts'
            },*/
            plotOptions: {
                pie: {
                    innerSize: 90,
                    depth: 40
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormatter: function () {
                    if (this.avgTime > 0) {
                        return '<span style="color:' + this.color + '">' + this.name + '</span>: <b>' + this.y + '</b> of total<br/>  <span style="color:' + this.color + '">AVG Time</span>: <b>' + this.avgTime + ' Secs</b>';
                    }
                    else {
                        return '<span style="color:' + this.color + '">' + this.name + '</span>: <b>' + this.y + '</b> of total<br/>';
                    }
                }
            },
            navigation: {
                buttonOptions: {
                    y: 35,
                }
            },
            series: [
                {
                    name: 'Business Units',
                    colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                    data: this.donutChartList
                }
            ],
            noData: {
                style: {
                    fontWeight: 'bold',
                    fontSize: '15px',
                    color: '#303030'
                }
            },
            drilldown: {
                drillUpButton: {
                    position: {
                        verticalAlign: 'top',
                        align: 'right',
                        y: 0,
                        x: 0,
                    },
                    theme: {
                        drillUpText: '◁ Back',
                        fill: '#ffffff',
                        'stroke-width': 1,
                        stroke: 'silver',
                        height: 12,
                        textDecoration: '',
                        r: 0,
                    },
                },
                series: chartSubData
            }
        });
    };
    DashBoardContentComponent.prototype.clickableTransaction = function () {
        var chartSubData = [];
        this.loggingChartData = this.sucChartDataList;
        for (var _i = 0, _a = this.loggingChartData; _i < _a.length; _i++) {
            var drill = _a[_i];
            var subCharData = [];
            for (var _b = 0, _c = drill.dataList.successList; _b < _c.length; _b++) {
                var applicationData = _c[_b];
                var appData = {};
                var entCharData = [];
                appData.name = applicationData.name;
                appData.y = applicationData.y;
                appData.drilldown = applicationData.drilldown;
                subCharData.push(appData);
                for (var _d = 0, _e = applicationData.dataList.successList; _d < _e.length; _d++) {
                    var entityData = _e[_d];
                    //subCharData.push([data.name, data.y]) ;
                    var entData = {};
                    entData.name = entityData.name;
                    entData.y = entityData.y;
                    //appData.drilldown = applicationData.name
                    entCharData.push(entData);
                }
                entCharData =
                    {
                        name: applicationData.name,
                        id: applicationData.id,
                        data: entCharData,
                        colors: ['#7cb5ec']
                    };
                chartSubData.push(entCharData);
            }
            subCharData =
                {
                    name: drill.name,
                    id: drill.id,
                    data: subCharData,
                    colors: ['#7cb5ec']
                };
            chartSubData.push(subCharData);
        }
        for (var _f = 0, _g = this.loggingChartData; _f < _g.length; _f++) {
            var drill = _g[_f];
            var subCharData = [];
            for (var _h = 0, _j = drill.dataList.failureList; _h < _j.length; _h++) {
                var applicationData = _j[_h];
                // console.log("logging applicationData:"+JSON.stringify(applicationData));
                var appData = {};
                appData.name = applicationData.name;
                appData.y = applicationData.y;
                appData.drilldown = applicationData.drilldown;
                subCharData.push(appData);
            }
            subCharData =
                {
                    name: drill.name + " FAILED",
                    id: drill.id + " FAILED",
                    data: subCharData,
                    colors: ['#f7a35c']
                };
            chartSubData.push(subCharData);
            /* failure list under application */
            for (var _k = 0, _l = drill.dataList.successList; _k < _l.length; _k++) {
                var applicationData = _l[_k];
                var entCharData = [];
                /* console.log("entityData:"+JSON.stringify(applicationData));
                 console.log("entityData failure list:"+JSON.stringify(applicationData.dataList.failureList));
           */
                for (var _m = 0, _o = applicationData.dataList.failureList; _m < _o.length; _m++) {
                    var entityData = _o[_m];
                    //   console.log("logging entityData:"+JSON.stringify(entityData));
                    var entData = {};
                    entData.name = entityData.name;
                    entData.y = entityData.y;
                    // entData.drilldown = applicationData.name+"_F";
                    entCharData.push(entData);
                }
                entCharData =
                    {
                        name: applicationData.name + " FAILED",
                        id: applicationData.id + " FAILED",
                        data: entCharData,
                        colors: ['#f7a35c']
                    };
                chartSubData.push(entCharData);
            }
        }
        //  console.log("chartSubData:"+JSON.stringify(chartSubData));
        highcharts__WEBPACK_IMPORTED_MODULE_8__["chart"](this.containerTransaction.nativeElement, {
            // Created pie chart using Highchart
            chart: {
                type: 'column'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                type: 'category'
            },
            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'Transactions'
                }, stackLabels: {
                    enabled: true,
                    style: {
                        fontsize: "13px"
                    }
                }
            },
            navigation: {
                buttonOptions: {
                    y: 35,
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0,
                    borderWidth: 0.2
                },
                series: {
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [{
                    name: 'Success',
                    colors: ['#7cb5ec'],
                    data: this.sucChartDataList
                }, {
                    name: 'Failures',
                    colors: ['#f7a35c'],
                    data: this.failChartDataList
                }],
            noData: {
                style: {
                    fontWeight: 'bold',
                    fontSize: '15px',
                    color: '#303030'
                }
            },
            drilldown: {
                drillUpButton: {
                    position: {
                        verticalAlign: 'top',
                        align: 'right',
                        y: 0,
                        x: 0,
                    },
                    theme: {
                        drillUpText: '<Back',
                        fill: '#ffffff',
                        'stroke-width': 1,
                        stroke: 'silver',
                        height: 12,
                        r: 0,
                    },
                },
                allowPointDrilldown: false,
                series: chartSubData
            }
        });
    };
    DashBoardContentComponent.prototype.clickableNotification = function () {
        var chartSubData = [];
        for (var _i = 0, _a = this.notifyChartData; _i < _a.length; _i++) {
            var drill = _a[_i];
            var subCharData = [];
            for (var _b = 0, _c = drill.data; _b < _c.length; _b++) {
                var applicationData = _c[_b];
                //subCharData.push([data.name, data.y]) ;
                var appData = {};
                var entCharData = [];
                appData.name = applicationData.name;
                appData.y = applicationData.y;
                appData.drilldown = applicationData.drilldown;
                subCharData.push(appData);
                for (var _d = 0, _e = applicationData.data; _d < _e.length; _d++) {
                    var entityData = _e[_d];
                    //subCharData.push([data.name, data.y]) ;
                    var entData = {};
                    entData.name = entityData.name;
                    entData.y = entityData.y;
                    //appData.drilldown = applicationData.name
                    entCharData.push(entData);
                }
                entCharData =
                    {
                        name: applicationData.name,
                        id: applicationData.id,
                        data: entCharData,
                        colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b']
                    };
                chartSubData.push(entCharData);
            }
            subCharData =
                {
                    name: drill.name,
                    id: drill.id,
                    data: subCharData,
                    colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b']
                };
            chartSubData.push(subCharData);
        }
        highcharts__WEBPACK_IMPORTED_MODULE_8__["chart"](this.containerNotification.nativeElement, {
            // Created pie chart using Highchart
            chart: {
                type: 'bar',
            },
            title: {
                text: ''
            },
            /*subtitle: {
              text: '3D donut in Highcharts'
            },*/
            xAxis: {
                type: 'category',
            },
            yAxis: {
                title: {
                    text: 'Notifications Count'
                },
            },
            navigation: {
                buttonOptions: {
                    y: 35,
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0,
                    borderWidth: 0.2
                }, series: {
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:f}</b> of total<br/>'
            },
            series: [
                {
                    name: 'Notifications',
                    colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                    data: this.notifyChartList
                }
            ],
            noData: {
                style: {
                    fontWeight: 'bold',
                    fontSize: '15px',
                    color: '#303030'
                }
            },
            drilldown: {
                drillUpButton: {
                    position: {
                        verticalAlign: 'top',
                        align: 'right',
                        y: 0,
                        x: 0,
                    },
                    theme: {
                        drillUpText: '<Back',
                        fill: '#ffffff',
                        'stroke-width': 1,
                        stroke: 'silver',
                        height: 12,
                        r: 0,
                    },
                },
                series: chartSubData
            }
        });
    };
    DashBoardContentComponent.prototype.sankeyChart = function () {
        console.log(this.sankeyGraphList);
        var appData;
        appData = [];
        var sankeyGraphs;
        sankeyGraphs = [];
        // console.log("drill:"+JSON.stringify(drill));
        //this.networkChartData.push(['Start', drill.name]) ;
        var index = 0;
        for (var _i = 0, _a = this.sankeyGraphList; _i < _a.length; _i++) {
            var applicationData = _a[_i];
            //subCharData.push([data.name, data.y]) ;
            appData[index] = [];
            appData[index][0] = applicationData.source;
            appData[index][1] = applicationData.destination;
            appData[index][2] = applicationData.weight;
            appData[index][3] = applicationData.total;
            appData[index][4] = applicationData.successCount;
            appData[index][5] = applicationData.failureCount;
            console.log(appData);
            index = index + 1;
        }
        var chartWidth = 0;
        var minSankeyChart = highcharts__WEBPACK_IMPORTED_MODULE_8__["chart"](this.containerSankey.nativeElement, {
            title: {
                text: ''
            },
            chart: {
                events: {
                    redraw: function () {
                        console.log("redraw");
                        console.log(this.chartWidth);
                        var previousChartWidth = chartWidth;
                        console.log(previousChartWidth);
                        chartWidth = this.chartWidth;
                        if (chartWidth > previousChartWidth) {
                            this.series[0].update({
                                type: 'sankey',
                                dataLabels: {
                                    allowOverlap: true,
                                    enabled: true,
                                    color: '#003399',
                                    padding: 1,
                                    borderRadius: 3,
                                    backgroundColor: 'rgba(252, 252, 197, 0.7)',
                                    borderWidth: 0.5,
                                    borderColor: '#AAA',
                                    nodeFormatter: function () {
                                        var response;
                                        var inboundarray = this.point.linksTo;
                                        var inboundtotal = 0;
                                        var outboundarray = this.point.linksFrom;
                                        var outboundtotal = 0;
                                        var outboundFailureCount = 0;
                                        var outboundSuccessCount = 0;
                                        inboundarray.forEach(function (item, index) {
                                            inboundtotal += inboundarray[index].tot;
                                        });
                                        outboundarray.forEach(function (item, index) {
                                            outboundtotal += outboundarray[index].tot;
                                            outboundFailureCount += outboundarray[index].failureCount;
                                            outboundSuccessCount += outboundarray[index].successCount;
                                        });
                                        response = this.key + "<br>\n                     Total : " + outboundtotal + "<br>\n            ";
                                        return response;
                                    },
                                }
                            });
                        }
                        if (chartWidth < previousChartWidth) {
                            this.series[0].remove(true);
                            this.addSeries({
                                keys: ['from', 'to', 'weight', 'tot', 'successCount', 'failureCount'],
                                colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                                data: appData,
                                dataLabels: {
                                    allowOverlap: false,
                                    color: '#FGFFGG',
                                    enabled: true,
                                },
                                type: 'sankey',
                                name: ''
                            });
                        }
                    }
                }
            },
            tooltip: {
                formatter: function () {
                    var response;
                    if (this.point.shapeType == "rect") {
                        console.log(this.point.isNode);
                        var inboundarray = this.point.linksTo;
                        var inboundtotal = 0;
                        var outboundarray = this.point.linksFrom;
                        var outboundtotal = 0;
                        var outboundFailureCount = 0;
                        var outboundSuccessCount = 0;
                        inboundarray.forEach(function (item, index) {
                            inboundtotal += inboundarray[index].tot;
                        });
                        outboundarray.forEach(function (item, index) {
                            outboundtotal += outboundarray[index].tot;
                            outboundFailureCount += outboundarray[index].failureCount;
                            outboundSuccessCount += outboundarray[index].successCount;
                        });
                        response = this.key + "<br>\n           Total : " + outboundtotal + "<br>\n           Success : " + outboundSuccessCount + "<br>\n           Failure : " + outboundFailureCount + "<br>\n      ";
                    }
                    if (this.point.shapeType == "path") {
                        response = this.point.from + " -> " + this.point.to + " :\n                Transaction : " + this.point.tot + "<br>\n                Success : " + this.point.successCount + "<br>\n                Failure : " + this.point.failureCount + "<br>\n                ";
                    }
                    return response;
                }
            },
            noData: {
                style: {
                    fontWeight: 'bold',
                    fontSize: '15px',
                    color: '#303030'
                }
            },
            series: [
                {
                    keys: ['from', 'to', 'weight', 'tot', 'successCount', 'failureCount'],
                    colors: ['#7cb5ec', '#f15c80', '#e4d354', '#2b908f', '#8085e9', '#f7a35c', '#90ed7d', '#f45b5b'],
                    data: appData,
                    /*formatter: function () {
        
                      let response;
        
                      response = `${this.point.from} -> ${this.point.to} : ${this.point.tot}<br>
                      `
        
        
                      return response
        
                    },*/
                    //verticalAlign: 'center',
                    type: 'sankey',
                    name: '',
                }
            ]
        });
        console.log("end of sankeychart method");
    };
    DashBoardContentComponent.prototype.setDefaultValue = function (name) {
        if (name == "Application") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
        }
        if (name == "Entity") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
        }
        if (name == "Enterprise Service") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
        if (name == "ALL") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_6__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
    };
    DashBoardContentComponent.prototype.ngOnInit = function () {
        var _this = this;
        highcharts__WEBPACK_IMPORTED_MODULE_8__["setOptions"]({
            lang: {
                drillUpText: '< Back'
            }
        });
        //  this.spinnerService.show();
        //document.getElementById("directedGraph").innerHTML = '';
        // document.getElementById("successStatus").innerHTML ="";
        //console.log("maxDate:"+this.maxDate);
        this._businessUnitService.getBUnit().subscribe(function (bunitListValues) {
            //   console.log("bunitListValues : "+JSON.stringify(bunitListValues));
            _this.bunitList = bunitListValues;
            _this.setDefaultValue("ALL");
            if (_this.bunitList.length <= 1 && _this._userSessionService.getUserType() != 1) {
                //      document.getElementById("successStatus").innerHTML = "Business Units are not mapped to User. Please check with Admin for mapping BU.";
                _this._userSessionService.setMsg("");
                _this._router.navigate(['/logout']);
            }
        }), function (error) {
            console.log(error);
        };
        this._dashboardService.getAllDonutChartData().subscribe(function (donutChartData) {
            _this.donutChartList = donutChartData;
            _this.donutChartData = donutChartData;
            _this.chartAreaData = [];
            _this.clickableLogging();
        }), function (error) {
            console.log(error);
        };
        this._dashboardService.getAllBarChartData().subscribe(function (barChartDataValue) {
            //   console.log(barChartDataValue);
            _this.barChartList = barChartDataValue;
            _this.sucChartDataList = barChartDataValue.successList;
            _this.failChartDataList = barChartDataValue.failureList;
            _this.loggingChartData = barChartDataValue.successList;
            _this.clickableTransaction();
        }), function (error) {
            console.log(error);
        };
        this._dashboardService.getNotificationBarChartData().subscribe(function (notificationBarChartDataValue) {
            //console.log(notificationBarChartDataValue);
            _this.notificationBarChartList = notificationBarChartDataValue;
            _this.notifyChartList = notificationBarChartDataValue;
            _this.notifyChartData = notificationBarChartDataValue;
            _this.clickableNotification();
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
        this._dashboardService.getAllSankeyGraphData().subscribe(function (sankeyGraphData) {
            console.log(sankeyGraphData);
            _this.sankeyGraphList = sankeyGraphData;
            _this.sankeyChart();
        }), function (error) {
            console.log(error);
        }; // console.log("sankey chart completed:");
    };
    DashBoardContentComponent.prototype.setDefaultValues = function () {
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
    };
    DashBoardContentComponent.prototype.onBUChange = function (bunit) {
        var _this = this;
        console.log("bunit:" + bunit);
        this.buAppNameList = [];
        this.d3AppNameList = [];
        this.entityList = [];
        this.esList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.setDefaultValues();
        this.setDefaultValue("Entity");
        this.setDefaultValue("Enterprise Service");
        console.log("this.defBUAPPname:" + this.defBUAppName);
        if (bunit != null && bunit != 0) {
            this.bunitTemp = bunit;
            this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
                _this.d3AppNameList = buAppNameListValues;
                _this.buAppNameList = buAppNameListValues;
            }), function (error) {
                console.log(error);
            };
        }
    };
    DashBoardContentComponent.prototype.onBUAppNameChange = function (buAppName) {
        var _this = this;
        this.entityList = [];
        this.esList = [];
        this.buAppNameTemp = "";
        this.entitytemp = "";
        // this.buAppNameTemp = buAppName;
        this.setDefaultValues();
        console.log("this.defBUAppName:" + this.defBUAppName);
        if (buAppName != "" && buAppName != "0") {
            //console.log("inside On bu appnamechange if:"+buAppName);
            this.buAppNameTemp = buAppName;
            this._businessUnitService.getEntityNameByApplicationId(buAppName).subscribe(function (entityListValues) {
                _this.entityList = entityListValues;
                _this.d3entityList = entityListValues;
                _this.setDefaultValue("Enterprise Service");
            }), function (error) {
                console.log(error);
            };
        }
        else {
            //console.log("inside On bu appnamechange else:")
            this.setDefaultValue("Entity");
            this.setDefaultValue("Enterprise Service");
        }
    };
    DashBoardContentComponent.prototype.onEntityChange = function (entity) {
        var _this = this;
        this.esList = [];
        this.entitytemp = "";
        this.setDefaultValues();
        if (entity != "" && entity != "0") {
            this.entitytemp = entity;
            this._businessUnitService.getESNameByEntityId(entity).subscribe(function (esListValues) {
                _this.esList = esListValues;
                _this.d3esList = esListValues;
            }), function (error) {
                console.log(error);
            };
        }
        else {
            this.setDefaultValue("Enterprise Service");
        }
    };
    // onDurationChange(entity,buSearchdata,buDuration) {
    //   console.log("******onDurationChange***** "+buDuration.duration);
    //   //this.buSearch(buSearchdata,buDuration);
    // } 
    DashBoardContentComponent.prototype.buSearch = function (data) {
        var _this = this;
        //debugger;
        this.spinnerService.show();
        var buint = document.getElementById('buint').value;
        var buAppName = document.getElementById('buAppName').value;
        var entity = document.getElementById('entity').value;
        var es = document.getElementById('es').value;
        /* console.log("businessUnit "+buint);
         console.log("applicationName "+buAppName);
          console.log("entityName "+entity);
         console.log("entServiceName "+es);
         console.log("startDate "+data.startDate);
         console.log("endDate "+data.endDate);*/
        console.log("duration " + data.duration);
        this.busearch = new _dao_busearch__WEBPACK_IMPORTED_MODULE_4__["BUSearch"]();
        if (buint != "" && buint != this.defBU) {
            this.busearch.businessUnit = buint;
            if (buAppName != "" && buAppName != this.defBUAppName) {
                this.busearch.applicationName = buAppName;
            }
            if (entity != "" && entity != this.defBUEntity) {
                this.busearch.entityName = entity;
            }
            if (es != "" && es != "0") {
                this.busearch.entServiceName = es;
            }
        }
        var predate = new Date();
        var date = predate.getDate();
        var month = predate.getMonth() + 1;
        var year = predate.getFullYear();
        var monthStr = "";
        var dateStr = "";
        if (month < 10) {
            monthStr = "0" + month;
        }
        if (date < 10) {
            dateStr = "0" + date;
        }
        else {
            dateStr = "" + date;
        }
        var current_date = year + '-' + monthStr + '-' + dateStr;
        if (data.startDate != "") {
            if (data.startDate > current_date) {
                alert("Future date not allowed");
                return;
            }
            this.busearch.startDate = data.startDate;
        }
        if (data.endDate != "") {
            if (data.endDate > current_date) {
                alert("Future date not allowed");
                return;
            }
            this.busearch.endDate = data.endDate;
        }
        if (data.startDate != "" && data.endDate != "") {
            if (data.startDate > data.endDate) {
                alert("Start date later than End Date selected");
                return;
            }
        }
        // if(buDuration.duration != "")
        // {
        //     this.busearch.duration = buDuration.duration;
        // }
        if (data.duration != "" && data.duration != "0") {
            this.busearch.duration = data.duration;
        }
        console.log("BuSearch:" + this.busearch);
        console.log("BuSearch String:" + JSON.stringify(this.busearch));
        this._dashboardService.getSankeyGraphDataBySearch(this.busearch).subscribe(function (sankeyGraphData) {
            console.log(sankeyGraphData);
            _this.sankeyGraphList = [];
            _this.sankeyGraphList = sankeyGraphData;
            _this.sankeyChart();
            //this.interfaceCon();
            //  this.networkChart();
            //console.log("this.donutChartData:"+JSON.stringify(this.donutChartData));
            //this.createRelationshipChartData();
            //    this.relationshipService.createChart(this.networkChartData); 
            // Runtime.load(this.relationshipService.createChart(this.networkChartData), Inspector.into(this.chartContainer1.nativeElement));
        }), function (error) {
            console.log(error);
        }; // console.log("sankey chart completed:");
        this._dashboardService.getAllDonutChartDataBySearch(this.busearch).subscribe(function (donutChartData) {
            console.log(donutChartData);
            _this.donutChartList = donutChartData;
            _this.donutChartData = donutChartData;
            _this.chartAreaData = [];
            _this.clickableLogging();
            /*  this.networkChart(); */
            //  this.interfaceGraphbySearch(this.busearch);
        }), function (error) {
            console.log(error);
        };
        this._dashboardService.getAllBarChartDataBySearch(this.busearch).subscribe(function (barChartDataValue) {
            //debugger;
            _this.barCount = 0;
            //  console.log(barChartDataValue);
            _this.barChartList = barChartDataValue;
            _this.barChartAppName = [];
            _this.sucChartDataList = barChartDataValue.successList;
            _this.failChartDataList = barChartDataValue.failureList;
            _this.loggingChartData = barChartDataValue.successList;
            _this.clickableTransaction();
        }), function (error) {
            console.log(error);
        };
        this._dashboardService.getNotificationBarChartDataBySearch(this.busearch).subscribe(function (notificationBarChartDataValue) {
            //   console.log(notificationBarChartDataValue);
            _this.notificationBarChartList = [];
            _this.notificationBarChartList = notificationBarChartDataValue;
            _this.notifyChartList = notificationBarChartDataValue;
            _this.notifyChartData = notificationBarChartDataValue;
            _this.clickableNotification();
            var sortedArray = _this.notificationBarChartList.sort(function (a, b) {
                return a.appCount > b.appCount ? -1 : a.appCount < b.appCount ? 1 : 0;
            });
            /* if(this.notificationBarChartList.length > 10){
             this.notificationBarChartList.length=10;
             }*/
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])("containerElement", { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], DashBoardContentComponent.prototype, "containerPieChart", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])("containerElementNotification", { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], DashBoardContentComponent.prototype, "containerNotification", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])("containerElementTransaction", { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], DashBoardContentComponent.prototype, "containerTransaction", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])("containerElementSankey", { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], DashBoardContentComponent.prototype, "containerSankey", void 0);
    DashBoardContentComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dash-board-content',
            template: __webpack_require__(/*! ./dash-board-content.component.html */ "./src/app/components/dash-board-content/dash-board-content.component.html"),
            styles: [__webpack_require__(/*! ./dash-board-content.component.css */ "./src/app/components/dash-board-content/dash-board-content.component.css"), __webpack_require__(/*! ./highchart.css */ "./src/app/components/dash-board-content/highchart.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_7__["UserSessionService"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_5__["Ng4LoadingSpinnerService"], _service_business_unit_service__WEBPACK_IMPORTED_MODULE_2__["BusinessUnitService"], _service_dashboard_service__WEBPACK_IMPORTED_MODULE_1__["DashboardService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], src_app_service_relationshipsGraphService__WEBPACK_IMPORTED_MODULE_14__["RelationshipsGraphService"]])
    ], DashBoardContentComponent);
    return DashBoardContentComponent;
}());



/***/ }),

/***/ "./src/app/components/dash-board-content/highchart.css":
/*!*************************************************************!*\
  !*** ./src/app/components/dash-board-content/highchart.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#csv {\r\n\tdisplay: none;\r\n}\r\n\r\n.highcharts-figure, .highcharts-data-table table {\r\n    min-width: 310px;\r\n    max-width: 800px;\r\n    margin: 1em auto;\r\n}\r\n\r\n.highcharts-data-table table {\r\n\tfont-family: Verdana, sans-serif;\r\n\tborder-collapse: collapse;\r\n\tborder: 1px solid #EBEBEB;\r\n\tmargin: 10px auto;\r\n\ttext-align: center;\r\n\twidth: 100%;\r\n\tmax-width: 500px;\r\n}\r\n\r\n.highcharts-data-table caption {\r\n    padding: 1em 0;\r\n    font-size: 1.2em;\r\n    color: #555;\r\n}\r\n\r\n.highcharts-data-table th {\r\n\tfont-weight: 600;\r\n    padding: 0.5em;\r\n}\r\n\r\n.highcharts-data-table td, .highcharts-data-table th, .highcharts-data-table caption {\r\n    padding: 0.5em;\r\n}\r\n\r\n.highcharts-data-table thead tr, .highcharts-data-table tr:nth-child(even) {\r\n    background: #f8f8f8;\r\n}\r\n\r\n.highcharts-data-table tr:hover {\r\n    background: #f1f7ff;\r\n}\r\n"

/***/ }),

/***/ "./src/app/components/dash-board/dash-board.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/dash-board/dash-board.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/dash-board/dash-board.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/dash-board/dash-board.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<app-side-bar \n(loggingEvent)=\"receiveMessage($event)\" \n(notificationEvent)=\"receiveNotification($event)\" \n(userEvent)=\"receiveUser($event)\" \n(logDetailsEvent)=\"receiveLogDetails($event)\" \n(notificationDetailsEvent)=\"receiveNotificationDetails($event)\" \n(appInfoEvent)=\"receiveAppInfo($event)\" \n(dashBoardEvent)=\"receiveDashBoard($event)\"\n(newInterfaceEvent)=\"receiveNewInterface($event)\" \n(generalInstructionEvent)=\"generalInstructionMethod($event)\" \n(dataPurgeEvent)=\"dataPurgeMethod($event)\">\n\n</app-side-bar>\n<app-dash-board-content *ngIf=\"dashBoardFlagparent\"></app-dash-board-content>\n<app-logging *ngIf=\"logFlagparent\"></app-logging>\n<app-notification *ngIf=\"notificationFlagparent\"></app-notification>\n<app-user *ngIf=\"userFlagparent\"></app-user>\n<!-- <app-log-details *ngIf=\"logDetailsFlagparent\"></app-log-details> -->\n<!-- <app-notification-details *ngIf=\"notificationDetailsFlagparent\"></app-notification-details> -->\n<app-app-info *ngIf=\"appInfoFlagparent\"></app-app-info>\n<app-new-interface *ngIf=\"newInterfaceFlagparent\"></app-new-interface>\n<app-general-instruction *ngIf=\"generalInstruction\"></app-general-instruction>\n<app-data-purge *ngIf=\"dataPurge\"></app-data-purge>\n<!-- <app-footer></app-footer> -->\n"

/***/ }),

/***/ "./src/app/components/dash-board/dash-board.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/dash-board/dash-board.component.ts ***!
  \***************************************************************/
/*! exports provided: DashBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBoardComponent", function() { return DashBoardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DashBoardComponent = /** @class */ (function () {
    //uname:any = null;
    //constructor(private _router:Router) {
    function DashBoardComponent(_router, route) {
        this._router = _router;
        this.route = route;
        this.dashBoardFlagparent = true;
        this.logFlagparent = false;
        this.notificationFlagparent = false;
        this.applicationFlagparent = false;
        this.userFlagparent = false;
        this.notificationDetailsFlagparent = false;
        this.appInfoFlagparent = false;
        this.generalInstruction = false;
        this.logDetailsFlag = null;
        this.notificationDetailsFlag = null;
        this.bioLogSearchFlag = null;
        this.bioNotifySearchFlag = null;
        this.newInterfaceFlagparent = false;
        this.dataPurge = false;
        console.log("************ " + this.route.queryParams.subscribe(function (params) { params['logDetailsFlag'] || false; }));
        /*console.log("*****BioTransId******* "+this.route.snapshot.paramMap.get('BioTransId'));
        console.log("*****notifyHistoryId******* "+this.route.snapshot.paramMap.get('NotifyHistoryId'));
        //console.log("*****uname******* "+this.route.snapshot.paramMap.get('uname'));
    
        this.logDetailsFlag = this.route.snapshot.paramMap.get('BioTransId');
        this.notificationDetailsFlag = this.route.snapshot.paramMap.get('NotifyHistoryId');
        //this.uname = this.route.snapshot.paramMap.get('uname');
    */
        //if(this.routeFlag != null && this.routeFlag == "true")
        if (this.logDetailsFlag != null) {
            console.log("******logDetails****** ");
            this.notificationFlagparent = false;
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else if (this.notificationDetailsFlag != null) {
            console.log("******notificationDetails****** ");
            this.notificationFlagparent = false;
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationDetailsFlagparent = true;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            this.bioLogSearchFlag = this.route.snapshot.paramMap.get('logSearchFlag');
            this.bioNotifySearchFlag = this.route.snapshot.paramMap.get('notificationSearchFlag');
            if (this.bioLogSearchFlag != null && this.bioLogSearchFlag == "true") {
                console.log("******logSearch****** ");
                this.notificationFlagparent = false;
                this.applicationFlagparent = false;
                this.userFlagparent = false;
                this.logFlagparent = true;
                this.notificationDetailsFlagparent = false;
                this.appInfoFlagparent = false;
                this.dashBoardFlagparent = false;
                this.generalInstruction = false;
                this.newInterfaceFlagparent = false;
                this.dataPurge = false;
            }
            else if (this.bioNotifySearchFlag != null && this.bioNotifySearchFlag == "true") {
                console.log("******notificationSearch****** ");
                this.notificationFlagparent = true;
                this.applicationFlagparent = false;
                this.userFlagparent = false;
                this.logFlagparent = false;
                this.notificationDetailsFlagparent = false;
                this.appInfoFlagparent = false;
                this.dashBoardFlagparent = false;
                this.generalInstruction = false;
                this.newInterfaceFlagparent = false;
                this.dataPurge = false;
                this.receiveNotification(true);
            }
        }
    }
    DashBoardComponent.prototype.ngOnInit = function () {
        /*this.dashBoardFlagparent = false;
        this.notificationFlagparent = true;
        console.log("dashboard componenet ngOnInit():");
        this.receiveNotification(true);*/
    };
    DashBoardComponent.prototype.receiveMessage = function ($event) {
        //debugger;
        if ($event == "true") {
            this.notificationFlagparent = false;
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = true;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            //this.notificationFlagparent = true;
            //this.logFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveNotification = function ($event) {
        //debugger;
        console.log("dashboard componenet receiveNotification():" + $event);
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = true;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            //this.logFlagparent = true;
            //this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveUser = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = true;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            //this.logFlagparent = true;
            //this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveNotificationDetails = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = true;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveAppInfo = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = true;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveDashBoard = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = true;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.generalInstructionMethod = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = true;
            this.newInterfaceFlagparent = false;
            this.dataPurge = false;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.dataPurgeMethod = function ($event) {
        //debugger;
        console.log("dataPurgeMethod");
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = false;
            this.dataPurge = true;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent.prototype.receiveNewInterface = function ($event) {
        //debugger;
        if ($event == "true") {
            this.applicationFlagparent = false;
            this.userFlagparent = false;
            this.logFlagparent = false;
            this.notificationFlagparent = false;
            this.notificationDetailsFlagparent = false;
            this.appInfoFlagparent = false;
            this.dashBoardFlagparent = false;
            this.generalInstruction = false;
            this.newInterfaceFlagparent = true;
            this.dataPurge = false;
        }
        else {
            // this.logFlagparent = true;
            // this.notificationFlagparent = false;
        }
    };
    DashBoardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dash-board',
            template: __webpack_require__(/*! ./dash-board.component.html */ "./src/app/components/dash-board/dash-board.component.html"),
            styles: [__webpack_require__(/*! ./dash-board.component.css */ "./src/app/components/dash-board/dash-board.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"]])
    ], DashBoardComponent);
    return DashBoardComponent;
}());



/***/ }),

/***/ "./src/app/components/data-purge-details/data-purge-details.component.css":
/*!********************************************************************************!*\
  !*** ./src/app/components/data-purge-details/data-purge-details.component.css ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/data-purge-details/data-purge-details.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/components/data-purge-details/data-purge-details.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n\n    <!-- The Modal -->\n    <div class=\"modal\" id=\"purgeDetailsModal\">\n      <div id=\"modelLogResize\" class=\"modal-dialog modalDialogBox\">\n        <div class=\"modal-content\">\n  \n          <!-- Modal Header -->\n          <div class=\"modal-header\">\n            <div class=\"row\">\n              <h4 class=\"modal-title\">Logging Detail</h4>\n              <button type=\"button\" id=\"b1\" class=\"close\" (click)=\"closeModel()\" data-dismiss=\"modal\">&times;</button>\n              <button type=\"button\" class=\"btn btn-default reduce reduce\" onclick=\"reduce()\" style=\"display:none\"><img src=\"assets/img/reduce.png\"\n                  alt=\"Resize\" height=\"15\" /></button>\n              <button type=\"button\" class=\"btn btn-default resize  enlarge\" onclick=\"resize()\"><img src=\"assets/img/enlarge.png\"\n                  alt=\"Resize\" height=\"15\" /></button>\n            </div>\n          </div>\n  \n          <!-- Modal body -->\n          <div class=\"modal-body\">\n            <div class=\"content-wrapper\" style=\"padding-top:20px !important\">\n              <section class=\"content\">\n                <div class=\"row\">\n                  <div class=\"col-md-12\">\n  \n                    <div class=\"log_tab loggingTable\">\n                      <div class=\"row\">\n                        <div class=\"bioid\"><b>Purge Id : <span>{{purgeId}}</span></b></div>\n                        <table class=\"logmain logdet table-striped\" border=\"1\" width=50px>\n                            <tr *ngIf=\"purgeDataList?.length > 0\">\n                              <td> <b>Detail Id</b></td>\n                              <td> <b>App Name</b></td>\n                              <td><b>App Group</b> </td>\n                              <td><b>Log Count</b> </td>\n                              <td><b>Notify Count</b> </td>\n                              \n                            </tr>\n                            \n                            <tr *ngFor=\"let bioLogDetails of purgeDataList\">\n                              <td>{{bioLogDetails.purgeDetailId}}</td>\n                              <td> {{bioLogDetails.appName}}</td>\n                              <td> {{bioLogDetails.appGroupName}}</td>\n                              <td> {{bioLogDetails.logCount}}</td>\n                              <td>{{bioLogDetails.notifyCount}}</td>\n\n                            </tr>\n                          </table>\n                        <!-- <table class=\"logmain logdet table-striped\"> -->\n                        \n                        <!-- </table> -->\n                        <div class=\"spc_line\"></div>\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </section>\n            </div>\n          </div>\n        </div>\n        </div>\n          </div>"

/***/ }),

/***/ "./src/app/components/data-purge-details/data-purge-details.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/components/data-purge-details/data-purge-details.component.ts ***!
  \*******************************************************************************/
/*! exports provided: DataPurgeDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataPurgeDetailsComponent", function() { return DataPurgeDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DataPurgeDetailsComponent = /** @class */ (function () {
    function DataPurgeDetailsComponent() {
    }
    DataPurgeDetailsComponent.prototype.ngOnInit = function () {
        console.log("DataPurgeDetailsComponent id:" + this.purgeId);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('purgeId'),
        __metadata("design:type", String)
    ], DataPurgeDetailsComponent.prototype, "purgeId", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('purgeDataList'),
        __metadata("design:type", Object)
    ], DataPurgeDetailsComponent.prototype, "purgeDataList", void 0);
    DataPurgeDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-data-purge-details',
            template: __webpack_require__(/*! ./data-purge-details.component.html */ "./src/app/components/data-purge-details/data-purge-details.component.html"),
            styles: [__webpack_require__(/*! ./data-purge-details.component.css */ "./src/app/components/data-purge-details/data-purge-details.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], DataPurgeDetailsComponent);
    return DataPurgeDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/data-purge/data-purge.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/data-purge/data-purge.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/data-purge/data-purge.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/data-purge/data-purge.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper user\">\n    <ol class=\"breadcrumb\">\n        <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n      <li class=\"breadcrumb-item\">Purge History</li>\n    </ol>\n    <section class=\"content\">\n      <div class=\"row\">\n        <div class=\"col-md-12\">\n  \n          \n  <br/>\n  \n          <div class=\"table_color3\">\n            <div class=\"row\">\n              <div class=\"container-fluid\" style=\"padding-right:5px !important\">\n                <ag-grid-angular style=\"height: 530px;\" class=\"ag-theme-balham\" [rowData]=\"rowData\"\n                  [columnDefs]=\"columnDefs\" [enableSorting]=\"true\" [enableFilter]=\"true\" [rowHeight]=\"30\" \n                  [suppressRowClickSelection]=\"true\" [debug]=\"true\" [enableColResize]=\"true\" [enableRangeSelection]=\"true\"\n                  [paginationAutoPageSize]=\"false\" [pagination]=\"true\" [paginationPageSize]=15 [overlayLoadingTemplate]=\"overlayLoadingTemplate\"\n                  (gridReady)=\"onGridReady($event)\"  (cellClicked)=\"onCellClicked($event)\" (rowClicked)=\"onRowClicked($event)\">\n                </ag-grid-angular>\n              </div>\n            </div>\n          </div>\n  \n        </div>\n  \n      </div>\n    </section>\n  </div>\n  <app-data-purge-details \n[purgeId]=purgeId \n[purgeDataList]=purgeDataList>\n</app-data-purge-details>"

/***/ }),

/***/ "./src/app/components/data-purge/data-purge.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/data-purge/data-purge.component.ts ***!
  \***************************************************************/
/*! exports provided: DataPurgeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataPurgeComponent", function() { return DataPurgeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_purge_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/purge.service */ "./src/app/service/purge.service.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var DataPurgeComponent = /** @class */ (function () {
    function DataPurgeComponent(purgeService, spinnerService) {
        this.purgeService = purgeService;
        this.spinnerService = spinnerService;
        this.rowData = [];
        this.columnDefs = [];
        this.status = "";
    }
    DataPurgeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.spinnerService.show();
        this.columnDefs = [
            { headerName: 'Purge Start Date', field: 'purgeStartDate', width: 200 },
            { headerName: 'Purge End Date', field: 'purgeEndDate', width: 200 },
            { headerName: 'Purge Status', field: 'purgeStatus', width: 150,
                cellRenderer: function (params) {
                    var html = '<a data-toggle="modal" data-target="#purgeDetailsModal" href="#">' + params.data.purgeStatus + '</a>';
                    return html;
                }
            },
            { headerName: 'Remarks', field: 'purgeRemarks', width: 200 },
            { headerName: 'Run By', field: 'executedBy', width: 150 },
            { headerName: 'Run Date', field: 'executedDate', width: 200 }
        ];
        this.purgeService.getPurgeHistoryDetails().subscribe(function (purgeHistory) {
            _this.rowData = purgeHistory;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    DataPurgeComponent.prototype.onGridReady = function (params) {
        this.gridApi = params.api;
        this.gridApi.showLoadingOverlay();
    };
    DataPurgeComponent.prototype.onCellClicked = function (event) {
        console.log("onCellClicked " + event.colDef.headerName);
        if (event.colDef.headerName == "Purge Status") {
            this.status = "Purge Status";
        }
    };
    DataPurgeComponent.prototype.onRowClicked = function (event) {
        var _this = this;
        console.log("on row clicked:" + event);
        if (this.status == "Purge Status") {
            console.log(" Purge statue of PurgeId:" + event.data.purgeId);
            this.purgeId = event.data.purgeId;
            this.purgeService.purgeDetails(this.purgeId).subscribe(function (purgeDetails) {
                console.log("purgeDetails:" + JSON.stringify(purgeDetails));
                _this.purgeDataList = purgeDetails;
            }), function (error) {
                console.log(error);
            };
            this.status = "";
        }
    };
    DataPurgeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-data-purge',
            template: __webpack_require__(/*! ./data-purge.component.html */ "./src/app/components/data-purge/data-purge.component.html"),
            styles: [__webpack_require__(/*! ./data-purge.component.css */ "./src/app/components/data-purge/data-purge.component.css")]
        }),
        __metadata("design:paramtypes", [_service_purge_service__WEBPACK_IMPORTED_MODULE_1__["PurgeService"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_2__["Ng4LoadingSpinnerService"]])
    ], DataPurgeComponent);
    return DataPurgeComponent;
}());



/***/ }),

/***/ "./src/app/components/error-page/error-page.component.css":
/*!****************************************************************!*\
  !*** ./src/app/components/error-page/error-page.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/error-page/error-page.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/components/error-page/error-page.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid loginBg\"  >\n    <header class=\"main-header\" >\n        <div class=\"row\" >\n\n          <div class=\"col-sm-12\" >\n              <nav class=\"navbar navbar-inverse\">\n                  <div class=\"container-fluid \" >   \n                    <div class=\"collapse navbar-collapse\" id=\"myNavbar\">\n                      <ul class=\"nav navbar-nav\">      \n                        <li class=\"logo\">\n                            <img src=\"assets/img/etm_logo.png\" alt=\"logo\" height=\"50\" style=\"float:right; margin-top:10px !important;  margin-left: -30px !important\">\n                          \n                        </li>\n                        <!-- <li> <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"push-menu\" role=\"button\">\n                            <i class=\"fa fa-right-arrow\"></i>\n                          </a></li>     -->\n                          <!-- <li> \n                              <a href=\"#\" id=\"icon\" class=\"icon\" data-toggle=\"push-menu\" role=\"button\">\t&#171;</a>\n                              <a href=\"#\" id=\"icon2\" class=\"icon2\" style=\"display:none\" data-toggle=\"push-menu\" role=\"button\">&#187;\n                              </a>\n                         \n                          </li>    -->\n                      </ul>\n                      <ul class=\"nav navbar-nav navbar-right\">      \n                       \n                        <li > \n                            <img src=\"assets/img/biogen-logo-refresh-new.svg\" alt=\"logo\" height=\"30\" style=\"float:right; margin-top:8px; margin-right: 5px\"  >\n                           </li>\n                      </ul>      \n                    </div>\n                  </div>\n                </nav>\n          </div>\n        </div>\n    \n        </header>\n       \n\n        <div class=\"logout-page\">       \n\n            <div class=\"container-fluid\">\n                \n                <div class=\"row\" >\n                    <div style=\"height:150px; display:block;\">&nbsp;</div>\n                    <div class=\"col-sm-8 leftSide\">\n                           \n                        <div class=\"loginImg\">\n\n                            <img src=\"assets/img/logout_banner - v1.png\" alt=\"loginimg\"/>\n                          </div>\n                          <div style=\"height:10%; display:block;\">&nbsp;</div>       \n                          <div class=\"captionArea\">\n                              \n                              <h4 class=\"caption\">E<span>nterprise</span> T<span>ransaction</span> M<span>onitoring</span> (ETM) <span> helps you to log, notify, visualize transaction status</span></h4>\n                          </div>\n                         \n        \n                    </div>\n                    <div class=\"col-sm-4 rightSide\">\n                        <div style=\"height:50px; display:block;\">&nbsp;</div>\n                        <div class=\"formContent\">\n                            <h3>Sign In </h3><br/>\n                            <p style=\"font-size:18px;\">Session timed out/exception occurred. Please login again for accessing ETM.</p>\n                                <!-- <div style=\"margin-bottom: 35px\" class=\"input-group\">\n                                  <span class=\"input-group-addon\"><i class=\"fa fa-user-circle-o\"></i></span>\n                                  <input type=\"text\" name=\"j_username\" placeholder=\"User ID\" class=\"form-control inputPadding\" ngModel>\n                                </div> -->\n                                <!-- <div style=\"margin-bottom: 35px\" class=\"input-group\">\n                                  <span class=\"input-group-addon passwordPadding\"><i class=\"fa fa-lock\" style=\"padding:0 2px 0 3px\"></i></span>\n                                  <input type=\"password\" name=\"j_password\" placeholder=\"password\" class=\"form-control inputPadding\" ngModel>\n                                </div>\n                         -->\n                         <br/><br/><br/>\n                                <div style=\"margin-top:10px\" class=\"form-group\">\n                                  <div class=\"controls\">\n                                      <a href={{hostName}}> <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\" id=\"log\" name=\"B1\">Continue to Sign In</button></a>\n                                  </div>\n                                </div>\n                              <div id=\"lstatus\" style=\"color: #FF0000;\"></div>\n                         \n                        </div>\n                  </div>\n                </div>\n            </div>\n               \n                 <!-- Footer -->\n                 <!-- <footer>\n                    <div class=\"row footerBg\">\n                        <div class=\"col-lg-12\">\n                            <strong>Copyright &copy; 2018 <a href=\"#\" style=\"color:#3fafd5\">Biogen</a>.</strong>\n                        </div>\n                    </div>\n                </footer> -->\n                </div>\n                \n              </div>\n              "

/***/ }),

/***/ "./src/app/components/error-page/error-page.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/components/error-page/error-page.component.ts ***!
  \***************************************************************/
/*! exports provided: ErrorPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorPageComponent", function() { return ErrorPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ErrorPageComponent = /** @class */ (function () {
    function ErrorPageComponent(_userSessionService) {
        this._userSessionService = _userSessionService;
        this.hostName = "";
        this.hostName = this._userSessionService.getHostName();
        console.log("error page constructor this.hostName: " + this.hostName);
    }
    ErrorPageComponent.prototype.ngOnInit = function () {
        this.hostName = this._userSessionService.getHostName();
        console.log("error page on load this.hostName: " + this.hostName);
        if (this.error != null) {
            console.log("Error:" + this.error);
        }
    };
    ErrorPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-error-page',
            template: __webpack_require__(/*! ./error-page.component.html */ "./src/app/components/error-page/error-page.component.html"),
            styles: [__webpack_require__(/*! ./error-page.component.css */ "./src/app/components/error-page/error-page.component.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_1__["UserSessionService"]])
    ], ErrorPageComponent);
    return ErrorPageComponent;
}());



/***/ }),

/***/ "./src/app/components/general-instruction/general-instruction.component.css":
/*!**********************************************************************************!*\
  !*** ./src/app/components/general-instruction/general-instruction.component.css ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/general-instruction/general-instruction.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/components/general-instruction/general-instruction.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper\">\n    <!-- Content Header (Page header) -->\n    <ol class=\"breadcrumb\">\n         <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n         <li class=\"breadcrumb-item\"> General instructions</li>\n       </ol>\n<section class=\"content\">\n<div class=\"row general_tab\">\n  <div class=\"col-md-12\" style=\"padding:0 !important; margin:0 !important\">\n        <div class=\"panel with-nav-tabs panel-default\">\n            <div class=\"panel-heading\">\n                    <ul class=\"nav nav-tabs\">\n                        <li class=\"active\"><a href=\"#tab1default\" data-toggle=\"tab\">Introduction</a></li>\n                        <li><a href=\"#tab2default\" data-toggle=\"tab\">Getting Started</a></li>\n                        <li><a href=\"#tab3default\" data-toggle=\"tab\">Technical Overview</a></li>\n                        <li><a href=\"#tab4default\" data-toggle=\"tab\">Best Practices</a></li>\n                        <li><a href=\"#tab5default\" data-toggle=\"tab\">FAQ</a></li>\n                 \n                    </ul>\n            </div>\n            <div class=\"panel-body\">\n                <div class=\"tab-content\">\n                    <div class=\"tab-pane fade in active\" id=\"tab1default\">\n                      <h3>Introduction</h3>\n                      <p>Biogen DEA team has designed and developed a web based system called ETM - Enterprise Transaction Management. ETM is envisaged as the Custom utility framework to log, monitor and provide notifications of transactions. It can also be extended and used by other enterprise applications for similar usage.</p>\n                      <!-- <p>Biogen FMW team has designed and developed a web based system called ETM - Enterprise Transaction Management. ETM is envisaged as the single application to track the transactions happening through the Biogen Fusion middleware system. It helps as an audit / logging application, to send email notification for specific events within the transaction and also as a tool for the support team members or business owners for tracking of requests or identifying the cause of errors with the error payloads. It can also be extended and used by other enterprise applications for similar usage.\n                      </p>\n                    <p>It also provides a single-source of application for the overall flow of the interfaces and also gives an overview on the complete history about the particular interface in terms of the document locations, linked CRs etc.\n                    </p> -->\n                    \n                    \n                    <h3>ETM 2.0 Features</h3>\n                    <p>\n                    <li class=\"tabClass\">Additional exposure to ETM framework through JMS Capability and also exposed as REST API</li>\n                    <li class=\"tabClass\">Enhanced UI with metrics based dashboard</li>\n                    <li class=\"tabClass\">Solution is now platform independent (Removed dependency on FMW domains )</li>\n                    <li class=\"tabClass\">Email aggregator, Frequency are configurable</li>\n                    <li class=\"tabClass\">Notification emails delivery identification </li>\n                    <li class=\"tabClass\">Enhanced search capabilities with Business Unit, Application, Entity, Enterprise Services, Interface Id</li>\n                    <li class=\"tabClass\">Custom template based bulk notification support</li>\n                    <li class=\"tabClass\">Enable history for individual interfaces and access to myCIMS and design</li>\n                    </p>\n                    </div>\n                    <div class=\"tab-pane fade\" id=\"tab2default\">\n\n<h3>AppId Configuration</h3>\n\nFor integrating the resprective Interface with ETM for logging and Notification, \na request has to be sent to MW admin for provisioning of APPID. The below section provides a\nquick snippet for sending the request in the form of Insert script.<br>&nbsp;\n\n<div class=\"shadowbox\">\n<pre ><code class=\"language-java\" data-lang=\"sql\">\n-- Example: Provision of APPID \"BES-TRANSPORT-DESTINATION\"--\n\nInsert into ETMCLD.BIO_LOG_APPLICATION (APP_ID,APP_NAME,APP_TYPE_ID,APP_GROUP_ID,LOGGER_ID,APP_DESC,CREATED_BY,CREATED_DATE,UPDATED_BY,UPDATED_DATE) \nvalues (LOG_APPLICATION_ROWID.NEXTVAL,'BES-TRANSPORT-DESTINATION',1,1,3,'BES TRANSPORT DESTINATION Interface','DBA',SYSDATE,null,null);\ncommit;\n\n</code></pre>\n</div>\n\n<br>\nIn ETM 2.0, sending of email notifications has been moved from SOA fusion middleware layer\nand is included as part of ETM.<br> The below section provides a\nquick snippet for configuring the Notify parameters for respective APPID in the form of Insert script.<br>&nbsp;\n\n<div class=\"shadowbox\">\n<pre ><code class=\"language-java\" data-lang=\"sql\">\n-- EX: Configure of Notify Properties for above created APPID \"BES-TRANSPORT-DESTINATION\"--\n\nInsert into ETMCLD.BIO_NOTIFY (ID,APP_ID,EX_CATEGORY,EX_TYPE,CREATED_DATE,UPDATED_DATE,CREATED_BY,UPDATED_BY) values \n(BIO_NOTIFY_SEQ.NEXTVAL,&APP_ID,'APPLICATION','ERROR',SYSDATE,SYSDATE,'DBA','DBA');\ncommit;\n\n</code></pre>\n</div>\n<br>\n<br>\n<h3>ETM GUI Application Access</h3>\n\nFor accessing ETM GUI application, the respective user has to submit the BAM request to get the access provisioned.\n<br> The below section provides a quick snippet for submitting BAM request.<br>&nbsp;\n\n<div class=\"shadowbox\">\n<pre ><code class=\"language-java\" data-lang=\"sql\">\n\n<b>Manage Requests--> Oracle Applications --> Oracle Fusion Platform</b> \n\nChoose either of the below and submit the request\n\nService item: Enterprise Transactions Monitoring (ETM) � User Role\n\nService item: Enterprise Transactions Monitoring (ETM) � Admin Role\n\n\n</code></pre>\n</div>\n<br>\n<br>\n<h3>ETM GUI Application URLs</h3>\n<br>\n\n<div class=\"shadowbox\">\n  <pre ><code class=\"language-java\" data-lang=\"sql\">\n  \n  <b>https://eisutldev.biogen.com/eisUtilWeb/login</b> \n  \n  Note: Use your Biogen Network Login Credentials\n  \n  </code></pre>\n  </div>\n  <br>\n\n\n                    </div>\n                    <div class=\"tab-pane fade\" id=\"tab3default\">\n                    \n                        <h3>Architecture</h3>\n                        <br>\n                        The below diagram depicts the components involved with ETM 2.0 and also gives a generic overview \n                        on the flow between various sub-systems within ETM 2.0\n                        <br>\n                        <br>\n                        <img src=\"assets/img/etm_arch.jpg\" alt=\"ETM Architecture\" class=\"center\"> \n                      <br>\n                      <br><br>\n                      \n                      <h3>Sample Interface Integration Diagram</h3>\n                      The below flow diagram gives ageneric example of Logging/Notifications as highlighted in the Interface Diagram\n                      <br>\n                      <br>\n                      <img src=\"assets/img/WMS-SwissLog_Sample.jpg\" class=\"img-responsive smaller\" alt=\"Sample Interface Diagram\" > \n\n                      <br>\n                      <br>\n                      <br>\n                      <h3>Methods of invoking ETM service</h3>\n                      <h4>SOAP based</h4>\n                      <br>\n                      <textarea rows=\"25\" cols=\"120\" id=\"soapDescription\"\nstyle=\"resize: none;\" data-role=\"none\" spellcheck=\"false\">\n\n<wsdl:definitions targetNamespace=\"http://www.biogen.com/eip/services/eisUtilService\" xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:sch=\"http://www.biogen.com/eip/services/eisUtilService\" xmlns:soap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:tns=\"http://www.biogen.com/eip/services/eisUtilService\">\n   <wsdl:types>\n      <schema attributeFormDefault=\"unqualified\" elementFormDefault=\"qualified\" targetNamespace=\"http://www.biogen.com/eip/services/eisUtilService\" xmlns=\"http://www.w3.org/2001/XMLSchema\">\n         <element name=\"eisLogNotifyRequest\">\n            <complexType>\n               <choice>\n                  <group ref=\"tns:eisLogNotifyRequest_V1\"/>\n               </choice>\n               <attribute name=\"version\" type=\"string\" use=\"required\"/>\n            </complexType>\n         </element>\n         <group name=\"eisLogNotifyRequest_V1\">\n            <sequence>\n               <element name=\"version1\">\n                  <complexType>\n                     <sequence>\n                        <!--unique app Id Ex: BES-eData  -Required-->\n                        <element name=\"appId\" type=\"string\"/>\n                        <!--unique id generated in FMW and passed to service invocation -Required-->\n                        <element name=\"biogenTransId\" type=\"string\"/>\n                        <!--TO identify operation either Log, Notify or BOTH refer enumeration for values -Required-->\n                        <element name=\"operation\" type=\"tns:operationNameType\"/>\n                        <!--<element name=\"operation\" type=\"string\"/>-->\n                        <element maxOccurs=\"1\" minOccurs=\"0\" name=\"loggingRequest\" type=\"tns:loggingRequest_V1\"/>\n                        <element maxOccurs=\"1\" minOccurs=\"0\" name=\"notifyRequest\" type=\"tns:notificationType_V1\"/>\n                     </sequence>\n                  </complexType>\n               </element>\n            </sequence>\n         </group>\n         <!--Attributes needs to be passed for Operation=\"LOG OR BOTH\"-->\n         <complexType name=\"loggingRequest_V1\">\n            <sequence>\n               <!--LOG levels to either INFO,DEBUG,ERROR -Required-->\n               <element name=\"logLevel\" type=\"tns:LogLevelType\"/>\n               <!--OSB service name/ SOA composite Name EX: SyncadeNotifyWorkAlertEventRequest_PS -Required-->\n               <element name=\"serviceInvokerName\" type=\"string\"/>\n               <!--Needed for Logging point EX: FTP_READ,DB_POLLING.. -Required-->\n               <element name=\"messageCode\" type=\"string\"/>\n               <!--Detailed description of logging point point EX: FTP_Adapter read from input xml file from source   -->\n               <element minOccurs=\"0\" name=\"messageDescription\" type=\"string\"/>\n               <!--Actual RAQ Data at logging point, it will helpful for reprocessing needs -Reqired-->\n               <element name=\"messagePayload\" type=\"string\"/>\n               <!--to encrypt sensitive data payloads for the transaction-->\n               <element default=\"N\" name=\"needPayloadEncryption\" type=\"string\"/>\n               <!--it accepts either SUCCESS, FAILED  -Required-->\n               <element name=\"serviceStatus\" type=\"string\"/>\n               <!--service invocation time  -Required-->\n               <element name=\"serviceInvokeTime\" type=\"dateTime\"/>\n               <!--service invocation time  -Optional-->\n               <element minOccurs=\"0\" name=\"serviceEndTime\" type=\"dateTime\"/>\n               <!--its required to capture the multiple target, status, time  -Required-->\n               <group minOccurs=\"0\" ref=\"tns:TargtetInfoType\"/>\n               <!--its info attributes with key, value pair and passed any logging point flow - Optional-->\n               <element maxOccurs=\"unbounded\" minOccurs=\"0\" name=\"entityAttributes\" type=\"tns:additionalPropertiesType\"/>\n            </sequence>\n         </complexType>\n         <!--Attributes needs to be passed for Operation=\"Notification OR BOTH \"-->\n         <complexType name=\"notificationType_V1\">\n            <sequence>\n               <!--exception categories For EX: Business,system,Technical -Required-->\n               <element name=\"exceptionCategory\" type=\"string\"/>\n               <!--exception type means its error, success,info For EX: ERROR,SUCCESS,INFO -Required-->\n               <element name=\"exceptionType\" type=\"string\"/>\n               <!--error out service name -Required-->\n               <element name=\"faultedService\" type=\"string\"/>\n               <!--error message from the service, it will displays message in case of error code 100 as per existing system -Optional-->\n               <element minOccurs=\"0\" name=\"faultMessage\" type=\"string\"/>\n               <!--Notification email body -Optional-->\n               <element minOccurs=\"0\" name=\"subject\" type=\"string\"/>\n               <!--Cusomized Error codes, oracle standard error code -Required-->\n               <element name=\"errorCode\" type=\"string\"/>\n               <!--customized error/success description -Required-->\n               <element name=\"errorDesc\" type=\"string\"/>\n               <!--Notification Service Invocation Timestamp -Required-->\n               <element name=\"notificationTime\" type=\"dateTime\"/>\n               <!--Cusomized Error codes, oracle standard error code -Required-->\n               <element name=\"messageCode\" type=\"string\"/>\n               <!--customized error/success description -Required-->\n               <element name=\"messageDescription\" type=\"string\"/>\n               <!--body payload at the time Notification triggered -Optional-->\n               <element minOccurs=\"0\" name=\"payload\" type=\"string\"/>\n               <!--additional exception Attributes to display under error details -Optional-->\n               <element maxOccurs=\"unbounded\" minOccurs=\"0\" name=\"exceptionAttributes\" type=\"tns:additionalPropertiesType\"/>\n               <!--additional info Attributes to display in case of error code 100 as per existing system -Optional-->\n               <element maxOccurs=\"unbounded\" minOccurs=\"0\" name=\"additionalInfo\" type=\"tns:additionalPropertiesType\"/>\n            </sequence>\n         </complexType>\n         <group name=\"TargtetInfoType\">\n            <sequence>\n               <!--target system name to be passed only at logging points, where it is fanning out in the flow to different systems-->\n               <element name=\"targetSystemName\" type=\"string\"/>\n               <!--it accepts either SUCCESS, FAILED  -Required-->\n               <element name=\"targetServiceStatus\" type=\"string\"/>\n               <!--service invocation time  -Required-->\n               <element name=\"targetServiceInvokeTime\" type=\"dateTime\"/>\n               <!--service invocation time  -Optional-->\n               <element minOccurs=\"0\" name=\"targetServiceEndTime\" type=\"dateTime\"/>\n            </sequence>\n         </group>\n         <complexType name=\"additionalPropertiesType\">\n            <sequence>\n               <element name=\"name\" type=\"string\"/>\n               <element name=\"value\" type=\"string\"/>\n            </sequence>\n         </complexType>\n         <simpleType name=\"operationNameType\">\n            <restriction base=\"string\">\n               <enumeration value=\"LOG\"/>\n               <enumeration value=\"NOTIFY\"/>\n               <enumeration value=\"BOTH\"/>\n            </restriction>\n         </simpleType>\n         <simpleType name=\"LogLevelType\">\n            <restriction base=\"string\">\n               <enumeration value=\"INFO\"/>\n               <enumeration value=\"DEBUG\"/>\n               <enumeration value=\"ERROR\"/>\n            </restriction>\n         </simpleType>\n      </schema>\n   </wsdl:types>\n   <wsdl:message name=\"eisLogNotifyRequest\">\n      <wsdl:part element=\"tns:eisLogNotifyRequest\" name=\"eisLogNotifyRequest\"/>\n   </wsdl:message>\n   <wsdl:portType name=\"eisUtilServiceProcess\">\n      <wsdl:operation name=\"eisLogNotify\">\n         <wsdl:input message=\"tns:eisLogNotifyRequest\" name=\"eisLogNotifyRequest\"/>\n      </wsdl:operation>\n   </wsdl:portType>\n   <wsdl:binding name=\"eisUtilServiceProcessSoap11\" type=\"tns:eisUtilServiceProcess\">\n      <soap:binding style=\"document\" transport=\"http://schemas.xmlsoap.org/soap/http\"/>\n      <wsdl:operation name=\"eisLogNotify\">\n         <soap:operation soapAction=\"\"/>\n         <wsdl:input name=\"eisLogNotifyRequest\">\n            <soap:body use=\"literal\"/>\n         </wsdl:input>\n      </wsdl:operation>\n   </wsdl:binding>\n   <wsdl:service name=\"eisUtilServiceProcessService\">\n      <wsdl:port binding=\"tns:eisUtilServiceProcessSoap11\" name=\"eisUtilServiceProcessSoap11\">\n         <soap:address location=\"http://10.240.8.62:7001/eisUtilservice/eisUtilService/\"/>\n      </wsdl:port>\n   </wsdl:service>\n</wsdl:definitions>\n\n</textarea>\n                      \n<h4>REST API Sample Invocation request Object - Notify Operation</h4>\n                      <br>\n                      <textarea rows=\"8\" cols=\"120\" id=\"restSample\"\nstyle=\"resize: none;\" data-role=\"none\" spellcheck=\"false\">\n{\n  \"version1\": {\n    \"appId\": \"BES-RMIP-CoA-RETRIEVE\",\n    \"biogenTransId\": \"232FF-43333BAFD-SAFDAS2-342FDSAF-342-DF232\",\n    \"operation\": \"NOTIFY\",\n    \"notifyRequest\": {\n      \"exceptionCategory\": \"BUSINESS\",\n      \"exceptionType\": \"ERROR\",\n      \"faultedService\": \"RMIP_COA_RetriveService_PS\",\n      \"faultMessage\": \"End point System is down, kindly act on it \",\n      \"errorCode\": \"MW-TEch-2001\",\n      \"errorDesc\": \"End point system is unavailable\",\n      \"notificationTime\": \"2018-08-04T09:55:03.511-04:00\",\n      \"messageCode\": \"Error_Stage\",\n      \"messageDescription\": \"error validation\"\n    }\n  }\n}\n</textarea>\n\n<br>\n\n                      <h4>Direct JMS Invocation Example from SOA services</h4>\n                      \n                      <br>\n                      For all FMW Interfaces, it is recommended to use direct JMS invocations instead of SOAP invocations.\n                      <br>Please refer to below util business service available in DEV1 OSB server for this purposes.                      \n                      <br>\n                      <textarea rows=\"8\" cols=\"120\" id=\"restSample\"\nstyle=\"resize: none;\" data-role=\"none\" spellcheck=\"false\">\n\nUtility Business Service: utility/eisUtilService/BusinessService/EisUtilJMSPublisher_BS.bix\n\nJMS Endpoint: jms://eisutlvmd01.biogen.com:7010/jms.eisServiceConfactory/jms.eisUtilServiceQueue\n\n</textarea>\n\n                      <h3>ETM Environment Information</h3>\n                      Note: Will be included later\n                       \n                    </div>\n                    <div class=\"tab-pane fade\" id=\"tab4default\">\n                      <h3>Recommendations</h3>\n                      <br>\n                      <li class=\"tabClass\">Make use of JMS direct invocations instead of SOAP approach for all SOA/OSB Interfaces. \n                        This way we can avoid additional overhead in the message publishing flow</li>\n                        <br>\n                      <li class=\"tabClass\">Ensure all ETM service invocations are Asynchronous calls</li>                        \n\n                    </div>\n                    <div class=\"tab-pane fade\" id=\"tab5default\">\n                      <h3>Frequently Asked Clarifications</h3>\n                      <li class=\"tabClass\">How to get access for ETM gui application.</li>\n                      <br>\n                      <li class=\"tabClass\">Where can I get details on endpoints of ETM service in different domains</li>\n                      <br>\n                      <li class=\"tabClass\">How do I know as which Business unit the particular Interface, which I am working on belongs to</li>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n      </div>\n    </section>\n    </div>\n   "

/***/ }),

/***/ "./src/app/components/general-instruction/general-instruction.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/components/general-instruction/general-instruction.component.ts ***!
  \*********************************************************************************/
/*! exports provided: GeneralInstructionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneralInstructionComponent", function() { return GeneralInstructionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var GeneralInstructionComponent = /** @class */ (function () {
    function GeneralInstructionComponent() {
    }
    GeneralInstructionComponent.prototype.ngOnInit = function () {
    };
    GeneralInstructionComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-general-instruction',
            template: __webpack_require__(/*! ./general-instruction.component.html */ "./src/app/components/general-instruction/general-instruction.component.html"),
            styles: [__webpack_require__(/*! ./general-instruction.component.css */ "./src/app/components/general-instruction/general-instruction.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], GeneralInstructionComponent);
    return GeneralInstructionComponent;
}());



/***/ }),

/***/ "./src/app/components/header/header.component.css":
/*!********************************************************!*\
  !*** ./src/app/components/header/header.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<header class=\"main-header\">\r\n<div class=\"row\">\r\n  <div class=\"col-sm-12\">\r\n      <nav class=\"navbar navbar-inverse\">\r\n          <div class=\"container-fluid\" style=\"\">   \r\n            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">\r\n              <ul class=\"nav navbar-nav\">      \r\n                <li class=\"logo\">\r\n                    <img src=\"assets/img/etm_logo.png\" alt=\"logo\" height=\"50\">\r\n                  <!-- <a href=\"index.html\" >\r\n                    \r\n                   </a> -->\r\n                </li>\r\n                <!-- <li> <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"push-menu\" role=\"button\">\r\n                    <i class=\"fa fa-right-arrow\"></i>\r\n                  </a></li>     -->\r\n                  <li> \r\n                      <a href=\"#\" id=\"icon\" class=\"icon\" data-toggle=\"push-menu\" role=\"button\">\t&#171;</a>\r\n                      <a href=\"#\" id=\"icon2\" class=\"icon2\" style=\"display:none\" data-toggle=\"push-menu\" role=\"button\">&#187;\r\n                      </a>\r\n                 \r\n                  </li>   \r\n              </ul>\r\n              <ul class=\"nav navbar-nav navbar-right\">      \r\n                <li class=\"welcome\">\r\n                  <!-- <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">  </a> -->\r\n                  <div class=\"row\">\r\n                    <!-- <div class=\"col-sm-3 user\">\r\n                        <i class=\"fa fa-user-circle\" aria-hidden=\"true\"></i>\r\n                    </div> -->\r\n                    <div class=\"col-sm-9\">\r\n                        <span class=\"hidden-xs\">Welcome</span>  \r\n                        <span class=\"hidden-xs\">{{uname}}</span>   \r\n                    </div>\r\n                  </div>\r\n                  \r\n                 </li>\r\n                <li>\r\n                  <button type=\"submit\" id=\"logout\" name=\"logout\" (click)=\"logout()\"class=\"btn btn-default btn-flat logoutTxt\"><i class=\"fa fa-sign-out signOut\" aria-hidden=\"true\"></i><br/>Sign out</button>\r\n              </li>\r\n                <li class=\"logo1\"> \r\n                    <img src=\"assets/img/biogen-logo-refresh-new.svg\" alt=\"logo\" height=\"20\">\r\n                    <!-- <a href=\"javascript:void(0);\" ></a> -->\r\n                  </li>\r\n              </ul>      \r\n            </div>\r\n          </div>\r\n        </nav>\r\n  </div>\r\n</div>\r\n    <!-- Logo -->\r\n  <!-- <a href=\"index.html\" class=\"logo\">\r\n   <img src=\"assets/img/biogen-logo-refresh-new.svg\" alt=\"logo\">\r\n  </a> -->\r\n\r\n  \r\n</header>\r\n"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(_userSessionService, _router) {
        this._userSessionService = _userSessionService;
        this._router = _router;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._userSessionService.getUserNameByUserId().subscribe(function (userData) {
            console.log("HeaderComponent.ts");
            console.log("userData:" + userData);
            if (userData != null) {
                console.log(userData);
                console.log("userData.userId:" + userData.userId);
                console.log("userData.updatedBy:" + userData.updatedBy);
                console.log("userData.userType:" + userData.userType);
                _this._userSessionService.setUserName(userData.userId);
                _this.uname = userData.userId;
                _this._userSessionService.setHostName("https://" + userData.updatedBy + "/eisUtilWeb/login");
                _this._userSessionService.setFileURL("https://" + userData.updatedBy + "/eisUtilWeb");
                _this._userSessionService.setUserType(userData.userType);
                _this._userSessionService.setMsg("logOut");
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    HeaderComponent.prototype.logout = function () {
        var _this = this;
        console.log("logout HeaderComponent.ts");
        this._userSessionService.logout(this.uname).subscribe(function (user) {
            _this._userSessionService.setMsg("logOut");
            _this._router.navigate(['/logout']);
        }),
            function (error) {
                console.log(error);
            };
    };
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/components/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/components/header/header.component.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_1__["UserSessionService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/components/interface-design-model/interface-design-model.component.css":
/*!****************************************************************************************!*\
  !*** ./src/app/components/interface-design-model/interface-design-model.component.css ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/interface-design-model/interface-design-model.component.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/interface-design-model/interface-design-model.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n  <!-- <h2>Modal Example</h2> -->\n  <!-- Button to Open the Modal -->\n  <!-- <button type=\"button\" (click)=\"showModel1()\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#myModal\">\n    Open modal\n  </button> -->\n\n  <!-- The Modal -->\n  <div class=\"modal\" id=\"interfaceDesignModal\">\n    <div id=\"modelResize\" class=\"modal-dialog modalDialogBox\">\n      <div class=\"modal-content\">\n      \n        <!-- Modal Header -->\n        <div class=\"modal-header\">\n          <div class=\"row\">\n              <h4 class=\"modal-title\">Interface Design Diagram</h4>\n          \n          <button type=\"button\" id=\"b1\" class=\"close\" onclick=\"removeSizeClass()\" (click)=\"closeModel()\" data-dismiss=\"modal\">&times;</button>\n          <button type=\"button\" class=\"btn btn-default reduce reduce\" onclick=\"reduce()\" style=\"display:none\"><img src=\"assets/img/reduce.png\" alt=\"Resize\" height=\"15\"/></button>\n          <button type=\"button\" class=\"btn btn-default resize  enlarge\" onclick=\"resize()\"><img src=\"assets/img/enlarge.png\" alt=\"Resize\" height=\"15\"/></button>\n          </div>\n          \n        </div>\n        \n        <!-- Modal body -->\n        <div class=\"modal-body\">\n          <div class=\"content-wrapper\">\n            <section class=\"content\">\n              <div class=\"row\">\n                <div class=\"col-md-12\">\n\n            <div class=\"log_tab\">\n                 <div class=\"row\">\n        \n                  <!-- <img id=\"pfimg\" name=\"pfimg\" class=\"img-responsive smaller\" src=\"http://localhost:8080/eisUtilWeb/file/show/{{appId}}\"/> -->\n\n                  <img id=\"pfimg\" name=\"pfimg\" class=\"img-responsive smaller\" src=\"{{hostName}}/file/show/{{appId}}\"/>\n                  \n                \n                  \n                  \n                 <div class=\"spc_line\"></div>\n            </div>\n      \n      </div>\n    </div>\n  </div>\n"

/***/ }),

/***/ "./src/app/components/interface-design-model/interface-design-model.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/components/interface-design-model/interface-design-model.component.ts ***!
  \***************************************************************************************/
/*! exports provided: InterfaceDesignModelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InterfaceDesignModelComponent", function() { return InterfaceDesignModelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InterfaceDesignModelComponent = /** @class */ (function () {
    function InterfaceDesignModelComponent(_userSessionService) {
        this._userSessionService = _userSessionService;
        this.hostName = this._userSessionService.getFileURL();
    }
    InterfaceDesignModelComponent.prototype.ngOnInit = function () {
        this.hostName = this._userSessionService.getFileURL();
        console.log("**************** " + this.appId);
    };
    InterfaceDesignModelComponent.prototype.closeModel = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('appId'),
        __metadata("design:type", Number)
    ], InterfaceDesignModelComponent.prototype, "appId", void 0);
    InterfaceDesignModelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-interface-design-model',
            template: __webpack_require__(/*! ./interface-design-model.component.html */ "./src/app/components/interface-design-model/interface-design-model.component.html"),
            styles: [__webpack_require__(/*! ./interface-design-model.component.css */ "./src/app/components/interface-design-model/interface-design-model.component.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_1__["UserSessionService"]])
    ], InterfaceDesignModelComponent);
    return InterfaceDesignModelComponent;
}());



/***/ }),

/***/ "./src/app/components/log-details-model/log-details-model.component.css":
/*!******************************************************************************!*\
  !*** ./src/app/components/log-details-model/log-details-model.component.css ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/log-details-model/log-details-model.component.html":
/*!*******************************************************************************!*\
  !*** ./src/app/components/log-details-model/log-details-model.component.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n\n    <!-- The Modal -->\n    <div class=\"modal\" id=\"loggingDetailsModal\">\n      <div id=\"modelLogResize\" class=\"modal-dialog modalDialogBox\">\n        <div class=\"modal-content\">\n  \n          <!-- Modal Header -->\n          <div class=\"modal-header\">\n            <div class=\"row\">\n              <h4 class=\"modal-title\">Logging Detail</h4>\n              <button type=\"button\" id=\"b1\" class=\"close\" (click)=\"closeModel()\" data-dismiss=\"modal\">&times;</button>\n              <button type=\"button\" class=\"btn btn-default reduce reduce\" onclick=\"reduce()\" style=\"display:none\"><img src=\"assets/img/reduce.png\"\n                  alt=\"Resize\" height=\"15\" /></button>\n              <button type=\"button\" class=\"btn btn-default resize  enlarge\" onclick=\"resize()\"><img src=\"assets/img/enlarge.png\"\n                  alt=\"Resize\" height=\"15\" /></button>\n            </div>\n          </div>\n  \n          <!-- Modal body -->\n          <div class=\"modal-body\">\n            <div class=\"content-wrapper\" style=\"padding-top:20px !important\">\n              <section class=\"content\">\n                <div class=\"row\">\n                  <div class=\"col-md-12\">\n  \n                    <div class=\"log_tab loggingTable\">\n                      <div class=\"row\">\n                        <div class=\"bioid\"><b>Bio Transaction Id : <span>{{bioTransId}}</span></b></div>\n                        <table class=\"logmain logdet table-striped\" border=\"1\">\n                          <tr *ngIf=\"bioLogDetailsList?.length > 0\">\n                            <td> <b>Service Name</b></td>\n                            <td> <b>Scope/Stage Name</b></td>\n                            <td><b>Message Description</b> </td>\n                            <td><b> Log Level</b> </td>\n                            <td><b>Service Status</b> </td>\n                            <td><b>Logged Time</b> </td>\n                            <td><b>Payload</b> </td>\n                            <td><b>Download</b> </td>\n                          </tr>\n                          \n                          <tr *ngFor=\"let bioLogDetails of bioLogDetailsList\">\n                            <td>{{bioLogDetails.serviceInvoker}}</td>\n                            <td> {{bioLogDetails.messageCode}}</td>\n                            <td> {{bioLogDetails.messageDesc}}</td>\n                            <td> {{bioLogDetails.logLevel}}</td>\n                            <td>{{bioLogDetails.serviceStatus}}</td>\n                            <td>{{bioLogDetails.serviceStartTime}}</td>\n                            <td> <textarea readonly=\"readonly\" title={{bioLogDetails.payLoad}} rows=\"2\" cols=\"55\" readonly>{{bioLogDetails.payLoad}}</textarea></td>\n                            <input type=\"hidden\"  class=\"form-control\" value={{bioLogDetails.payLoad}} #detailsPayload>\n                            <td>\n\n                                \n                                    <button type=\"button\" class=\"btn btn-primary downloadBtn\" data-toggle=\"modal\" data-target=\"\"\n                                      id=\"downloadPaylod\" name=\"downloadPayload\" (click)=\"downloadPayload(detailsPayload)\"><span\n                                       style=\"color:white\" class=\"glyphicon glyphicon-download-alt\"></span>\n                                      </button>\n                                 \n                            </td>\n                          </tr>\n                        </table>\n                        <!-- <table class=\"logmain logdet table-striped\"> -->\n                        <div *ngFor=\"let targetSystemLogDetails of targetSystemLogDetailsList\">\n                          <table class=\"logmain logdet table-striped\" border=\"1\" *ngIf=targetSystemLogDetails.targetSystemName style=\"margin-bottom:0 !important\">\n                            <tr>\n                              <td><b>Target System</b></td>\n                              <td><b>Status  <span ng-bind=\"index\"></span></b></td>\n                              <td><b>Start Time</b></td>\n                              <td><b>End Time</b></td>\n                            </tr>\n                              <tr *ngIf=targetSystemLogDetails.targetSystemName>\n                              <td>{{targetSystemLogDetails.targetSystemName}} </td>\n                              <td>{{targetSystemLogDetails.targetServiceStatus}} </td>\n                              <td>{{targetSystemLogDetails.targetServiceStartTime}} </td>\n                              <td>{{targetSystemLogDetails.targetServiceEndTime}}</td>\n                            </tr>\n                          </table>\n                          \n                          <table class=\"logmain logdet table-striped\" border=\"1\" *ngIf=targetSystemLogDetails.targetSystemName>\n                            <tr>\n                              <!-- <td> <b>Target System Details</b></td> -->\n                              <td> <b>Service Name</b></td>\n                              <td> <b>Scope/Stage Name</b></td>\n                              <td><b>Message Description</b> </td>\n                              <td><b> Log Level</b> </td>\n                              <td><b>Service Status</b> </td>\n                              <td><b>Logged Time</b> </td>\n                              <!-- <td><b>Key</b> </td>\n                             <td><b>value</b> </td> -->\n                              <td><b>Payload</b> </td>\n                              <td><b>Download</b> </td>\n                            </tr>\n            <tr *ngFor=\"let logDetails of targetSystemLogDetails.logDetailsList\">\n                            <td>{{logDetails.serviceInvoker}}</td>\n                            <td> {{logDetails.messageCode}}</td>\n                            <td> {{logDetails.messageDesc}}</td>\n                            <td>{{logDetails.logLevel}}</td>\n                            <td> {{logDetails.serviceStatus}}</td>\n                            <td>{{logDetails.serviceStartTime}}</td>\n                            <!-- <td>{{targetSystemLogDetails.key}}</td>\n                        <td>{{targetSystemLogDetails.value}}</td> -->\n                            <td> <textarea readonly=\"readonly\" title={{logDetails.payLoad}} rows=\"2\" cols=\"55\"\n                                readonly>{{logDetails.payLoad}}</textarea></td>\n                                <input type=\"hidden\"  class=\"form-control\" value={{logDetails.payLoad}} #targetDetailsPayload>\n                                <td>\n    \n                                  \n                                        <button type=\"button\" class=\"btn btn-primary downloadBtn\" data-toggle=\"modal\" data-target=\"\"\n                                          id=\"downloadPaylod\" name=\"downloadPayload\" (click)=\"downloadPayload(targetDetailsPayload)\"><span\n                                          style=\"color:white\" class=\"glyphicon glyphicon-download-alt\"></span>\n                                          </button>\n\n                                </td>\n\n                        </tr>\n  \n                        </table>\n                      </div>\n                        <!-- </table> -->\n                        <div class=\"spc_line\"></div>\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </section>\n            </div>\n          </div>\n        </div>\n        </div>\n          </div>"

/***/ }),

/***/ "./src/app/components/log-details-model/log-details-model.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/components/log-details-model/log-details-model.component.ts ***!
  \*****************************************************************************/
/*! exports provided: LogDetailsModelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogDetailsModelComponent", function() { return LogDetailsModelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! file-saver */ "./node_modules/file-saver/dist/FileSaver.min.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var LogDetailsModelComponent = /** @class */ (function () {
    function LogDetailsModelComponent() {
    }
    LogDetailsModelComponent.prototype.ngOnInit = function () {
        console.log("LogDetailsModelComponent ngOnInit():");
    };
    LogDetailsModelComponent.prototype.downloadPayload = function (data) {
        console.log("data direct:" + data.value);
        var blob = new Blob([data.value], { type: "text/plain;charset=utf-8" });
        file_saver__WEBPACK_IMPORTED_MODULE_1___default.a.saveAs(blob, "payload.xml");
    };
    /* hideModel()
    {
      document.getElementById('myModal').style.display = "none";
    } */
    LogDetailsModelComponent.prototype.closeModel = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('bioTransId'),
        __metadata("design:type", String)
    ], LogDetailsModelComponent.prototype, "bioTransId", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('bioLogDetailsList'),
        __metadata("design:type", Array)
    ], LogDetailsModelComponent.prototype, "bioLogDetailsList", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('targetSystemLogDetailsList'),
        __metadata("design:type", Array)
    ], LogDetailsModelComponent.prototype, "targetSystemLogDetailsList", void 0);
    LogDetailsModelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-log-details-model',
            template: __webpack_require__(/*! ./log-details-model.component.html */ "./src/app/components/log-details-model/log-details-model.component.html"),
            styles: [__webpack_require__(/*! ./log-details-model.component.css */ "./src/app/components/log-details-model/log-details-model.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], LogDetailsModelComponent);
    return LogDetailsModelComponent;
}());



/***/ }),

/***/ "./src/app/components/logging/logging.component.css":
/*!**********************************************************!*\
  !*** ./src/app/components/logging/logging.component.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/logging/logging.component.html":
/*!***********************************************************!*\
  !*** ./src/app/components/logging/logging.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper dashboard\">\r\n  <ol class=\"breadcrumb\">\r\n     <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\r\n    \r\n    <!-- <li class=\"breadcrumb-item\"><a  [routerLink]=\"['']\">Home</a></li> -->\r\n    <li class=\"breadcrumb-item\">Logging</li>\r\n  </ol>\r\n  <section class=\"content logging\">\r\n    <div class=\"row\">\r\n      <form #buSearchForm=\"ngForm\" (ngSubmit)=\"buSearch(buSearchForm.value)\" class=\"form-horizontal\" role=\"form\">\r\n        <div class=\"loggingSearchingBox\">\r\n          <div class=\"fieldBox\">\r\n            <select class=\"form-control\" id=\"buint\" name=\"buint\" (change)=\"onBUChange($event.target.value)\"  [(ngModel)]='defBU' [value]='defBU' ngModel>\r\n              <option *ngFor=\"let bunit of bunitList\" value={{bunit.id}}>{{bunit.name}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"fieldBox\">\r\n            <select class=\"form-control\" id=\"buAppName\" name=\"buAppName\"  [(ngModel)]='defBUAppName' [value]='defBUAppName' \r\n              (change)=\"onBUAppNameChange($event.target.value)\" ngModel>\r\n              <option *ngFor=\"let buAppName of buAppNameList\" value={{buAppName.id}}>{{buAppName.name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"fieldBox\">\r\n            <select class=\"form-control\" id=\"entity\" name=\"entity\"  [(ngModel)]='defBUEntity' (change)=\"onEntityChange($event.target.value)\"\r\n              ngModel>\r\n              <option *ngFor=\"let entity of entityList\" value={{entity.id}}>{{entity.name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"fieldBox\">\r\n            <select class=\"form-control\" id=\"es\" name=\"es\" [(ngModel)]='defBUes' ngModel>\r\n              <option *ngFor=\"let es of esList\" value={{es.id}}>{{es.name}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"fieldBox\" > <!--style=\"width:30px !important\" -->\r\n            <select class=\"form-control \" id=\"duration\" name=\"duration\" [(ngModel)]=\"defDuration\" ngModel>\r\n              <option value='0' disabled>Days</option>\r\n              <option value='1'>today</option>\r\n            <option value='7'>7 days</option>\r\n            <option value='15'>15 days</option>\r\n            <option value='30'>30 days</option>\r\n            <option value='60'>60 days</option>\r\n            <option value='90'>90 days</option>\r\n          </select>\r\n        </div>\r\n          \r\n          <div class=\"searchBtnBox\">\r\n            <button type=\"submit\" id=\"logSearchBtn\" class=\"btn btn-primary\" name=\"logSearchBtn\">Search &nbsp;<i\r\n                class=\"fa fa-search\" aria-hidden=\"true\"></i></button>\r\n          </div>\r\n        </div>\r\n      </form> \r\n    </div>\r\n    <div class=\"col-sm-12\" style=\"padding-right:0 !important\">\r\n        <a id=\"p1\" class=\"pull-right\" onclick=\"showBox()\">Show Advance Search</a>\r\n        <a id=\"p2\" class=\"pull-right\" onclick=\"hideBox()\" style=\"display:none\">Hide Advance Search</a>\r\n      </div>\r\n    <div class=\"clearfix\"></div>\r\n      <div class=\"row\">\r\n    <form #logSearchForm=\"ngForm\" (ngSubmit)=\"logSearch(logSearchForm.value)\" class=\"form-horizontal\" role=\"form\">\r\n      <div class=\"loggingAdvSearchingBox\" id=\"advanceSearch\" style=\"display:none\">\r\n        <div class=\"header\">\r\n          <span class=\"advText\">Advance Search</span>\r\n          <button type=\"submit\" id=\"logSearchBtn\" name=\"logSearchBtn\" class=\"refreshBtn  pull-right\"><i\r\n              class=\"fa fa-refresh \" aria-hidden=\"true\"></i></button>\r\n        </div>\r\n        <div class=\"clearfix\"></div>\r\n        <div class=\"advContent\">\r\n          <div class=\"lineRow\">\r\n              <div class=\"fieldBox\">\r\n                   <input type=\"text\" class=\"form-control \" id=\"biogenTransId\" name=\"biogenTransId\" placeholder=\"Biogen Transaction ID\" ngModel>\r\n              </div>\r\n              <div class=\"orBox\"><span>or</span></div>\r\n            <div class=\"fieldBox\">               \r\n              <select class=\"form-control \" id=\"appGroup\" name=\"appGroup\"\r\n                (change)=\"onAppGroupChange($event.target.value)\" ngModel>\r\n                <option value=\"\" selected>Interface Group</option>\r\n                <option *ngFor=\"let appGroup of appGroupList\" value={{appGroup.appGroup}}>\r\n                  {{appGroup.appGroup}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n            <div class=\"fieldBox\">\r\n              <select class=\"form-control \" id=\"appName\" name=\"appName\" (change)=\"onChange($event.target.value)\"\r\n                ngModel>\r\n                <option value=\"\" selected>Interface Name</option>\r\n                <option *ngFor=\"let appName of appNameList\" value={{appName.appName}}>{{appName.appName}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n            <!-- <div class=\"fieldBox\">\r\n              <select class=\"form-control \" id=\"period\" name=\"period\" ngModel>\r\n                <option value=\"\" selected>Period</option>\r\n                <option value=\"5\">5 days</option>\r\n                <option value=\"7\">7 days</option>\r\n                <option value=\"15\">15 days</option>\r\n                <option value=\"20\">20 days</option>\r\n                <option value=\"30\">30 days</option>\r\n                <option value=\"50\">50 days</option>\r\n              </select>\r\n            </div> -->\r\n            <!-- <div class=\"fieldBox datepick\">\r\n             <input class=\"unstyled\" type=\"datetime-local\" id=\"startDate\" name=\"startDate\" width=\"175\" placeholder=\"yyyy-MM-ddTHH:mm:ss\"\r\n                ngModel>\r\n            </div>\r\n            <div class=\"fieldBox datepick\">\r\n              <input class=\"unstyled\" type=\"datetime-local\" id=\"endDate\" name=\"endDate\" width=\"175\"\r\n                ngModel>\r\n            </div> -->\r\n\r\n            <div class=\"fieldBox  datepick\">\r\n              <input [owlDateTime]=\"dt1\" id=\"startDate\" [max]=\"maxDate\" name=\"startDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt1\" placeholder=\"Start Date Time\" ngModel>\r\n              <owl-date-time #dt1></owl-date-time>\r\n          </div>\r\n          <div class=\"fieldBox  datepick\">\r\n            <input [owlDateTime]=\"dt2\" id=\"endDate\" [max]=\"maxDate\" name=\"endDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt2\" placeholder=\"End Date Time\" ngModel>\r\n            <owl-date-time #dt2></owl-date-time>\r\n        </div>\r\n\r\n            <div class=\"fieldBox\">\r\n              <!--<select multiple class=\"form-control \" id=\"status\" name=\"status\" ngModel>\r\n                <option value=\"\" selected>Status</option>\r\n                <option *ngFor=\"let status of statusList\" value={{status}}>{{status}}</option>\r\n              </select>-->\r\n              <ng-multiselect-dropdown\r\n              class=\".ng-multiselect-dropdown .dropdown-menu\"\r\n              id =\"status\"\r\n              name=\"status\"\r\n              [placeholder]=\"'Select Status'\"\r\n              [data]=\"statusList\"\r\n              [(ngModel)]=\"status\" \r\n              [settings]=\"dropdownSettings\"\r\n              (onSelect)=\"onItemSelect($event)\">\r\n          </ng-multiselect-dropdown>\r\n            </div>\r\n            <div class=\"searchBtnBox\">\r\n              <button type=\"submit\" id=\"logSearchBtn\" class=\"btn btn-primary\" name=\"logSearchBtn\"><i\r\n                  class=\"fa fa-search\" style=\"margin-left: -3px;\" aria-hidden=\"true\"></i></button>\r\n            </div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n          <div class=\"lineRow\">\r\n            <div *ngIf=\"keyFlag\">\r\n            <div class=\"fieldBox\">\r\n                <select class=\"form-control \" id=\"key\" name=\"key\" ngModel>\r\n                    <option value=\"\" selected>Key</option>\r\n                    <option *ngFor=\"let key of keyList\" value={{key}}>{{key}}</option>\r\n                  </select>\r\n            </div>\r\n            \r\n            <div class=\"fieldBox\">\r\n              <select class=\"form-control \" id=\"condition\" name=\"condition\" ngModel>\r\n                <option value=\"\" selected>Condition</option>\r\n                <option *ngFor=\"let condition of conditionList\" value={{condition}}>{{condition}}</option>\r\n              </select>\r\n          </div>\r\n            <div class=\"fieldBox\">\r\n                <input type=\"text\" class=\"form-control \" id=\"value\" name=\"value\" placeholder=\"Value\" ngModel>\r\n            </div>\r\n          </div>\r\n            <div class=\"quickBtn pull-right\" *ngIf=\"keyBtnFlag\">\r\n              <input id=\"add_key\" class=\"btn btn-primary\" type=\"button\" value={{buttonName}} (click)=\"showKey()\">\r\n            </div>\r\n          </div>\r\n          <div class=\"clearfix\"></div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n    </form>\r\n  </div>\r\n  <div class=\"clearfix\"></div>\r\n    <div class=\"row\">\r\n\r\n\r\n      <div class=\"table_color3\">\r\n          <div class=\"container-fluid\">\r\n            <ag-grid-angular style=\"height: 530px;\" class=\"col8-Grid ag-theme-balham\" [rowData]=\"rowData\"\r\n              [columnDefs]=\"columnDefs\" [enableSorting]=\"true\" [enableFilter]=\"true\" [rowHeight]=\"30\" \r\n              [suppressRowClickSelection]=\"true\" [debug]=\"true\" [enableColResize]=\"true\" [enableRangeSelection]=\"true\"\r\n              [paginationAutoPageSize]=\"false\" [pagination]=\"true\" [paginationPageSize]=15\r\n              [overlayLoadingTemplate]=\"overlayLoadingTemplate\" (gridReady)=\"onGridReady($event)\"\r\n              (cellClicked)=\"onCellClicked($event)\" (rowClicked)=\"onRowClicked($event)\">\r\n            </ag-grid-angular>\r\n\r\n            <div class=\"app_btn\">\r\n              <button type=\"button\" class=\"btn btn-primary downloadBtn\" data-toggle=\"modal\" data-target=\"\"\r\n                id=\"exportData\" name=\"exportData\" (click)=\"exportData()\"><span\r\n                  class=\"glyphicon glyphicon-download-alt\"></span>\r\n                Download</button>\r\n            </div>\r\n          </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n  <div id=\"targetSystemStatus\" class=\"modal fade createInterface \" role=\"dialog\">\r\n      <div class=\"modal-dialog\" style=\"width:550px !important\">\r\n        <!-- Modal content-->\r\n        <div class=\"modal-content\">\r\n          <div class=\"modal-header\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n            <span class=\"modal-title\">Providers System Status</span>\r\n          </div>\r\n          <div class=\"modal-body\">\r\n  \r\n              <div *ngFor=\"let targetSystemLogDetails of targetSystemLogDetailsList\">\r\n                  <table class=\"logmain logdet table-striped\" border=\"1\" *ngIf=targetSystemLogDetails.targetSystemName style=\"margin-bottom:0 !important\">\r\n                    <tr>\r\n                      <td><b>Provider System</b></td>\r\n                      <td><b>Status<span ng-bind=\"index\"></span></b></td>\r\n                      <td><b>Start Time</b></td>\r\n                      <td><b>End Time</b></td>\r\n                    </tr>\r\n                      <tr *ngIf=targetSystemLogDetails.targetSystemName>\r\n                      <td>{{targetSystemLogDetails.targetSystemName}} </td>\r\n                      <td>{{targetSystemLogDetails.targetServiceStatus}} </td>\r\n                      <td>{{targetSystemLogDetails.targetServiceStartTime}} </td>\r\n                      <td>{{targetSystemLogDetails.targetServiceEndTime}}</td>\r\n                    </tr>\r\n                  </table>\r\n              </div>\r\n            <div class=\"clearfix\"></div>\r\n          </div>\r\n          <!-- <div class=\"modal-footer\">\r\n              <button type=\"submit\" id=\"integrationPatternSave\" name=\"integrationPatternSave\" class=\"close\">Close</button>\r\n          </div> -->\r\n        </div>\r\n      </div>\r\n    </div>\r\n</div>\r\n<app-log-details-model [bioTransId]=bioTransId [bioLogDetailsList]=bioLogDetailsList\r\n  [targetSystemLogDetailsList]=targetSystemLogDetailsList></app-log-details-model>\r\n  \r\n  \r\n\r\n  "

/***/ }),

/***/ "./src/app/components/logging/logging.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/components/logging/logging.component.ts ***!
  \*********************************************************/
/*! exports provided: LoggingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoggingComponent", function() { return LoggingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_bio_log_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/bio-log.service */ "./src/app/service/bio-log.service.ts");
/* harmony import */ var _service_application_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/application.service */ "./src/app/service/application.service.ts");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _dao_bio_log_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../dao/bio-log-search */ "./src/app/dao/bio-log-search.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _dao_busearch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dao/busearch */ "./src/app/dao/busearch.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










//import { SideBarComponent } from '../side-bar/side-bar.component';

//declare var  $:any;
var LoggingComponent = /** @class */ (function () {
    //private  sideBarComponent:SideBarComponent;
    function LoggingComponent(_userSessionService, spinnerService, _bioLogService, _applicationService, _businessUnitService, _router, _datePipe, route) {
        this._userSessionService = _userSessionService;
        this.spinnerService = spinnerService;
        this._bioLogService = _bioLogService;
        this._applicationService = _applicationService;
        this._businessUnitService = _businessUnitService;
        this._router = _router;
        this._datePipe = _datePipe;
        this.route = route;
        this.rowData = [];
        this.columnDefs = [];
        this.statusList = [];
        this.keyList = [];
        this.conditionList = ["is", "is not", "contains", "does not contain", "begins with", "ends with", "in between"];
        this.bunitList = [];
        this.buAppNameList = [];
        this.entityList = [];
        this.esList = [];
        this.duration = 1;
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.bioLogSearch = new _dao_bio_log_search__WEBPACK_IMPORTED_MODULE_4__["BioLogSearch"]();
        this.title = 'Logging Search';
        this.keyFlag = false;
        this.keyBtnFlag = false;
        this.buttonName = 'Quick Search';
        this.dropdownSettings = {};
        this.showFilter = false;
        this.status = "";
        this.busearch = null;
        this.maxDate = new Date();
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
        this.defDuration = 1;
        this.limitSelection = false;
        this.dashBoardEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    LoggingComponent.prototype.setDefaultValue = function (name) {
        if (name == "Application") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
        }
        if (name == "Entity") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
        }
        if (name == "Enterprise Service") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
        if (name == "ALL") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_9__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
    };
    LoggingComponent.prototype.setDefaultValues = function () {
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
        this.defDuration = 1;
    };
    LoggingComponent.prototype.toogleShowFilter = function () {
        this.showFilter = !this.showFilter;
        this.dropdownSettings = Object.assign({}, this.dropdownSettings, { allowSearchFilter: this.showFilter });
    };
    LoggingComponent.prototype.handleLimitSelection = function () {
        if (this.limitSelection) {
            this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
        }
        else {
            this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
        }
    };
    LoggingComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.spinnerService.show();
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'status',
            textField: 'status',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            allowSearchFilter: this.showFilter,
            itemsShowLimit: 2
        };
        this.columnDefs = [
            { headerName: 'Bio Trans Id', field: 'bioTransId', width: 0, hide: true },
            { headerName: 'App Group', field: 'appGroup', width: 100 },
            { headerName: 'Interface Name', field: 'appName', width: 140, editable: true },
            { headerName: 'Business Keys', field: 'message', width: 170, editable: true },
            { headerName: 'Service Invoker', field: 'serviceInvoker', width: 150, editable: true },
            { headerName: 'Duration', field: 'duration', width: 150, editable: true },
            { headerName: 'Status', field: 'serviceInvokerStatus', width: 120,
                cellRenderer: function (params) {
                    var status = params.data.serviceInvokerStatus;
                    /* if (params.data.serviceInvokerStatus !="MULTI") {
                         var html = ""+status;
                     } else {
                       var html = '<a  data-toggle="modal" data-target="#targetSystemStatus" href="#">click</a>';
                     }*/
                    var html = '<a data-toggle="modal" data-target="#loggingDetailsModal" href="#">' + status + '</a>';
                    return html;
                }
            },
            { headerName: 'Start Time', field: 'startTime', width: 170 },
            { headerName: 'End Time', field: 'endTime', width: 170 },
            /*{headerName: 'View', field: '', width:80,
              template:
              '<a data-toggle="modal" data-target="#myModal" href="#"><i class="fa fa-eye" aria-hidden="true"></i></a>'
            },*/
            { headerName: 'Notification', field: '', width: 80,
                cellRenderer: function (params) {
                    if (params.data.notificationSize > 0) {
                        var html = '<a><i class="fa fa-envelope-open" aria-hidden="true"></i></a>';
                    }
                    else {
                        var html = "";
                    }
                    return html;
                }
                // template:
                // '<a><i class="fa fa-bell" aria-hidden="true"></i></a>'
            }
        ];
        this.overlayLoadingTemplate =
            '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
        console.log("Logging*****BioTransId******* " + this._applicationService.getBiogenTransId());
        if (this._applicationService.getBiogenTransId() != null && this._applicationService.getBiogenTransId().trim() != "") {
            this.bioLogSearch.bioTransId = this._applicationService.getBiogenTransId();
            this._bioLogService.getAdvancedSearchLogDetails(this.bioLogSearch).subscribe(function (bioLog) {
                _this._applicationService.setBiogenTransId("");
                //debugger;
                //console.log(bioLog);
                _this.rowData = bioLog;
                _this.spinnerService.hide();
            }, function () { return _this.spinnerService.hide(); }), function (error) {
                console.log(error);
            };
        }
        else {
            this._bioLogService.getLogDetails().subscribe(function (bioLog) {
                //debugger;
                //console.log(bioLog);
                _this.rowData = bioLog;
                _this.spinnerService.hide();
            }, function () { return _this.spinnerService.hide(); }), function (error) {
                console.log(error);
            };
        }
        this._applicationService.getAppGroupList().subscribe(function (appGroupListValues) {
            //  console.log("appGroupListValues : "+appGroupListValues);
            _this.appGroupList = appGroupListValues;
        }), function (error) {
            console.log(error);
        };
        this._applicationService.getServiceInvokerStatusList().subscribe(function (serviceInvokerStatusListValues) {
            //console.log("serviceInvokerStatusListValues : "+serviceInvokerStatusListValues);
            _this.statusList = serviceInvokerStatusListValues;
        }), function (error) {
            console.log(error);
        };
        this._businessUnitService.getBUnit().subscribe(function (bunitListValues) {
            //console.log("bunitListValues : "+bunitListValues);
            _this.bunitList = bunitListValues;
            _this.setDefaultValue("ALL");
        }), function (error) {
            console.log(error);
        };
    };
    LoggingComponent.prototype.onGridReady = function (params) {
        this.gridApi = params.api;
        // this.gridApi.showLoadingOverlay();
    };
    LoggingComponent.prototype.onCellClicked = function (event) {
        console.log("onCellClicked " + event.colDef.headerName);
        if (event.colDef.headerName == "View") {
            this.status = "View";
        }
        else if (event.colDef.headerName == "View Tab") {
            this.status = "View Tab";
        }
        if (event.colDef.headerName == "Status") {
            this.status = "Status";
        }
        else if (event.colDef.headerName == "Status Tab") {
            this.status = "Status Tab";
        }
        if (event.colDef.headerName == "Notification") {
            this.status = "Notification";
        }
    };
    LoggingComponent.prototype.onRowClicked = function (event) {
        var _this = this;
        console.log("onRowClicked === " + event.data.bioTransId);
        if (this.status == "View Tab") {
            console.log('View', event.data.bioTransId);
            this._router.navigate(['/dbtemp', { BioTransId: event.data.bioTransId }]).then(function (nav) {
                console.log("==11= " + nav);
                _this._router.navigate(['/dashboard', { BioTransId: event.data.bioTransId }]);
            }, function (err) {
                console.log("====44==" + err);
            });
            this.status = "";
        }
        if (this.status == "Status Tab") {
            console.log('status', event.data.bioTransId);
            this._router.navigate(['/dbtemp', { BioTransId: event.data.bioTransId }]).then(function (nav) {
                console.log("==11= " + nav);
                _this._router.navigate(['/dashboard', { BioTransId: event.data.bioTransId }]);
            }, function (err) {
                console.log("====44==" + err);
            });
            this.status = "";
        }
        if (this.status == "Notification") {
            console.log('logging', event.data.bioTransId);
            this.bioTransId = event.data.bioTransId;
            this._applicationService.setBiogenTransId(this.bioTransId);
            //      this._router.navigate(['/notification', { BioTransId: event.data.bioTransId } ]);
            this._router.navigate(['/dbtemp', { notificationSearchFlag: "true" }]).then(function (nav) {
                console.log("==notification= " + nav);
            }, function (err) {
                console.log("====44==" + err);
            });
            this.status = "";
        }
        if (this.status == "View") {
            console.log('View', event.data.bioTransId);
            this.bioTransId = event.data.bioTransId;
            this._bioLogService.getDetailedLogDetails(this.bioTransId).subscribe(function (bioLogDetails) {
                //debugger;
                console.log("************* " + bioLogDetails.length);
                //this.bioLogDetailsList = bioLogDetails;
                _this.bioLogDetailsTemp = bioLogDetails;
                _this.bioLogDetailsList = _this.bioLogDetailsTemp.bioLogDetailsList;
                _this.targetSystemLogDetailsList = _this.bioLogDetailsTemp.targetSystemLogDetailsList;
            }), function (error) {
                console.log(error);
            };
            this.status = "";
        }
        if (this.status == "Status") {
            console.log('View', event.data.bioTransId);
            this.bioTransId = event.data.bioTransId;
            this._bioLogService.getDetailedLogDetails(this.bioTransId).subscribe(function (bioLogDetails) {
                //debugger;
                console.log("************* " + bioLogDetails.length);
                //this.bioLogDetailsList = bioLogDetails;
                _this.bioLogDetailsTemp = bioLogDetails;
                _this.bioLogDetailsList = _this.bioLogDetailsTemp.bioLogDetailsList;
                _this.targetSystemLogDetailsList = _this.bioLogDetailsTemp.targetSystemLogDetailsList;
            }), function (error) {
                console.log(error);
            };
            this.status = "";
        }
    };
    LoggingComponent.prototype.exportData = function () {
        var params = {
            fileName: "LoggingSearch_" + this._datePipe.transform(new Date(), "yyyyMMddhhmmss") + ".csv",
            columnKeys: ['appGroup', 'appName', 'message', 'serviceInvoker', 'serviceInvokerStatus', 'startTime', 'endTime']
        };
        this.gridApi.exportDataAsCsv(params);
    };
    LoggingComponent.prototype.logSearch = function (data) {
        var _this = this;
        this.spinnerService.show();
        //debugger;
        /*    console.log("appGroup "+data.appGroup);
            console.log("appName "+data.appName);
            console.log("status "+data.status);
            console.log("key "+data.key);
            console.log("value "+data.value);
            console.log("value "+data.period);
            console.log("startDate "+data.startDate);
            console.log("endDate "+data.endDate);
            console.log("biogenTransId:"+data.biogenTransId); */
        var startDate = document.getElementById('startDate').value;
        console.log("document startDate:" + startDate);
        var predate = new Date();
        var date = predate.getDate();
        var month = predate.getMonth() + 1;
        var year = predate.getFullYear();
        var monthStr = "";
        var dateStr = "";
        if (month < 10) {
            monthStr = "0" + month;
        }
        if (date < 10) {
            dateStr = "0" + date;
        }
        else {
            dateStr = "" + date;
        }
        console.log("preddate:" + predate);
        var current_date = year + '-' + monthStr + '-' + dateStr;
        console.log("current_date:" + current_date);
        if (data.startDate != "") {
            /* if(data.startDate > current_date){
               alert("Future date not allowed");
               return;
             }*/
        }
        if (data.endDate != "") {
            if (data.endDate > current_date) {
                alert("Future date not allowed");
                return;
            }
        }
        if (data.startDate != "" && data.endDate != "") {
            if (data.startDate > data.endDate) {
                alert("Start date later than End Date selected");
                return;
            }
        }
        this.bioLogSearch.appGroup = data.appGroup;
        this.bioLogSearch.appName = data.appName;
        this.bioLogSearch.status = data.status;
        this.bioLogSearch.key = data.key;
        this.bioLogSearch.value = data.value;
        this.bioLogSearch.period = data.period;
        this.bioLogSearch.startDate = data.startDate;
        this.bioLogSearch.endDate = data.endDate;
        this.bioLogSearch.bioTransId = data.biogenTransId;
        this.bioLogSearch.duration = data.duration;
        this.bioLogSearch.condition = data.condition;
        if (data.status.length == 0) {
            this.bioLogSearch.status = [];
            console.log("data status is intialized");
        }
        this._bioLogService.getAdvancedSearchLogDetails(this.bioLogSearch).subscribe(function (bioLog) {
            //debugger;
            console.log(bioLog);
            _this.rowData = bioLog;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    LoggingComponent.prototype.onItemSelect = function (item) {
        console.log('onItemSelect', item);
        this.bioLogSearch.status = item;
    };
    LoggingComponent.prototype.onSelectAll = function (items) {
        console.log('onSelectAll', items);
        this.bioLogSearch.status = items;
    };
    LoggingComponent.prototype.showKey = function () {
        this.keyFlag = !this.keyFlag;
        if (this.keyFlag)
            this.buttonName = "Remove";
        else
            this.buttonName = "Quick Search";
    };
    LoggingComponent.prototype.onChange = function (appName) {
        var _this = this;
        if (appName != "") {
            this._bioLogService.getKeyListByAppName(appName).subscribe(function (keyListValues) {
                //      console.log("keyListValues : "+keyListValues);
                _this.keyList = keyListValues;
            }), function (error) {
                console.log(error);
            };
            this.keyBtnFlag = true;
        }
        else {
            this.keyList.length = 0;
        }
    };
    LoggingComponent.prototype.onAppGroupChange = function (appGroupName) {
        var _this = this;
        this._applicationService.getAppNameByAppGroupId(appGroupName).subscribe(function (appNameListValues) {
            //    console.log(appNameListValues);
            _this.appNameList = appNameListValues;
        }), function (error) {
            console.log(error);
        };
    };
    LoggingComponent.prototype.onBUChange = function (bunit) {
        var _this = this;
        console.log("bunit:" + bunit);
        this.buAppNameList = [];
        this.entityList = [];
        this.esList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.setDefaultValues();
        this.setDefaultValue("Entity");
        this.setDefaultValue("Enterprise Service");
        console.log("this.defBUAPPname:" + this.defBUAppName);
        if (bunit != null && bunit != 0) {
            this.bunitTemp = bunit;
            this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
                _this.buAppNameList = buAppNameListValues;
            }), function (error) {
                console.log(error);
            };
        }
    };
    LoggingComponent.prototype.onBUAppNameChange = function (buAppName) {
        var _this = this;
        this.entityList = [];
        this.esList = [];
        this.buAppNameTemp = "";
        this.entitytemp = "";
        // this.buAppNameTemp = buAppName;
        this.setDefaultValues();
        console.log("this.defBUAppName:" + this.defBUAppName);
        if (buAppName != "" && buAppName != "0") {
            // console.log("inside On bu appnamechange if:"+buAppName);
            this.buAppNameTemp = buAppName;
            this._businessUnitService.getEntityNameByApplicationId(buAppName).subscribe(function (entityListValues) {
                _this.entityList = entityListValues;
                _this.setDefaultValue("Enterprise Service");
            }), function (error) {
                console.log(error);
            };
        }
        else {
            //console.log("inside On bu appnamechange else:")
            this.setDefaultValue("Entity");
            this.setDefaultValue("Enterprise Service");
        }
    };
    LoggingComponent.prototype.onEntityChange = function (entity) {
        var _this = this;
        this.esList = [];
        this.entitytemp = "";
        this.setDefaultValues();
        if (entity != "" && entity != "0") {
            this.entitytemp = entity;
            this._businessUnitService.getESNameByEntityId(entity).subscribe(function (esListValues) {
                _this.esList = esListValues;
            }), function (error) {
                console.log(error);
            };
        }
        else {
            this.setDefaultValue("Enterprise Service");
        }
    };
    LoggingComponent.prototype.buSearch = function (data) {
        var _this = this;
        //debugger;
        this.spinnerService.show();
        var bunit = document.getElementById('buint').value;
        var buAppName = document.getElementById('buAppName').value;
        var entity = document.getElementById('entity').value;
        var es = document.getElementById('es').value;
        var duration = document.getElementById('duration').value;
        /*      console.log("let businessUnit "+bunit);
              console.log("let applicationName "+buAppName);
               console.log("let entityName "+entity);
              console.log("let entServiceName "+es);
        */
        /*if(data.buint == "" && data.buAppName == "" && data.entity == "" && data.es == "")
        {
          alert("Please select business unit");
          return;
        }*/
        this.busearch = new _dao_busearch__WEBPACK_IMPORTED_MODULE_6__["BUSearch"]();
        console.log(duration);
        if (duration != "" && duration != "0") {
            this.busearch.duration = duration;
        }
        else {
            this.busearch.duration = 1;
        }
        if (bunit != "" && bunit != "0") {
            this.busearch.businessUnit = bunit;
            if (buAppName != "" && buAppName != "0") {
                this.busearch.applicationName = buAppName;
                if (entity != "" && entity != "0") {
                    this.busearch.entityName = entity;
                    if (es != "" && es != "0") {
                        this.busearch.entServiceName = es;
                    }
                }
            }
        }
        this._bioLogService.getBUSearchLogDetails(this.busearch).subscribe(function (bioLog) {
            //debugger;
            console.log(_this.busearch.duration);
            console.log(bioLog);
            _this.rowData = bioLog;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], LoggingComponent.prototype, "dashBoardEvent", void 0);
    LoggingComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-logging',
            template: __webpack_require__(/*! ./logging.component.html */ "./src/app/components/logging/logging.component.html"),
            styles: [__webpack_require__(/*! ./logging.component.css */ "./src/app/components/logging/logging.component.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_10__["UserSessionService"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_8__["Ng4LoadingSpinnerService"], _service_bio_log_service__WEBPACK_IMPORTED_MODULE_1__["BioLogService"], _service_application_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationService"], _service_business_unit_service__WEBPACK_IMPORTED_MODULE_3__["BusinessUnitService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]])
    ], LoggingComponent);
    return LoggingComponent;
}());



/***/ }),

/***/ "./src/app/components/logout/logout.component.css":
/*!********************************************************!*\
  !*** ./src/app/components/logout/logout.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/logout/logout.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/logout/logout.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js\"></script>\n<div class=\"container-fluid loginBg\">\n    <header class=\"main-header\" >\n        <div class=\"row\" >\n\n          <div class=\"col-sm-12\" >\n              <nav class=\"navbar navbar-inverse\">\n                  <div class=\"container-fluid \" >   \n                    <div class=\"collapse navbar-collapse\" id=\"myNavbar\">\n                      <ul class=\"nav navbar-nav\">      \n                        <li class=\"logo\">\n                            <img src=\"assets/img/etm_logo.png\" alt=\"logo\" height=\"50\" style=\"float:right; margin-top:10px !important;  margin-left: -30px !important\">\n                          \n                        </li>\n                        <!-- <li> <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"push-menu\" role=\"button\">\n                            <i class=\"fa fa-right-arrow\"></i>\n                          </a></li>     -->\n                          <!-- <li> \n                              <a href=\"#\" id=\"icon\" class=\"icon\" data-toggle=\"push-menu\" role=\"button\">\t&#171;</a>\n                              <a href=\"#\" id=\"icon2\" class=\"icon2\" style=\"display:none\" data-toggle=\"push-menu\" role=\"button\">&#187;\n                              </a>\n                         \n                          </li>    -->\n                      </ul>\n                      <ul class=\"nav navbar-nav navbar-right\">      \n                       \n                        <li > \n                            <img src=\"assets/img/biogen-logo-refresh-new.svg\" alt=\"logo\" height=\"30\" style=\"float:right; margin-top:8px; margin-right: 5px\"  >\n                           </li>\n                      </ul>      \n                    </div>\n                  </div>\n                </nav>\n          </div>\n        </div>\n    \n        </header>\n       \n\n        <div class=\"logout-page\">       \n\n            <div class=\"container-fluid\">\n                \n                <div class=\"row\" >\n                    <div style=\"height:150px; display:block;\">&nbsp;</div>\n                    <div class=\"col-sm-8 leftSide\">\n                           \n                        <div class=\"loginImg\">\n\n                            <img src=\"assets/img/logout_banner - v1.png\" alt=\"loginimg\"/>\n                          </div>\n                          <div style=\"height:10%; display:block;\">&nbsp;</div>       \n                          <div class=\"captionArea\">\n                              \n                              <h4 class=\"caption\">E<span>nterprise</span> T<span>ransaction</span> M<span>onitoring</span> (ETM) <span>helps you to log, notify, visualize transaction status and provide information for further analysis.</span></h4>\n                          </div>\n                         \n        \n                    </div>\n                    <div class=\"col-sm-4 rightSide\">\n                        <div style=\"height:50px; display:block;\">&nbsp;</div>\n                        <div class=\"formContent\"  *ngIf=\"isLogout =='logOut'\">\n\n                            <h3>Sign In </h3><br/>\n                            <p style=\"font-size:18px;\">Thank you for using Enterprise Transaction Monitoring. Please login again for accessing ETM.</p>\n                           \n                                <!-- <div style=\"margin-bottom: 35px\" class=\"input-group\">\n                                  <span class=\"input-group-addon\"><i class=\"fa fa-user-circle-o\"></i></span>\n                                  <input type=\"text\" name=\"j_username\" placeholder=\"User ID\" class=\"form-control inputPadding\" ngModel>\n                                </div> -->\n                                <!-- <div style=\"margin-bottom: 35px\" class=\"input-group\">\n                                  <span class=\"input-group-addon passwordPadding\"><i class=\"fa fa-lock\" style=\"padding:0 2px 0 3px\"></i></span>\n                                  <input type=\"password\" name=\"j_password\" placeholder=\"password\" class=\"form-control inputPadding\" ngModel>\n                                </div>\n                         -->\n                         <br/><br/><br/>\n                                <div style=\"margin-top:10px\" class=\"form-group\">\n                                  <div class=\"controls\">\n                                      <a href={{hostName}}> <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\" id=\"log\" name=\"B1\">Continue to Sign In</button></a>\n                                  </div>\n                                </div>\n                              <div id=\"lstatus\" style=\"color: #FF0000;\"></div>\n                             \n                                    \n                        </div>\n                        <div class=\"formContent\" *ngIf=\"isLogout ==''\">\n                            <p style=\"font-size:18px;\">You are not authroized to access ETM application. Please Contact <a href=\"mailto:DL-FMWPlatform-Operations@biogen.com\">DL-FMW Platform-Operations</a> for registering.</p>\n                              \n\n                        </div>\n                  </div>\n                </div>\n            </div>\n                 <!-- Footer -->\n                 <!-- <footer>\n                    <div class=\"row footerBg\">\n                        <div class=\"col-lg-12\">\n                            <strong>Copyright &copy; 2018 <a href=\"#\" style=\"color:#3fafd5\">Biogen</a>.</strong>\n                        </div>\n                    </div>\n                </footer> -->\n                </div>\n                \n              </div>\n              "

/***/ }),

/***/ "./src/app/components/logout/logout.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/logout/logout.component.ts ***!
  \*******************************************************/
/*! exports provided: LogoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogoutComponent", function() { return LogoutComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var LogoutComponent = /** @class */ (function () {
    function LogoutComponent(_userSessionService) {
        this._userSessionService = _userSessionService;
        this.isLogout = '';
        this.hostName = this._userSessionService.getHostName();
        console.log("logout constructor this.hostName: " + this.hostName);
    }
    LogoutComponent.prototype.ngOnInit = function () {
        this.hostName = this._userSessionService.getHostName();
        console.log("logout on load this.hostName: " + this.hostName);
        this.isLogout = this._userSessionService.getMsg();
        console.log("isLogout:" + this.isLogout);
        if (this.error != null) {
            console.log("Error:" + this.error);
        }
    };
    LogoutComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-logout',
            template: __webpack_require__(/*! ./logout.component.html */ "./src/app/components/logout/logout.component.html"),
            styles: [__webpack_require__(/*! ./logout.component.css */ "./src/app/components/logout/logout.component.css")]
        }),
        __metadata("design:paramtypes", [_service_user_session_service__WEBPACK_IMPORTED_MODULE_1__["UserSessionService"]])
    ], LogoutComponent);
    return LogoutComponent;
}());



/***/ }),

/***/ "./src/app/components/new-interface/new-interface.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/components/new-interface/new-interface.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/new-interface/new-interface.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/new-interface/new-interface.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<script>\n  var app = angular.module('myApp', []);\n  app.controller('myCtrl', function($scope) {\n      $scope.interfaceName = this.interfaceName;\n  });\n  </script>\n  \n<div class=\"content-wrapper dashboard\">\n  <ol class=\"breadcrumb\">\n      <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n    <li class=\"breadcrumb-item\">Interface Management</li>\n  </ol>\n\n  <section class=\"content \">\n    <div class=\"row general_tab\">\n      <div class=\"col-md-12\" style=\"padding:0 !important; margin:0 !important\">\n        <div class=\"panel with-nav-tabs panel-default\">\n          <div class=\"panel-heading\">\n            <ul class=\"nav nav-tabs\">\n              <li class=\"active\"><a href=\"#tab1default\" id=\"interfaceTab\" data-toggle=\"tab\">Logging </a></li>\n              <li><a href=\"#tab2default\" id=\"tab2\" data-toggle=\"tab\" class=\"disableTab\">Notification </a></li>\n              <li><a href=\"#tab3default\" id=\"tab3\" data-toggle=\"tab\" class=\"disableTab\">Interface </a></li>\n            </ul>\n          </div>\n          <div class=\"panel-body createInterface\">\n            <div class=\"tab-content \">\n\n              <div class=\"tab-pane fade in active\" id=\"tab1default\">\n\n\n                <form #integrationDetailsForm=\"ngForm\" (ngSubmit)=\"saveApplication(integrationDetailsForm.value)\"\n                  class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n                  <div id=\"successStatus\" style=\"color: green;\"></div>\n                  <div id=\"errorStatus\" style=\"color: #FF0000;\"></div>\n                  <div class=\"panel-group \">\n                    <div class=\"panel panel-default\">\n                      <div class=\"clearfix\"></div>\n                      <div class=\"clearfix\"></div>\n                      <div class=\"panel-heading\">Interface Details</div>\n                      <div class=\"panel-body \" style=\"padding-bottom:8px !important\">\n\n                        <div class=\"row\">\n                          <div class=\"col-sm-4\">\n                              <span class=\"mandatory\">*</span>\n                            <div class=\"col-sm-11\">\n                                <ng2-completer id=\"apName\" name=\"apName\" [datasource]=\"interfacList\"  (change)=\"onInterfaceSelcted($event.target.value)\" placeholder=\"&nbsp;&nbsp;&nbsp;&#xf002; &nbsp;&nbsp;&nbsp;Quick Search or type Interface Name\" style=\"font-family:Arial, FontAwesome;width:100% !important\" [minSearchLength]=\"2\" ngModel></ng2-completer>\n                            <!-- <input type=\"text\" class=\"form-control \" id=\"appName\" name=\"appName\"\n                              placeholder=\"Interface Name\" ngModel required> -->\n                              </div>\n                          </div>\n                          <div class=\"col-sm-4\">\n                              <span class=\"mandatory\">*</span>\n                              <div class=\"col-sm-11\">\n                            <input type=\"text\" class=\"form-control \" id=\"description\" name=\"description\" value={{bioLogApplicationData.appDesc}}\n                              placeholder=\"Description\" ngModel [required]=\"true\">\n                              </div>\n                          </div>\n\n                          <div class=\"col-sm-4\">\n                            <div class=\"col-sm-11\">\n                              <select class=\"form-control\" id=\"entity\" name=\"entity\" [value] ='bioLogApplicationData.entity' ngModel>\n                                <option value=\"\" disabled selected>Entity</option>\n                                <option *ngFor=\"let entity of entityList\" value={{entity.id}}>{{entity.name}}</option>\n                              </select>\n                            </div>\n                            <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\" data-target=\"#addEntity\"><i\n                                  class=\"fa fa-plus\"></i></button>\n                            </div>\n                          </div>\n                        </div>\n                        <div class=\"row\">\n                          <div class=\"col-sm-4\">\n                              <div class=\"col-sm-11\">\n                            <select class=\"form-control\" id=\"es\" name=\"es\" [value] ='bioLogApplicationData.enterpriseService' ngModel>\n                              <option value=\"\" disabled selected>Enterprise service</option>\n                              <option *ngFor=\"let es of esList\" value={{es.id}}>{{es.name}}</option>\n                            </select>\n                            </div>\n                            <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\" data-target=\"#addEnterpriseService\"><i\n                                  class=\"fa fa-plus\"></i></button>\n                            </div>\n\n                          </div>\n\n                          <div class=\"col-sm-4\">\n                            <span class=\"mandatory\">*</span>\n                            <div class=\"col-sm-11\">\n                              <select class=\"form-control \" id=\"appType\" name=\"appType\"  [value] ='bioLogApplicationData.appTypeId'  ngModel [required]=\"true\">\n                                <option value=\"\" disabled selected>Interface Type</option>\n                                <option *ngFor=\"let appType of appTypeList\" value={{appType.appTypeId}}>\n                                  {{appType.appType}}</option>\n                              </select>\n                            </div>\n                            <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\"\n                                data-target=\"#addInterfaceType\"><i class=\"fa fa-plus\"></i></button>\n                            </div>\n                          </div>\n\n                          <div class=\"col-sm-4\">\n                            <span class=\"mandatory\">*</span>\n                            <div class=\"col-sm-11\">\n                              <select class=\"form-control \" id=\"appGroup\" name=\"appGroup\"  [value] ='bioLogApplicationData.appGroupId' ngModel [required]=\"true\">\n                                <option value=\"\" disabled selected>Interface Group</option>\n                                <option *ngFor=\"let appGroup of appGroupList\" value={{appGroup.appGroupId}}>\n                                  {{appGroup.appGroup}}</option>\n                              </select>\n                            </div>\n                            <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\" data-target=\"#addGroups\"><i\n                                  class=\"fa fa-plus\"></i></button>\n                            </div>\n                          </div>\n                        </div>\n                        <div class=\"row\">\n                          <div class=\"col-sm-4\">\n                              <span class=\"mandatory\">*</span>\n                              <div class=\"col-sm-11\">\n                            <select class=\"form-control \" id=\"logLevel\" name=\"logLevel\" [value] ='bioLogApplicationData.loggerId' ngModel [required]=\"true\">\n                              <option value=\"\" disabled selected>Log Level</option>\n                              <option *ngFor=\"let logLevel of logLevelList\" value={{logLevel.loggerId}}>\n                                {{logLevel.loggerLevel}}</option>\n                            </select>\n                            </div>\n                          </div>\n                          <div class=\"col-sm-4\">\n                            <div class=\"col-sm-11\">\n\n                            </div>\n                          </div>\n                          <div class=\"col-sm-4\">\n                          </div>\n                        </div>\n\n                        <div class=\"clearfix\"></div>\n                        <!-- </form> -->\n                      </div>\n                    </div>\n\n                  </div>\n                  <!-- Source Systems -->\n                  <div class=\"panel-group \">\n                    <div class=\"panel panel-default\">\n                      <div class=\"panel-heading\">\n                        <div class=\"col-sm-6 \">\n                            <span>Source Systems</span>\n                          \n                          \n                              <button type=\"button\" class=\"pull-right addNotiBtn add-more\" id=\"createSourceType\" style=\"float:right !important\"\n                              name=\"createSourceType\" (click)=\"addmoreSourceSystem()\"><i class=\"fa fa-plus\"></i></button>\n                            \n                        </div>\n                        <div class=\"col-sm-6 separator\">\n                          <span>Target Systems</span>\n                          <button type=\"button\" class=\"pull-right addNotiBtn add-more\" id=\"createTargetType\" style=\"float:right !important\"\n                          name=\"createTargetType\" (click)=\"addmoreTargetSystem()\"><i class=\"fa fa-plus\"></i></button>\n                        </div>\n                      </div>\n                      <div class=\"panel-body createInterface\" style=\"padding:0 !important\">\n\n                        <div class=\"col-sm-6 separator2\">\n                         \n                          <form [formGroup]=\"sourceSystemForm\" class=\"form-horizontal\" ngNativeValidate>\n                              <div formArrayName=\"sourceSystemRows\"> \n                          <div *ngFor=\"let strow of sourceSystemForm.controls.sourceSystemRows.controls; let i=index\"  [formGroupName]=\"i\">\n\n                          <div class=\"col-sm-12\"\n                            style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                            <div class=\"col-sm-11\">\n                            <select class=\"form-control\" formControlName=\"sourceAppName\">\n                              <option value=\"\" disabled selected>Application</option>\n                              <option *ngFor=\"let buAppName of sourceAppNameList\" value={{buAppName.text}}>{{buAppName.name}}</option>\n                            </select>\n                          </div>\n                          <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\"\n                              data-target=\"#addApplication\"><i class=\"fa fa-plus\"></i></button>\n                             \n                            </div>\n                          </div>\n                          <div class=\"col-sm-12\"\n                          style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                          <div class=\"col-sm-11\">\n                          <select class=\"form-control \" id=\"sourceType\" formControlName=\"sourceAppType\">\n                              <option value=\"\" disabled selected>Source Type</option>\n                              <option *ngFor=\"let sourceType of sourceTypeList\" value={{sourceType.id}}>{{sourceType.name}}</option>\n                            </select>\n                          </div>\n                          <div class=\"col-sm-1\">\n                              <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\" data-target=\"#addSourceType\"><i\n                                class=\"fa fa-plus\"></i></button>\n                              \n                            </div>\n                          </div>\n\n\n                          <div class=\"col-sm-11\"\n                            style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                            <button class=\"removeNotificationBtn\" *ngIf=\"sourceSystemForm.controls.sourceSystemRows.controls.length > 1\" (click)=\"deleteSourceSystemRow(i)\" type=\"button\"><i class=\"glyphicon glyphicon-remove\"></i>\n                            </button>\n                          </div>\n                          <!-- </form> -->\n                        </div></div>\n                        </form>\n                        <div class=\"clearfix\"></div>\n                      </div>\n                        <!-- Target Systems -->\n                        <div class=\"col-sm-6 separator1\">\n                          <form [formGroup]=\"targetSystemForm\" class=\"form-horizontal\" ngNativeValidate>\n                              <div formArrayName=\"targetSystemRows\"> \n                          <div *ngFor=\"let strow of targetSystemForm.controls.targetSystemRows.controls; let i=index\"  [formGroupName]=\"i\">\n\n                          <div class=\"col-sm-12\"\n                            style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                            <div class=\"col-sm-11\">\n                                <select class=\"form-control\" formControlName=\"targetAppName\">\n                                    <option value=\"\" disabled selected>Application</option>\n                                    <option *ngFor=\"let buAppName of targetAppNameList\" value={{buAppName.text}}>{{buAppName.name}}</option>\n                                  </select>\n                             <!-- <ng-multiselect-dropdown idField=\"targetbuAppName\" [data]=\"targetAppNameList\"\n                              [(ngModel)]=\"selectedItems\" [settings]=\"dropdownSettings\" (onDeSelect)=\"onItemDeSelect($event)\"\n                              (onSelect)=\"onItemSelect($event)\" (onSelectAll)=\"onSelectAll($event)\" (onDeSelectAll)=\"onDeSelectAll($event)\" ngModel>\n                            </ng-multiselect-dropdown> -->\n                          </div>\n                          <div class=\"col-sm-1\">\n                            <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\"\n                            data-target=\"#addApplication\"><i class=\"fa fa-plus\"></i></button>\n                           \n                          </div>\n                          </div>\n\n                          <div class=\"col-sm-12\"\n                            style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                            <div class=\"col-sm-11\">\n                                <select class=\"form-control \" id=\"targetType\" formControlName=\"targetAppType\">\n                                    <option value=\"\" disabled selected>Target Type</option>\n                                    <option *ngFor=\"let sourceType of targetTypeList\" value={{sourceType.id}}>{{sourceType.name}}</option>\n                                  </select>\n                            </div>\n                            <div class=\"col-sm-1\">\n                                <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\" data-target=\"#addTargetType\"><i\n                                  class=\"fa fa-plus\"></i></button>\n                            </div>\n\n                          </div>\n                         \n                          <div class=\"col-sm-11\"\n                            style=\"padding-left: 0px !important; padding-right: 0px !important; padding-top: 10px\">\n                            <button class=\"removeNotificationBtn\" *ngIf=\"targetSystemForm.controls.targetSystemRows.controls.length > 1\" (click)=\"deleteTargetSystemRow(i)\" type=\"button\"><i class=\"glyphicon glyphicon-remove\"></i>\n                            </button>\n                          </div>\n\n\n                          <!-- </form> -->\n                        </div></div>\n                        </form>\n                          <div class=\"clearfix\"></div><br />\n                        </div>\n\n                      </div>\n                    </div>\n                  </div>\n                  <div class=\"clearfix\"></div>\n                  <div class=\"btnArea1\">\n                    <button type=\"submit\" id=\"appSave\" class=\"saveBtn\" name=\"appSave\"><i\n                        class=\"fa fa-save\"></i>&nbsp;Save</button>\n                  </div>\n                </form>\n              </div>\n              <div class=\"tab-pane fade\" id=\"tab2default\">\n                <div class=\"panel-group \">\n                    <div ng-app=\"myApp\" ng-controller=\"myCtrl\">\n                        Interface Name: <span><strong>{{interfaceName}}</strong></span>\n                      </div>\n                  <div class=\"panel panel-default\">\n                    <div class=\"clearfix\"></div>\n                    \n                    <div class=\"panel-heading\">Notification\n                      <button type=\"submit\" class=\"pull-right addNotiBtn add-more\" id=\"notificationSave\"\n                        name=\"notificationSave\" (click)=\"addmoreNotification()\"><i class=\"fa fa-plus\"></i></button>\n                    </div>\n                    <div class=\"panel-body \" style=\"padding-bottom:8px !important\">\n                        <form [formGroup]=\"notificationForm\" (ngSubmit)=\"saveNotification(notificationForm.value)\" class=\"form-horizontal\" ngNativeValidate>\n                            <div id=\"notifySuccess\" style=\"color: green;\"></div>\n                            <div id=\"notifyError\" style=\"color: #FF0000;\"></div>\n                            <div formArrayName=\"notificationRows\">\n                                <div *ngFor=\"let notificationRow of notificationForm.controls.notificationRows.controls; let i=index\"  [formGroupName]=\"i\">\n                          <div class=\"row\">\n                            <div class=\"col-sm-3\">\n                              <span class=\"mandatory\">*</span>\n                              <input type=\"text\" class=\"form-control \" required formControlName=\"exCategory\"\n                                placeholder=\"Exception Catagory Ex: Application, System\" required>\n                            </div>\n                            <div class=\"col-sm-3\">\n                              <span class=\"mandatory\">*</span>\n                              <input type=\"text\" class=\"form-control \" formControlName=\"exType\"\n                                placeholder=\"Exception Type Ex: ERROR,SUCCESS\" required>\n                            </div>\n                            <div class=\"col-sm-3\"></div>\n                          </div>\n\n                          <div class=\"row\">\n                            <div class=\"col-sm-3\">\n                              <span class=\"mandatory\">*</span>\n                              <select class=\"form-control\" formControlName=\"notificationEnabled\" required>\n                                <option value=\"\" disabled selected>IS Notification Active</option>\n                                <option value=\"YES\">YES</option>\n                                <option value=\"NO\">NO</option>\n                              </select>\n                             \n                            </div>\n                            <div class=\"col-sm-3\">\n                              <span class=\"mandatory\">*</span>\n                              <input type=\"text\" formControlName=\"toemail\" placeholder=\"To Email Ids\" required>\n                            </div>\n                            <div class=\"col-sm-3\">\n                              <!-- <span class=\"mandatory\">*</span> -->\n                              <input type=\"text\" class=\"form-control \" formControlName=\"ccemail\" placeholder=\"CC email Ids\">\n                            </div>\n                            <div class=\"col-sm-3\">\n                              <!-- <span class=\"mandatory\">*</span> -->\n                              <input type=\"text\" class=\"form-control \" formControlName=\"template\" placeholder=\"Template Ex: DefaultNotification.vm\" >\n                            </div>\n\n                          </div>\n                          <div class=\"clearfix\"></div>\n                          <div class=\"row\">\n                            <div class=\"col-sm-3\">\n                              <span class=\"mandatory\">*</span>\n\n                              <select class=\"form-control\" formControlName=\"notificationType\"\n                              (change)=\"onNotificationTypeChange($event.target.value)\" required>\n                                <option value=\"\" disabled selected>Email Trigger type</option>\n                                <option value=\"IMMEDIATE\">IMMEDIATE</option>\n                                <option value=\"SCHEDULED\">SCHEDULED</option>\n                              </select>\n                            </div>\n\n                            <div class=\"col-sm-3\" *ngIf=\"scheduledFlag\">\n                              <input type=\"text\" class=\"form-control \" formControlName=\"frequency\" placeholder=\"Schedule Frequency In Milliseconds\">\n                            </div>\n                            <div class=\"col-sm-3\">\n                                <select class=\"form-control\" formControlName=\"thresholdEnabled\" (change)=\"onThresholdChange($event.target.value)\">\n                                  <option value=\"\" disabled selected>Threshold Enabled</option>\n                                  <option value=\"YES\">YES</option>\n                                  <option value=\"NO\">NO</option>\n                                </select>\n                              </div>\n  \n                              <div class=\"col-sm-3\" *ngIf=\"thresholdFlag\">\n                                <input type=\"text\" class=\"form-control \" formControlName=\"thresholdLimit\"\n                                  placeholder=\"Threshold Max Count\">\n                              </div>\n\n                          </div>\n                          <div class=\"clearfix\"></div>\n                          <div class=\"clearfix\"></div>\n                          <div class=\"row\">\n                              <div class=\"col-sm-3\"  *ngIf=\"scheduledFlag\">\n                                  <select class=\"form-control\" formControlName=\"aggregationEnabled\">\n                                    <option value=\"\" disabled selected>Aggregation Enabled</option>\n                                    <option value=\"YES\">YES</option>\n                                    <option value=\"NO\">NO</option>\n                                  </select>\n                                </div>\n    \n                                <div class=\"col-sm-3\"  *ngIf=\"scheduledFlag\">\n                                  <input type=\"text\" class=\"form-control \" formControlName=\"aggregationCount\" placeholder=\"Aggregation Count\">\n                                </div>\n                                <div class=\"\">\n                                    <button class=\"removeNotificationBtn\" *ngIf=\"notificationForm.controls.notificationRows.controls.length > 1\" (click)=\"deleteNotificationRow(i)\" type=\"button\"><i class=\"glyphicon glyphicon-remove\"></i>\n                                    </button>\n                                  </div>\n                            \n                          </div>\n                          <div class=\"row clearfix\"> </div>\n                        </div>\n                            </div>\n                        <div class=\"clearfix\"></div>\n                                              <div class=\"btnArea1\">\n                          <button type=\"submit\" id=\"notificationSave\" class=\"saveBtn\" name=\"notificationSave\"><i\n                              class=\"fa fa-save\"></i>&nbsp;Save</button>\n                        </div>\n                      </form>\n                    </div>\n                  </div>\n\n                </div>\n              </div>\n\n              <!-- Interface configuration Begins here-->\n              <div class=\"tab-pane fade\" id=\"tab3default\">\n                <div class=\"panel-group \">\n                  <div class=\"panel panel-default\" style=\"border: none !important\">\n                    <div class=\"clearfix\"></div>\n                    <div ng-app=\"myApp\" ng-controller=\"myCtrl\">\n                      Interface Name: <span><strong>{{interfaceName}}</strong></span>\n                    </div>\n                    <div style=\"border:1px solid #ccc\">\n                    <div class=\"panel-heading\">Integration Details\n                    </div>\n                    <div class=\"panel-body \" style=\"padding-bottom:8px !important\">\n\n                      <form #interfaceForm=\"ngForm\" (ngSubmit)=\"saveInterface(interfaceForm.value)\"\n                        class=\"form-horizontal\" role=\"form\">\n                    <div id=\"integrationSuccessStatus\" style=\"color: green;\"></div>\n                    <div id=\"integrationErrorStatus\" style=\"color: #FF0000;\"></div>\n                          <div class=\"row\">\n                            <div class=\"col-sm-3\">\n                                <span class=\"mandatory\">*</span>\n                                <div class=\"col-sm-11\">\n                                   <select class=\"form-control \" id=\"integrationPattern\" name=\"integrationPattern\"   [value] ='defIntegrationPattern' ngModel>\n                                      <option value=\"\" disabled selected>Inegration Pattern</option>\n                                      <option *ngFor=\"let pattern of patternList\" value={{pattern.id}}>{{pattern.name}}</option>\n                                    </select>\n                                  </div>\n                                   <div class=\"col-sm-1\">\n                                    <button type=\"button\" class=\"modalBtn\" data-toggle=\"modal\"\n                                      data-target=\"#addintegrationPattern\"><i class=\"fa fa-plus\"></i></button>\n                                  </div>\n                                  \n                            </div>\n                      \n                            <div class=\"col-sm-3\">\n                                <!-- <span class=\"mandatory\">*</span> -->\n                              <input type=\"file\" class=\"form-control \" id=\"designDiagram\" \n                              (change)=\"onFileChanged($event)\" name=\"designDiagram\"\n                                placeholder=\"Upload Design diagram\" ngModel>\n                              <!-- <input type=\"text\" class=\"form-control \" id=\"serviceEnabled\" name=\"serviceEnabled\" placeholder=\"Service Enabled Ex: YES/NO\"\n                                                                                          ngModel> -->\n\n                            </div>\n                          </div>\n\n                       <div class=\"clearfix\"></div>\n\n                        <div class=\"btnArea1\">\n                          <button type=\"submit\" id=\"saveInterface\" class=\"saveBtn\" name=\"saveInterface\"><i\n                              class=\"fa fa-save\"></i>&nbsp;Save</button>\n                        </div>\n                      </form>\n                    </div>\n                  </div>\n                    <div class=\"clearfix\"></div><br/>\n<!-- ITPD details begins-->\n<div style=\"border:1px solid #ccc\">\n<div class=\"panel-heading\">ITPD Details  <button type=\"submit\" class=\"pull-right addNotiBtn add-more\" id=\"createITPD\"\n  name=\"createITPD\" (click)=\"addmoreITPD()\"><i class=\"fa fa-plus\"></i></button>\n  </div>\n  <div class=\"panel-body \" style=\"padding-bottom:8px !important\">\n\n      <form [formGroup]=\"itpdForm\" (ngSubmit)=\"saveITPDDetails(itpdForm.value)\" class=\"form-horizontal\" ngNativeValidate>\n        \n          <div id=\"itpdErrorStatus\" style=\"color: #FF0000;\"></div>\n          <div id=\"itpdSuccessStatus\" style=\"color: green;\"></div>\n          <div formArrayName=\"itemRows\">\n          <div *ngFor=\"let itemrow of itpdForm.controls.itemRows.controls; let i=index\"  [formGroupName]=\"i\">\n        <div class=\"row\">\n          <div class=\"col-sm-3\">\n            <span class=\"mandatory\">*</span>\n            <input type=\"text\" formControlName=\"ITPDNo\" placeholder=\"ITPD#\" required>\n          </div>\n          <div class=\"col-sm-3\">\n            <span class=\"mandatory\">*</span>\n            <input type=\"text\" formControlName=\"itpdDescription\" placeholder=\"ITPD Description\" required>\n\n          </div>\n          <div class=\"col-sm-3\">\n              <button class=\"removeITPDBtn\" *ngIf=\"itpdForm.controls.itemRows.controls.length > 1\" (click)=\"deleteITPDRow(i)\" type=\"button\"><i class=\"glyphicon glyphicon-remove\"></i>\n              </button>\n \n            </div>\n          <div class=\"col-sm-3\">\n\n          </div>\n          </div>\n        </div>\n      </div>\n     <div class=\"clearfix\"></div>\n    \n      <div class=\"btnArea1\">\n        <button type=\"submit\" id=\"saveITPDDetails\" class=\"saveBtn\" name=\"saveITPDDetails\"><i\n            class=\"fa fa-save\"></i>&nbsp;Save</button>\n      </div>\n    </form>\n  </div>\n</div>\n  <div class=\"clearfix\"></div><br/>\n<!-- ITPD details ends-->\n<!-- CR Details begins-->\n<div style=\"border:1px solid #ccc\">\n<div class=\"panel-heading\">CR Details <button type=\"submit\" class=\"pull-right addNotiBtn add-more\" id=\"createCRs\"\n  name=\"createCRs\" (click)=\"addmoreCR()\"><i class=\"fa fa-plus\"></i></button>\n  </div>\n  <div class=\"panel-body \" style=\"padding-bottom:8px !important\">\n      <form [formGroup]=\"crForm\" (ngSubmit)=\"saveCRDetails(crForm.value)\" class=\"form-horizontal\" ngNativeValidate>\n          <div id=\"crErrorStatus\" style=\"color: #FF0000;\"></div>\n          <div id=\"crSuccessStatus\" style=\"color: green;\"></div>\n          <div formArrayName=\"crRows\">\n          <div *ngFor=\"let crRow of crForm.controls.crRows.controls; let i=index\"  [formGroupName]=\"i\">\n        <div class=\"row\">\n          <div class=\"col-sm-11 crdetails\">\n              <div class=\"col-sm-3\">\n                  <span class=\"mandatory\">*</span>\n                  <input type=\"text\" class=\"form-control \" formControlName=\"crNo\"  placeholder=\"CR#\" required>\n                </div>\n                <div class=\"col-sm-3\">\n                  <span class=\"mandatory\">*</span>\n                  <input type=\"text\" class=\"form-control \" formControlName=\"crDescription\" placeholder=\"CR Description\" required>\n      \n                </div>\n                <div class=\"col-sm-3 datepick\">\n                  <!-- <span class=\"mandatory\">*</span> -->\n                    <input class=\"unstyled\" class=\"form-control dateInputPos\" type=\"date\" formControlName=\"crImplementationDate\">\n               </div>\n                <div class=\"col-sm-3\">\n                  <!-- <span class=\"mandatory\">*</span> -->\n                  <input type=\"text\" class=\"form-control \" formControlName=\"crComments\"    placeholder=\"Comments\">                        \n                </div>\n          </div>\n          <div class=\"col-sm-1\">\n              <button class=\"removeCRBtn\" *ngIf=\"crForm.controls.crRows.controls.length > 1\" (click)=\"deleteCRRow(i)\" type=\"button\"><i class=\"glyphicon glyphicon-remove\"></i></button>\n            </div>\n\n        </div>\n      </div>\n          </div>\n     <div class=\"clearfix\"></div>\n      <div class=\"btnArea1\">\n        <button type=\"submit\" id=\"saveCRDetails\" class=\"saveBtn\" name=\"saveCRDetails\"><i\n            class=\"fa fa-save\"></i>&nbsp;Save</button>\n      </div>\n    </form>\n  </div>\n</div>  \n<!-- CR details ends -->\n<div class=\"clearfix\"></div>\n                  </div>\n\n                </div>\n              </div>\n              <!-- Interface configuration ends here-->\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <!-- add group -->\n  <div id=\"addGroups\" class=\"modal fade createInterface \" role=\"dialog\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n        <form #interfaceGroupForm=\"ngForm\" (ngSubmit)=\"saveInterfaceGroup(interfaceGroupForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n      <!-- Modal content-->\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Interface Group</span>\n        </div>\n        <div class=\"modal-body\">\n\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"interfaceGroupName\" name=\"interfaceGroupName\"\n              placeholder=\"Enter Interface Group Name\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"intefaceGroupDescription\" name=\"intefaceGroupDescription\" placeholder=\"Inteface Group Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n          <button type=\"submit\" id=\"interfaceGroupSave\" name=\"interfaceGroupSave\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n</form>\n    </div>\n  </div>\n\n  <!-- addintegrationPattern -->\n  <div id=\"addintegrationPattern\" class=\"modal fade createInterface \" role=\"dialog\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n        <form #integrationPatternForm=\"ngForm\" (ngSubmit)=\"saveIntegrationPattern(integrationPatternForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n      <!-- Modal content-->\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Integration Pattern</span>\n        </div>\n        <div class=\"modal-body\">\n          <div id=\"integrationPatternStatus\" style=\"color: #FF0000;\"></div>\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"integrationPattern\" name=\"integrationPattern\"\n              placeholder=\"Enter Integration Pattern\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"integrationPatternDescription\" name=\"integrationPatternDescription\" placeholder=\"Integration Pattern Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n            <button type=\"submit\" id=\"integrationPatternSave\" name=\"integrationPatternSave\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n</form>\n    </div>\n  </div>\n\n  <!-- Interface type -->\n  <div id=\"addInterfaceType\" class=\"modal fade createInterface \" role=\"dialog\" style=\"border-radius:25px !important\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n        <form #interfaceTypForm=\"ngForm\" (ngSubmit)=\"saveInterfaceType(interfaceTypForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n      <!-- Modal content-->\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Interface Type</span>\n        </div>\n        <div class=\"modal-body\">\n          <div id=\"interfaceTypeStatus\" style=\"color: #FF0000;\"></div>\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control inputPadding\" id=\"interfaceTypeName\" name=\"interfaceTypeName\"\n              placeholder=\"Enter Interface Type Name\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control inputPadding\" id=\"interfaceTypedescription\" name=\"interfaceTypedescription\" placeholder=\"Enter Interface Type Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n          <button type=\"submit\" id=\"interfaceTypeSave\" name=\"interfaceTypeSave\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n</form>\n    </div>\n  </div>\n\n\n  <!-- add Entity -->\n  <div id=\"addEntity\" class=\"modal fade createInterface \" role=\"dialog\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n\n      <!-- Modal content-->\n      <form #entityForm=\"ngForm\" (ngSubmit)=\"saveEntity(entityForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Entity</span>\n        </div>\n       \n        <div class=\"modal-body\">\n          <div id=\"entityStatus\" style=\"color: #FF0000;\"></div>\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"entityName\" name=\"entityName\"\n              placeholder=\"Enter Entity Name\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"entityDescription\" name=\"entityDescription\" placeholder=\"Enter Entity Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n            <button type=\"submit\" id=\"entitySave\" name=\"entitySave\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n  </form>\n    </div>\n  </div>\n\n  <!-- add EnterpriseService -->\n  <div id=\"addEnterpriseService\" class=\"modal fade createInterface \" role=\"dialog\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n\n      <!-- Modal content-->\n      <form #eServiceForm=\"ngForm\" (ngSubmit)=\"saveEnterpriseService(eServiceForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Enterprise Service</span>\n        </div>\n      \n        <div class=\"modal-body\">\n          <div id=\"esStatus\" style=\"color: #FF0000;\"></div>\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"esname\" name=\"esname\"\n              placeholder=\"Enter Enterprise Service Name\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"esDescription\" name=\"esDescription\" placeholder=\"Enter Enterprise Service Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n            <button type=\"submit\" id=\"enterpriseSave\" name=\"enterpriseSave\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n  </form>\n    </div>\n  </div>\n\n   <!-- Application -->\n   <div id=\"addApplication\" class=\"modal fade createInterface \" role=\"dialog\">\n    <div class=\"modal-dialog\" style=\"width:550px !important\">\n\n      <!-- Modal content-->\n      <form #newApplicationServiceForm=\"ngForm\" (ngSubmit)=\"saveNewApplication(newApplicationServiceForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n        \n      <div class=\"modal-content\">\n        <div class=\"modal-header\">\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n          <span class=\"modal-title\">Add Application</span>\n        </div>\n      \n        <div class=\"modal-body\">\n          <div id=\"newAppStatus\" style=\"color: #FF0000;\"></div>\n          <div class=\"col-sm-12\">\n                <ng2-completer id=\"buName\" name=\"buName\" [datasource]=\"bunitListCons\" placeholder=\"Search Business Unit\" style=\"width:100% !important\" [minSearchLength]=\"2\" ngModel></ng2-completer>\n            </div>\n            <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"newApplicationName\" name=\"newApplicationName\"\n              placeholder=\"Enter Application Name\" ngModel>\n          </div>\n          <div class=\"clearfix\"></div><br />\n          <div class=\"col-sm-12\">\n            <input type=\"text\" class=\"form-control \" id=\"newApplicationDescription\" name=\"newApplicationDescription\" placeholder=\"Enter Application Description\"\n              ngModel>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n        <div class=\"modal-footer\">\n            <button type=\"submit\" id=\"saveNewApplication\" name=\"saveNewApplication\" class=\"saveBtn\">Save</button>\n        </div>\n      </div>\n  </form>\n    </div>\n  </div>\n  \n  <!-- add SourceType -->\n  <div id=\"addSourceType\" class=\"modal fade createInterface \" role=\"dialog\">\n      <div class=\"modal-dialog\" style=\"width:550px !important\">\n  \n        <!-- Modal content-->\n        <form #sourceTypeForm=\"ngForm\" (ngSubmit)=\"saveSourceType(sourceTypeForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n        <div class=\"modal-content\">\n          <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n            <span class=\"modal-title\">Add Source Type </span>\n          </div>\n        \n          <div class=\"modal-body\">\n            <div id=\"sourceTypeStatus\" style=\"color: #FF0000;\"></div>\n            <div class=\"col-sm-12\">\n              <input type=\"text\" class=\"form-control \" id=\"sourceType\" name=\"sourceType\"\n                placeholder=\"Enter Source Type Name\" ngModel>\n            </div>\n            <div class=\"clearfix\"></div><br />\n            <div class=\"col-sm-12\">\n              <input type=\"text\" class=\"form-control \" id=\"sourceTypeDescription\" name=\"sourceTypeDescription\" placeholder=\"Enter Source Type Description\"\n                ngModel>\n            </div>\n            <div class=\"clearfix\"></div>\n          </div>\n          <div class=\"modal-footer\">\n              <button type=\"submit\" id=\"sourceTypeSave\" name=\"sourceTypeSave\" class=\"saveBtn\">Save</button>\n          </div>\n        </div>\n    </form>\n      </div>\n    </div>\n\n    \n  <!-- add EnterpriseService -->\n  <div id=\"addTargetType\" class=\"modal fade createInterface \" role=\"dialog\">\n      <div class=\"modal-dialog\" style=\"width:550px !important\">\n  \n        <!-- Modal content-->\n        <form #targetTypeForm=\"ngForm\" (ngSubmit)=\"saveTargetType(targetTypeForm.value)\" class=\"form-horizontal\" role=\"form\" ngNativeValidate>\n        <div class=\"modal-content\">\n          <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n            <span class=\"modal-title\">Add Target Type</span>\n          </div>\n        \n          <div class=\"modal-body\">\n            <div id=\"targetTypeStatus\" style=\"color: #FF0000;\"></div>\n            <div class=\"col-sm-12\">\n              <input type=\"text\" class=\"form-control \" id=\"targetTypename\" name=\"targetTypename\"\n                placeholder=\"Enter Target Type Name\" ngModel>\n            </div>\n            <div class=\"clearfix\"></div><br />\n            <div class=\"col-sm-12\">\n              <input type=\"text\" class=\"form-control \" id=\"targetTypeDescription\" name=\"targetTypeDescription\" placeholder=\"Enter Target Type Description\"\n                ngModel>\n            </div>\n            <div class=\"clearfix\"></div>\n          </div>\n          <div class=\"modal-footer\">\n              <button type=\"submit\" id=\"targetTypeSave\" name=\"targetTypeSave\" class=\"saveBtn\">Save</button>\n          </div>\n        </div>\n    </form>\n      </div>\n    </div>\n\n</div>"

/***/ }),

/***/ "./src/app/components/new-interface/new-interface.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/new-interface/new-interface.component.ts ***!
  \*********************************************************************/
/*! exports provided: NewInterfaceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewInterfaceComponent", function() { return NewInterfaceComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/bio-notify.service */ "./src/app/service/bio-notify.service.ts");
/* harmony import */ var _dao_bio_notification__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../dao/bio-notification */ "./src/app/dao/bio-notification.ts");
/* harmony import */ var _service_application_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/application.service */ "./src/app/service/application.service.ts");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _dao_bio_log_application__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dao/bio-log-application */ "./src/app/dao/bio-log-application.ts");
/* harmony import */ var _dao_bio_log_app_type__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../dao/bio-log-app-type */ "./src/app/dao/bio-log-app-type.ts");
/* harmony import */ var _dao_bio_log_app_group__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../dao/bio-log-app-group */ "./src/app/dao/bio-log-app-group.ts");
/* harmony import */ var _service_bio_app_doc_history_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../service/bio-app-doc-history.service */ "./src/app/service/bio-app-doc-history.service.ts");
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
/* harmony import */ var _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../dao/bio-app-doc-history */ "./src/app/dao/bio-app-doc-history.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_12__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};













var NewInterfaceComponent = /** @class */ (function () {
    function NewInterfaceComponent(_fb, _bioAppDocHistoryService, _applicationService, _businessUnitService, _bioNotifyService, spinnerService) {
        this._fb = _fb;
        this._bioAppDocHistoryService = _bioAppDocHistoryService;
        this._applicationService = _applicationService;
        this._businessUnitService = _businessUnitService;
        this._bioNotifyService = _bioNotifyService;
        this.spinnerService = spinnerService;
        this.bioNotification = new _dao_bio_notification__WEBPACK_IMPORTED_MODULE_3__["BioNotification"]();
        this.updateBioNotification = new _dao_bio_notification__WEBPACK_IMPORTED_MODULE_3__["BioNotification"]();
        this.bioLogApplication = new _dao_bio_log_application__WEBPACK_IMPORTED_MODULE_6__["BioLogApplicationData"]();
        this.bioLogAppType = new _dao_bio_log_app_type__WEBPACK_IMPORTED_MODULE_7__["BioLogAppType"]();
        this.bioLogAppGroup = new _dao_bio_log_app_group__WEBPACK_IMPORTED_MODULE_8__["BioLogAppGroup"]();
        this.scheduledFlag = false;
        this.thresholdFlag = false;
        this.dropdownSettings = {};
        this.rowData = [];
        this.columnDefs = [];
        this.notifyPropsNameList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.fileId = 0;
        this.targetBUAPPId = [];
        this.appIntegrationId = 0;
        this.bunitListCons = [];
        this.bioIntDet = [];
        this.bioNotifyList = [];
        this.bioLogApplicationData = new _dao_bio_log_application__WEBPACK_IMPORTED_MODULE_6__["BioLogApplicationData"]();
        this.interfacList = [];
        this.interfaceDetailsList = [];
        this.defSourceType = 0;
        this.defTargetType = 0;
        this.defSourceAppName = 0;
        this.defTargetAppName = 0;
        this.defIntegrationPattern = "";
        this.defitpdDescription = "";
        this.defitpdNumber = "";
        this.defcrNo = "";
        this.defcrDesc = "";
        this.defcrImplDate = "";
        this.defcrComments = "";
        this.updateflag = "0";
        this.notifyPropsId = 0;
        this.notifyId = 0;
        this.itpdId = 0;
        this.crId = 0;
        this.targetBusinessId = 0;
        this.sourceBusinessId = 0;
    }
    NewInterfaceComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.spinnerService.show();
        this.updateflag = "0";
        this.bioNotification.exceptionCategory = "";
        this.bioNotification.exceptionType = "";
        this.bioNotification.aggregationEnabled = "";
        this.bioNotification.aggregationCount = "";
        this.bioNotification.toemail = "";
        this.bioNotification.ccemail = "";
        this.bioNotification.frequency = "";
        this.bioNotification.notificationEnabled = "";
        this.bioNotification.notificationType = "";
        this.bioNotification.template = "";
        this.bioNotification.thresholdEnabled = "";
        this.bioNotification.thresholdLimit = "";
        this.itpdForm = this._fb.group({
            itemRows: this._fb.array([this.initItemRows()])
        });
        this.notificationForm = this._fb.group({
            notificationRows: this._fb.array([this.initNotificationRows()])
        });
        this.sourceSystemForm = this._fb.group({
            sourceSystemRows: this._fb.array([this.initSourceSystemRows()])
        });
        this.targetSystemForm = this._fb.group({
            targetSystemRows: this._fb.array([this.initTargetSystemRows()])
        });
        this.crForm = this._fb.group({
            crRows: this._fb.array([this.initCRRows()])
        });
        this._applicationService.getAppTypeList().subscribe(function (appTypesListValues) {
            //      console.log(appTypesListValues);
            _this.appTypeList = appTypesListValues;
            _this.selectedAppType = _this.appTypeList[1];
        }), function (error) {
            console.log(error);
        };
        this._applicationService.getAppGroupList().subscribe(function (appgroupListValues) {
            //console.log(appgroupListValues);
            _this.appGroupList = appgroupListValues;
        }), function (error) {
            console.log(error);
        };
        this._applicationService.getLogLevelList().subscribe(function (logLevelListValues) {
            _this.logLevelList = logLevelListValues;
        }), function (error) {
            console.log(error);
        };
        this._businessUnitService.getBUDetails().subscribe(function (defaultLOVs) {
            //console.log("defaultLOVs : "+defaultLOVs);
            _this.defaultLOVs = defaultLOVs;
            _this.bunitList = _this.defaultLOVs.buList;
            _this.sourceAppNameList = _this.defaultLOVs.applicationList;
            _this.targetAppNameList = _this.defaultLOVs.applicationList;
            _this.entityList = _this.defaultLOVs.entityList;
            _this.esList = _this.defaultLOVs.esList;
            _this.patternList = _this.defaultLOVs.patternList;
            _this.sourceTypeList = _this.defaultLOVs.sourceTargetTypeList;
            _this.targetTypeList = _this.defaultLOVs.sourceTargetTypeList;
            console.log("this.sourceTypeList:" + _this.sourceTypeList);
            //console.log("sourceAppNameList:"+JSON.stringify(this.sourceAppNameList));
            for (var _i = 0, _a = _this.bunitList; _i < _a.length; _i++) {
                var appName = _a[_i];
                _this.bunitListCons.push(appName.name);
            }
            //      console.log("bunitListCons:"+this.bunitListCons);
        }), function (error) {
            console.log(error);
        };
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true
        };
        this._applicationService.getAllApplicationDetails().subscribe(function (application) {
            //console.log(application);
            _this.interfaceDetailsList = application;
            for (var _i = 0, _a = _this.interfaceDetailsList; _i < _a.length; _i++) {
                var inter = _a[_i];
                _this.interfacList.push(inter.appName);
            }
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    NewInterfaceComponent.prototype.onItemSelect = function (item) {
        //    console.log(item);
        this.targetBUAPPId.push(item.id);
        //  console.log("onItemSelect this.targetBUAPPId="+this.targetBUAPPId);    
    };
    NewInterfaceComponent.prototype.onSelectAll = function (items) {
        //console.log(items);
        this.targetBUAPPId = [];
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            this.targetBUAPPId.push(item.id);
        }
        //console.log(" onSelectAll --> this.targetBUAPPId="+this.targetBUAPPId);
    };
    NewInterfaceComponent.prototype.onDeSelectAll = function (items) {
        //console.log(items);
        this.targetBUAPPId = [];
        //  console.log("onDeSelectAll --> this.targetBUAPPId="+this.targetBUAPPId);
    };
    NewInterfaceComponent.prototype.onItemDeSelect = function (item) {
        //  console.log(item);
        var newItems = [];
        for (var _i = 0, _a = this.targetBUAPPId; _i < _a.length; _i++) {
            var itemId = _a[_i];
            if (item.id != itemId) {
                newItems.push(itemId);
            }
        }
        this.targetBUAPPId = newItems;
        //  console.log("onItemDeSelect--> this.targetBUAPPId="+this.targetBUAPPId);    
    };
    NewInterfaceComponent.prototype.onSourceBUChange = function (bunit) {
        var _this = this;
        if (bunit == "") {
            //this.buAppNameList = [];
            this.sourceAppNameList = [];
            this.targetAppNameList = [];
            this.entityList = [];
            this.esList = [];
            this.bunitTemp = "";
            this.buAppNameTemp = "";
            return;
        }
        this.bunitTemp = bunit;
        this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
            //$("#buAppName").select("val2");
            _this.sourceAppNameList = buAppNameListValues;
            _this.targetAppNameList = buAppNameListValues;
        }), function (error) {
            console.log(error);
        };
    };
    NewInterfaceComponent.prototype.onTargetBUChange = function (bunit) {
        var _this = this;
        if (bunit == "") {
            //this.buAppNameList = [];
            this.targetAppNameList = [];
            this.entityList = [];
            this.esList = [];
            this.bunitTemp = "";
            this.buAppNameTemp = "";
            return;
        }
        this.bunitTemp = bunit;
        this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
            //$("#buAppName").select("val2");
            _this.targetAppNameList = buAppNameListValues;
        }), function (error) {
            console.log(error);
        };
    };
    NewInterfaceComponent.prototype.saveApplication = function (data) {
        //debugger;
        //  console.log(data);
        console.log("update flag:" + this.updateflag);
        document.getElementById("successStatus").innerHTML = "";
        document.getElementById("errorStatus").innerHTML = "";
        this.targetbuAppplication = "";
        /*for(let itemId of this.targetBUAPPId )  {
          this.targetbuAppplication=this.targetbuAppplication+itemId+",";
          }
          this.targetbuAppplication = this.targetbuAppplication.substring(0,this.targetbuAppplication.length);
        console.log("target bu application:"+this.targetbuAppplication);
        */
        this.bioLogApplication.appId = this.appId.toString();
        //    this.bioLogApplication.appName = data.appName;
        this.bioLogApplication.appName = this.interfaceName;
        this.bioLogApplication.appTypeId = data.appType;
        this.bioLogApplication.appGroupId = data.appGroup;
        this.bioLogApplication.loggerId = data.logLevel;
        this.bioLogApplication.appDesc = data.description;
        this.bioLogApplication.entity = data.entity;
        this.bioLogApplication.enterpriseService = data.es;
        // this.bioLogApplication.updatedBy = this.updateflag;
        //this.bioLogApplication.sourceBu = data.sourcebuint;
        //this.bioLogApplication.sourceApplication = data.sourcebuAppName;
        //this.bioLogApplication.targetBu = data.targetbuint;
        var arrayControl = this.sourceSystemForm.get('sourceSystemRows');
        this.sourceTypeDataList = [];
        for (var _i = 0, _a = arrayControl.controls; _i < _a.length; _i++) {
            var item = _a[_i];
            this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
            //this.bioLOVsData.id=item.value.sourceAppName
            if (item.value.businessId != null && item.value.businessId != '') {
                this.bioLOVsData.id = item.value.businessId;
            }
            else {
                this.bioLOVsData.id = 0;
            }
            this.bioLOVsData.text = item.value.sourceAppName;
            this.bioLOVsData.type = item.value.sourceAppType;
            this.sourceTypeDataList.push(this.bioLOVsData);
        }
        arrayControl = this.targetSystemForm.get('targetSystemRows');
        this.targetTypeDataList = [];
        for (var _b = 0, _c = arrayControl.controls; _b < _c.length; _b++) {
            var item = _c[_b];
            this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
            if (item.value.businessId != null && item.value.businessId != '') {
                this.bioLOVsData.id = item.value.businessId;
            }
            else {
                this.bioLOVsData.id = 0;
            }
            this.bioLOVsData.text = item.value.targetAppName;
            this.bioLOVsData.type = item.value.targetAppType;
            this.targetTypeDataList.push(this.bioLOVsData);
        }
        //console.log("this.sourceTypeDataList:"+JSON.stringify(this.sourceTypeDataList));
        //console.log("this.targetTypeDataList:"+JSON.stringify(this.targetTypeDataList));
        this.bioLogApplication.sourceAppList = this.sourceTypeDataList;
        this.bioLogApplication.targetAppList = this.targetTypeDataList;
        //this.bioLogApplication.targetApplication = data.targetbuAppName;
        this.bioLogApplication.targetApplication = this.targetbuAppplication;
        var errorMsg = "";
        /*if(this.bioLogApplication.appName == null || this.bioLogApplication.appName.trim() == "")
        {
          errorMsg = errorMsg+"Please Enter Application Name<br/>";
        }*/
        if (this.updateflag == "0" || this.appId == 0) {
            if (data.description == null || data.description.trim() == "") {
                errorMsg = errorMsg + "Please Enter Description<br/>";
            }
            if (data.appType == null || data.appType.trim() == "") {
                errorMsg = errorMsg + "Please Select App Type<br/>";
            }
            if (data.appGroup == null || data.appGroup.trim() == "") {
                errorMsg = errorMsg + "Please Select App Group<br/>";
            }
            if (data.logLevel == null || data.logLevel.trim() == "") {
                errorMsg = errorMsg + "Please Select Log Level<br/>";
            }
            if (data.description == null || data.description.trim() == "") {
                errorMsg = errorMsg + "Please Enter Description";
            }
        }
        if (errorMsg != "") {
            document.getElementById("errorStatus").innerHTML = errorMsg;
            return;
        }
        console.log("invalid operation:updateFlag:" + this.updateflag + ",appId:" + this.appId);
        if (this.updateflag == "1" && this.appId > 0) {
            this.updateApplication();
        }
        else {
            this.createApplication();
        }
    };
    NewInterfaceComponent.prototype.createApplication = function () {
        var _this = this;
        this._applicationService.createApplication(this.bioLogApplication).subscribe(function (serverResponse) {
            _this.interfaceName = _this.bioLogApplication.appName;
            _this.serverResponse = serverResponse;
            var errorCode = _this.serverResponse.errorCode;
            console.log("createApplication Transaction status :: " + _this.serverResponse.status);
            if (errorCode == "-1") {
                // document.getElementById("errorStatus").innerHTML = "Interface already Exists."; 
                document.getElementById("errorStatus").innerHTML = _this.serverResponse.errorDescription;
            }
            if (errorCode == "0") {
                //document.getElementById("errorStatus").innerHTML = "Interface Not created. Please try again."; 
                document.getElementById("errorStatus").innerHTML = _this.serverResponse.errorDescription;
            }
            if (errorCode == "-2") {
                document.getElementById("successStatus").innerHTML = "Interface created successfully.";
                //document.getElementById("errorStatus").innerHTML = "Source and Target Systems mappings Not Created. Please Edit in Edit page."; 
                document.getElementById("errorStatus").innerHTML = _this.serverResponse.errorDescription;
                _this.enableTab();
            }
            if (_this.serverResponse.status == 'SUCCESS') {
                _this.interfaceName = _this.bioLogApplication.appName;
                _this.appId = _this.serverResponse.id;
                document.getElementById("successStatus").innerHTML = "Interface created successfully.";
                document.getElementById("errorStatus").innerHTML = "";
                _this.enableTab();
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.updateApplication = function () {
        var _this = this;
        this._applicationService.upateApplication(this.bioLogApplication).subscribe(function (serverResponse) {
            _this.interfaceName = _this.bioLogApplication.appName;
            _this.serverResponse = serverResponse;
            var errorCode = _this.serverResponse.errorCode;
            console.log("upateApplication Transaction status :: " + _this.serverResponse.status);
            if (errorCode == "-2") {
                document.getElementById("errorStatus").innerHTML = _this.serverResponse.errorDescription;
                _this.enableTab();
            }
            if (_this.serverResponse.status == 'SUCCESS') {
                _this.appId = _this.serverResponse.id;
                document.getElementById("successStatus").innerHTML = "Interface Updated successfully.";
                document.getElementById("errorStatus").innerHTML = "";
                _this.enableTab();
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.saveNotification = function (data) {
        var arrayControl = this.notificationForm.get('notificationRows');
        this.bioNotifyList = [];
        //  var item = arrayControl.controls[0].value;
        for (var _i = 0, _a = arrayControl.controls; _i < _a.length; _i++) {
            var item = _a[_i];
            this.updateBioNotification = new _dao_bio_notification__WEBPACK_IMPORTED_MODULE_3__["BioNotification"]();
            this.updateBioNotification.exceptionCategory = item.value.exCategory;
            this.updateBioNotification.exceptionType = item.value.exType;
            this.updateBioNotification.aggregationEnabled = item.value.aggregationEnabled;
            this.updateBioNotification.aggregationCount = item.value.aggregationCount;
            this.updateBioNotification.ccemail = item.value.ccemail;
            this.updateBioNotification.frequency = item.value.frequency;
            this.updateBioNotification.notificationEnabled = item.value.notificationEnabled;
            this.updateBioNotification.notificationType = item.value.notificationType;
            this.updateBioNotification.template = item.value.template;
            this.updateBioNotification.thresholdEnabled = item.value.thresholdEnabled;
            this.updateBioNotification.thresholdLimit = item.value.thresholdLimit;
            this.updateBioNotification.toemail = item.value.toemail;
            if (item.value.notifyId != null && item.value.notifyId != '') {
                this.updateBioNotification.notifyId = item.value.notifyId;
            }
            else {
                this.updateBioNotification.notifyId = 0;
            }
            this.updateBioNotification.notifyPropsId = this.notifyPropsId;
            this.updateBioNotification.appId = this.appId;
            this.bioNotifyList.push(this.updateBioNotification);
        }
        this.bioNotification.appId = this.appId;
        if (this.notifyId > 0 && this.notifyPropsId > 0) {
            this._bioNotifyService.updateNotification(this.bioNotifyList).subscribe(function (response) {
                if (response.status == "SUCCESS") {
                    document.getElementById("notifyError").innerHTML = "";
                    document.getElementById("notifySuccess").innerHTML = "Notification Properties Updated successfully!";
                }
                else {
                    document.getElementById("notifyError").innerHTML = "Notification Updation Error. Please try again.";
                }
                //         this.notificationPropForm.reset();
            }),
                function (error) {
                    console.log(error);
                };
        }
        else {
            this._bioNotifyService.createNotification(this.bioNotifyList).subscribe(function (response) {
                if (response.status == "SUCCESS") {
                    document.getElementById("notifyError").innerHTML = "";
                    document.getElementById("notifySuccess").innerHTML = "Notification Properties created successfully!";
                }
                else {
                    document.getElementById("notifyError").innerHTML = "Notification Creation Error. Please try again.";
                }
                //         this.notificationPropForm.reset();
            }),
                function (error) {
                    console.log(error);
                };
        }
    };
    NewInterfaceComponent.prototype.enableTab = function () {
        $('#tab2').removeClass('disableTab');
        $('#tab3').removeClass('disableTab');
    };
    NewInterfaceComponent.prototype.saveInterfaceType = function (data) {
        var _this = this;
        console.log("saveInterfaceTypeName:" + data.interfaceTypeName);
        this.bioLogAppType.appType = data.interfaceTypeName;
        this.bioLogAppType.description = data.interfaceTypedescription;
        if (this.bioLogAppType.appType == null || this.bioLogAppType.appType.trim() == "") {
            document.getElementById("lstatus").innerHTML = "Please Enter Application Type";
            return;
        }
        this._applicationService.createAppType(this.bioLogAppType).subscribe(function (flag) {
            console.log("interface type create status :: " + flag);
            if (flag) {
                console.log("getting new apptype:");
                _this._applicationService.getAppTypeList().subscribe(function (appTypesListValues) {
                    //console.log(appTypesListValues);
                    _this.appTypeList = appTypesListValues;
                    _this.selectedAppType = _this.appTypeList[2];
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
        $('#addInterfaceType').click();
    };
    NewInterfaceComponent.prototype.saveInterfaceGroup = function (data) {
        var _this = this;
        console.log("saveInterfaceGroup:" + data.interfaceGroupName);
        this.bioLogAppGroup.appGroup = data.interfaceGroupName;
        this.bioLogAppGroup.description = data.intefaceGroupDescription;
        if (this.bioLogAppGroup.appGroup == null || this.bioLogAppGroup.appGroup.trim() == "") {
            document.getElementById("lstatus").innerHTML = "Please Enter Application Group";
            return;
        }
        this._applicationService.createAppGroup(this.bioLogAppGroup).subscribe(function (flag) {
            console.log("interface group create status :: " + flag);
            $('#addGroups').click();
            if (flag) {
                _this._applicationService.getAppGroupList().subscribe(function (appgroupListValues) {
                    //console.log(appgroupListValues);
                    _this.appGroupList = appgroupListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.onFileChanged = function (event) {
        var _this = this;
        this.selectedFile = event.target.files[0];
        console.log("data:" + this.selectedFile.size);
        this._bioAppDocHistoryService.uploadFile(this.appId, this.fileId, this.selectedFile).subscribe(function (fileId) {
            console.log("File upload Id  : " + fileId);
            _this.fileId = fileId;
        }), function (error) {
            console.log(error);
        };
    };
    NewInterfaceComponent.prototype.saveInterface = function (data) {
        var _this = this;
        //    console.log("saveInterface:"+data);
        console.log("integrationPattern:" + data.integrationPattern);
        var errorMsg = "";
        if (data.integrationPattern == null || data.integrationPattern.trim() == "") {
            errorMsg = errorMsg + "Please Select Integration Pattern</br>";
        }
        /*if(data.sourceType == null || data.sourceType.trim() == "")
        {
          errorMsg = errorMsg+ "Please Select Source Type</br>";
    
        }
        if(data.targetType == null || data.targetType.trim() == "")
        {
          errorMsg = errorMsg+ "Please Select Target Type</br>";
    
        }
        
        if(this.fileId == 0)
        {
          errorMsg = errorMsg+ "Please Upload File";
    
        }
        */
        if (errorMsg != "") {
            document.getElementById("integrationErrorStatus").innerHTML = errorMsg;
            return;
        }
        this.bioIntegrationDetails = new _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_11__["BioAppDocHistory"]();
        this.bioIntegrationDetails.fileId = this.fileId;
        this.bioIntegrationDetails.appId = this.appId;
        this.bioIntegrationDetails.integrationPatternId = data.integrationPattern;
        // this.bioIntegrationDetails.sourceTypeId = data.sourceType;
        // this.bioIntegrationDetails.targetTypeId = data.targetType;
        if (this.appIntegrationId != 0 && data.integrationPattern != "") {
            this.bioIntegrationDetails.appIntegrationId = this.appIntegrationId;
            this._applicationService.updateInterface(this.bioIntegrationDetails).subscribe(function (appIntegrationId) {
                console.log("Application integration Id :: " + appIntegrationId);
                if (appIntegrationId != 0) {
                    document.getElementById("integrationErrorStatus").innerHTML = "";
                    document.getElementById("integrationSuccessStatus").innerHTML = "Interface Created Successfully.";
                    _this.appIntegrationId = appIntegrationId;
                }
                else {
                    document.getElementById("integrationErrorStatus").innerHTML = "Error while creating Interface. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
        else {
            this._applicationService.createInterface(this.bioIntegrationDetails).subscribe(function (appIntegrationId) {
                console.log("Application integration Id :: " + appIntegrationId);
                if (appIntegrationId != 0) {
                    document.getElementById("integrationErrorStatus").innerHTML = "";
                    document.getElementById("integrationSuccessStatus").innerHTML = "Interface Created Successfully.";
                    _this.appIntegrationId = appIntegrationId;
                }
                else {
                    document.getElementById("integrationErrorStatus").innerHTML = "Error while creating Interface. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
    };
    NewInterfaceComponent.prototype.saveCRDetails = function (data) {
        var arrayControl = this.crForm.get('crRows');
        this.bioIntDet = [];
        for (var _i = 0, _a = arrayControl.controls; _i < _a.length; _i++) {
            var item = _a[_i];
            this.bioIntegrationDetails = new _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_11__["BioAppDocHistory"]();
            this.bioIntegrationDetails.appIntegrationId = this.appIntegrationId;
            //this.bioIntegrationDetails.appIntegrationId = 22;
            this.bioIntegrationDetails.crNo = item.value.crNo;
            this.bioIntegrationDetails.crDescription = item.value.crDescription;
            this.bioIntegrationDetails.implementedDate = item.value.crImplementationDate;
            this.bioIntegrationDetails.comments = item.value.crComments;
            if (item.value.crId != null && item.value.crId != '') {
                this.bioIntegrationDetails.sourceTypeId = item.value.crId;
            }
            else {
                this.bioIntegrationDetails.sourceTypeId = 0;
            }
            console.log("crId:" + item.value.crId);
            this.bioIntDet.push(this.bioIntegrationDetails);
        }
        if (this.crId > 0) {
            console.log("Update CR Details");
            this._applicationService.updateCRDetails(this.bioIntDet).subscribe(function (response) {
                //  console.log("updateCRDetails:: "+response);
                if (response.status == "SUCCESS") {
                    document.getElementById("crErrorStatus").innerHTML = "";
                    document.getElementById("crSuccessStatus").innerHTML = "CR Created Successfully.";
                }
                else {
                    document.getElementById("crErrorStatus").innerHTML = "Error while creating CR details. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
        else {
            console.log("Create CR Details");
            this._applicationService.createCRDetails(this.bioIntDet).subscribe(function (response) {
                // console.log("CR response :: "+response);
                if (response.status == "SUCCESS") {
                    document.getElementById("crErrorStatus").innerHTML = "";
                    document.getElementById("crSuccessStatus").innerHTML = "CR Created Successfully.";
                }
                else {
                    document.getElementById("crErrorStatus").innerHTML = "Error while creating CR details. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
    };
    NewInterfaceComponent.prototype.saveIntegrationPattern = function (data) {
        //console.log("saveIntegrationPattern name:"+data.integrationPattern);
        //   console.log("saveIntegrationPattern description:"+data.integrationPatternDescription);
        var _this = this;
        var errorMsg = "";
        if (data.integrationPattern == null || data.integrationPattern.trim() == "") {
            errorMsg = errorMsg + "Please Enter Integration Pattern Name</br>";
        }
        if (data.integrationPatternDescription == null || data.integrationPatternDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter  Integration Pattern Description";
        }
        if (errorMsg != "") {
            document.getElementById("integrationPatternStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.integrationPattern;
        this.bioLOVsData.description = data.integrationPatternDescription;
        this.bioLOVsData.type = "Integration Pattern";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("integration Pattern create status :: " + flag);
            $('#addintegrationPattern').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (patternListValues) {
                    //console.log(patternListValues);
                    _this.patternList = patternListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.saveSourceType = function (data) {
        //   console.log("saveSourceType name:"+data.sourceType);
        //  console.log("saveSourceType description:"+data.sourceTypeDescription);
        var _this = this;
        var errorMsg = "";
        if (data.sourceType == null || data.sourceType.trim() == "") {
            errorMsg = errorMsg + "Please Enter Source Type Name</br>";
        }
        if (data.sourceTypeDescription == null || data.sourceTypeDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter  Source Type Description";
        }
        if (errorMsg != "") {
            document.getElementById("sourceTypeStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.sourceType;
        this.bioLOVsData.description = data.sourceTypeDescription;
        this.bioLOVsData.type = "Source Type";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("integration Source Type create status :: " + flag);
            $('#addSourceType').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (sourceTypeListValues) {
                    //console.log(sourceTypeListValues);
                    _this.sourceTypeList = sourceTypeListValues;
                    _this.targetTypeList = sourceTypeListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.saveTargetType = function (data) {
        //console.log("saveTargetType name:"+data.targetTypename);
        //console.log("saveTargetType description:"+data.targetTypeDescription);
        var _this = this;
        var errorMsg = "";
        if (data.targetTypename == null || data.targetTypename.trim() == "") {
            errorMsg = errorMsg + "Please Enter Target Type Name</br>";
        }
        if (data.targetTypeDescription == null || data.targetTypeDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter  Target Type Description";
        }
        if (errorMsg != "") {
            document.getElementById("targetTypeStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.targetTypename;
        this.bioLOVsData.description = data.targetTypeDescription;
        this.bioLOVsData.type = "Target Type";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("integration Target Type create status :: " + flag);
            $('#addTargetType').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (targetTypeListValues) {
                    //     console.log(targetTypeListValues);
                    _this.targetTypeList = targetTypeListValues;
                    _this.sourceTypeList = targetTypeListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.saveEntity = function (data) {
        //console.log("saveEntity name:"+data.entityName);
        //console.log("saveEntity description:"+data.entityDescription);
        var _this = this;
        var errorMsg = "";
        if (data.entityName == null || data.entityName.trim() == "") {
            errorMsg = errorMsg + "Please Enter Entity Name</br>";
        }
        if (data.entityDescription == null || data.entityDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter Entity Description";
        }
        if (errorMsg != "") {
            document.getElementById("entityStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.entityName;
        this.bioLOVsData.description = data.entityDescription;
        this.bioLOVsData.type = "Entity";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("Entity create status :: " + flag);
            $('#addEntity').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (entityListValues) {
                    //    console.log(entityListValues);
                    _this.entityList = entityListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.saveEnterpriseService = function (data) {
        //  console.log("saveEnterpriseService name:"+data.esname);
        //console.log("saveEnterpriseService description:"+data.esDescription);
        var _this = this;
        var errorMsg = "";
        if (data.esname == null || data.esname.trim() == "") {
            errorMsg = errorMsg + "Please Enter Enterprise Service Name</br>";
        }
        if (data.esDescription == null || data.esDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter  Enterprise Service Description";
        }
        if (errorMsg != "") {
            document.getElementById("esStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.esname;
        this.bioLOVsData.description = data.esDescription;
        this.bioLOVsData.type = "ES";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("Enterprise service create status :: " + flag);
            $('#addEnterpriseService').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (esListValues) {
                    //console.log(esListValues);
                    _this.esList = esListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    NewInterfaceComponent.prototype.onNotificationTypeChange = function (data) {
        console.log("notifictaionTYpe:" + data);
        if (data == "SCHEDULED") {
            this.scheduledFlag = true;
        }
        else {
            this.scheduledFlag = false;
        }
    };
    NewInterfaceComponent.prototype.onThresholdChange = function (data) {
        console.log("onThresholdChange:" + data);
        if (data == "YES") {
            this.thresholdFlag = true;
        }
        else {
            this.thresholdFlag = false;
        }
    };
    NewInterfaceComponent.prototype.saveNewApplication = function (data) {
        //   console.log("saveNewApplication name:"+data.newApplicationName);
        //console.log("saveNewApplication description:"+data.newApplicationDescription);
        //console.log("save New Applciation: businessUnit:"+data.buName)
        var _this = this;
        var errorMsg = "";
        if (data.newApplicationName == null || data.newApplicationName.trim() == "") {
            errorMsg = errorMsg + "Please Enter Application Name</br>";
        }
        if (data.newApplicationDescription == null || data.newApplicationDescription.trim() == "") {
            errorMsg = errorMsg + "Please Enter Application Description";
        }
        if (errorMsg != "") {
            document.getElementById("newAppStatus").innerHTML = errorMsg;
            return;
        }
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_10__["BioLOVsData"]();
        this.bioLOVsData.name = data.newApplicationName;
        this.bioLOVsData.description = data.newApplicationDescription;
        this.bioLOVsData.status = data.buName;
        this.bioLOVsData.type = "APPLICATION";
        this._businessUnitService.createMasterData(this.bioLOVsData).subscribe(function (flag) {
            console.log("Application create status :: " + flag);
            $('#addApplication').click();
            if (flag) {
                _this._businessUnitService.getDetailsByType(_this.bioLOVsData.type).subscribe(function (appListValues) {
                    //console.log(appListValues);
                    _this.sourceAppNameList = appListValues;
                    _this.targetAppNameList = appListValues;
                }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    Object.defineProperty(NewInterfaceComponent.prototype, "formArr", {
        get: function () {
            return this.itpdForm.get('itemRows');
        },
        enumerable: true,
        configurable: true
    });
    NewInterfaceComponent.prototype.addmoreITPD = function () {
        this.formArr.push(this.initItemRows());
    };
    NewInterfaceComponent.prototype.deleteITPDRow = function (index) {
        this.formArr.removeAt(index);
    };
    NewInterfaceComponent.prototype.initItemRows = function () {
        return this._fb.group({
            ITPDNo: [''],
            itpdDescription: ['']
        });
    };
    Object.defineProperty(NewInterfaceComponent.prototype, "formCRArr", {
        get: function () {
            return this.crForm.get('crRows');
        },
        enumerable: true,
        configurable: true
    });
    NewInterfaceComponent.prototype.addmoreCR = function () {
        this.formCRArr.push(this.initCRRows());
    };
    NewInterfaceComponent.prototype.deleteCRRow = function (index) {
        this.formCRArr.removeAt(index);
    };
    NewInterfaceComponent.prototype.initCRRows = function () {
        return this._fb.group({
            crNo: [''],
            crDescription: [''],
            crImplementationDate: [''],
            crComments: ['']
        });
    };
    Object.defineProperty(NewInterfaceComponent.prototype, "formSourceSystemArr", {
        get: function () {
            return this.sourceSystemForm.get('sourceSystemRows');
        },
        enumerable: true,
        configurable: true
    });
    NewInterfaceComponent.prototype.addmoreSourceSystem = function () {
        this.formSourceSystemArr.push(this.initSourceSystemRows());
    };
    NewInterfaceComponent.prototype.deleteSourceSystemRow = function (index) {
        this.formSourceSystemArr.removeAt(index);
    };
    NewInterfaceComponent.prototype.initSourceSystemRows = function () {
        return this._fb.group({
            sourceAppName: [''],
            sourceAppType: [''],
        });
    };
    Object.defineProperty(NewInterfaceComponent.prototype, "formTargetSystemArr", {
        get: function () {
            return this.targetSystemForm.get('targetSystemRows');
        },
        enumerable: true,
        configurable: true
    });
    NewInterfaceComponent.prototype.addmoreTargetSystem = function () {
        this.formTargetSystemArr.push(this.initTargetSystemRows());
    };
    NewInterfaceComponent.prototype.deleteTargetSystemRow = function (index) {
        this.formTargetSystemArr.removeAt(index);
    };
    NewInterfaceComponent.prototype.initTargetSystemRows = function () {
        return this._fb.group({
            targetAppName: [''],
            targetAppType: [''],
        });
    };
    Object.defineProperty(NewInterfaceComponent.prototype, "formNotificationArr", {
        get: function () {
            return this.notificationForm.get('notificationRows');
        },
        enumerable: true,
        configurable: true
    });
    NewInterfaceComponent.prototype.addmoreNotification = function () {
        this.formNotificationArr.push(this.initNotificationRows());
    };
    NewInterfaceComponent.prototype.deleteNotificationRow = function (index) {
        this.formNotificationArr.removeAt(index);
    };
    NewInterfaceComponent.prototype.initNotificationRows = function () {
        return this._fb.group({
            exCategory: [''],
            exType: [''],
            notificationEnabled: [''],
            toemail: [''],
            ccemail: [''],
            template: [''],
            notificationType: [''],
            frequency: [''],
            thresholdEnabled: [''],
            thresholdLimit: [''],
            aggregationEnabled: [''],
            aggregationCount: ['']
        });
    };
    NewInterfaceComponent.prototype.saveITPDDetails = function (data) {
        var arrayControl = this.itpdForm.get('itemRows');
        this.bioIntDet = [];
        //  var item = arrayControl.controls[0].value;
        for (var _i = 0, _a = arrayControl.controls; _i < _a.length; _i++) {
            var item = _a[_i];
            this.bioIntegrationDetails = new _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_11__["BioAppDocHistory"]();
            this.bioIntegrationDetails.appIntegrationId = this.appIntegrationId;
            this.bioIntegrationDetails.itpdNo = item.value.ITPDNo;
            this.bioIntegrationDetails.itpdDescription = item.value.itpdDescription;
            if (item.value.itpdId != null && item.value.itpdId != '') {
                this.bioIntegrationDetails.sourceTypeId = item.value.itpdId;
            }
            else {
                this.bioIntegrationDetails.sourceTypeId = 0;
            }
            this.bioIntDet.push(this.bioIntegrationDetails);
            // console.log("itpd#"+item.value.ITPDNo);
            // console.log("itpd#"+item.value.itpdDescription);
            console.log("itpdID:" + item.value.itpdId);
        }
        if (this.itpdId > 0) {
            console.log("Update ITPD details");
            this._applicationService.updateITPDDetails(this.bioIntDet).subscribe(function (response) {
                console.log("ITPD response :: " + response);
                if (response.status == "SUCCESS") {
                    document.getElementById("itpdErrorStatus").innerHTML = "";
                    document.getElementById("itpdSuccessStatus").innerHTML = "ITPD Created Successfully.";
                }
                else {
                    document.getElementById("itpdErrorStatus").innerHTML = "Error while creating ITPD details. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
        else {
            console.log("Create ITPD details");
            this._applicationService.createITPDDetails(this.bioIntDet).subscribe(function (response) {
                console.log("ITPD response :: " + response);
                if (response.status == "SUCCESS") {
                    document.getElementById("itpdErrorStatus").innerHTML = "";
                    document.getElementById("itpdSuccessStatus").innerHTML = "ITPD Created Successfully.";
                }
                else {
                    document.getElementById("itpdErrorStatus").innerHTML = "Error while creating ITPD details. Please try again.";
                }
            }),
                function (error) {
                    console.log(error);
                };
        }
    };
    NewInterfaceComponent.prototype.onInterfaceSelcted = function (data) {
        var _this = this;
        //   console.log("onInterfaceSelcted--"+data);
        this.appId = 0;
        this.interfaceName = data;
        for (var _i = 0, _a = this.interfaceDetailsList; _i < _a.length; _i++) {
            var inter = _a[_i];
            if (inter.appName == data) {
                this.appId = inter.appId;
                this.updateflag = "1";
                this.defIntegrationPattern = "";
                break;
            }
        }
        console.log("appId:" + this.appId);
        if (this.appId > 0) {
            this._applicationService.getAppplicationDetails(this.appId).subscribe(function (bioLogApplicationData) {
                console.log("BioLogApplication Data for appID: " + JSON.stringify(bioLogApplicationData));
                _this.bioLogApplicationData = bioLogApplicationData;
                for (var _i = 0, _a = _this.bioLogApplicationData.businessInfoDataList; _i < _a.length; _i++) {
                    var bu = _a[_i];
                    if (bu.sourceTargetTypeInd != null && bu.sourceTargetTypeInd == 'S') {
                        _this.sourceBusinessId = bu.businessId;
                    }
                    if (bu.sourceTargetTypeInd != null && bu.sourceTargetTypeInd == 'T') {
                        _this.targetBusinessId = bu.businessId;
                    }
                }
                _this.appIntegrationId = _this.bioLogApplicationData.integrationDetails.integrationId;
                //  console.log("integrationPatternId:"+this.bioLogApplicationData.integrationDetails.integrationPatternId);
                //  console.log("this.appIntegrationId:"+this.appIntegrationId);
                if (_this.bioLogApplicationData.integrationDetails.fileId != null && _this.bioLogApplicationData.integrationDetails.fileId != 0) {
                    _this.fileId = _this.bioLogApplicationData.integrationDetails.fileId;
                }
                document.getElementById("successStatus").innerHTML = "";
                document.getElementById("errorStatus").innerHTML = "";
                if (_this.appId > 0) {
                    _this.enableTab();
                }
                _this.loadSourceSystems();
                _this.loadTargetSystems();
                _this.inerfaceName = _this.bioLogApplicationData.appName;
                _this.loadNotificationDetails();
                if (_this.bioLogApplicationData.integrationDetails.integrationPatternId != null && _this.bioLogApplicationData.integrationDetails.integrationPatternId != '0') {
                    _this.defIntegrationPattern = _this.bioLogApplicationData.integrationDetails.integrationPatternId;
                }
                _this.loadITPDDetails();
                _this.loadCRDetails();
            }), function (error) {
                console.log(error);
            };
        }
    };
    NewInterfaceComponent.prototype.loadNotificationDetails = function () {
        console.log("loadNotificationDetails");
        var arr = [];
        if (this.bioLogApplicationData.notificationList != null && this.bioLogApplicationData.notificationList.length > 0) {
            this.notifyId = 1;
            this.notifyPropsId = 1;
            for (var _i = 0, _a = this.bioLogApplicationData.notificationList; _i < _a.length; _i++) {
                var data = _a[_i];
                arr.push(this.loadNotificationRows(data));
            }
            this.notificationForm = this._fb.group({
                notificationRows: this._fb.array(arr)
            });
        }
        else {
            this.notificationForm = this._fb.group({
                notificationRows: this._fb.array([this.initNotificationRows()])
            });
        }
    };
    NewInterfaceComponent.prototype.loadSourceSystems = function () {
        console.log("loadSourceSystems");
        var arr = [];
        if (this.bioLogApplicationData.sourceAppList != null && this.bioLogApplicationData.sourceAppList.length > 0) {
            for (var _i = 0, _a = this.bioLogApplicationData.sourceAppList; _i < _a.length; _i++) {
                var data = _a[_i];
                /*         console.log("data.text:"+data.text)    ;
                         console.log("data.refId:"+data.refId) ;
                         console.log("data.businessId:"+data.id) ;*/
                arr.push(this.loadSourceSystemRows(data));
            }
            this.sourceSystemForm = this._fb.group({
                sourceSystemRows: this._fb.array(arr)
            });
        }
        else {
            this.sourceSystemForm = this._fb.group({
                sourceSystemRows: this._fb.array([this.initSourceSystemRows()])
            });
        }
    };
    NewInterfaceComponent.prototype.loadCRDetails = function () {
        console.log("loadCRDetails");
        var arr = [];
        if (this.bioLogApplicationData.integrationDetails.crDetailsList != null && this.bioLogApplicationData.integrationDetails.crDetailsList.length > 0) {
            this.crId = 1;
            for (var _i = 0, _a = this.bioLogApplicationData.integrationDetails.crDetailsList; _i < _a.length; _i++) {
                var data = _a[_i];
                /*   console.log("data.text:"+data.crNumber)    ;
                   console.log("data.refId:"+data.crDescription)    ;*/
                arr.push(this.loadCrRows(data));
            }
            this.deleteCRRow(0);
            this.crForm = this._fb.group({
                crRows: this._fb.array(arr)
            });
        }
        else {
            this.crForm = this._fb.group({
                crRows: this._fb.array([this.initCRRows()])
            });
        }
    };
    NewInterfaceComponent.prototype.loadCrRows = function (data) {
        /*        this.defcrNo = data.crNumber;
                this.defcrDesc = data.crDescription;
                this.defcrImplDate = data.crImplementationDate;
                this.defcrComments = data.comments;*/
        return this._fb.group({
            crNo: data.crNumber,
            crDescription: data.crDescription,
            crImplementationDate: data.crImplementationDate,
            crComments: data.comments,
            crId: data.crID
        });
    };
    NewInterfaceComponent.prototype.loadITPDDetails = function () {
        console.log("loadITPDDetails");
        var arr = [];
        if (this.bioLogApplicationData.integrationDetails.itpdDetailsList != null && this.bioLogApplicationData.integrationDetails.itpdDetailsList.length > 0) {
            this.itpdId = 1;
            for (var _i = 0, _a = this.bioLogApplicationData.integrationDetails.itpdDetailsList; _i < _a.length; _i++) {
                var data = _a[_i];
                /*        console.log("data.text:"+data.itpdNumber)    ;
                        console.log("data.refId:"+data.itpdDescription)    ;*/
                arr.push(this.loadITPDRows(data));
            }
            this.itpdForm = this._fb.group({
                itemRows: this._fb.array(arr)
            });
        }
        else {
            this.itpdForm = this._fb.group({
                itemRows: this._fb.array([this.initItemRows()])
            });
        }
    };
    NewInterfaceComponent.prototype.loadITPDRows = function (data) {
        // this.defitpdNumber=data.itpdNumber;
        // this.defitpdDescription=data.itpdDescription;
        return this._fb.group({
            ITPDNo: data.itpdNumber,
            itpdDescription: data.itpdDescription,
            itpdId: data.itpdID
        });
    };
    NewInterfaceComponent.prototype.loadTargetSystems = function () {
        console.log("loadTargetSystems");
        var arr = [];
        if (this.bioLogApplicationData.targetAppList != null && this.bioLogApplicationData.targetAppList.length > 0) {
            for (var _i = 0, _a = this.bioLogApplicationData.targetAppList; _i < _a.length; _i++) {
                var data = _a[_i];
                /*  console.log("data.text:"+data.text)    ;
                  console.log("data.refId:"+data.refId)    ;
                  console.log("data.businessId:"+data.id) ;*/
                arr.push(this.loadTargetSystemRows(data));
            }
            this.targetSystemForm = this._fb.group({
                targetSystemRows: this._fb.array(arr)
            });
        }
        else {
            this.targetSystemForm = this._fb.group({
                targetSystemRows: this._fb.array([this.initTargetSystemRows()])
            });
        }
    };
    NewInterfaceComponent.prototype.loadSourceSystemRows = function (data) {
        return this._fb.group({
            sourceAppName: data.text,
            sourceAppType: data.refId,
            businessId: data.id
        });
    };
    NewInterfaceComponent.prototype.loadTargetSystemRows = function (data) {
        return this._fb.group({
            targetAppName: data.text,
            targetAppType: data.refId,
            businessId: data.id
        });
    };
    NewInterfaceComponent.prototype.loadNotificationRows = function (data) {
        /*console.log("loadNotifcaionRows:"+JSON.stringify(data));
        this.bioNotification.exceptionCategory = data.exceptionCategory;
          this.bioNotification.exceptionType = data.exceptionType;
          this.bioNotification.aggregationEnabled = data.aggregationEnabled;
          this.bioNotification.aggregationCount = data.aggregationCount
          this.bioNotification.ccemail = data.ccemail;
          this.bioNotification.frequency = data.frequency;
          this.bioNotification.notificationEnabled = data.notificationEnabled
          this.bioNotification.notificationType = data.notificationType
          this.bioNotification.template= data.template;
            this.bioNotification.thresholdEnabled = "";
            if(data.thresholdEnabled != null &&  data.thresholdEnabled !=""){
              this.bioNotification.thresholdEnabled = data.thresholdEnabled;
            }
          this.bioNotification.thresholdLimit = data.thresholdLimit;
          this.bioNotification.toemail =  data.toemail;*/
        var thresholdEnabled = '';
        if (data.thresholdEnabled != null && data.thresholdEnabled != "") {
            thresholdEnabled = data.thresholdEnabled;
        }
        return this._fb.group({
            exCategory: data.exceptionCategory,
            exType: data.exceptionType,
            notificationEnabled: data.notificationEnabled,
            toemail: data.toemail,
            ccemail: data.ccemail,
            template: data.template,
            notificationType: data.notificationType,
            frequency: data.frequency,
            thresholdEnabled: thresholdEnabled,
            thresholdLimit: data.thresholdLimit,
            aggregationEnabled: data.aggregationEnabled,
            aggregationCount: data.aggregationCount,
            notifyId: data.notifyId
        });
    };
    NewInterfaceComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-new-interface',
            template: __webpack_require__(/*! ./new-interface.component.html */ "./src/app/components/new-interface/new-interface.component.html"),
            styles: [__webpack_require__(/*! ./new-interface.component.css */ "./src/app/components/new-interface/new-interface.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"], _service_bio_app_doc_history_service__WEBPACK_IMPORTED_MODULE_9__["BioAppDocHistoryService"], _service_application_service__WEBPACK_IMPORTED_MODULE_4__["ApplicationService"], _service_business_unit_service__WEBPACK_IMPORTED_MODULE_5__["BusinessUnitService"], _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_2__["BioNotifyService"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_12__["Ng4LoadingSpinnerService"]])
    ], NewInterfaceComponent);
    return NewInterfaceComponent;
}());



/***/ }),

/***/ "./src/app/components/notification-details-model/notification-details-model.component.css":
/*!************************************************************************************************!*\
  !*** ./src/app/components/notification-details-model/notification-details-model.component.css ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/notification-details-model/notification-details-model.component.html":
/*!*************************************************************************************************!*\
  !*** ./src/app/components/notification-details-model/notification-details-model.component.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- The Modal -->\n<div class=\"modal\" id=\"myModal\">\n    <div id=\"modelResize\" class=\"modal-dialog modalDialogBox\">\n    <div class=\"modal-content\">\n    \n      <!-- Modal Header -->\n      <div class=\"modal-header\">\n          <div class=\"row\">\n              <h4 class=\"modal-title\">Notification Detail</h4>          \n          <button type=\"button\" id=\"b1\" class=\"close\" (click)=\"closeModel()\" data-dismiss=\"modal\">&times;</button>\n          <button type=\"button\" class=\"btn btn-default reduce reduce\" onclick=\"reduce()\" style=\"display:none\"><img src=\"assets/img/reduce.png\" alt=\"Resize\" height=\"15\"/></button>\n          <button type=\"button\" class=\"btn btn-default resize  enlarge\" onclick=\"resize()\"><img src=\"assets/img/enlarge.png\" alt=\"Resize\" height=\"15\"/></button>\n          </div>          \n        </div>\n    \n      <!-- Modal body -->\n      <div class=\"modal-body\">\n        <div class=\"content-wrapper\" style=\"padding-top:20px !important\">\n          <section class=\"content\">\n            <div class=\"row\">\n              <div class=\"col-md-12\">\n\n          <div class=\"log_tab\">\n               <div class=\"row\">\n                <div class=\"bioid\"><b>Notify History Id : <span>{{notifyHistoryId}}</span></b></div>\n                <div class=\"bioid\"><b>From Email : <span>{{fromEmail}}</span></b></div>\n                <div class=\"bioid\"><b>To Email : <span>{{toEmail}}</span></b></div>\n                <div class=\"bioid\"><b>CC Email : <span>{{ccEmail}}</span></b></div>\n                   <table class=\"logdet table-striped\" border=\"1\">\n                      <tr>\n                          <td width=\"15%\"> <b>Name</b></td>\n                          <td><b>Value</b> </td>\n                      </tr>\n                      <tr *ngFor=\"let bioNotifyDetails of bioNotifyDetailsList\">\n                          <td> {{bioNotifyDetails.name}}</td>\n                          <td> {{bioNotifyDetails.value}}</td>\n                      </tr>\n                    </table>\n                    <div class=\"spc_line\"></div>\n          </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/components/notification-details-model/notification-details-model.component.ts":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/notification-details-model/notification-details-model.component.ts ***!
  \***********************************************************************************************/
/*! exports provided: NotificationDetailsModelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationDetailsModelComponent", function() { return NotificationDetailsModelComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var NotificationDetailsModelComponent = /** @class */ (function () {
    function NotificationDetailsModelComponent() {
    }
    NotificationDetailsModelComponent.prototype.ngOnInit = function () {
        console.log("NotificationDetailsModelComponent ngOnInit()" + this.notifyHistoryId);
    };
    NotificationDetailsModelComponent.prototype.closeModel = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('notifyHistoryId'),
        __metadata("design:type", String)
    ], NotificationDetailsModelComponent.prototype, "notifyHistoryId", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('fromEmail'),
        __metadata("design:type", String)
    ], NotificationDetailsModelComponent.prototype, "fromEmail", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('toEmail'),
        __metadata("design:type", String)
    ], NotificationDetailsModelComponent.prototype, "toEmail", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('ccEmail'),
        __metadata("design:type", String)
    ], NotificationDetailsModelComponent.prototype, "ccEmail", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('bioNotifyDetailsList'),
        __metadata("design:type", Array)
    ], NotificationDetailsModelComponent.prototype, "bioNotifyDetailsList", void 0);
    NotificationDetailsModelComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-notification-details-model',
            template: __webpack_require__(/*! ./notification-details-model.component.html */ "./src/app/components/notification-details-model/notification-details-model.component.html"),
            styles: [__webpack_require__(/*! ./notification-details-model.component.css */ "./src/app/components/notification-details-model/notification-details-model.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], NotificationDetailsModelComponent);
    return NotificationDetailsModelComponent;
}());



/***/ }),

/***/ "./src/app/components/notification/notification.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/notification/notification.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/notification/notification.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/components/notification/notification.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper notification\">\n    <ol class=\"breadcrumb\">\n        <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n        <li class=\"breadcrumb-item\">Notification</li>\n      </ol>\n    <section class=\"content\">\n        <div class=\"row\">\n            <form #buSearchForm = \"ngForm\" (ngSubmit) = \"buSearch(buSearchForm.value)\" class=\"form-horizontal\" role=\"form\"> \n            <div class=\"loggingSearchingBox\">\n              <div class=\"fieldBox\">\n                  <select class=\"form-control \" id=\"buint\" name=\"buint\" (change)=\"onBUChange($event.target.value)\" [(ngModel)]='defBU' [value]='defBU' ngModel>\n                      <option *ngFor=\"let bunit of bunitList\" value={{bunit.id}}>{{bunit.name}}</option>\n                    </select>\n              </div>\n              <div class=\"fieldBox\">\n                  <select class=\"form-control \" id=\"buAppName\" name=\"buAppName\" (change)=\"onBUAppNameChange($event.target.value)\" [(ngModel)]='defBUAppName' [value]='defBUAppName' ngModel>\n                      <option *ngFor=\"let buAppName of buAppNameList\" value={{buAppName.id}}>{{buAppName.name}}</option>\n                    </select>\n                </div>\n                <div class=\"fieldBox\">\n                    <select class=\"form-control \" id=\"entity\" name=\"entity\" (change)=\"onEntityChange($event.target.value)\" [(ngModel)]='defBUEntity' ngModel>\n                        <option *ngFor=\"let entity of entityList\" value={{entity.id}}>{{entity.name}}</option>\n                      </select>\n                  </div>\n                  <div class=\"fieldBox\">\n                      <select class=\"form-control \" id=\"es\" name=\"es\" [(ngModel)]='defBUes' ngModel>\n                          <option *ngFor=\"let es of esList\" value={{es.id}}>{{es.name}}</option>\n                        </select>\n                    </div>\n                    <div class=\"fieldBox\" > <!--style=\"width:30px !important\" -->\n                      <select class=\"form-control \" id=\"duration\" name=\"duration\" [(ngModel)]=\"defDuration\" ngModel>\n                        <option value='0' disabled>Days</option>\n                        <option value='1'>today</option>\n                      <option value='7'>7 days</option>\n                      <option value='15'>15 days</option>\n                      <option value='30'>30 days</option>\n                      <option value='60'>60 days</option>\n                      <option value='90'>90 days</option>\n                    </select>\n                  </div>\n          \n                    <div class=\"searchBtnBox\">\n                        <button type=\"submit\" id=\"logSearchBtn\" class=\"btn btn-primary\" name=\"logSearchBtn\">Search &nbsp;<i class=\"fa fa-search\" aria-hidden=\"true\"></i></button> \n                      </div>\n            </div>\n            </form>\n        </div>\n        \n            <div class=\"clearfix\"></div>\n            <div class=\"col-sm-12\" style=\"padding-right:0 !important\">\n                <a id=\"p1\" class=\"pull-right\" onclick=\"showBox()\">Show Advance Search</a>\n                <a id=\"p2\" class=\"pull-right\" onclick=\"hideBox()\" style=\"display:none\">Hide Advance Search</a>\n              </div>\n              <div class=\"clearfix\"></div>\n              <div class=\"row\">\n                  <form #logSearchForm=\"ngForm\" (ngSubmit)=\"notificationSearch(logSearchForm.value)\" class=\"form-horizontal\" role=\"form\">\n                    <div class=\"notificationAdvSearchingBox\" id=\"advanceSearch\" style=\"display:none\">\n                      <div class=\"header\">\n                        <span class=\"advText\">Advance Search</span>                       \n                            <button type=\"submit\"  id=\"nottifySearchBtn\" name=\"nottifySearchBtn\" class=\"refreshBtn  pull-right\">\n                             <i class=\"fa fa-refresh\" aria-hidden=\"true\"></i></button> \n                      </div>\n                      <div class=\"clearfix\"></div>\n                      <div class=\"advContent\">\n                        <div class=\"lineRow\">\n                          <div class=\"fieldBox\">\n                              <select class=\"form-control \" id=\"appGroup\" name=\"appGroup\" (change)=\"onAppGroupChange($event.target.value)\" ngModel>\n                                  <option value=\"\" selected>App Group</option>\n                                  <option *ngFor=\"let appGroup of appGroupList\" value= {{appGroup.appGroup}}>{{appGroup.appGroup}}</option>\n                                </select>\n                          </div>\n                          <div class=\"fieldBox\">\n                              <select class=\"form-control \" id=\"appName\" name=\"appName\" (change)=\"onChangeAppName($event.target.value)\" ngModel>\n                                  <option value=\"\" selected>Interface Name</option>\n                                  <option *ngFor=\"let appName of appNameList\" value= {{appName.appName}}>{{appName.appName}}</option>\n                                </select>\n                          </div>\n                          <div class=\"fieldBox\">\n                             <select class=\"form-control \" id=\"exCategory\" name=\"exCategory\" ngModel>\n                          <option value=\"\" selected>ExCategory</option>\n                          <option *ngFor=\"let exCategory of exCategoryList\" value= {{exCategory}}>{{exCategory}}</option>\n                        </select>\n                          </div>\n                          <div class=\"fieldBox\">\n                               <select class=\"form-control \" id=\"exType\" name=\"exType\" ngModel>\n                          <option value=\"\" selected>ExType</option>\n                          <option *ngFor=\"let exType of exTypeList\" value= {{exType}}>{{exType}}</option>\n                        </select>\n                          </div>\n                          <div class=\"fieldBox\">\n                              <select class=\"form-control \" id=\"status\" name=\"status\" ngModel>\n                                  <option value=\"\" selected>Status</option>\n                                  <option *ngFor=\"let status of statusList\" value= {{status}}>{{status}}</option>\n                                </select>\n                          </div>\n            <div class=\"fieldBox datepick\">\n              <input [owlDateTime]=\"dt1\" id=\"startDate\" name=\"startDate\" [max]=\"maxDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt1\" placeholder=\"Start Date Time\" ngModel>\n              <owl-date-time #dt1></owl-date-time>\n          </div>\n          <div class=\"fieldBox datepick\">\n            <input [owlDateTime]=\"dt2\" id=\"endDate\" name=\"endDate\" [max]=\"maxDate\" class=\"form-control\" [owlDateTimeTrigger]=\"dt2\" placeholder=\"End Date Time\" ngModel>\n            <owl-date-time #dt2></owl-date-time>\n        </div>\n                        </div>\n                        <div class=\"searchBtnBox\">\n                        <button type=\"submit\" id=\"nottifySearchBtn\"  name=\"nottifySearchBtn\" ><i class=\"fa fa-search\" aria-hidden=\"true\"></i></button>\n                        </div>\n                        <div class=\"clearfix\"></div>\n                  \n                      </div>\n              \n                    </div>\n              \n                  </form>\n                </div>\n                <div class=\"clearfix\"></div>\n\n\n          <div>\n\n\n\n \n    \n    \n    <div class=\"table_color3\">\n        <div class=\"row\">\n              <div class=\"container-fluid\">\n                  <ag-grid-angular \n                    style=\"height: 530px;\" \n                    class=\"col8-Grid ag-theme-balham\"\n                    [rowData]=\"rowData\" \n                    [columnDefs]=\"columnDefs\"\n                    [enableSorting]=\"true\"\n                    [enableFilter]=\"true\"\n                    [rowHeight]=\"30\"                   \n                    [suppressRowClickSelection]=\"true\"\n                    [debug]=\"true\"\n                    [enableColResize]=\"true\"\n                    [enableRangeSelection]=\"true\"\n                    [paginationAutoPageSize]=\"false\"\n                     [pagination]=\"true\" \n                     [paginationPageSize]=15\n                    [overlayLoadingTemplate]=\"overlayLoadingTemplate\"\n                    (gridReady)=\"onGridReady($event)\"\n                    (cellClicked)=\"onCellClicked($event)\"\n                    (rowClicked)=\"onRowClicked($event)\"\n                    >\n                </ag-grid-angular>\n                \n  <div class=\"app_btn\">\n    <button type=\"button\" class=\"btn btn-primary downloadBtn\" data-toggle=\"modal\" data-target=\"\" id=\"exportData\" name=\"exportData\" (click)=\"exportData()\"><span class=\"glyphicon glyphicon-download-alt\"></span> Download</button> \n  </div>\n\n  </div>\n</div>\n</div>\n  </div>\n     \n</section>\n</div>\n\n<app-notification-details-model \n[notifyHistoryId]=notifyHistoryId \n[fromEmail]=fromEmail \n[toEmail]=toEmail \n[ccEmail]=ccEmail \n[bioNotifyDetailsList]=bioNotifyDetailsList>\n</app-notification-details-model>\n<app-log-details-model [bioTransId]=bioTransId [bioLogDetailsList]=bioLogDetailsList\n  [targetSystemLogDetailsList]=targetSystemLogDetailsList></app-log-details-model>\n"

/***/ }),

/***/ "./src/app/components/notification/notification.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/notification/notification.component.ts ***!
  \*******************************************************************/
/*! exports provided: NotificationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationComponent", function() { return NotificationComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/bio-notify.service */ "./src/app/service/bio-notify.service.ts");
/* harmony import */ var _service_application_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/application.service */ "./src/app/service/application.service.ts");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _dao_bio_notify_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../dao/bio-notify-search */ "./src/app/dao/bio-notify-search.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _dao_bio_notify_props_temp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../dao/bio-notify-props-temp */ "./src/app/dao/bio-notify-props-temp.ts");
/* harmony import */ var _dao_busearch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../dao/busearch */ "./src/app/dao/busearch.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _service_bio_log_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../service/bio-log.service */ "./src/app/service/bio-log.service.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var NotificationComponent = /** @class */ (function () {
    function NotificationComponent(spinnerService, _bioLogService, _bioNotifyService, _applicationService, _businessUnitService, _router, _datePipe, route) {
        this.spinnerService = spinnerService;
        this._bioLogService = _bioLogService;
        this._bioNotifyService = _bioNotifyService;
        this._applicationService = _applicationService;
        this._businessUnitService = _businessUnitService;
        this._router = _router;
        this._datePipe = _datePipe;
        this.route = route;
        this.rowData = [];
        this.columnDefs = [];
        this.exCategoryList = [];
        this.exTypeList = [];
        this.statusList = [];
        this.bunitList = [];
        this.buAppNameList = [];
        this.entityList = [];
        this.esList = [];
        this.duration = 1;
        this.status = "";
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.bioNotifySearch = new _dao_bio_notify_search__WEBPACK_IMPORTED_MODULE_4__["BioNotifySearch"]();
        this.bioNotifyPropsTemp = new _dao_bio_notify_props_temp__WEBPACK_IMPORTED_MODULE_6__["BioNotifyPropsTemp"]();
        this.busearch = null;
        this.title = 'Notification Search';
        this.maxDate = new Date();
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
        this.defDuration = 1;
        console.log("notification*****BioTransId******* " + _applicationService.getBiogenTransId());
    }
    NotificationComponent.prototype.setDefaultValue = function (name) {
        this.duration = 1;
        if (name == "Application") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
        }
        if (name == "Entity") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
        }
        if (name == "Enterprise Service") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
        if (name == "ALL") {
            var data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Application";
            this.buAppNameList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Entity";
            this.entityList.push(data);
            data = null;
            data = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_11__["BioLOVsData"]();
            data.id = 0;
            data.name = "Enterprise Service";
            this.esList.push(data);
        }
    };
    NotificationComponent.prototype.setDefaultValues = function () {
        this.defBU = "0";
        this.defBUAppName = "0";
        this.defBUEntity = "0";
        this.defBUes = "0";
        this.defDuration = 1;
    };
    NotificationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.spinnerService.show();
        this.columnDefs = [
            { headerName: 'Notify History Id', field: 'notifyHistoryId', width: 0, hide: true },
            { headerName: 'Bio Trans Id', field: 'biogenTransId', width: 0, hide: true },
            { headerName: 'App Group', field: 'appGroup', width: 120 },
            { headerName: 'Interface Name', field: 'appName', width: 175, editable: true },
            { headerName: 'Exception Category', field: 'exCategory', width: 150 },
            { headerName: 'Duration', field: 'duration', width: 150, editable: true },
            { headerName: 'Exception Type', field: 'exType', width: 120,
                cellRenderer: function (params) {
                    // var html =  '<a>'+params.data.exType+'</a>';
                    var html = '<a data-toggle="modal" data-target="#loggingDetailsModal" href="#">' + params.data.exType + '</a>';
                    return html;
                }
            },
            { headerName: 'Status', field: 'status', width: 80,
                cellRenderer: function (params) {
                    var html = '<a data-toggle="modal" data-target="#myModal" href="#">' + params.data.status + '</a>';
                    return html;
                }
            },
            { headerName: 'Created Date', field: 'createdDate', width: 170 },
            { headerName: 'Updated Date', field: 'updatedDate', width: 170 }
        ];
        this.overlayLoadingTemplate =
            '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
        this.overlayNoRowsTemplate =
            '<span class="ag-overlay-loading-center">No Rows to display</span>';
        if (this._applicationService.getBiogenTransId() != null && this._applicationService.getBiogenTransId() != '') {
            this.bioNotifySearch.bioTransId = this._applicationService.getBiogenTransId();
            console.log("load notification details based on biogen transId:" + this._applicationService.getBiogenTransId());
            this._bioNotifyService.getBioNotificationHistoryByAdSearch(this.bioNotifySearch).subscribe(function (bioNotify) {
                _this._applicationService.setBiogenTransId("");
                _this.rowData = bioNotify;
                _this.spinnerService.hide();
            }, function () { return _this.spinnerService.hide(); }), function (error) {
                console.log(error);
            };
        }
        else {
            console.log("load notification details order by date");
            this._bioNotifyService.getBioNotificationHistory().subscribe(function (bioNotify) {
                _this.rowData = bioNotify;
                _this.spinnerService.hide();
            }, function () { return _this.spinnerService.hide(); }), function (error) {
                console.log(error);
            };
        }
        this._applicationService.getAppGroupList().subscribe(function (appGroupListValues) {
            // console.log("appGroupListValues : "+appGroupListValues);
            _this.appGroupList = appGroupListValues;
        }), function (error) {
            console.log(error);
        };
        this._bioNotifyService.getBNHStatusList().subscribe(function (bnhStatusListValues) {
            //console.log("bnhStatusListValues : "+bnhStatusListValues);
            _this.statusList = bnhStatusListValues;
        }), function (error) {
            console.log(error);
        };
        this._businessUnitService.getBUnit().subscribe(function (bunitListValues) {
            _this.bunitList = bunitListValues;
            _this.setDefaultValue("ALL");
        }), function (error) {
            console.log(error);
        };
    };
    //rowData = getRowData();
    NotificationComponent.prototype.onGridReady = function (params) {
        this.gridApi = params.api;
        //this.gridApi.showLoadingOverlay();
    };
    NotificationComponent.prototype.onChangeAppName = function (appName) {
        var _this = this;
        this._bioNotifyService.getExCategoryAndExTypeByAppName(appName).subscribe(function (bioNotifyPropsTempValues) {
            _this.bioNotifyPropsTemp = bioNotifyPropsTempValues;
            _this.exCategoryList = _this.bioNotifyPropsTemp.exCategoryList;
            _this.exTypeList = _this.bioNotifyPropsTemp.exTypeList;
        }), function (error) {
            console.log(error);
        };
    };
    NotificationComponent.prototype.onBUChange = function (bunit) {
        var _this = this;
        console.log("bunit:" + bunit);
        this.buAppNameList = [];
        this.entityList = [];
        this.esList = [];
        this.bunitTemp = "";
        this.buAppNameTemp = "";
        this.entitytemp = "";
        this.setDefaultValues();
        this.setDefaultValue("Entity");
        this.setDefaultValue("Enterprise Service");
        console.log("this.defBUAPPname:" + this.defBUAppName);
        if (bunit != null && bunit != 0) {
            this.bunitTemp = bunit;
            this._businessUnitService.getAppNameByBUnit(bunit).subscribe(function (buAppNameListValues) {
                _this.buAppNameList = buAppNameListValues;
            }), function (error) {
                console.log(error);
            };
        }
    };
    NotificationComponent.prototype.onBUAppNameChange = function (buAppName) {
        var _this = this;
        this.entityList = [];
        this.esList = [];
        this.buAppNameTemp = "";
        this.entitytemp = "";
        // this.buAppNameTemp = buAppName;
        this.setDefaultValues();
        console.log("this.defBUAppName:" + this.defBUAppName);
        if (buAppName != "" && buAppName != "0") {
            //     console.log("inside On bu appnamechange if:"+buAppName);
            this.buAppNameTemp = buAppName;
            this._businessUnitService.getEntityNameByApplicationId(buAppName).subscribe(function (entityListValues) {
                _this.entityList = entityListValues;
                _this.setDefaultValue("Enterprise Service");
            }), function (error) {
                console.log(error);
            };
        }
        else {
            //  console.log("inside On bu appnamechange else:")
            this.setDefaultValue("Entity");
            this.setDefaultValue("Enterprise Service");
        }
    };
    NotificationComponent.prototype.onEntityChange = function (entity) {
        var _this = this;
        this.esList = [];
        this.entitytemp = "";
        this.setDefaultValues();
        if (entity != "" && entity != "0") {
            this.entitytemp = entity;
            this._businessUnitService.getESNameByEntityId(entity).subscribe(function (esListValues) {
                _this.esList = esListValues;
            }), function (error) {
                console.log(error);
            };
        }
        else {
            this.setDefaultValue("Enterprise Service");
        }
    };
    NotificationComponent.prototype.onCellClicked = function (event) {
        console.log("onCellClicked " + event.colDef.headerName);
        if (event.colDef.headerName == "View") {
            this.status = "View";
        }
        else if (event.colDef.headerName == "View Tab") {
            this.status = "View Tab";
        }
        if (event.colDef.headerName == "Status") {
            this.status = "Status";
        }
        else if (event.colDef.headerName == "Status Tab") {
            this.status = "Status Tab";
        }
        else if (event.colDef.headerName == "logDet") {
            this.status = "logViewTab";
        }
        else if (event.colDef.headerName == "Exception Type") {
            this.status = "Exception Type";
        }
    };
    NotificationComponent.prototype.onRowClicked = function (event) {
        var _this = this;
        if (this.status == "Status") {
            console.log(" Notification view");
            this.notifyHistoryId = event.data.notifyHistoryId;
            this._bioNotifyService.getBioNotifyProps(this.notifyHistoryId).subscribe(function (bioNotifyPropsTempList) {
                console.log(bioNotifyPropsTempList);
                for (var _i = 0, bioNotifyPropsTempList_1 = bioNotifyPropsTempList; _i < bioNotifyPropsTempList_1.length; _i++) {
                    var bioNotifyPropsTemp = bioNotifyPropsTempList_1[_i];
                    console.log("getBioNotifyProps " + bioNotifyPropsTemp);
                    if (bioNotifyPropsTemp.name == "FROM_EMAIL") {
                        _this.fromEmail = bioNotifyPropsTemp.value;
                    }
                    if (bioNotifyPropsTemp.name == "TO_EMAIL") {
                        _this.toEmail = bioNotifyPropsTemp.value;
                    }
                    if (bioNotifyPropsTemp.name == "CC_EMAIL") {
                        _this.ccEmail = bioNotifyPropsTemp.value;
                    }
                }
            }), function (error) {
                console.log(error);
            };
            this._bioNotifyService.getNotificationHistoryDetails(event.data.notifyHistoryId).subscribe(function (bioNotifyDetails) {
                //debugger;
                console.log(bioNotifyDetails);
                _this.bioNotifyDetailsList = bioNotifyDetails;
            }), function (error) {
                console.log(error);
            };
        }
        if (this.status == "View") {
            console.log(" Notification view");
            this.notifyHistoryId = event.data.notifyHistoryId;
            this._bioNotifyService.getBioNotifyProps(this.notifyHistoryId).subscribe(function (bioNotifyPropsTempList) {
                //        console.log(bioNotifyPropsTempList);
                for (var _i = 0, bioNotifyPropsTempList_2 = bioNotifyPropsTempList; _i < bioNotifyPropsTempList_2.length; _i++) {
                    var bioNotifyPropsTemp = bioNotifyPropsTempList_2[_i];
                    //        console.log("getBioNotifyProps "+bioNotifyPropsTemp);
                    if (bioNotifyPropsTemp.name == "FROM_EMAIL") {
                        _this.fromEmail = bioNotifyPropsTemp.value;
                    }
                    if (bioNotifyPropsTemp.name == "TO_EMAIL") {
                        _this.toEmail = bioNotifyPropsTemp.value;
                    }
                    if (bioNotifyPropsTemp.name == "CC_EMAIL") {
                        _this.ccEmail = bioNotifyPropsTemp.value;
                    }
                }
            }), function (error) {
                console.log(error);
            };
            this._bioNotifyService.getNotificationHistoryDetails(event.data.notifyHistoryId).subscribe(function (bioNotifyDetails) {
                //debugger;
                //    console.log(bioNotifyDetails);
                _this.bioNotifyDetailsList = bioNotifyDetails;
            }), function (error) {
                console.log(error);
            };
        }
        if (this.status == "Exception Type") {
            console.log('Exception type', event.data.biogenTransId);
            console.log('View', event.data.biogenTransId);
            this.bioTransId = event.data.biogenTransId;
            this._bioLogService.getDetailedLogDetails(this.bioTransId).subscribe(function (bioLogDetails) {
                //debugger;
                console.log("************* " + bioLogDetails.length);
                //this.bioLogDetailsList = bioLogDetails;
                _this.bioLogDetailsTemp = bioLogDetails;
                _this.bioLogDetailsList = _this.bioLogDetailsTemp.bioLogDetailsList;
                _this.targetSystemLogDetailsList = _this.bioLogDetailsTemp.targetSystemLogDetailsList;
            }), function (error) {
                console.log(error);
            };
            this.status = "";
        }
    };
    NotificationComponent.prototype.exportData = function () {
        var params = {
            fileName: "NotificationSearch_" + this._datePipe.transform(new Date(), "yyyyMMddhhmmss") + ".csv",
            columnKeys: ['appGroup', 'appName', 'exCategory', 'exType', 'status', 'createdDate', 'updatedDate']
        };
        this.gridApi.exportDataAsCsv(params);
    };
    NotificationComponent.prototype.notificationSearch = function (data) {
        var _this = this;
        this.spinnerService.show();
        /*    console.log("appGroup "+data.appGroup);
            console.log("appName "+data.appName);
            console.log("status "+data.status);
            console.log("exCategory "+data.exCategory);
            console.log("exType "+data.exType);
            console.log("startDate "+data.startDate);
            console.log("endDate "+data.endDate);
        */
        var predate = new Date();
        var date = predate.getDate();
        var month = predate.getMonth() + 1;
        var year = predate.getFullYear();
        var monthStr = "";
        var dateStr = "";
        if (month < 10) {
            monthStr = "0" + month;
        }
        if (date < 10) {
            dateStr = "0" + date;
        }
        else {
            dateStr = "" + date;
        }
        var current_date = year + '-' + monthStr + '-' + dateStr;
        if (data.startDate != "") {
            if (data.startDate > current_date) {
                alert("Future date not allowed");
                return;
            }
        }
        if (data.endDate != "") {
            if (data.endDate > current_date) {
                alert("Future date not allowed");
                return;
            }
        }
        if (data.startDate != "" && data.endDate != "") {
            if (data.startDate > data.endDate) {
                alert("Start date later than End Date selected");
                return;
            }
        }
        this.bioNotifySearch.appGroup = data.appGroup;
        this.bioNotifySearch.appName = data.appName;
        this.bioNotifySearch.status = data.status;
        this.bioNotifySearch.exCategory = data.exCategory;
        this.bioNotifySearch.exType = data.exType;
        this.bioNotifySearch.createdDate = data.startDate;
        this.bioNotifySearch.updatedDate = data.endDate;
        this._bioNotifyService.getBioNotificationHistoryByAdSearch(this.bioNotifySearch).subscribe(function (bioNotify) {
            //debugger;
            //console.log(bioNotify);
            _this.rowData = bioNotify;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    NotificationComponent.prototype.buSearch = function (data) {
        var _this = this;
        this.spinnerService.show();
        //debugger;
        var bunit = document.getElementById('buint').value;
        var buAppName = document.getElementById('buAppName').value;
        var entity = document.getElementById('entity').value;
        var es = document.getElementById('es').value;
        var duration = document.getElementById('duration').value;
        /*
          console.log("let businessUnit "+bunit);
          console.log("let applicationName "+buAppName);
           console.log("let entityName "+entity);
          console.log("let entServiceName "+es);
    */
        this.busearch = new _dao_busearch__WEBPACK_IMPORTED_MODULE_7__["BUSearch"]();
        if (duration != "" && duration != "0") {
            this.busearch.duration = duration;
        }
        else {
            this.busearch.duration = 1;
        }
        if (bunit != "" && bunit != "0") {
            this.busearch.businessUnit = bunit;
            if (buAppName != "" && buAppName != "0") {
                this.busearch.applicationName = buAppName;
                if (entity != "" && entity != "0") {
                    this.busearch.entityName = entity;
                    if (es != "" && es != "0") {
                        this.busearch.entServiceName = es;
                    }
                }
            }
        }
        this._bioNotifyService.getNotificationsAndHistoryByBUSearch(this.busearch).subscribe(function (bioNotify) {
            //debugger;
            //     console.log(bioNotify);
            _this.rowData = bioNotify;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
    };
    NotificationComponent.prototype.onAppGroupChange = function (appGroupName) {
        var _this = this;
        this._applicationService.getAppNameByAppGroupId(appGroupName).subscribe(function (appNameListValues) {
            //    console.log(appNameListValues);
            _this.appNameList = appNameListValues;
        }), function (error) {
            console.log(error);
        };
    };
    NotificationComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-notification',
            template: __webpack_require__(/*! ./notification.component.html */ "./src/app/components/notification/notification.component.html"),
            styles: [__webpack_require__(/*! ./notification.component.css */ "./src/app/components/notification/notification.component.css")]
        }),
        __metadata("design:paramtypes", [ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_10__["Ng4LoadingSpinnerService"], _service_bio_log_service__WEBPACK_IMPORTED_MODULE_9__["BioLogService"], _service_bio_notify_service__WEBPACK_IMPORTED_MODULE_1__["BioNotifyService"], _service_application_service__WEBPACK_IMPORTED_MODULE_2__["ApplicationService"], _service_business_unit_service__WEBPACK_IMPORTED_MODULE_3__["BusinessUnitService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _angular_common__WEBPACK_IMPORTED_MODULE_8__["DatePipe"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]])
    ], NotificationComponent);
    return NotificationComponent;
}());

/*function getRowData() {
  var rowData = [];

    rowData.push(
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' },
      { userId: 'Test', userType: 'Celica', emailID: 'Test@123.com', firstName: 'Jag', lastName: 'K' }
    );
  
  return rowData;
}*/


/***/ }),

/***/ "./src/app/components/side-bar/side-bar.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/side-bar/side-bar.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/side-bar/side-bar.component.html":
/*!*************************************************************!*\
  !*** ./src/app/components/side-bar/side-bar.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<aside class=\"main-sidebar\">\n    <!-- sidebar: style can be found in sidebar.less -->\n    <section class=\"sidebar\">\n      <!-- sidebar menu: : style can be found in sidebar.less -->\n      <ul class=\"sidebar-menu\" data-widget=\"tree\">\n\t   <li class=\"firstLevelMenu parent\"><a  (click)=\"showDashboard()\"><i class=\"fa fa-dashboard\"></i> Dashboard</a></li>\n     <li class=\"firstLevelMenu parent\"><a  (click)=\"showLogging()\"><i class=\"fa fa-file-text-o\" aria-hidden=\"true\"></i> Logging</a></li>\n     <li class=\"firstLevelMenu parent\"><a  (click)=\"showNotification()\"><i class=\"fa fa-bell\"></i> Notification</a></li>\n     <li class=\"firstLevelMenu parent\"><a  (click)=\"showAppInfo()\"><i class=\"fa fa-cubes\" aria-hidden=\"true\"></i> Interface Details</a></li>\n\t\t <li class=\"treeview\">\n        <li class=\"treeview\"></li>\n        <!-- <li id=\"sub\" class=\"treeview\" > -->\n             <!-- remove permanantntly -->\n                <li class=\"treeview\" *ngIf=\"userType == 1\">\n                \n                <!-- show only for configured admin users in db <li class=\"treeview\" *ngIf=\"userType < 2\">   -->\n               <!--      <li class=\"treeview\"> -->\n          <a>\n            <i class=\"fa fa-cog\"></i>\n            <span>Administration</span>\n            <span class=\"pull-right-container\">\n              <i class=\"fa fa-angle-left pull-right\"></i>\n            </span>\n          </a>\n          <ul class=\"treeview-menu\">\n               <li class=\"secondLevelMenu parent\"><a (click)=\"showNewInterface()\">Interface Management</a></li>\n             <li class=\"secondLevelMenu parent\"><a (click)=\"showUser()\">User Management</a></li>\n             <li class=\"secondLevelMenu parent\"><a (click)=\"showDataPurge()\">Purge History</a></li>\n         </ul>\n        </li>\n      \n        <li class=\"firstLevelMenu parent\"><a  (click)=\"showGeneralinfo()\"><i class=\"fa fa-question-circle\"></i> General instructions</a></li>\n        </ul>\n    </section>\n    <!-- /.sidebar -->\n  </aside>\n"

/***/ }),

/***/ "./src/app/components/side-bar/side-bar.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/side-bar/side-bar.component.ts ***!
  \***********************************************************/
/*! exports provided: SideBarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SideBarComponent", function() { return SideBarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _service_user_session_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/user-session.service */ "./src/app/service/user-session.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SideBarComponent = /** @class */ (function () {
    function SideBarComponent(_router, _userSessionService) {
        var _this = this;
        this._router = _router;
        this._userSessionService = _userSessionService;
        this.loggingEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.notificationEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.applicationEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.userEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.appInfoEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.dashBoardEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.generalInstructionEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.newInterfaceEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.dataPurgeEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        console.log("sidebar constructor");
        this.userType = this._userSessionService.getUserType();
        this._userSessionService.getUserNameByUserId().subscribe(function (userData) {
            if (userData != null) {
                console.log("userData.userType:" + userData.userType);
                _this._userSessionService.setUserName(userData.userId);
                _this.userType = userData.userType;
                _this._userSessionService.setHostName("https://" + userData.updatedBy + "/eisUtilWeb/login");
                _this._userSessionService.setUserType(userData.userType);
            }
        }),
            function (error) {
                console.log(error);
            };
    }
    SideBarComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userType = this._userSessionService.getUserType();
        console.log("userType:" + this.userType);
        this._userSessionService.getUserNameByUserId().subscribe(function (userData) {
            if (userData != null) {
                console.log("userData.userType:" + userData.userType);
                _this._userSessionService.setUserName(userData.userId);
                _this.userType = userData.userType;
                _this._userSessionService.setHostName("https://" + userData.updatedBy + "/eisUtilWeb/login");
                _this._userSessionService.setUserType(userData.userType);
            }
        }),
            function (error) {
                console.log(error);
            };
        $(document).ready(function () {
            $('.sidebar ul li.parent').click(function () {
                $('li.parent').removeClass("active");
                $(this).addClass("active");
            });
        });
        $('.treeview').click(function () {
            $(this).addClass("sub_menu");
        });
        $('.sidebar-menu li.parent').click(function () {
            $('.treeview').removeClass("sub_menu");
        });
    };
    SideBarComponent.prototype.showLogging = function () {
        //console.log("dfdfgs");
        //debugger;
        this.loggingEvent.emit("true");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showNotification = function () {
        //debugger;
        console.log("showNotification in sidebar component");
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("true");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showApplication = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("true");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showUser = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("true");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showAppType = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showAppInfo = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("true");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showDashboard = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("true");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showGeneralinfo = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("true");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showNewInterface = function () {
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("true");
        this.dataPurgeEvent.emit("false");
    };
    SideBarComponent.prototype.showDataPurge = function () {
        console.log("showDataPurge");
        this.loggingEvent.emit("false");
        this.notificationEvent.emit("false");
        this.applicationEvent.emit("false");
        this.userEvent.emit("false");
        this.appInfoEvent.emit("false");
        this.dashBoardEvent.emit("false");
        this.generalInstructionEvent.emit("false");
        this.newInterfaceEvent.emit("false");
        this.dataPurgeEvent.emit("true");
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "loggingEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "notificationEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "applicationEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "userEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "appInfoEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "dashBoardEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "generalInstructionEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "newInterfaceEvent", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "dataPurgeEvent", void 0);
    SideBarComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-side-bar',
            template: __webpack_require__(/*! ./side-bar.component.html */ "./src/app/components/side-bar/side-bar.component.html"),
            styles: [__webpack_require__(/*! ./side-bar.component.css */ "./src/app/components/side-bar/side-bar.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _service_user_session_service__WEBPACK_IMPORTED_MODULE_2__["UserSessionService"]])
    ], SideBarComponent);
    return SideBarComponent;
}());



/***/ }),

/***/ "./src/app/components/user/user.component.css":
/*!****************************************************!*\
  !*** ./src/app/components/user/user.component.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/user/user.component.html":
/*!*****************************************************!*\
  !*** ./src/app/components/user/user.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"content-wrapper user\">\n  <ol class=\"breadcrumb\">\n      <li class=\"breadcrumb-item\"><a href=\"/eisUtilWeb\">Home</a></li>\n    <li class=\"breadcrumb-item\">User Management</li>\n  </ol>\n  <section class=\"content\">\n    <div class=\"row\">\n      <div class=\"col-md-12\">\n\n        <div class=\"top_search main_search search_tab clearfix\">\n          <!-- new search start -->\n          <div class=\"container-fluid\" style=\"padding:0 !important\">\n            <div class=\"panel panel-default\" style=\"margin:0 !important\">\n              <div class=\"panel-body\" style=\"padding: 8px 15px !important\">\n                  <div id=\"successStatus\" style=\"color: green;\"></div>\n                  <div id=\"errorStatus\" style=\"color: #FF0000;\"></div>\n                <div class=\"searchBox\" style=\"padding-bottom:0px !important\">\n                    <form #bioLogUserForm=\"ngForm\" (ngSubmit)=\"saveOrDeleteUser(bioLogUserForm.value)\"  class=\"form-horizontal\"\n                    role=\"form\">\n                    <div class=\"row\">\n                      <div class=\"col-sm-3\">\n                          <span class=\"mandatory\">*</span>\n                          <div class=\"col-sm-11\">\n                          <ng2-completer id=\"userId\" name=\"userId\" [datasource]=\"userListCons\" (change)=\"onUserSelcted($event.target.value)\" placeholder=\"&#xf002;&nbsp;&nbsp;&nbsp;Quick Search or type User Id\" style=\"font-family:Arial, FontAwesome\" [minSearchLength]=\"2\" ngModel></ng2-completer>\n                        <!-- <input type=\"text\" class=\"form-control \" id=\"userId\" name=\"userId\" placeholder=\"User ID\"\n                          ngModel> -->\n                      </div>\n                      </div>\n                      <div class=\"col-sm-3\" > <span class=\"mandatory\">*</span>\n                        <div class=\"col-sm-11\" style=\"margin:0px !important\"> \n                        <select class=\"form-control \" id=\"userType\" name=\"userType\" [value] ='userType' ngModel>\n                          <option value=\"\" disabled selected>User Type</option>\n                          <option *ngFor=\"let userType of userTypeList\" value={{userType.userTypeId}}>{{userType.userType}}\n                          </option>\n                        </select>\n                        </div>\n                      </div>\n      \n                      <div class=\"col-sm-3\" >\n                          <span class=\"mandatory\">*</span>\n                          <div class=\"col-sm-11\" >\n                          <ng-multiselect-dropdown idField=\"targetbuName\" [data]=\"bunitList\" name=\"BUName\" \n                          [(ngModel)]=\"selectedItems\" [settings]=\"dropdownSettings\" (onDeSelect)=\"onItemDeSelect($event)\"\n                          (onSelect)=\"onItemSelect($event)\" (onSelectAll)=\"onSelectAll($event)\" (onDeSelectAll)=\"onDeSelectAll($event)\" ngModel>\n                        </ng-multiselect-dropdown>\n                      </div>\n                      </div>\n                      <div class=\"col-sm-3\">\n                          <button type=\"submit\" id=\"userSave\" class=\"saveBtns\" name=\"userSave\" (click)=\"onSaveClick()\"><i\n                            class=\"fa fa-save \"></i>&nbsp;Save</button>\n                            <button type=\"submit\" id=\"userDelete\" class=\"saveBtns\" name=\"userDelete\"  (click)=\"onDeleteClick()\"><i \n                              class=\"fa fa-save \"></i>&nbsp;Delete</button>\n                      </div>\n                    \n                      <div>\n                      </div>\n                    </div>\n                    <div class=\"clearfix\"></div>\n              \n              </form>\n            </div>\n              </div>\n            </div>\n          </div>\n        </div>\n\n\n        <div class=\"table_color3\">\n          <div class=\"row\">\n            <div class=\"container-fluid\" style=\"padding-right:5px !important\">\n              <ag-grid-angular style=\"height: 530px;\" class=\"ag-theme-balham\" [rowData]=\"rowData\"\n                [columnDefs]=\"columnDefs\" [enableSorting]=\"true\" [enableFilter]=\"true\" [rowHeight]=\"30\" \n                [suppressRowClickSelection]=\"true\" [debug]=\"true\" [enableColResize]=\"true\" [enableRangeSelection]=\"true\"\n                [paginationAutoPageSize]=\"true\" [pagination]=\"true\" [paginationPageSize]=15 [overlayLoadingTemplate]=\"overlayLoadingTemplate\"\n                (gridReady)=\"onGridReady($event)\">\n              </ag-grid-angular>\n            </div>\n\n          </div>\n        </div>\n\n      </div>\n\n    </div>\n  </section>\n</div>"

/***/ }),

/***/ "./src/app/components/user/user.component.ts":
/*!***************************************************!*\
  !*** ./src/app/components/user/user.component.ts ***!
  \***************************************************/
/*! exports provided: UserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserComponent", function() { return UserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_user_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../service/user.service */ "./src/app/service/user.service.ts");
/* harmony import */ var _dao_biologuser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../dao/biologuser */ "./src/app/dao/biologuser.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _service_business_unit_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/business-unit.service */ "./src/app/service/business-unit.service.ts");
/* harmony import */ var _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../dao/bio-LOVs-data */ "./src/app/dao/bio-LOVs-data.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var UserComponent = /** @class */ (function () {
    function UserComponent(_businessUnitService, _userService, spinnerService) {
        this._businessUnitService = _businessUnitService;
        this._userService = _userService;
        this.spinnerService = spinnerService;
        this.dropdownSettings = {};
        this.rowData = [];
        this.columnDefs = [];
        this.bioLogUser = new _dao_biologuser__WEBPACK_IMPORTED_MODULE_2__["Biologuser"]();
        this.title = 'BioLogUser Details';
        this.bunitList = [];
        this.targetBUId = [];
        this.userListCons = [];
        this.userType = "";
        this.buList = [];
        this.selectedItems = [];
        this.saveClicked = false;
    }
    UserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.saveClicked = false;
        this.spinnerService.show();
        this.overlayLoadingTemplate =
            '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>';
        this._userService.getUserTypeList().subscribe(function (userTypesListValues) {
            //console.log(userTypesListValues);
            _this.userTypeList = userTypesListValues;
            //console.log("====== "+this.userTypeList[1].userType);
            _this.selectedUserType = _this.userTypeList[1];
        }), function (error) {
            console.log(error);
        };
        this.columnDefs = [
            { headerName: 'UserId', field: 'userId', width: 130 },
            { headerName: 'UserType', field: 'userType', width: 150 },
            /*{headerName: 'EmailID', field: 'emailID', width:160 },
            {headerName: 'FirstName', field: 'firstName', width:160},
            {headerName: 'LastName', field: 'lastName', width:160}, */
            { headerName: 'Business Units', field: 'buStr', width: 300 },
            { headerName: 'CreatedDate', field: 'createdDate', width: 160 },
            { headerName: 'UpdatedDate', field: 'updatedDate', width: 160 }
        ];
        this._userService.getAllBioLogUsers().subscribe(function (biologuser) {
            //debugger;
            // console.log(JSON.stringify(biologuser));
            _this.rowData = biologuser;
            for (var _i = 0, _a = _this.rowData; _i < _a.length; _i++) {
                var user = _a[_i];
                _this.userListCons.push(user.userId);
            }
        }), function (error) {
            console.log(error);
        };
        this.bioLOVsData = new _dao_bio_LOVs_data__WEBPACK_IMPORTED_MODULE_5__["BioLOVsData"]();
        this.bioLOVsData.type = "BU";
        this._businessUnitService.getDetailsByType(this.bioLOVsData.type).subscribe(function (buListValues) {
            // console.log("bunitListValues : "+buListValues);
            _this.bunitList = buListValues;
            _this.spinnerService.hide();
        }, function () { return _this.spinnerService.hide(); }), function (error) {
            console.log(error);
        };
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: false
        };
    };
    UserComponent.prototype.onGridReady = function (params) {
        this.gridApi = params.api;
        this.gridApi.showLoadingOverlay();
    };
    UserComponent.prototype.clear = function () {
        this.createBioLogUserForm.reset();
    };
    UserComponent.prototype.onItemSelect = function (item) {
        //console.log("Bu selected:"+JSON.stringify(item));
        this.targetBUId.push(item.id);
        //console.log("onItemSelect this.targetBUId="+this.targetBUId);    
    };
    UserComponent.prototype.onSelectAll = function (items) {
        // console.log(items);
        this.targetBUId = [];
        for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
            var item = items_1[_i];
            this.targetBUId.push(item.id);
        }
        //console.log(" onSelectAll --> this.targetBUAPPId="+this.targetBUId);
    };
    UserComponent.prototype.onDeSelectAll = function (items) {
        //    console.log(items);
        this.targetBUId = [];
        //  console.log("onDeSelectAll --> this.targetBUId="+this.targetBUId);
    };
    UserComponent.prototype.onItemDeSelect = function (item) {
        //console.log(item);
        var newItems = [];
        for (var _i = 0, _a = this.targetBUId; _i < _a.length; _i++) {
            var itemId = _a[_i];
            if (item.id != itemId) {
                newItems.push(itemId);
            }
        }
        this.targetBUId = newItems;
        //console.log("onItemDeSelect--> this.targetBUId="+this.targetBUId);    
    };
    UserComponent.prototype.onSaveClick = function () {
        this.saveClicked = true;
    };
    UserComponent.prototype.onDeleteClick = function () {
        this.saveClicked = false;
    };
    UserComponent.prototype.saveOrDeleteUser = function (data) {
        if (this.saveClicked) {
            console.log("saveuser");
            this.saveUser(data);
        }
        else {
            console.log("deleteUser");
            this.deleteUser(data);
        }
    };
    UserComponent.prototype.deleteUser = function (data) {
        var _this = this;
        this.spinnerService.show();
        //debugger;
        /* console.log("userId "+data.userId);
         console.log("userType "+data.userType);
         console.log("selected BUs:"+this.targetBUId);
         */
        //this.bioLogApplication.appId = "";
        this.bioLogUser.userId = data.userId;
        this.bioLogUser.userType = data.userType;
        if (data.userType == null || data.userType.trim() == "") {
            this.bioLogUser.userType = this.userType;
        }
        //    console.log("targetBUID:"+JSON.stringify(this.targetBUId));
        var buIds = "";
        /* if(this.targetBUId == null || this.targetBUId == "")
         {
           for(let itemId of this.selectedItems )  {
             this.targetBUId.push(itemId.id);
             }
         }*/
        console.log("targetBUID:" + JSON.stringify(this.targetBUId));
        for (var _i = 0, _a = this.targetBUId; _i < _a.length; _i++) {
            var itemId = _a[_i];
            buIds = buIds + itemId + ",";
        }
        this.bioLogUser.buList = buIds;
        var errorMsg = "";
        if (data.userId == null || data.userId.trim() == "") {
            errorMsg = errorMsg + "Please Enter Network User Name<br/>";
        }
        if ((data.userType == null || data.userType.trim() == "") && this.userType == "") {
            errorMsg = errorMsg + "Please Select User Type<br/>";
        }
        if (this.targetBUId == null || this.targetBUId == "") {
            errorMsg = errorMsg + "Please Selct Associated Business Units<br/>";
        }
        if (errorMsg != "") {
            document.getElementById("successStatus").innerHTML = "";
            document.getElementById("errorStatus").innerHTML = errorMsg;
            return;
        }
        this._userService.deleteBioLogUser(this.bioLogUser).subscribe(function (response) {
            console.log("Success :: " + response);
            if (response) {
                document.getElementById("successStatus").innerHTML = "User has been Deleted successfully!!";
                document.getElementById("errorStatus").innerHTML = "";
                _this.createBioLogUserForm.reset();
                _this.userType = "";
                _this.targetBUId = [];
                _this.userListCons = [];
                _this._userService.getAllBioLogUsers().subscribe(function (biologuser) {
                    _this.rowData = biologuser;
                    for (var _i = 0, _a = _this.rowData; _i < _a.length; _i++) {
                        var user = _a[_i];
                        _this.userListCons.push(user.userId);
                    }
                    _this.spinnerService.hide();
                }, function () { return _this.spinnerService.hide(); }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    UserComponent.prototype.saveUser = function (data) {
        var _this = this;
        this.spinnerService.show();
        //debugger;
        /* console.log("userId "+data.userId);
         console.log("userType "+data.userType);
         console.log("selected BUs:"+this.targetBUId);
         */
        //this.bioLogApplication.appId = "";
        this.bioLogUser.userId = data.userId;
        this.bioLogUser.userType = data.userType;
        if (data.userType == null || data.userType.trim() == "") {
            this.bioLogUser.userType = this.userType;
        }
        //    console.log("targetBUID:"+JSON.stringify(this.targetBUId));
        var buIds = "";
        /* if(this.targetBUId == null || this.targetBUId == "")
         {
           for(let itemId of this.selectedItems )  {
             this.targetBUId.push(itemId.id);
             }
         }*/
        console.log("targetBUID:" + JSON.stringify(this.targetBUId));
        for (var _i = 0, _a = this.targetBUId; _i < _a.length; _i++) {
            var itemId = _a[_i];
            buIds = buIds + itemId + ",";
        }
        this.bioLogUser.buList = buIds;
        var errorMsg = "";
        if (data.userId == null || data.userId.trim() == "") {
            errorMsg = errorMsg + "Please Enter Network User Name<br/>";
        }
        if ((data.userType == null || data.userType.trim() == "") && this.userType == "") {
            errorMsg = errorMsg + "Please Select User Type<br/>";
        }
        if (this.targetBUId == null || this.targetBUId == "") {
            errorMsg = errorMsg + "Please Selct Associated Business Units<br/>";
        }
        if (errorMsg != "") {
            document.getElementById("successStatus").innerHTML = "";
            document.getElementById("errorStatus").innerHTML = errorMsg;
            return;
        }
        this._userService.createBioLogUser(this.bioLogUser).subscribe(function (response) {
            console.log("Success :: " + response);
            if (response) {
                document.getElementById("successStatus").innerHTML = "User has been created successfully!!";
                document.getElementById("errorStatus").innerHTML = "";
                _this.createBioLogUserForm.reset();
                _this.userType = "";
                _this.targetBUId = [];
                _this.userListCons = [];
                _this._userService.getAllBioLogUsers().subscribe(function (biologuser) {
                    _this.rowData = biologuser;
                    for (var _i = 0, _a = _this.rowData; _i < _a.length; _i++) {
                        var user = _a[_i];
                        _this.userListCons.push(user.userId);
                    }
                    _this.spinnerService.hide();
                }, function () { return _this.spinnerService.hide(); }), function (error) {
                    console.log(error);
                };
            }
        }),
            function (error) {
                console.log(error);
            };
    };
    UserComponent.prototype.onUserSelcted = function (data) {
        console.log("selected userId:" + data);
        var userTemp = null;
        this.targetBUId = [];
        for (var _i = 0, _a = this.rowData; _i < _a.length; _i++) {
            var user = _a[_i];
            if (user.userId == data) {
                userTemp = user;
                //console.log("userDetails:"+JSON.stringify(user));
                break;
            }
        }
        this.selectedItems = [];
        // console.log("userBUList:"+JSON.stringify(userTemp));
        if (userTemp != null && userTemp != "") {
            for (var _b = 0, _c = this.userTypeList; _b < _c.length; _b++) {
                var userType = _c[_b];
                if (userType.userType == userTemp.userType) {
                    this.userType = userType.userTypeId;
                }
            }
            //  console.log("this.userType:"+this.userType);
            for (var _d = 0, _e = userTemp.buList; _d < _e.length; _d++) {
                var bu = _e[_d];
                console.log("bu:" + JSON.stringify(bu));
                this.selectedItems.push({ id: bu.appId, name: bu.appName });
                this.onItemSelect({ id: bu.appId, name: bu.appName });
            }
        }
        //console.log("selcted Items:"+JSON.stringify(this.selectedItems));
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('bioLogUserForm'),
        __metadata("design:type", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgForm"])
    ], UserComponent.prototype, "createBioLogUserForm", void 0);
    UserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user',
            template: __webpack_require__(/*! ./user.component.html */ "./src/app/components/user/user.component.html"),
            styles: [__webpack_require__(/*! ./user.component.css */ "./src/app/components/user/user.component.css")]
        }),
        __metadata("design:paramtypes", [_service_business_unit_service__WEBPACK_IMPORTED_MODULE_4__["BusinessUnitService"], _service_user_service__WEBPACK_IMPORTED_MODULE_1__["UserService"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_6__["Ng4LoadingSpinnerService"]])
    ], UserComponent);
    return UserComponent;
}());



/***/ }),

/***/ "./src/app/constant/app-constant.service.ts":
/*!**************************************************!*\
  !*** ./src/app/constant/app-constant.service.ts ***!
  \**************************************************/
/*! exports provided: AppConstantService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConstantService", function() { return AppConstantService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AppConstantService = /** @class */ (function () {
    function AppConstantService() {
        //readonly HOST_NAME: string = 'http://localhost:8888/eisUtilWeb';
        //readonly HOST_NAME: string = 'http://10.240.8.62:7001/eisUtilWeb';
        //readonly HOST_NAME: string = 'https://eisutldev.biogen.com/eisUtilWeb';
        this.HOST_NAME = '/eisUtilWeb';
        //readonly HOST_NAME: string = 'https://eisutltst.biogen.com/eisUtilWeb';
        //readonly HOST_NAME: string = 'https://eisutlstg.biogen.com/eisUtilWeb';
        //readonly HOST_NAME: string = 'https://eisutl.biogen.com/eisUtilWeb';
        this.headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'Content-Type': 'application/json' });
        this.options = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: this.headers });
    }
    AppConstantService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], AppConstantService);
    return AppConstantService;
}());



/***/ }),

/***/ "./src/app/dao/app-name-temp.ts":
/*!**************************************!*\
  !*** ./src/app/dao/app-name-temp.ts ***!
  \**************************************/
/*! exports provided: AppNameTemp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppNameTemp", function() { return AppNameTemp; });
var AppNameTemp = /** @class */ (function () {
    function AppNameTemp() {
    }
    return AppNameTemp;
}());



/***/ }),

/***/ "./src/app/dao/application.ts":
/*!************************************!*\
  !*** ./src/app/dao/application.ts ***!
  \************************************/
/*! exports provided: Application */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Application", function() { return Application; });
var Application = /** @class */ (function () {
    function Application() {
    }
    return Application;
}());



/***/ }),

/***/ "./src/app/dao/bio-LOVs-data.ts":
/*!**************************************!*\
  !*** ./src/app/dao/bio-LOVs-data.ts ***!
  \**************************************/
/*! exports provided: BioLOVsData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLOVsData", function() { return BioLOVsData; });
var BioLOVsData = /** @class */ (function () {
    function BioLOVsData() {
    }
    return BioLOVsData;
}());



/***/ }),

/***/ "./src/app/dao/bio-app-doc-history.ts":
/*!********************************************!*\
  !*** ./src/app/dao/bio-app-doc-history.ts ***!
  \********************************************/
/*! exports provided: BioAppDocHistory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioAppDocHistory", function() { return BioAppDocHistory; });
var BioAppDocHistory = /** @class */ (function () {
    function BioAppDocHistory() {
    }
    return BioAppDocHistory;
}());



/***/ }),

/***/ "./src/app/dao/bio-log-app-group.ts":
/*!******************************************!*\
  !*** ./src/app/dao/bio-log-app-group.ts ***!
  \******************************************/
/*! exports provided: BioLogAppGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLogAppGroup", function() { return BioLogAppGroup; });
var BioLogAppGroup = /** @class */ (function () {
    function BioLogAppGroup() {
    }
    return BioLogAppGroup;
}());



/***/ }),

/***/ "./src/app/dao/bio-log-app-type.ts":
/*!*****************************************!*\
  !*** ./src/app/dao/bio-log-app-type.ts ***!
  \*****************************************/
/*! exports provided: BioLogAppType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLogAppType", function() { return BioLogAppType; });
var BioLogAppType = /** @class */ (function () {
    function BioLogAppType() {
    }
    return BioLogAppType;
}());



/***/ }),

/***/ "./src/app/dao/bio-log-application.ts":
/*!********************************************!*\
  !*** ./src/app/dao/bio-log-application.ts ***!
  \********************************************/
/*! exports provided: BioLogApplicationData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLogApplicationData", function() { return BioLogApplicationData; });
var BioLogApplicationData = /** @class */ (function () {
    function BioLogApplicationData() {
    }
    return BioLogApplicationData;
}());



/***/ }),

/***/ "./src/app/dao/bio-log-search.ts":
/*!***************************************!*\
  !*** ./src/app/dao/bio-log-search.ts ***!
  \***************************************/
/*! exports provided: BioLogSearch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLogSearch", function() { return BioLogSearch; });
var BioLogSearch = /** @class */ (function () {
    function BioLogSearch() {
    }
    return BioLogSearch;
}());



/***/ }),

/***/ "./src/app/dao/bio-log.ts":
/*!********************************!*\
  !*** ./src/app/dao/bio-log.ts ***!
  \********************************/
/*! exports provided: BioLog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLog", function() { return BioLog; });
var BioLog = /** @class */ (function () {
    function BioLog() {
    }
    return BioLog;
}());



/***/ }),

/***/ "./src/app/dao/bio-notification.ts":
/*!*****************************************!*\
  !*** ./src/app/dao/bio-notification.ts ***!
  \*****************************************/
/*! exports provided: BioNotification */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioNotification", function() { return BioNotification; });
var BioNotification = /** @class */ (function () {
    function BioNotification() {
    }
    return BioNotification;
}());



/***/ }),

/***/ "./src/app/dao/bio-notify-props-temp.ts":
/*!**********************************************!*\
  !*** ./src/app/dao/bio-notify-props-temp.ts ***!
  \**********************************************/
/*! exports provided: BioNotifyPropsTemp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioNotifyPropsTemp", function() { return BioNotifyPropsTemp; });
var BioNotifyPropsTemp = /** @class */ (function () {
    function BioNotifyPropsTemp() {
        this.exCategoryList = [];
        this.exTypeList = [];
    }
    return BioNotifyPropsTemp;
}());



/***/ }),

/***/ "./src/app/dao/bio-notify-search.ts":
/*!******************************************!*\
  !*** ./src/app/dao/bio-notify-search.ts ***!
  \******************************************/
/*! exports provided: BioNotifySearch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioNotifySearch", function() { return BioNotifySearch; });
var BioNotifySearch = /** @class */ (function () {
    function BioNotifySearch() {
    }
    return BioNotifySearch;
}());



/***/ }),

/***/ "./src/app/dao/bio-notify.ts":
/*!***********************************!*\
  !*** ./src/app/dao/bio-notify.ts ***!
  \***********************************/
/*! exports provided: BioNotify */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioNotify", function() { return BioNotify; });
var BioNotify = /** @class */ (function () {
    function BioNotify() {
    }
    return BioNotify;
}());



/***/ }),

/***/ "./src/app/dao/biologuser.ts":
/*!***********************************!*\
  !*** ./src/app/dao/biologuser.ts ***!
  \***********************************/
/*! exports provided: Biologuser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Biologuser", function() { return Biologuser; });
var Biologuser = /** @class */ (function () {
    function Biologuser() {
    }
    return Biologuser;
}());



/***/ }),

/***/ "./src/app/dao/busearch.ts":
/*!*********************************!*\
  !*** ./src/app/dao/busearch.ts ***!
  \*********************************/
/*! exports provided: BUSearch */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BUSearch", function() { return BUSearch; });
var BUSearch = /** @class */ (function () {
    function BUSearch() {
    }
    return BUSearch;
}());



/***/ }),

/***/ "./src/app/dao/notification-category.ts":
/*!**********************************************!*\
  !*** ./src/app/dao/notification-category.ts ***!
  \**********************************************/
/*! exports provided: NotificationCategory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationCategory", function() { return NotificationCategory; });
var NotificationCategory = /** @class */ (function () {
    function NotificationCategory() {
    }
    return NotificationCategory;
}());



/***/ }),

/***/ "./src/app/dao/user.ts":
/*!*****************************!*\
  !*** ./src/app/dao/user.ts ***!
  \*****************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());



/***/ }),

/***/ "./src/app/service/GlobalErrorHandler.ts":
/*!***********************************************!*\
  !*** ./src/app/service/GlobalErrorHandler.ts ***!
  \***********************************************/
/*! exports provided: GlobalErrorHandler */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalErrorHandler", function() { return GlobalErrorHandler; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


//import * as StackTrace from 'stacktrace-js';
var GlobalErrorHandler = /** @class */ (function () {
    function GlobalErrorHandler(injector) {
        this.injector = injector;
    }
    GlobalErrorHandler.prototype.handleError = function (error) {
        var router = this.injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]);
        console.log("redirecting to error page");
        router.navigate(['/error'], { queryParams: error });
        // router.navigate(['/error'],);
        // Log the error anyway
        console.error('It happens: ', error);
    };
    GlobalErrorHandler = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], GlobalErrorHandler);
    return GlobalErrorHandler;
}());



/***/ }),

/***/ "./src/app/service/application.service.ts":
/*!************************************************!*\
  !*** ./src/app/service/application.service.ts ***!
  \************************************************/
/*! exports provided: ApplicationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationService", function() { return ApplicationService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _dao_application__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dao/application */ "./src/app/dao/application.ts");
/* harmony import */ var _dao_bio_log_application__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dao/bio-log-application */ "./src/app/dao/bio-log-application.ts");
/* harmony import */ var _dao_bio_log_app_type__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../dao/bio-log-app-type */ "./src/app/dao/bio-log-app-type.ts");
/* harmony import */ var _dao_bio_log_app_group__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../dao/bio-log-app-group */ "./src/app/dao/bio-log-app-group.ts");
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};











var ApplicationService = /** @class */ (function () {
    function ApplicationService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.application = new _dao_application__WEBPACK_IMPORTED_MODULE_6__["Application"]();
        this.bioLogApplication = new _dao_bio_log_application__WEBPACK_IMPORTED_MODULE_7__["BioLogApplicationData"]();
        this.bioLogAppType = new _dao_bio_log_app_type__WEBPACK_IMPORTED_MODULE_8__["BioLogAppType"]();
        this.bioLogAppGroup = new _dao_bio_log_app_group__WEBPACK_IMPORTED_MODULE_9__["BioLogAppGroup"]();
        this.baseurl = this._constant.HOST_NAME + "/app";
        this.options = this._constant.options;
    }
    ApplicationService.prototype.getBiogenTransId = function () {
        return this.biogenTransId;
    };
    ApplicationService.prototype.setBiogenTransId = function (biogenTransId) {
        this.biogenTransId = biogenTransId;
    };
    ApplicationService.prototype.getAllApplicationDetails = function () {
        return this._http.get(this.baseurl + '/details', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAppplicationDetails = function (appId) {
        return this._http.get(this.baseurl + '/details/' + appId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAllAppTypeDetails = function () {
        return this._http.get(this.baseurl + '/type/details', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAllAppGroupDetails = function () {
        return this._http.get(this.baseurl + '/group/details', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAppTypeList = function () {
        return this._http.get(this.baseurl + '/type', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAppGroupList = function () {
        return this._http.get(this.baseurl + '/group', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getLogLevelList = function () {
        return this._http.get(this.baseurl + '/log', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAppNameList = function () {
        return this._http.get(this.baseurl + '/name', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getAppNameByAppGroupId = function (appGroupName) {
        return this._http.get(this.baseurl + '/name/group/' + appGroupName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.getServiceInvokerStatusList = function () {
        return this._http.get(this.baseurl + '/sistatus', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createApplication = function (bioLogApplicationData) {
        console.log("JSON.stringify(bioLogApplicationData):" + JSON.stringify(bioLogApplicationData));
        return this._http.post(this.baseurl + '/save', JSON.stringify(bioLogApplicationData), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.upateApplication = function (bioLogApplicationData) {
        console.log("JSON.stringify(bioLogApplicationData):" + JSON.stringify(bioLogApplicationData));
        return this._http.post(this.baseurl + '/update', JSON.stringify(bioLogApplicationData), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createAppType = function (bioLogAppType) {
        return this._http.post(this.baseurl + '/save/apptype', JSON.stringify(bioLogAppType), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createAppGroup = function (bioLogAppGroup) {
        return this._http.post(this.baseurl + '/save/appgroup', JSON.stringify(bioLogAppGroup), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createInterface = function (bioAppDocHistory) {
        return this._http.post(this.baseurl + '/saveInterface', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.updateInterface = function (bioAppDocHistory) {
        return this._http.post(this.baseurl + '/updateInterface', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createITPDDetails = function (bioAppDocHistory) {
        console.log("bioAppDoc:" + JSON.stringify(bioAppDocHistory));
        return this._http.post(this.baseurl + '/saveITPDDetails', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.updateITPDDetails = function (bioAppDocHistory) {
        console.log("bioAppDoc:" + JSON.stringify(bioAppDocHistory));
        return this._http.post(this.baseurl + '/updateITPDDetails', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.createCRDetails = function (bioAppDocHistory) {
        console.log("createCRDetails bioAppDoc:" + JSON.stringify(bioAppDocHistory));
        return this._http.post(this.baseurl + '/saveCRDetails', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.updateCRDetails = function (bioAppDocHistory) {
        console.log("updateCRDetails bioAppDoc:" + JSON.stringify(bioAppDocHistory));
        return this._http.post(this.baseurl + '/updateCRDetails', JSON.stringify(bioAppDocHistory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    ApplicationService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    ApplicationService.prototype.setter = function (application) {
        this.application = application;
    };
    ApplicationService.prototype.getter = function () {
        return this.application;
    };
    ApplicationService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_10__["AppConstantService"]])
    ], ApplicationService);
    return ApplicationService;
}());



/***/ }),

/***/ "./src/app/service/bio-app-doc-history.service.ts":
/*!********************************************************!*\
  !*** ./src/app/service/bio-app-doc-history.service.ts ***!
  \********************************************************/
/*! exports provided: BioAppDocHistoryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioAppDocHistoryService", function() { return BioAppDocHistoryService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../dao/bio-app-doc-history */ "./src/app/dao/bio-app-doc-history.ts");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var BioAppDocHistoryService = /** @class */ (function () {
    function BioAppDocHistoryService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.bioAppDocHistory = new _dao_bio_app_doc_history__WEBPACK_IMPORTED_MODULE_3__["BioAppDocHistory"]();
        this.headers = new Headers({ 'Content-Type': 'multipart/form-data', 'Access-Control-Allow-Origin': '*' });
        this.baseurl = this._constant.HOST_NAME + "/doc/history";
        this.file_baseurl = this._constant.HOST_NAME + "/file";
        // this.options = this._constant.options;
    }
    BioAppDocHistoryService.prototype.getAllBioAppDocHistory = function () {
        return this._http.get(this.baseurl + '/details', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioAppDocHistoryService.prototype.getAllBioAppDocHistoryBySearch = function (buSearch) {
        this.options = this._constant.options;
        return this._http.post(this.baseurl + '/details', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioAppDocHistoryService.prototype.getAllBioAppDocHistoryByAppId = function (appId) {
        return this._http.get(this.baseurl + '/details/' + appId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioAppDocHistoryService.prototype.showImage = function () {
        return this._http.get(this.baseurl + '/show', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioAppDocHistoryService.prototype.uploadFile = function (appId, fileId, selectedFile) {
        var uploadData = new FormData();
        console.log("fileName" + selectedFile.name);
        uploadData.append('file', selectedFile);
        return this._http.post(this.file_baseurl + '/save/' + appId + '/' + fileId, uploadData, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioAppDocHistoryService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    BioAppDocHistoryService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_7__["AppConstantService"]])
    ], BioAppDocHistoryService);
    return BioAppDocHistoryService;
}());



/***/ }),

/***/ "./src/app/service/bio-log.service.ts":
/*!********************************************!*\
  !*** ./src/app/service/bio-log.service.ts ***!
  \********************************************/
/*! exports provided: BioLogService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioLogService", function() { return BioLogService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _dao_bio_log__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dao/bio-log */ "./src/app/dao/bio-log.ts");
/* harmony import */ var _dao_bio_log_search__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dao/bio-log-search */ "./src/app/dao/bio-log-search.ts");
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var BioLogService = /** @class */ (function () {
    function BioLogService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.bioLog = new _dao_bio_log__WEBPACK_IMPORTED_MODULE_6__["BioLog"]();
        this.bioLogSearch = new _dao_bio_log_search__WEBPACK_IMPORTED_MODULE_7__["BioLogSearch"]();
        this.baseurl = this._constant.HOST_NAME + "/log";
        this.options = this._constant.options;
    }
    BioLogService.prototype.getDetailedLogDetails = function (bioTransId) {
        return this._http.get(this.baseurl + '/detail/' + bioTransId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getTargetSystemDetailsDetails = function (bioTransId) {
        return this._http.get(this.baseurl + '/targetSystemDetails/' + bioTransId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getLogDetails = function () {
        return this._http.get(this.baseurl + '/details', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getAdvancedSearchLogDetails = function (bioLogSearch) {
        // return this._http.get(this.baseurl+'/adsearch/details?bioLogSearch='+encodeURIComponent(JSON.stringify(bioLogSearch)),this.options).map((res: Response) => res.json())
        // .catch(this.errorHandler);
        return this._http.post(this.baseurl + '/adsearch/details', JSON.stringify(bioLogSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getBUSearchLogDetails = function (buSearch) {
        console.log(buSearch.duration);
        return this._http.post(this.baseurl + '/busearch/details', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getKeyList = function () {
        return this._http.get(this.baseurl + '/key', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.getKeyListByAppName = function (appName) {
        return this._http.get(this.baseurl + '/key/' + appName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioLogService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    BioLogService.prototype.setter = function (bioLog) {
        this.bioLog = bioLog;
    };
    BioLogService.prototype.getter = function () {
        return this.bioLog;
    };
    BioLogService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__["AppConstantService"]])
    ], BioLogService);
    return BioLogService;
}());



/***/ }),

/***/ "./src/app/service/bio-notify.service.ts":
/*!***********************************************!*\
  !*** ./src/app/service/bio-notify.service.ts ***!
  \***********************************************/
/*! exports provided: BioNotifyService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BioNotifyService", function() { return BioNotifyService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _dao_bio_notify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dao/bio-notify */ "./src/app/dao/bio-notify.ts");
/* harmony import */ var _dao_bio_notify_search__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dao/bio-notify-search */ "./src/app/dao/bio-notify-search.ts");
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
/* harmony import */ var _dao_notification_category__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../dao/notification-category */ "./src/app/dao/notification-category.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var BioNotifyService = /** @class */ (function () {
    function BioNotifyService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.bioNotify = new _dao_bio_notify__WEBPACK_IMPORTED_MODULE_6__["BioNotify"]();
        this.bioNotifySearch = new _dao_bio_notify_search__WEBPACK_IMPORTED_MODULE_7__["BioNotifySearch"]();
        this.notificationCategory = new _dao_notification_category__WEBPACK_IMPORTED_MODULE_9__["NotificationCategory"]();
        this.baseurl = this._constant.HOST_NAME + "/notify";
        this.options = this._constant.options;
    }
    BioNotifyService.prototype.getBioNotificationHistory = function () {
        return this._http.get(this.baseurl + '/history', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getBioNotificationHistoryByAdSearch = function (bioNotifySearch) {
        return this._http.post(this.baseurl + '/history/adsearch', JSON.stringify(bioNotifySearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getNotificationsAndHistoryByBUSearch = function (buSearch) {
        console.log("getNotificationsAndHistoryByBUSearch" + JSON.stringify(buSearch));
        return this._http.post(this.baseurl + '/history/busearch', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getNotificationHistoryDetails = function (notifyHistoryId) {
        return this._http.get(this.baseurl + '/detail/' + notifyHistoryId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getBioNotifyProps = function (notifyHistoryId) {
        return this._http.get(this.baseurl + '/props/' + notifyHistoryId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getExCategoryList = function () {
        return this._http.get(this.baseurl + '/excategory', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getExTypeList = function () {
        return this._http.get(this.baseurl + '/extype', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getBNHStatusList = function () {
        return this._http.get(this.baseurl + '/bnhstatus', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.createNotificationCategory = function (notificationCategory) {
        return this._http.post(this.baseurl + '/save', JSON.stringify(notificationCategory), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.createNotification = function (bioNotification) {
        console.log("bioAppDoc:" + JSON.stringify(bioNotification));
        return this._http.post(this.baseurl + '/save', JSON.stringify(bioNotification), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.updateNotification = function (bioNotification) {
        console.log("bioAppDoc:" + JSON.stringify(bioNotification));
        return this._http.post(this.baseurl + '/update', JSON.stringify(bioNotification), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getAllBioNotify = function () {
        return this._http.get(this.baseurl + '/category', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getAllBioNotifyProps = function () {
        return this._http.get(this.baseurl + '/props', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getAllBioNotifyPropsName = function () {
        return this._http.get(this.baseurl + '/props/name', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getExCategoryAndExTypeByAppId = function (appId) {
        return this._http.get(this.baseurl + '/excategory/extype/' + appId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getExCategoryAndExTypeByAppName = function (appName) {
        return this._http.get(this.baseurl + '/excategory/extype/' + appName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.getNotifyIdByExCategoryAndExTypeAndAppId = function (appId, exCategory, exType) {
        return this._http.get(this.baseurl + '/notifyid/' + appId + '/' + exCategory + '/' + exType, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.createBioNotifiyProps = function (bioNotifyProps) {
        return this._http.post(this.baseurl + '/props/save', JSON.stringify(bioNotifyProps), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BioNotifyService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    BioNotifyService.prototype.setter = function (bioNotify) {
        this.bioNotify = bioNotify;
    };
    BioNotifyService.prototype.getter = function () {
        return this.bioNotify;
    };
    BioNotifyService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__["AppConstantService"]])
    ], BioNotifyService);
    return BioNotifyService;
}());



/***/ }),

/***/ "./src/app/service/business-unit.service.ts":
/*!**************************************************!*\
  !*** ./src/app/service/business-unit.service.ts ***!
  \**************************************************/
/*! exports provided: BusinessUnitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessUnitService", function() { return BusinessUnitService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var BusinessUnitService = /** @class */ (function () {
    function BusinessUnitService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.baseurl = this._constant.HOST_NAME + "/bu";
        this.options = this._constant.options;
    }
    BusinessUnitService.prototype.getBUnit = function () {
        return this._http.get(this.baseurl + '/bunit', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getBUDetails = function () {
        return this._http.get(this.baseurl + '/BUDetails', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getDetailsByType = function (type) {
        return this._http.get(this.baseurl + '/details/' + type, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getAppNameByBUnit = function (bunit) {
        return this._http.get(this.baseurl + '/app/name/' + bunit, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getEntityNameByBUnitAndAppName = function (bunit, appName) {
        return this._http.get(this.baseurl + '/entity/name/' + bunit + '/' + appName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getEntityNameByApplicationId = function (appName) {
        return this._http.get(this.baseurl + '/entity/name/' + appName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getESNameByBUnitAndAppNameAndEntityName = function (bunit, appName, entityName) {
        return this._http.get(this.baseurl + '/es/name/' + bunit + '/' + appName + '/' + entityName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getESNameByEntityId = function (entityName) {
        return this._http.get(this.baseurl + '/es/name/' + entityName, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.getInterfaceNameByEntity = function (bunit, appName, entity) {
        return this._http.get(this.baseurl + '/interface/name/' + bunit + '/' + appName + '/' + entity, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.createMasterData = function (bioLOVsData) {
        console.log("bioLOVsData:" + JSON.stringify(bioLOVsData));
        return this._http.post(this.baseurl + '/saveMasterData', JSON.stringify(bioLOVsData), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    BusinessUnitService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    BusinessUnitService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__["AppConstantService"]])
    ], BusinessUnitService);
    return BusinessUnitService;
}());



/***/ }),

/***/ "./src/app/service/dashboard.service.ts":
/*!**********************************************!*\
  !*** ./src/app/service/dashboard.service.ts ***!
  \**********************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var DashboardService = /** @class */ (function () {
    function DashboardService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.baseurl = this._constant.HOST_NAME + "/dashboard";
        this.options = this._constant.options;
    }
    DashboardService.prototype.getAllDonutChartData = function () {
        console.log("getAllDonutChartData:");
        return this._http.get(this.baseurl + '/donut', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getAllGraphDetails = function () {
        console.log("getAllGraphDetails:");
        return this._http.get(this.baseurl + '/dashboardDetails', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getAllBarChartData = function () {
        return this._http.get(this.baseurl + '/logging/bar', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getNotificationBarChartData = function () {
        return this._http.get(this.baseurl + '/notification/bar', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getAllSankeyGraphData = function () {
        console.log("getAllSankeyGraphData:");
        return this._http.get(this.baseurl + '/graph/sankygraph', this.options).map(function (res) {
            return res.json();
        }).catch(this.errorHandler);
    };
    DashboardService.prototype.getAllDonutChartDataBySearch = function (buSearch) {
        return this._http.post(this.baseurl + '/donut', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getAllBarChartDataBySearch = function (buSearch) {
        return this._http.post(this.baseurl + '/logging/bar', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getNotificationBarChartDataBySearch = function (buSearch) {
        return this._http.post(this.baseurl + '/notification/bar', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    DashboardService.prototype.getSankeyGraphDataBySearch = function (buSearch) {
        return this._http.post(this.baseurl + '/graph/sankygraph/search', JSON.stringify(buSearch), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    /* getAllDonutChartData()
     {
       return this._http.get(this.baseurl+'/donut', this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getDonutChartDataByBUnit(bunit:String)
     {
       return this._http.get(this.baseurl+'/donut/'+bunit, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getDonutChartDataByBUnitAndAppName(bunit:String, appName:String)
     {
       return this._http.get(this.baseurl+'/donut/'+bunit+'/'+appName, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getAllBarChartData()
     {
       return this._http.get(this.baseurl+'/bar', this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getBarChartDataByBUnit(bunit:String)
     {
       return this._http.get(this.baseurl+'/bar/'+bunit, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getBarChartDataByBUnitAndAppName(bunit:String, appName:String)
     {
       return this._http.get(this.baseurl+'/bar/'+bunit+'/'+appName, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getNotificationBarChartData()
     {
       return this._http.get(this.baseurl+'/notification/bar', this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getNotificationBarChartDataByBUnit(bunit:String)
     {
       return this._http.get(this.baseurl+'/notification/bar/'+bunit, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }
   
     getNotificationBarChartDataByBUnitAndAppName(bunit:String, appName:String)
     {
       return this._http.get(this.baseurl+'/notification/bar/'+bunit+'/'+appName, this.options).map((res: Response) => res.json())
       .catch(this.errorHandler);
     }*/
    DashboardService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    DashboardService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__["AppConstantService"]])
    ], DashboardService);
    return DashboardService;
}());



/***/ }),

/***/ "./src/app/service/force-direct.service.ts":
/*!*************************************************!*\
  !*** ./src/app/service/force-direct.service.ts ***!
  \*************************************************/
/*! exports provided: ForceDirectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForceDirectService", function() { return ForceDirectService; });
var ForceDirectService = /** @class */ (function () {
    function ForceDirectService() {
    }
    ForceDirectService.prototype.getArray = function (__countData) {
        var m0 = {
            id: "ee91e4c1347f8afb@127",
            variables: [{
                    inputs: ["md"],
                    value: (function (md) {
                        return (md);
                    })
                },
                {
                    name: "chart",
                    inputs: ["data", "forceSimulation", "d3", "DOM", "width", "height", "color", "drag"],
                    value: (function (data, forceSimulation, d3, DOM, width, height, color, drag) {
                        var links = data.links.map(function (d) { return Object.create(d); });
                        var nodes = data.nodes.map(function (d) { return Object.create(d); });
                        var simulation = forceSimulation(nodes, links).on("tick", ticked);
                        /* const svg = d3.select(DOM.svg(width, height))
                          .attr("viewBox", [-width / 2, -height / 2, width, height]);
              */
                        var svg = d3.select(DOM.svg('520', '370'))
                            .attr("viewBox", [-width / 2, -height / 2, width, height]);
                        var link = svg.append("g")
                            .attr("stroke", "#999")
                            .attr("stroke-opacity", 10)
                            .selectAll("line")
                            .data(links)
                            .enter().append("line")
                            .attr("stroke-width", function (d) { return Math.sqrt(d.value); });
                        var node = svg.append("g")
                            .selectAll("g")
                            .data(nodes)
                            .enter().append("g");
                        var circle = node.append("circle")
                            .attr("r", 30)
                            .attr("fill", color)
                            .attr("label", JSON.stringify(nodes))
                            .call(drag(simulation))
                            .on('click', function () {
                            console.log('clicked: ', this);
                            //   this.redirectTo('foo');
                        });
                        var lables = node.append("text")
                            .text(function (d) {
                            //            console.log("text:"+d.id);
                            return d.id;
                        })
                            .attr('width', 100)
                            .attr('x', 32)
                            .attr('y', 12);
                        node.append("title")
                            .text(function (d) {
                            //              console.log("title:"+d.id);
                            return d.id;
                        });
                        function ticked() {
                            link
                                .attr("x1", function (d) { return d.source.x; })
                                .attr("y1", function (d) { return d.source.y; })
                                .attr("x2", function (d) { return d.target.x; })
                                .attr("y2", function (d) { return d.target.y; });
                            node.attr("transform", function (d) {
                                return "translate(" + d.x + "," + d.y + ")";
                            });
                        }
                        return svg.node();
                    })
                },
                {
                    name: "forceSimulation",
                    inputs: ["d3"],
                    value: (function (d3) {
                        return (function forceSimulation(nodes, links) {
                            return d3.forceSimulation(nodes)
                                .force("link", d3.forceLink().distance(function (d) { console.log(999); return d.id; }).strength(2))
                                .force("link", d3.forceLink(links).id(function (d) { return d.id; }).distance(function (d) { return 350; }).strength(1)) //
                                .force("charge", d3.forceManyBody().strength(-350));
                            /*    .force("x", d3.forceX())
                                .force("y", d3.forceY()); */
                        });
                    })
                },
                {
                    name: "data",
                    value: __countData
                    //         value: (async function(){return(
                    //   (await fetch("https://gist.githubusercontent.com/mbostock/74cb803c013404ac30e63f020a52a2fd/raw/c7c74c939b602c56c80848963f9ad24802baaead/graph.json")).json()
                    //   )})
                },
                {
                    name: "height",
                    value: (function () {
                        return (680);
                    })
                },
                {
                    name: "color",
                    inputs: ["d3"],
                    value: (function (d3) {
                        var scale = d3.scaleOrdinal(d3.schemeCategory10);
                        return function (d) { return scale(d.group); };
                    })
                },
                {
                    name: "drag",
                    inputs: ["d3"],
                    value: (function (d3) {
                        return (function (simulation) {
                            function dragstarted(d) {
                                if (!d3.event.active)
                                    simulation.alphaTarget(0.3).restart();
                                d.fx = d.x;
                                d.fy = d.y;
                            }
                            function dragged(d) {
                                d.fx = d3.event.x;
                                d.fy = d3.event.y;
                            }
                            function dragended(d) {
                                if (!d3.event.active)
                                    simulation.alphaTarget(0);
                                d.fx = null;
                                d.fy = null;
                            }
                            return d3.drag()
                                .on("start", dragstarted)
                                .on("drag", dragged)
                                .on("end", dragended);
                        });
                    })
                },
                {
                    name: "d3",
                    inputs: ["require"],
                    value: (function (require) {
                        return (require("d3@5"));
                    })
                },
            ]
        };
        return {
            id: "ee91e4c1347f8afb@127", modules: [m0]
        };
    };
    ForceDirectService.prototype.childNode = function () {
        console.log("inseide the child node");
    };
    return ForceDirectService;
}());



/***/ }),

/***/ "./src/app/service/purge.service.ts":
/*!******************************************!*\
  !*** ./src/app/service/purge.service.ts ***!
  \******************************************/
/*! exports provided: PurgeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurgeService", function() { return PurgeService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var PurgeService = /** @class */ (function () {
    function PurgeService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.baseurl = this._constant.HOST_NAME + "/bioPurge";
        this.options = this._constant.options;
    }
    PurgeService.prototype.getPurgeHistoryDetails = function () {
        return this._http.get(this.baseurl + '/purgeHistory', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    PurgeService.prototype.purgeDetails = function (id) {
        return this._http.get(this.baseurl + '/purgeDetails/' + id, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    PurgeService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    PurgeService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__["AppConstantService"]])
    ], PurgeService);
    return PurgeService;
}());



/***/ }),

/***/ "./src/app/service/relationshipsGraphService.ts":
/*!******************************************************!*\
  !*** ./src/app/service/relationshipsGraphService.ts ***!
  \******************************************************/
/*! exports provided: RelationshipsGraphService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RelationshipsGraphService", function() { return RelationshipsGraphService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! d3 */ "./node_modules/d3/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RelationshipsGraphService = /** @class */ (function () {
    function RelationshipsGraphService() {
        this.margin = { top: 10, bottom: 20, left: 50, right: 20 };
        this.i = 0;
        this.duration = 750;
    }
    // ngOnInit() {
    //   // console.log('TREE CHART');
    //   /*this.createChart();
    //   if (this.data) {
    //     // this.updateChart();
    //   }*/
    // }
    // ngOnChanges() {
    //   if (this.chart) {
    //     //this.updateChart();
    //   }
    // }
    RelationshipsGraphService.prototype.createChart = function (data) {
        // console.log(this.data);
        this.width = 310 - this.margin.left - this.margin.right,
            this.height = 350 - this.margin.top - this.margin.bottom;
        this.svg = d3__WEBPACK_IMPORTED_MODULE_1__["select"](".d3-chart").append("svg")
            .attr("width", 'this.width + this.margin.right + this.margin.left')
            .attr("height", this.height + this.margin.top + this.margin.bottom)
            .append("g")
            .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
        // declares a tree layout and assigns the size
        this.treemap = d3__WEBPACK_IMPORTED_MODULE_1__["tree"]().size([this.height, this.width]);
        // Assigns parent, children, height, depth
        this.root = d3__WEBPACK_IMPORTED_MODULE_1__["hierarchy"](data, function (d) { console.log(d['children']); return d['children']; });
        this.root.x0 = this.height / 2;
        this.root.y0 = 1;
        // Collapse after the second level
        this.root.children.forEach(collapse); // forEach(this.collapse);
        this.update(this.root);
    };
    // Collapse the node and all it's children
    RelationshipsGraphService.prototype.update = function (source) {
        var self = this;
        // Assigns the x and y position for the nodes
        this.treeData = this.treemap(this.root);
        // Compute the new tree layout.
        this.nodes = this.treeData.descendants(),
            this.links = this.treeData.descendants().slice(1);
        // Normalize for fixed-depth.
        this.nodes.forEach(function (d) { d.y = d.depth * 100; });
        // ****************** Nodes section ***************************
        // Update the nodes...
        var node = this.svg.selectAll('g.node')
            .data(this.nodes, function (d) { return d.id || (d.id = ++this.i); });
        // Enter any new modes at the parent's previous position.
        var nodeEnter = node.enter().append('g')
            .attr('class', 'node')
            .attr("transform", function (d) {
            return "translate(" + source.y0 + "," + source.x0 + ")";
        })
            .on('click', function (d) {
            if (d.children) {
                d._children = d.children;
                d.children = null;
            }
            else {
                d.children = d._children;
                d._children = null;
            }
            console.log(self);
            self.update(d);
        });
        // Add Circle for the nodes
        nodeEnter.append('circle')
            .attr('class', 'node')
            .attr('r', 1e-6)
            .style("fill", function (d) {
            return d._children ? "lightsteelblue" : "#fff";
        });
        // Add labels for the nodes
        nodeEnter.append('text')
            .attr("dy", ".35em")
            .attr("x", function (d) {
            return d.children || d._children ? -13 : 13;
        })
            .attr("text-anchor", function (d) {
            return d.children || d._children ? "end" : "start";
        })
            .text(function (d) { return d.data.name; });
        // UPDATE
        var nodeUpdate = nodeEnter.merge(node);
        // Transition to the proper position for the node
        nodeUpdate.transition()
            .duration(this.duration)
            .attr("transform", function (d) {
            return "translate(" + d.y + "," + d.x + ")";
        });
        // Update the node attributes and style
        nodeUpdate.select('circle.node')
            .attr('r', 10)
            .style("fill", function (d) {
            return d._children ? "lightsteelblue" : "#fff";
        })
            .attr('cursor', 'pointer');
        // Remove any exiting nodes
        var nodeExit = node.exit().transition()
            .duration(this.duration)
            .attr("transform", function (d, self) {
            return "translate(" + source.y + "," + source.x + ")";
        })
            .remove();
        // On exit reduce the node circles size to 0
        nodeExit.select('circle')
            .attr('r', 1e-6);
        // On exit reduce the opacity of text labels
        nodeExit.select('text')
            .style('fill-opacity', 1e-6);
        // ****************** links section ***************************
        // Update the links...
        var link = this.svg.selectAll('path.link')
            .data(this.links, function (d) { return d.id; });
        // Enter any new links at the parent's previous position.
        var linkEnter = link.enter().insert('path', "g")
            .attr("class", "link")
            .attr('d', function (d) {
            var o = { x: source.x0, y: source.y0 };
            return self.diagonal(o, o); //this.diagonal(o, o);
        });
        // UPDATE
        var linkUpdate = linkEnter.merge(link);
        // Transition back to the parent element position
        linkUpdate.transition()
            .duration(this.duration)
            .attr('d', function (d) { return self.diagonal(d, d.parent); });
        // Remove any exiting links
        var linkExit = link.exit().transition()
            .duration(this.duration)
            .attr('d', function (d) {
            var o = { x: source.x, y: source.y };
            return self.diagonal(o, o);
        })
            .remove();
        // Store the old positions for transition.
        this.nodes.forEach(function (d) {
            d.x0 = d.x;
            d.y0 = d.y;
        });
    };
    // Creates a curved (diagonal) path from parent to the child nodes
    RelationshipsGraphService.prototype.diagonal = function (s, d) {
        var path = "M " + s.y + " " + s.x + "\n          C " + (s.y + d.y) / 2 + " " + s.x + ",\n            " + (s.y + d.y) / 2 + " " + d.x + ",\n            " + d.y + " " + d.x;
        return path;
    };
    // Toggle children on click.
    RelationshipsGraphService.prototype.click = function (d, self) {
        //console.log(this);
        // const self = this;
        if (d.children) {
            d._children = d.children;
            d.children = null;
        }
        else {
            d.children = d._children;
            d._children = null;
        }
        console.log(self);
        self.update(d);
    };
    RelationshipsGraphService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], RelationshipsGraphService);
    return RelationshipsGraphService;
}());

function collapse(d) {
    if (d.children) {
        d._children = d.children;
        d._children.forEach(collapse);
        d.children = null;
    }
}


/***/ }),

/***/ "./src/app/service/user-session.service.ts":
/*!*************************************************!*\
  !*** ./src/app/service/user-session.service.ts ***!
  \*************************************************/
/*! exports provided: UserSessionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserSessionService", function() { return UserSessionService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var UserSessionService = /** @class */ (function () {
    function UserSessionService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.msg = '';
        this.baseurl = this._constant.HOST_NAME + "/biolog";
        this.options = this._constant.options;
    }
    UserSessionService.prototype.setUserName = function (uname) {
        this.uname = uname;
    };
    UserSessionService.prototype.setFileURL = function (fileURL) {
        this.fileURL = fileURL;
    };
    UserSessionService.prototype.getFileURL = function () {
        return this.fileURL;
    };
    UserSessionService.prototype.getUserName = function () {
        return this.uname;
    };
    UserSessionService.prototype.setUserType = function (userType) {
        this.userType = userType;
    };
    UserSessionService.prototype.getUserType = function () {
        return this.userType;
    };
    UserSessionService.prototype.setHostName = function (hostName) {
        this.hostName = hostName;
    };
    UserSessionService.prototype.getHostName = function () {
        return this.hostName;
    };
    UserSessionService.prototype.getMsg = function () {
        return this.msg;
    };
    UserSessionService.prototype.setMsg = function (msg) {
        this.msg = msg;
    };
    UserSessionService.prototype.getUserNameByUserId = function () {
        console.log("inside the getUserNameByUserId method in user-session.service.ts:");
        return this._http.get(this.baseurl + '/networkUserName', this.options).map(function (res) { return res.json(); })
            .catch(this.GlobalErrorHandler);
    };
    // getUserNameByUserId(userId:String)
    // {
    //   console.log("inside the getUserNameByUserId method in user-session.service.ts");
    //   return this._http.get(this.baseurl+'/networkUserName', this.options).map((res: Response) => res.json())
    //       .catch(this.errorHandler);
    // }
    UserSessionService.prototype.logout = function (userId) {
        console.log("inside the logOut method in user-session.service.ts:");
        return this._http.get(this.baseurl + '/logOut/' + userId, this.options).map(function (res) { return res.json(); })
            .catch(this.GlobalErrorHandler);
    };
    UserSessionService.prototype.getServiceName = function () {
        console.log("inside the getServiceName method in user-session.service.ts:");
        return this._http.get(this.baseurl + '/getName', this.options).map(function (res) { return res.json(); })
            .catch(this.GlobalErrorHandler);
    };
    UserSessionService.prototype.GlobalErrorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    UserSessionService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_6__["AppConstantService"]])
    ], UserSessionService);
    return UserSessionService;
}());



/***/ }),

/***/ "./src/app/service/user.service.ts":
/*!*****************************************!*\
  !*** ./src/app/service/user.service.ts ***!
  \*****************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/Observable/throw */ "./node_modules/rxjs/add/Observable/throw.js");
/* harmony import */ var rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_Observable_throw__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _dao_user__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dao/user */ "./src/app/dao/user.ts");
/* harmony import */ var _dao_biologuser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../dao/biologuser */ "./src/app/dao/biologuser.ts");
/* harmony import */ var _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../constant/app-constant.service */ "./src/app/constant/app-constant.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var UserService = /** @class */ (function () {
    function UserService(_http, _constant) {
        this._http = _http;
        this._constant = _constant;
        this.user = new _dao_user__WEBPACK_IMPORTED_MODULE_6__["User"]();
        this.biologuser = new _dao_biologuser__WEBPACK_IMPORTED_MODULE_7__["Biologuser"]();
        this.baseurl = this._constant.HOST_NAME + "/bio";
        this.baseurlnew = this._constant.HOST_NAME + "/biolog";
        this.options = this._constant.options;
    }
    UserService.prototype.getBioLogUsers = function () {
        return this._http.get(this.baseurlnew + '/users', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.getAllBioLogUsers = function () {
        return this._http.get(this.baseurlnew + '/all/biologusers', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.getBioLogUser = function (userId) {
        return this._http.get(this.baseurlnew + '/user/' + userId, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.getUsers = function () {
        return this._http.get(this.baseurl + '/users', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.getUser = function (id) {
        return this._http.get(this.baseurl + '/user/' + id, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.deleteUser = function (id) {
        return this._http.delete(this.baseurl + '/user/' + id, this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.createUser = function (user) {
        return this._http.post(this.baseurl + '/user', JSON.stringify(user), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.updateUser = function (user) {
        return this._http.put(this.baseurl + '/user', JSON.stringify(user), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.getUserTypeList = function () {
        return this._http.get(this.baseurlnew + '/user/type', this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.createBioLogUser = function (biologuser) {
        return this._http.post(this.baseurlnew + '/user/save', JSON.stringify(biologuser), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.deleteBioLogUser = function (biologuser) {
        return this._http.post(this.baseurlnew + '/user/delete', JSON.stringify(biologuser), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.logOut = function () {
        return this._http.post('/eisUtilWeb/login', JSON.stringify(""), this.options).map(function (res) { return res.json(); })
            .catch(this.errorHandler);
    };
    UserService.prototype.errorHandler = function (error) {
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error || "Server Error");
    };
    UserService.prototype.setter = function (user) {
        this.user = user;
    };
    UserService.prototype.getter = function () {
        return this.user;
    };
    UserService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"], _constant_app_constant_service__WEBPACK_IMPORTED_MODULE_8__["AppConstantService"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: true
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\rodricks\BioGen\ETM_Developement\EisUtil_Angular\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map