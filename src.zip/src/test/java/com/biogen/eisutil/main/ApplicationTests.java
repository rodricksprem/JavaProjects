package com.biogen.eisutil.main;

/*@RunWith(SpringRunner.class)
@SpringBootTest*/
public class ApplicationTests {

	/*@Test
	public void contextLoads() {
	}*/

}
