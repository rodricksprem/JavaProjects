package com.bct.weeklystatus.services;

import com.bct.weeklystatus.entities.ProjectStatusDetail;

public interface ProjectStatusDetailService {

	
	public void saveProjectStatusDetail(ProjectStatusDetail projectStatusDetail);

	public void deleteProjectStatusDetail(ProjectStatusDetail projectStatusDetail);
	

}
