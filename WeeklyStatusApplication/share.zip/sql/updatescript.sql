UPDATE `bct_account` SET `account_owner` = 'Meeza Implementation' WHERE (`account_id` = '17');
UPDATE `bct_dashboard_fields` SET `date_selection_flag` =true, `description_flag` = true, `module_flag` = true, `status_flag` = true, `development_flag` = true WHERE (`project_id` = '1500');

UPDATE `bct_dashboard_fields` SET `remarks_flag` = false, `resource_flag` = true, `account_flag` = true WHERE (`project_id` = '500');

UPDATE `bct_dashboard_fields` SET `member_flag` = true WHERE (`project_id` = '1300');
UPDATE `bct_dashboard_fields` SET `date_selection_flag` = true, `status_flag` = true, `activity_flag` = true WHERE (`project_id` = '1100');
