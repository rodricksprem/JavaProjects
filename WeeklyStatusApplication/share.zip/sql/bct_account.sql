/*
-- Query: SELECT * FROM test.bct_account
LIMIT 0, 1000

-- Date: 2020-05-17 21:53
*/
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('1','Bahwan Excel','Bahwan Excel',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('10','OAB','OAB Support',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('11','Tesla Motors, Inc','Tesla Motors',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('12','Tranzact LLC','Tranzact LLC',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('13','University of Alabama','University of Alabama',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('14','Zycus - TAQA','Zycus - TAQA',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('16','Bench','Bench',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('17','Meeza technical Implementation','Meeza',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('2','BCT Internal','BCT Internal',2,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('3','Biogen','Biogen SOA Development & Support',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('4','CAFM','CAFM',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('5','CDOT','CDOT',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('6','CG','CG Support',2,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('7','Hudson Alpha','HA-GEP',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('8','IVMS - Monitoring Support','IVMS - Monitoring Support',1,NULL);
INSERT INTO bct_account (`account_id`,`account_name`,`account_owner`,`account_status`,`remarks`) VALUES ('9','Meeza','Meeza - Development & Support',1,NULL);
