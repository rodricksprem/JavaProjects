export class BctLogDetails {
    messageCode:string;
    messageDesc:string;
    logLevel:string;
    payLoad:string;
    serviceInvoker:string;
    serviceStatus:string;
    serviceStartTime:string;
    key:string;
    value:string;
}
