export class BUSearch {
    accountName:string;
    projectName:string;
     status:string;
    startDate:string;
    endDate:string;
}
