export class User {
    id:number;
    fname:string;
    lname:string;
}
