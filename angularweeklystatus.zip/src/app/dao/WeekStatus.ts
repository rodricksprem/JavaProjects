
export class WeekStatus {
    weekduration:string;
    projectStatus:number;

    
}
