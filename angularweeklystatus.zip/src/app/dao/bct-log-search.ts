export class BctLogSearch {
    bioTransId:string;
    appGroup:string;
    appName:string;
    key:string;
    condition:string;
    value:string;
    period:string;
    startDate:string;
    endDate:string;
    status:string[];
    duration:Number;
}
