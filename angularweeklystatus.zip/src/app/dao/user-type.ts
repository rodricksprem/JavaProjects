export class UserType {

    userType:string[];
}
