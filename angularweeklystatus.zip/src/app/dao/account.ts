export class Account {
    accountID:number;
    accountName:string;
    projectList:string;
    status:string;
    remarks:string;
    createdDate:string;
    updatedDate:string;
}
