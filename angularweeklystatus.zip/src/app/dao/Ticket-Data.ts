export class TicketData {
    projectName:string;
	weekDuration:string;
	ticketCreatedDate:Date;
	l1IssuesOpened:number;
    l1IssuesClosed:number;
    l2IssuesOpened:number;
    l2IssuesClosed:number;
}
