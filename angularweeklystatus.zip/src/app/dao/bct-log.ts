export class BctLog {
    bioTransId:string;
    appGroup:string;
    appName:string;
    // key:string;
    // value:string;
    message:string;
    serviceInvoker:string;
    serviceInvokerStatus:string;
    startTime:string;
    endTime:string
}
