
/* $(document).on('click', '.sidebar-menu .treeview', function (event) {
    if ($(this).hasClass("menu-open")){
        $(this).removeClass("menu-open");

    } else {
        $(".treeview").removeClass("menu-open");
        $(this).addClass("menu-open");
    }
}); */