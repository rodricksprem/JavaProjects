from java.lang import *
from java.util import *
from javax.management import *
from weblogic.connector.exception import RAOutboundException
from weblogic.application import ModuleException 

import javax.management.Attribute
file_loc='domainenv_'+sys.argv[1]+'.properties'
file=java.io.File(file_loc)
if file.exists():
	loadProperties(file_loc)
#MODULENAME=sys.argv[1]
file_loc='weblogic_resources_'+sys.argv[1]+'.properties'
print 'file loc: ' , file_loc
file=java.io.File(file_loc)
if file.exists():
	loadProperties(file_loc)
	
admin_url='t3://'+str(IP_URL)+':'+str(ADMIN_PORT)
jmsSystemResourceName=MODULENAME+'JmsSystemModule'
jmsSubDeploymentName=MODULENAME+'SubDeployment'


#connect to the AdminServer 

connect(userConfigFile=UserConfigFile,userKeyFile=UserKeyFile, url=admin_url)

################################################################################################################################################################
#creating FileStores on the Managed Server based on the properties given.#
################################################################################################################################################################

def creatingFileStores():
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = FILE_STORE+'.'+str(item)
					try:
						edit()
						startEdit(true)
						#iterate for each mananged server
						for x,fileStoreName in mydict.items():
							cd('/')
							#get MBean instance of the Managed Server Migratable target
							serverName='MigratableTargets/'+x+' (migratable)'
							servermb=getMBean(serverName)
							if servermb is None:
								print '@@@ No server MBean found, so target is not set !!!'
							else:	
								try:
									cd('/')
									fileStoremb=getMBean('FileStores/'+fileStoreName)
									if(fileStoremb!=None):
										print fileStoreName + ' already exist '
									else:
										cd('/')
										cd('FileStores')
										print '@@@ Creating the FileStore @@@ '+fileStoreName
										fileStoremb = create(fileStoreName,'FileStore')
										fileStoremb.setDirectory(FILE_STORE_DIRECTORY)
										fileStoremb.addTarget(servermb)
										print '@@@ Created the FileStore @@@ '+fileStoreName
										cd('/')		
								except 	Exception, e1:
									print 'Exception occurs while creating filestore '+fileStoreName  
						activate()
						print 'End of creatingFileStores() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingFileStores() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')

################################################################################################################################################################
#Deleting FileStores on the Managed Server based on the properties given.#
################################################################################################################################################################	
def deletingFileStores():
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = FILE_STORE+'.'+str(item)
					try:
						edit()
						startEdit(true)
						#iterate for each mananged server
						for x,fileStoreName in mydict.items():
							try:
								cd('/')
								filestoreMB=getMBean('FileStores/'+fileStoreName)
								if(filestoreMB!=None):
									cd('/')
									cd('FileStores/'+fileStoreName)
									fs=cmo
									cd('..')
									print '@@@ Deleting  the filestore @@@ '+fileStoreName
									cmo.destroyFileStore(fs)
									print '@@@ Deleted  the filestore @@@ '+fileStoreName
									cd('/')
								else:	
									print fileStoreName + ' not  exist '
							except 	Exception, e1:
								print 'Exception occurs while deleting filestore '+fileStoreName  
						activate()
						print 'End of deletingFileStores() ...'
					except Exception, e2:
					    print 'ACTIVATION FAILED in deletingFileStores() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
					    undo('true','y')
	
################################################################################################################################################################
#Creating JMS Servers on the Managed Server based on the properties given.#
################################################################################################################################################################		
def creatingJMSServers():
					jmsServerName=JMS_SERVER_NAME
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = JMS_SERVER_NAME+'.'+str(item)
					try:
						edit()
						startEdit(true)
						#iterate for each mananged server
						for x,jmsServerName in mydict.items():
								cd('/')	
								serverName='MigratableTargets/'+x+' (migratable)'
								#get MBean instance of the Managed Server
								#or else get MBean instance of the Managed Server Migratable target
								servermb=getMBean(serverName)
								if servermb is None:
									print '@@@ No server MBean found, so target is not set !!!'
								# MBean instance is valid
								else:	
									try:
										cd('/')
										jmsservermb=getMBean('JMSServers/'+jmsServerName)
										if(jmsservermb!=None):
											print jmsServerName + ' already exists'
										else:
											cd('/')
											print '@@@ Creating the JMSServer @@@ '+jmsServerName
											#creating JMSServer
											cd('JMSServers')
											jmsservermb = create(jmsServerName,'JMSServer')
											cd('/')
											fileStoreName='FileStores/'+FILE_STORE+'.'+x
											#get MBean instance of the filestore
											fileStoremb=getMBean(fileStoreName)
											cd('/')
											if fileStoremb is None:
												print '@@@ No FileStore MBean found ,so persistence store is not set !!!!!'
											else:
												#set the filestore as the persistent store for the JMSServer
												jmsservermb.setPersistentStore(fileStoremb)
												print '@@@ Set the Persistence Store for the jmsserver @@@ '+jmsServerName
												#set the target as MBean instance of the Managed Server
												jmsservermb.addTarget(servermb)
												print '@@@ Created the jmsserver @@@ '+jmsServerName
									except 	Exception, e1:
										print 'Exception occurs while creating  jmsserver '+jmsServerName
						activate()
						print 'End of creatingJMSServers() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingJMSServers() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting JMS Servers on the Managed Server based on the properties given.#
################################################################################################################################################################
def deletingJMSServers():
					jmsServerName=JMS_SERVER_NAME
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = JMS_SERVER_NAME+'.'+str(item)
					try:
						edit()
						startEdit(true)
						#iterate for each mananged server
						for x,jmsServerName in mydict.items():
									try:
										cd('/')
										jmsservermb=getMBean('JMSServers/'+jmsServerName)
										if(jmsservermb!=None):
											cd('/')
											cd('JMSServers/'+jmsServerName)
											jmsserver=cmo
											cd('..')
											print '@@@ Deleting  the jmsserver @@@ '+jmsServerName
											cmo.destroyJMSServer(jmsserver)
											print '@@@ Deleted  the jmsserver @@@ '+jmsServerName
											cd('/')
										else:
											print jmsServerName + ' not  exist '
									except 	Exception, e1:
										print 'Exception occurs while deleting jmsserver '+jmsServerName
						activate()
						print 'End of deletingJMSServers() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingJMSServers() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')


################################################################################################################################################################
#Creating JMS System Module on the Managed Server based on the properties given.#
################################################################################################################################################################	
def creatingJMSSystemModule():
					try:
						edit()
						startEdit(true)
						cd('/')
						#get MBean instance of the Cluster Server
						targetmb=getMBean('Clusters/'+CLUSTER_NAME)
						if targetmb is None:
							print '@@@ No cluster MBean found ,so target cannot be set !!!'
						# MBean instance is valid
						else:	
							try:
								cd('/')
								jmsSystemResourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
								if(jmsSystemResourcemb!=None):
									print jmsSystemResourceName + ' already   exist '
								else:
									cd('/')
									print '@@@ Creating the JMSSystemResource @@@ '+jmsSystemResourceName
									cd('JMSSystemResources')
									#creating JMSSystemResource
									jmsSystemResourcemb = create(jmsSystemResourceName,'JMSSystemResource')
									#set the target as MBean instance of the Cluster Server
									jmsSystemResourcemb.addTarget(targetmb)
									print '@@@ Created the JMSSystemResource @@@ '+jmsSystemResourceName
									cd('/')
							except 	Exception, e1:
								print 'Exception occurs while creating jms system module '+jmsSystemResourceName
						activate()
						print 'End of creatingJMSSystemModule() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingJMSSystemModule() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting JMS System Module on the Managed Server based on the properties given.#
################################################################################################################################################################		
def deletingJMSSystemModule():
					try:
						edit()
						startEdit(true)
						try:
							cd('/')
							jmsSystemResourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
							if(jmsSystemResourcemb!=None):
								cd('/')
								print '@@@ Deleting the JMSSystemResource @@@ '+jmsSystemResourceName
								#creating JMSSystemResource
								cd('JMSSystemResources/'+jmsSystemResourceName)
								jmsSystemResourcemb=cmo
								cd('..')
								cmo.destroyJMSSystemResource(jmsSystemResourcemb)
								print '@@@ Deleted the JMSSystemResource @@@ '+jmsSystemResourceName
								cd('/')
							else:
								print jmsSystemResourceName + ' is not   exist '
						except 	Exception, e1:
							print 'Exception occurs while deleting jms system module '+jmsSystemResourceName
						activate()
						print 'End of deletingJMSSystemModule() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingJMSSystemModule() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Creating Capability's SubDeployment Module on the JMS Servers based on the properties given.#
################################################################################################################################################################
def creatingSubDeployment():
					msServerName=JMS_SERVER_NAME
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					mydict1 = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = JMS_SERVER_NAME+'.'+str(item)
					try:
						edit()
						startEdit(true)
						#iterate for each jms server
						for x,jmsServerName in mydict.items():
								cd('/')
								jmsServerName='JMSServers/'+jmsServerName
								#get MBean instance of the JMS Server 
								jmsservermb=getMBean(jmsServerName)
								if jmsservermb is None:
									print '@@@ No JMS Server MBean found , hence this jmsserver '+jmsServerName +' cannot be set as an target for subdeployment !!!'
								# MBean instance is valid
								else:	
									mydict1[jmsServerName] = jmsservermb
						cd('/')			
						#get MBean instance of the JMSSystemResources 
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence subdeployment cannot be created !!!'
						else:
								try:
									cd('/')
									jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
									if(jmssubdeploymentmb!=None):
										print jmsSubDeploymentName + ' already   exist '
									else:	
										print '@@@ Creating the SubDeployment @@@  '+jmsSubDeploymentName
										#creating SubDeployment
										jmssubdeploymentmb = jmssystemresourcemb.createSubDeployment(jmsSubDeploymentName)
										print '@@@ Created the SubDeployment @@@  '+jmsSubDeploymentName
										for jmsServerName,jmsservermb in mydict1.items():				
											#set the target as MBean instance of the Managed Server
											jmssubdeploymentmb.addTarget(jmsservermb)			
								except 	Exception, e1:
									print 'Exception occurs while creating SubDeployment '+jmsSubDeploymentName		
						activate()
						print 'End of creatingSubDeployment()  ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingSubDeployment() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting Capability's SubDeployment Module on the JMS Servers based on the properties given.#
################################################################################################################################################################						
def deletingSubDeployment():
					msServerName=JMS_SERVER_NAME
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					mydict1 = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = JMS_SERVER_NAME+'.'+str(item)
					try:
						edit()
						startEdit(true)
						try:
							cd('/')
							#get MBean instance of the JMSSystemResources 
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
									print '@@@ No JMSSystemResources MBean found , so subdeployment cannot be deleted !!!'
							else:	
									cd('/')
									jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
									if(jmssubdeploymentmb!=None):
										print '@@@ Deleting the SubDeployment  @@@ '+jmsSubDeploymentName
										jmssystemresourcemb.destroySubDeployment(jmssubdeploymentmb)
										print '@@@ Deleted the SubDeployment  @@@ '+jmsSubDeploymentName
									else:
										print jmsSubDeploymentName + ' is not  exist '				
									cd('/')
						except 	Exception, e1:
								print 'Exception while deleting SubDeployment '+jmsSubDeploymentName	
						activate()
						print 'End of deletingSubDeployment() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingSubDeployment() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')

################################################################################################################################################################
#Creating JMS Connection Factories with XA enabled and targeted to SubDeployment  based on the properties given.#
################################################################################################################################################################	
def creatingXAQueueConnectionFactories():
					XAQCFList=CONNECTION_FACTORIES_LIST[1:-1]
					xaqcfslist=XAQCFList.split(',')
					mydict1={}
					#for each item in List
					for xaqcf in xaqcfslist:
							#split the item into name(key),value pair
						a,b = xaqcf.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						cd('/')
						jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , so JMS Connection Factories cannot be created !!!'
						else:
								for xaqcfName,load_balancing_params in mydict1.items():
									try:
										cd('/')
										xaqcfmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/ConnectionFactories/'+xaqcfName)
										if(xaqcfmb!=None):
											print xaqcfName + ' is  exist already '
										else:
											print '@@@ Creating the ConnectionFactory @@@  '+xaqcfName
											jmssystemresource=jmssystemresourcemb.getJMSResource()
											xaqcfmb=jmssystemresource.createConnectionFactory(xaqcfName)
											xaqcfmb.setJNDIName(xaqcfName)
											loadbalancingparamsmb=xaqcfmb.getLoadBalancingParams()
											if(load_balancing_params=='LBCF'):
												loadbalancingparamsmb.setLoadBalancingEnabled(true)
												loadbalancingparamsmb.setServerAffinityEnabled(false)
											if(load_balancing_params=='SACF'): 
												loadbalancingparamsmb.setLoadBalancingEnabled(false)
												loadbalancingparamsmb.setServerAffinityEnabled(true)
											transactionparamsmb=xaqcfmb.getTransactionParams()
											transactionparamsmb.setXAConnectionFactoryEnabled(true)
											if(jmssubdeploymentmb!=None):
												xaqcfmb.setSubDeploymentName(jmsSubDeploymentName)
											else:
												print '@@@ No SubDeployments MBean found , so SubDeploymnet  cannot be targeted to ConnectionFactory !!!'
											print '@@@ Created the ConnectionFactory @@@  '+xaqcfName
									except 	Exception, e1:
										print 'Exception occurs while creating ConnectionFactory '+xaqcfName	
								
						activate()
						print 'End of creatingXAQueueConnectionFactories() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingXAQueueConnectionFactories() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting JMS Connection Factories with XA enabled and targeted to SubDeployment  based on the properties given.#
################################################################################################################################################################							
def deletingXAQueueConnectionFactories():
					XAQCFList=CONNECTION_FACTORIES_LIST[1:-1]
					xaqcfslist=XAQCFList.split(',')
					mydict1={}
					#for each item in List
					for xaqcf in xaqcfslist:
							#split the item into name(key),value pair
						a,b = xaqcf.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , so ConnectionFactories cannot be deleted'
						else:
								cd('/')	
								for xaqcfName,params in mydict1.items():
									try:
										cd('/')
										xaqcfmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/ConnectionFactories/'+xaqcfName)
										if(xaqcfmb!=None):
											cd('/')
											cd('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/ConnectionFactories/'+xaqcfName)
											xaqcf=cmo
											cd('..')
											print '@@@ Deleting the ConnectionFactory  @@@ '+xaqcfName
											cmo.destroyConnectionFactory(xaqcf)
											print '@@@ Deleted the ConnectionFactory  @@@ '+xaqcfName
											cd('/')
										else:
											print xaqcfName+ ' is  not exist '
											cd('/')
									except 	Exception, e1:
										print 'Exception occurs while deleting ConnectionFactory '+xaqcfName	
								
						activate()
						print 'End of deletingXAQueueConnectionFactories() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingXAQueueConnectionFactories !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')

################################################################################################################################################################
#Creating JMS Uniform Distributed Queue targeted to SubDeployment module  based on the properties given.#
################################################################################################################################################################
def creatingUniformDistributedQueues():
					DDQueueList=DDQueue_List[1:-1]
					ddQueues=DDQueueList.split(',')
					mydict1={}
					#for each item in List
					for ddQueue in ddQueues:
							#split the item into name(key),value pair
						a,b = ddQueue.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						cd('/')
						jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found'
						else:
								for queueName,redeliveryQueueName in mydict1.items():
									try:
										jmssystemresource=jmssystemresourcemb.getJMSResource()
										cd('/')
										queuemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+queueName)
										if queuemb is None:
											print '@@@ Creating  the UniformDistributedQueue @@@  '+queueName
											queuemb=jmssystemresource.createUniformDistributedQueue(queueName)
											queuemb.setJNDIName(queueName)
											if(jmssubdeploymentmb!=None):
												queuemb.setSubDeploymentName(jmsSubDeploymentName)
											else:
												print '@@@ No SubDeployments MBean found , so SubDeploymnet  cannot be targeted to UniformDistributedQueue !!!'	
											print '@@@ Created  the UniformDistributedQueue @@@  '+queueName											
										else:
											print '@@@ UniformDistributedQueue is already found for '+queueName
									except 	Exception, e1:
										print 'Exception while creating  the UniformDistributedQueue  '+queueName		
									try:
										if (redeliveryQueueName != ''):
											cd('/')
											redeliveryqueuemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+redeliveryQueueName)
											if redeliveryqueuemb is None:
												print '@@@ Creating  the UniformDistributedQueue @@@  '+redeliveryQueueName
												redeliveryqueuemb=jmssystemresource.createUniformDistributedQueue(redeliveryQueueName)
												redeliveryqueuemb.setJNDIName(redeliveryQueueName)
												redeliveryqueuemb.setSubDeploymentName(jmsSubDeploymentName)
												print '@@@ Created  the UniformDistributedQueue @@@  '+redeliveryQueueName													
											else:
												print '@@@ UniformDistributedQueue  is already found for '+redeliveryQueueName
											if queuemb is None or redeliveryqueuemb is None:
												print '@@@ Setting Error Destination to Source Queue is failed'
											else:
												print '@@@ Setting  the DeliveryFailureParams to @@@  '+queueName
												deliveryparamsmb=queuemb.getDeliveryFailureParams()
												deliveryparamsmb.setRedeliveryLimit(int(RedeliveryLimit))
												deliveryparamsmb.setErrorDestination(redeliveryqueuemb)
												print '@@@ Set  the DeliveryFailureParams to @@@  '+queueName
									except Exception, e2:
										print 'Exception while creating  the UniformDistributedQueue '+redeliveryQueueName
									
						activate()
						print 'End of creatingUniformDistributedQueues() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingUniformDistributedQueues() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')							
################################################################################################################################################################
#Deleting JMS Uniform Distributed Queue targeted to SubDeployment module  based on the properties given.#
################################################################################################################################################################
def deletinguniformDistributedQueues():
					DDQueueList=DDQueue_List[1:-1]
					ddQueues=DDQueueList.split(',')
					mydict1={}
					#for each item in List
					for ddQueue in ddQueues:
							#split the item into name(key),value pair
						a,b = ddQueue.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found '
						else:
								for sourceQueueName,redeliveryQueueName in mydict1.items():
									try:
										cd('/')	
										redqMbean=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+redeliveryQueueName)									
										print redqMbean
										if(redqMbean!=None):
											cd('/')
											print '@@@ Deleting  the UniformDistributedQueue @@@  '+redeliveryQueueName
											cd('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues')	
											delete(redeliveryQueueName,'UniformDistributedQueue')
											print '@@@ Deleted  the UniformDistributedQueue @@@  '+redeliveryQueueName
										else:	
											print redeliveryQueueName + ' is  not exist'
									except 	Exception, e1:
										print 'Exception while deleting  the UniformDistributedQueue '+redeliveryQueueName								
									try:
										cd('/')	
										qMbean=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+sourceQueueName)
										if(qMbean!=None):
											cd('/')
											qMbean.unSet('DeliveryFailureParams')
											print '@@@ Deleting  the UniformDistributedQueue @@@  '+sourceQueueName
											cd('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues')	
											delete(sourceQueueName,'UniformDistributedQueue')
											print '@@@ Deleted  the UniformDistributedQueue @@@  '+sourceQueueName
										else:	
											print sourceQueueName + ' is  not exist '
									except 	Exception, e1:
										print 'Exception while deleting  the UniformDistributedQueue '+sourceQueueName
						activate()
						print 'End of deletinguniformDistributedQueues() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletinguniformDistributedQueues() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Creating JMS Uniform Distributed Topic targeted to SubDeployment module  based on the properties given.#
################################################################################################################################################################
def creatingUniformDistributedTopics():
					DDTopicList=DDTopic_List[1:-1]                                      
					ddTopics=DDTopicList.split(',')
					mydict1={}
					#for each item in List
					for ddTopic in ddTopics:
							#split the item into name(key),value pair
						a,b = ddTopic.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						cd('/')
						jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found'
						else:
								for TopicName,redeliveryQueueName in mydict1.items():
									try:
										jmssystemresource=jmssystemresourcemb.getJMSResource()
										cd('/')
										Topicmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedTopics/'+TopicName)
										if Topicmb is None:
											print '@@@ Creating  the UniformDistributedTopic @@@  '+TopicName
											Topicmb=jmssystemresource.createUniformDistributedTopic(TopicName)
											Topicmb.setJNDIName(TopicName)
											if(jmssubdeploymentmb!=None):
												Topicmb.setSubDeploymentName(jmsSubDeploymentName)
											else:
												print '@@@ No SubDeployments MBean found , so SubDeploymnet  cannot be targeted to UniformDistributedTopic !!!'	
											print '@@@ Created  the UniformDistributedTopic @@@  '+TopicName											
										else:
											print '@@@ UniformDistributedTopic is already found for '+TopicName
									except 	Exception, e1:
										print 'Exception while creating  the UniformDistributedTopic  '+TopicName		
									try:
										if (redeliveryQueueName != ''):
											cd('/')
											redeliveryQueuemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+redeliveryQueueName)
											if redeliveryQueuemb is None:
												print '@@@ Creating  the UniformDistributedTopic @@@  '+redeliveryQueueName
												redeliveryQueuemb=jmssystemresource.createUniformDistributedQueue(redeliveryQueueName)
												redeliveryQueuemb.setJNDIName(redeliveryQueueName)
												redeliveryQueuemb.setSubDeploymentName(jmsSubDeploymentName)
												print '@@@ Created  the UniformDistributedTopic @@@  '+redeliveryQueueName													
											else:
												print '@@@ UniformDistributedTopic  is already found for '+redeliveryQueueName
											if Topicmb is None or redeliveryQueuemb is None:
												print '@@@ Setting Error Destination to Source Topic is failed'
											else:
												print '@@@ Setting  the DeliveryFailureParams to @@@  '+TopicName
												deliveryparamsmb=Topicmb.getDeliveryFailureParams()
												deliveryparamsmb.setRedeliveryLimit(int(RedeliveryLimit))
												deliveryparamsmb.setErrorDestination(redeliveryQueuemb)
												print '@@@ Set  the DeliveryFailureParams to @@@  '+TopicName
									except Exception, e2:
										print 'Exception while creating  the UniformDistributedTopic '+redeliveryQueueName
									
						activate()
						print 'End of creatingUniformDistributedTopics() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingUniformDistributedTopics() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')							
################################################################################################################################################################
#Deleting JMS Uniform Distributed Topic targeted to SubDeployment module  based on the properties given.#
################################################################################################################################################################
def deletinguniformDistributedTopics():
					DDTopicList=DDTopic_List[1:-1]
					ddTopics=DDTopicList.split(',')
					mydict1={}
					#for each item in List
					for ddTopic in ddTopics:
							#split the item into name(key),value pair
						a,b = ddTopic.split(":")
						#assign it to dictionary
						mydict1[a] = b
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found '
						else:
								for sourceTopicName,redeliveryQueueName in mydict1.items():
									try:
										cd('/')	
										redqMbean=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+redeliveryQueueName)									
										print redqMbean
										if(redqMbean!=None):
											cd('/')
											print '@@@ Deleting  the UniformDistributedQueue @@@  '+redeliveryQueueName
											cd('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues')	
											delete(redeliveryQueueName,'UniformDistributedQueue')
											print '@@@ Deleted  the UniformDistributedQueue @@@  '+redeliveryQueueName
										else:	
											print redeliveryQueueName + ' is  not exist'
									except 	Exception, e1:
										print 'Exception while deleting  the UniformDistributedQueue '+redeliveryQueueName								
									try:
										cd('/')	
										qMbean=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedTopics/'+sourceTopicName)
										if(qMbean!=None):
											cd('/')
											qMbean.unSet('DeliveryFailureParams')
											print '@@@ Deleting  the UniformDistributedTopic @@@  '+sourceTopicName
											cd('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedTopics')	
											delete(sourceTopicName,'UniformDistributedTopic')
											print '@@@ Deleted  the UniformDistributedTopic @@@  '+sourceTopicName
										else:	
											print sourceTopicName + ' is  not exist '
									except 	Exception, e1:
										print 'Exception while deleting  the UniformDistributedTopic '+sourceTopicName
						activate()
						print 'End of deletinguniformDistributedTopics() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletinguniformDistributedTopics() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Configure Redelivery Limit for Source Adaptor's Queues based on the properties given.#
################################################################################################################################################################
def setRedeliverylimit():
					DDQueueList=DDQueue_List[1:-1]
					ddQueues=DDQueueList.split(',')
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict1={}
					#for each item in List
					for ddQueue in ddQueues:
							#split the item into name(key),value pair
						a,b = ddQueue.split(":")
						#assign it to dictionary
						mydict1[a] = b
					mydict = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = JMS_SERVER_NAME+'.'+str(item)
					try:
						edit()
						startEdit(true)
						cd('/')
						jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
						#iterate for each mananged server
						for source_queue,queueName in mydict1.items():
							 if(queueName!=""):
									try:
										cd('/')
										jq1=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+source_queue) 
										cd('/')
										errorq1=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName+'/UniformDistributedQueues/'+queueName) 
										print jq1
										deliveryparamsmb=jq1.getDeliveryFailureParams()
										deliveryparamsmb.setRedeliveryLimit(int(RedeliveryLimit))
										deliveryparamsmb.setErrorDestination(errorq1)
									except Exception, e1:
											print 'Source Queue to Which Redelvery Queue has to be set '+source_queue+'is not exist '
						activate()
						print 'End ofsetRedeliverylimit() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in setRedeliverylimit() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Creating JDBC XA DataSource.#
################################################################################################################################################################
def createDataSource():
					try:
						edit()
						startEdit(true)
						cd('/')
						#get MBean instance of the Cluster Server
						targetmb=getMBean('Clusters/'+CLUSTER_NAME)
						if targetmb is None:
							print '@@@ No cluster MBean found ,so target cannot be set !!!'
						# MBean instance is valid
						else:	
							try:
								cd('/')
								jdbcSystemResourcemb=getMBean('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
								if(jdbcSystemResourcemb!=None):
									print JDBC_DATASOURCE_NAME+ ' already   exist '
								else:
									cd('/')
									print '@@@ Creating the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME

									#cd('JDBCSystemResources')
									#creating JMSSystemResource
									jdbcSystemResourcesmb= create(JDBC_DATASOURCE_NAME,'JDBCSystemResource')
									jdbcSystemResourcesmb.addTarget(targetmb)
									jdbcSystemResourcemb=jdbcSystemResourcesmb.getJDBCResource()
									jdbcSystemResourcemb.setName(JDBC_DATASOURCE_NAME)
									jdbcDriverParams=jdbcSystemResourcemb.getJDBCDriverParams()
									#set the Driver name for the datasource
									jdbcDriverParams.setDriverName(JDBC_DRIVER_CLASS)
									jdbcDriverParams.setPassword(JDBC_USER_PASSWORD)
									#set the URL of the database for the datasource
									jdbcDriverParams.setUrl(JDBC_DB_URL)
									properties=jdbcDriverParams.getProperties()
									user=properties.createProperty('user')
									user.setValue(JDBC_USER_NAME)
									portNumber=properties.createProperty('portNumber')
									portNumber.setValue(JDBC_PORT_NO)
									databaseName=properties.createProperty('databaseName')
									databaseName.setValue(JDBC_DATABASE_NAME)
									serverName=properties.createProperty('serverName')
									serverName.setValue(JDBC_SERVER_NAME)

									# set JNDI Name
									jdbcDataSourceParams=jdbcSystemResourcemb.getJDBCDataSourceParams()
									jdbcDataSourceParams.addJNDIName(JDBC_DATASOURCE_JNDINAME)
									# set Test Conection On Reserve as true
									jdbcConnectionPoolParams=jdbcSystemResourcemb.getJDBCConnectionPoolParams()
									jdbcConnectionPoolParams.setTestConnectionsOnReserve(true)
									jdbcConnectionPoolParams.setTestTableName('dual')
									#set the target as MBean instance of the Cluster Server
									print '@@@ Created the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
									cd('/')
									print 'End of createDataSource() ...'	
							except 	Exception, e1:
								print 'Exception occurs while creating JDBCSystemResource  '+JDBC_DATASOURCE_NAME
								
						activate()
						print 'End of createDataSource() ...'	
					except Exception, e2:
						print 'ACTIVATION FAILED in createDataSource() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting JDBC XA DataSource.#
################################################################################################################################################################		
def deletingDataSource():
					try:
						edit()
						startEdit(true)
						try:
							cd('/')
							jdbcSystemResourcemb=getMBean('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
							if(jdbcSystemResourcemb!=None):
								cd('/')
								print '@@@ Deleting the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
								#creating JMSSystemResource
								cd('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
								jdbcSystemResourcemb=cmo
								cd('..')
								cmo.destroyJDBCSystemResource(jdbcSystemResourcemb)
								print '@@@ Deleted the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
								cd('/')
							else:
								print 'JDBCSystemResource '+JDBC_DATASOURCE_NAME + ' is not   exist '
                                                except 	Exception, e1:
							print 'Exception occurs while deleting JDBCSystemResource '+JDBC_DATASOURCE_NAME
						activate()
						print 'End of deletingDataSource() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingDataSource() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Creating JDBC XA DataSource.#
################################################################################################################################################################
def createGridDataSource():
					try:
						edit()
						startEdit(true)
						cd('/')
						#get MBean instance of the Cluster Server
						targetmb=getMBean('Clusters/'+CLUSTER_NAME)
						if targetmb is None:
							print '@@@ No cluster MBean found ,so target cannot be set !!!'
						# MBean instance is valid
						else:	
							try:
								cd('/')
								jdbcSystemResourcemb=getMBean('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
								if(jdbcSystemResourcemb!=None):
									print JDBC_DATASOURCE_NAME+ ' already   exist '
								else:
									cd('/')
									print '@@@ Creating the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME

									#cd('JDBCSystemResources')
									#creating JMSSystemResource
									jdbcSystemResourcesmb= create(JDBC_DATASOURCE_NAME,'JDBCSystemResource')
									jdbcSystemResourcesmb.addTarget(targetmb)
									jdbcSystemResourcemb=jdbcSystemResourcesmb.getJDBCResource()
									jdbcSystemResourcemb.setName(JDBC_DATASOURCE_NAME)
									jdbcDriverParams=jdbcSystemResourcemb.getJDBCDriverParams()
									#set the Driver name for the datasource
									jdbcDriverParams.setDriverName(JDBC_DRIVER_CLASS)
									jdbcDriverParams.setPassword(JDBC_USER_PASSWORD)
									#set the URL of the database for the datasource
									jdbcDriverParams.setUrl(JDBC_DB_URL)
									properties=jdbcDriverParams.getProperties()
									user=properties.createProperty('user')
									user.setValue(JDBC_USER_NAME)
									portNumber=properties.createProperty('portNumber')
									portNumber.setValue(JDBC_PORT_NO)
									databaseName=properties.createProperty('databaseName')
									databaseName.setValue(JDBC_DATABASE_NAME)
									serverName=properties.createProperty('serverName')
									serverName.setValue(JDBC_SERVER_NAME)

									# set JNDI Name
									jdbcDataSourceParams=jdbcSystemResourcemb.getJDBCDataSourceParams()
									jdbcDataSourceParams.addJNDIName(JDBC_DATASOURCE_JNDINAME)
									# set Test Conection On Reserve as true
									jdbcConnectionPoolParams=jdbcSystemResourcemb.getJDBCConnectionPoolParams()
									jdbcConnectionPoolParams.setTestConnectionsOnReserve(true)
									jdbcConnectionPoolParams.setTestTableName('dual')
									#set the target as MBean instance of the Cluster Server
									print '@@@ Created the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
									cd('/')
									print 'End of createGridDataSource() ...'	
							except 	Exception, e1:
								print 'Exception occurs while creating JDBCSystemResource  '+JDBC_DATASOURCE_NAME
								
						activate()
						print 'End of createGridDataSource() ...'	
					except Exception, e2:
						print 'ACTIVATION FAILED in createGridDataSource() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting JDBC XA DataSource.#
################################################################################################################################################################		
def deletingGridDataSource():
					try:
						edit()
						startEdit(true)
						try:
							cd('/')
							jdbcSystemResourcemb=getMBean('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
							if(jdbcSystemResourcemb!=None):
								cd('/')
								print '@@@ Deleting the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
								#creating JMSSystemResource
								cd('JDBCSystemResources/'+JDBC_DATASOURCE_NAME)
								jdbcSystemResourcemb=cmo
								cd('..')
								cmo.destroyJDBCSystemResource(jdbcSystemResourcemb)
								print '@@@ Deleted the JDBCSystemResource @@@ '+JDBC_DATASOURCE_NAME
								cd('/')
							else:
								print 'JDBCSystemResource '+JDBC_DATASOURCE_NAME + ' is not   exist '
                                                except 	Exception, e1:
							print 'Exception occurs while deleting JDBCSystemResource '+JDBC_DATASOURCE_NAME
						activate()
						print 'End of deletingGridDataSource() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingGridDataSource() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
						
################################################################################################################################################################
#Creating SAFAgents and targeted to managed server  based on the properties given.#
################################################################################################################################################################	
def creatingSAFAgents():
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					mydict={}
					for item in managedServers:
					   #assign it to dictionary
					    mydict[item] = SAFAgent+'.'+str(item)
					#for each item in List
					for x,safAgentName in mydict.items():
						try:
							edit()
							startEdit(true)
							cd('/')
							safagentresourcemb=getMBean('SAFAgents/'+safAgentName)
							cd('/')
							if safagentresourcemb != None:
									print '@@@ '+ safAgentName +' SAFAgent MBean Already found '
							else:
							       try:
									print '@@@ Creating the SAFAgent @@@  '+safAgentName
									cd('/')
									cd('SAFAgents')
									#creating SAFAgents
									safagentresourcemb = create(safAgentName,'SAFAgents')
									fileStoreName=FILE_STORE+'.'+str(x)
									cd('/')
									filestoreMB=getMBean('FileStores/'+fileStoreName)
									cd('/')
								        if(filestoreMB!=None):
								          safagentresourcemb.setStore(filestoreMB)
									  safagentresourcemb.setServiceType('Sending-only')
									  targets = filestoreMB.getTargets()
									  safagentresourcemb.setTargets(targets)
									  print '@@@ Created the SAFAgent @@@ '+safAgentName
									else:
									  print 'Filestore '+ fileStoreName +' is not   exist, so SAF agent cant be created for '+safAgentName
									cd('/')										
							       except 	Exception, e1:
									print 'Exception occurs while creating SAFAgents '+safAgentName	

							activate()
							print 'End of creatingSAFAgents() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in creatingSAFAgents() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')
################################################################################################################################################################
#Deleting SAFAgents and targeted to managed server  based on the properties given.#
################################################################################################################################################################	
def deletingSAFAgents():
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					mydict={}
					for item in managedServers:
					   #assign it to dictionary
					    mydict[item] = SAFAgent+'.'+str(item)
					#for each item in List
					for x,safAgentName in mydict.items():
						try:
							edit()
							startEdit(true)
							cd('/')
							safagentresourcemb=getMBean('SAFAgents/'+safAgentName)
							cd('/')
							if safagentresourcemb is None:
									print '@@@ '+ safAgentName +' SAFAgent MBean Not  found '
							else:
							       try:
									print '@@@ Deleting the SAFAgent @@@  '+safAgentName
									cd('SAFAgents')
									delete(safAgentName)									
							       except 	Exception, e1:
									print 'Exception occurs while deleting SAFAgents '+safAgentName	

							activate()
							print 'End of deletingSAFAgents() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in deletingSAFAgents() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')

################################################################################################################################################################
#Creating Module based SubDeployment Module on the SAF Agents based on the properties given.#
################################################################################################################################################################
def creatingSubDeploymentForSAFAgent():
					managedServerList=MS_LIST
					#split it and make it as a list
					managedServers=managedServerList.split(',')
					#create empty dictionary
					mydict = {}
					mydict1 = {}
					#for each item in List
					for item in managedServers:
						#assign it to dictionary
						mydict[item] = SAFAgent+'.'+str(item)
					try:
						edit()
						startEdit(true)
						safAgentExists=0
						#iterate for each SAFAgents
						for x,safAgentName in mydict.items():
							cd('/')
							#get MBean instance of the JMS Server 
							safagentsmb=getMBean('SAFAgents/'+safAgentName)
							if safagentsmb is None:
								print '@@@ No SAF Agent MBean found , hence this safagent '+safAgentName +' cannot be set as an target for subdeployment !!!'
								safAgentExists=1
						if (safAgentExists==0):
							cd('/')			
							#get MBean instance of the JMSSystemResources 
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence subdeployment cannot be created !!!'								
									
							else:
								try:
													
									jmsSubDeploymentName=SAFAgent+'SubDeployment'
									jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
									if(jmssubdeploymentmb!=None):
										print jmsSubDeploymentName + ' already   exist '
									else:	
										print '@@@ Creating the SubDeployment @@@  '+jmsSubDeploymentName
										#creating SubDeployment
										jmssubdeploymentmb = jmssystemresourcemb.createSubDeployment(jmsSubDeploymentName)
										print '@@@ Created the SubDeployment @@@  '+jmsSubDeploymentName
										for x,safAgentName in mydict.items():
											cd('/')
											safagentsmb=getMBean('SAFAgents/'+safAgentName)
											#set the target as MBean instance of the SAF Agent
											jmssubdeploymentmb.addTarget(safagentsmb)			
								except 	Exception, e1:
									print 'Exception occurs while creating SubDeployment '+jmsSubDeploymentName		
						activate()
						print 'End of creatingSubDeploymentForSAFAgent()  ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in creatingSubDeployment() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting Module based SubDeployment Module on the SAF Agents based on the properties given.#
################################################################################################################################################################						
def deletingSubDeploymentOfSAFAgents():
					try:
							edit()
							startEdit(true)
						
							try:
								cd('/')
								#get MBean instance of the JMSSystemResources 
								jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName)
								if jmssystemresourcemb is None:
										print '@@@ No JMSSystemResources MBean found , so subdeployment cannot be deleted !!!'
								else:	
										cd('/')
										jmsSubDeploymentName=SAFAgent+'SubDeployment'
										jmssubdeploymentmb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/SubDeployments/'+jmsSubDeploymentName)
										if(jmssubdeploymentmb!=None):
											print '@@@ Deleting the SubDeployment  @@@ '+jmsSubDeploymentName
											jmssystemresourcemb.destroySubDeployment(jmssubdeploymentmb)
											print '@@@ Deleted the SubDeployment  @@@ '+jmsSubDeploymentName
										else:
											print jmsSubDeploymentName + ' is not  exist '				
										cd('/')
							except 	Exception, e1:
									print 'Exception while deleting SubDeployment '+jmsSubDeploymentName	
							activate()
							print 'End of deletingSubDeployment() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deletingSubDeploymentOfSAFAgents() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')							
################################################################################################################################################################
#Creating SAF Remote Context .#
################################################################################################################################################################	
def creatingSAFRemotecontext():
					
					mydict1={}
					mydict2={}
					mydict3={}
					a,b,c,d = SAFRemoteContextDetails.split("::")
					mydict3[c]=d
					mydict2[b]=mydict3
					#assign it to dictionary
					mydict1[a] =mydict2					
					#assign it to dictionary
					
					for remoteContextName,mydict2 in mydict1.items():
					 for url,mydict3 in mydict2.items():
					  for username,password in mydict3.items():
						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence Remote Context cannot be created !!!'
							else:
								try:
									remoteSAFContextMB=jmssystemresourcemb.lookupSAFRemoteContext(remoteContextName)
									if remoteSAFContextMB != None:
										print '@@@ '+ remoteContextName +' Remote Context  MBean Already found '
									else:
										print '@@@ Creating the Remote Context @@@  '+remoteContextName

										#creating SAFRemoteContext
										jmssystemresourcemb.createSAFRemoteContext(remoteContextName)
										remoteSAFContextMB = jmssystemresourcemb.lookupSAFRemoteContext(remoteContextName);
										remoteSAFContextMB.getSAFLoginContext().setLoginURL(url);
										remoteSAFContextMB.getSAFLoginContext().setUsername(username);
										remoteSAFContextMB.getSAFLoginContext().setPassword(password);
										print '@@@ Created the SAFRemoteContext @@@ '+remoteContextName
										cd('/')										
								except 	Exception, e1:
									print 'Exception occurs while creating SAF RemoteContext '+remoteContextName	

							activate()
							print 'End of creatingSAFRemotecontext() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in creatingSAFRemotecontext() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')
################################################################################################################################################################
#Deleting SAF Remote Context .#
################################################################################################################################################################	
def deletingSAFRemotecontext():
					mydict1={}
					mydict2={}
					mydict3={}
					a,b,c,d = SAFRemoteContextDetails.split("::")
					mydict3[c]=d
					mydict2[b]=mydict3
					#assign it to dictionary
					mydict1[a] =mydict2					
					#assign it to dictionary
					
					for remoteContextName,mydict2 in mydict1.items():
					 for url,mydict3 in mydict2.items():
					  for username,password in mydict3.items():
						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence Remote Context cannot be deleted !!!'
							else:
								try:
									remoteSAFContextMB=jmssystemresourcemb.lookupSAFRemoteContext(remoteContextName)
									if remoteSAFContextMB is None:
										print '@@@ '+ remoteContextName +' Remote Context  MBean Not found '
									else:
										print '@@@ Deleting the Remote Context @@@  '+remoteContextName


										jmssystemresourcemb.destroySAFRemoteContext(remoteSAFContextMB)
										
										print '@@@ Delted the SAFRemoteContext @@@ '+remoteContextName
										cd('/')										
								except 	Exception, e1:
									print 'Exception occurs while creating SAF RemoteContext '+remoteContextName	

							activate()
							print 'End of deletingSAFRemotecontext() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in creatingSAFRemotecontext() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')	
################################################################################################################################################################
#Creating SAF ImportedDestination .#
################################################################################################################################################################	
def creatingSAFImportedDestination():
						managedServerList=MS_LIST
						#split it and make it as a list
						managedServers=managedServerList.split(',')
						
						mydict={}
						mydict1={}
						a,b,c,d = SAFRemoteContextDetails.split("::")
						mydict1[a]=b
						safImportedDestination=SAFImportedDestnation
					
						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence SAF Imported Destination cannot be created !!!'
							else:
								try:
									safImportedDestinationMB=jmssystemresourcemb.lookupSAFImportedDestinations(safImportedDestination)
									if safImportedDestinationMB != None:
										print '@@@ '+ safImportedDestination +' SAF Imported Destination MBean already found '
									else:
										print '@@@ Creating the SAF Imported Destination  @@@  '+safImportedDestination

										#creating SAF Imported Destination
										jmssystemresourcemb.createSAFImportedDestinations(safImportedDestination)
										safImportedDestinationMB = jmssystemresourcemb.lookupSAFImportedDestinations(safImportedDestination);
										#safImportedDestinationMB.setJNDIPrefix('jms/');
										for safcontext,b in mydict1.items():
										  remoteSAFContextMB = jmssystemresourcemb.lookupSAFRemoteContext(safcontext);
										  safImportedDestinationMB.setSAFRemoteContext(remoteSAFContextMB);
										safErrorHandlerMB=jmssystemresourcemb.lookupSAFErrorHandling(safErrorHandler)
										safImportedDestinationMB.setSAFErrorHandling(safErrorHandlerMB);
										safImportedDestinationMB.setTimeToLiveDefault(0);
										safImportedDestinationMB.setUseSAFTimeToLiveDefault(false);
										jmsSubDeploymentName=SAFAgent+'SubDeployment'
										safImportedDestinationMB.setSubDeploymentName(jmsSubDeploymentName);
										print '@@@ Created the  SAF Imported Destination  @@@ '+safImportedDestination
										cd('/')										
								except 	Exception, e1:
									print 'Exception occurs while creating SAF Imported Destination '+safImportedDestination	

							activate()
							print 'End of creatingSAFImportedDestination() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in creatingSAFImportedDestination() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')
################################################################################################################################################################
#Deleting SAF ImportedDestination .#
################################################################################################################################################################	
def deletingSAFImportedDestination():
						mydict={}
						mydict1={}
						a,b,c,d = SAFRemoteContextDetails.split("::")
						mydict1[a]=b					
						safImportedDestination=SAFImportedDestnation
						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence SAF Imported Destination  cannot be Deleted !!!'
							else:
								try:
									safImportedDestinationMB=jmssystemresourcemb.lookupSAFImportedDestinations(safImportedDestination)
									if safImportedDestinationMB is None:
										print '@@@ '+ safImportedDestination +' SAF Imported Destination MBean Not found '
									else:
										print '@@@ Deleting the SAF Imported Destination  @@@  '+safImportedDestination

										#deleting SAF Imported Destination
										jmssystemresourcemb.destroySAFImportedDestinations(safImportedDestinationMB)
										
										print '@@@ Deleteded the  SAF Imported Destination  @@@ '+safImportedDestination
										cd('/')										
								except 	Exception, e1:
									print 'Exception occurs while deleting SAF Imported Destination '+safImportedDestination	

							activate()
							print 'End of deletingSAFImportedDestination() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in deletingSAFImportedDestination() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')
################################################################################################################################################################
#adding queues and topic to SAF ImportedDestination .#
################################################################################################################################################################	
def addingQueues_TopicsToSAFImportedDestination():

						SAFQueueitems=SAFQueue_list.split(',')
						SAFTopicitems=SAFTopic_list.split(',')
						mydict={}
						queuedict={}
						topicdict={}
						safImportedDestination=SAFImportedDestnation
						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence Queues and Topics cannot be added to SAF Imported Destination  !!!'
							else:
								try:
									safImportedDestinationMB=jmssystemresourcemb.lookupSAFImportedDestinations(safImportedDestination)
									if safImportedDestinationMB is None:
										print '@@@ '+ safImportedDestination +' SAF Imported Destination MBean Not found so unable to add Queue or Topic '
									else:
										print '@@@ Adding  Queues and Topics to SAF Imported Destination  @@@  '+safImportedDestination
										for SAFQueueitem in SAFQueueitems:
											a,b = SAFQueueitem.split(":")
											queuedict[a]=b
										for remoteQueue,localQueue in queuedict.items():
										        safqueue = safImportedDestinationMB.lookupSAFQueue(localQueue)
											if(safqueue is None):
												print '@@@ Adding  Queue '+ remoteQueue +' to SAF Imported Destination  @@@  '+safImportedDestination
												safImportedDestinationMB.createSAFQueue(localQueue)
												safqueue = safImportedDestinationMB.lookupSAFQueue(localQueue)
												safqueue.setRemoteJNDIName(remoteQueue)
												safqueue.setLocalJNDIName(localQueue)
												print '@@@ Added  Queue '+ remoteQueue +' to SAF Imported Destination  @@@  '+safImportedDestination
											else:
											        print '@@@   Queue  '+ remoteQueue +' already exist under SAF Imported Destination  @@@  '+safImportedDestination	

										if len(SAFTopicitems)>1:
											for SAFTopicitem in SAFTopicitems:
												a,b = SAFTopicitem.split(":")
												topicdict[a]=b
											for remoteTopic,localTopic in topicdict.items():
												saftopic = safImportedDestinationMB.lookupSAFTopic(localTopic)
												if(saftopic is None):
													print '@@@ Adding Topic '+  remoteTopic +' to SAF Imported Destination  @@@  '+safImportedDestination
													safImportedDestinationMB.createSAFTopic(localTopic)
													saftopic= safImportedDestinationMB.lookupSAFTopic(localTopic)
													saftopic.setRemoteJNDIName(remoteTopic)
													saftopic.setLocalJNDIName(localTopic)
													print '@@@ Added Topic '+  remoteTopic +' to SAF Imported Destination  @@@  '+safImportedDestination
												else:
													print '@@@   Topic  '+ remoteTopic +' already exist under SAF Imported Destination  @@@  '+safImportedDestination					
										print '@@@ Added  Queues and Topics to SAF Imported Destination  @@@  '+safImportedDestination
										cd('/')										
								except 	Exception, e1:
									print 'Exception occurs while adding  Queues and Topics to SAF Imported Destination '+safImportedDestination	

							activate()
							print 'End of addingQueues_TopicsToSAFImportedDestination() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in addingQueues_TopicsToSAFImportedDestination() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')							
################################################################################################################################################################
#creating Error Handler .#
################################################################################################################################################################	
def creatingErrorHandlers():

						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence Eror Handler cannot be created !!!'
															
							else:
								safErrorHandlerMB=jmssystemresourcemb.lookupSAFErrorHandling(safErrorHandler)
								if safErrorHandlerMB != None:
							 		print '@@@  Error Handler MBean Already !!!'	
							 	else:
									try:
										print '@@@ Creating  Error Handler for SAF Imported Destination @@@  '+safErrorHandler
										jmssystemresourcemb.createSAFErrorHandling(safErrorHandler)
										safErrorHandlerMB=jmssystemresourcemb.lookupSAFErrorHandling(safErrorHandler)
										print '@@@ Created  Error Handler for SAF Imported Destination   @@@  '+safErrorHandler
										safErrorHandlerMB.setPolicy('Log')
										print '@@@ Created  Error Handler for SAF Imported Destination   @@@  '+safErrorHandler

									except 	Exception, e1:
										print 'Exception occurs while creating Error Handler '+safErrorHandler	

							activate()
							print 'End of creatingErrorHandlers() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in creatingErrorHandlers() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')
################################################################################################################################################################
#deleting Error Handler .#
################################################################################################################################################################	
def deletingErrorHandlers():

						try:
							edit()
							startEdit(true)
							cd('/')
							jmssystemresourcemb=getMBean('JMSSystemResources/'+jmsSystemResourceName+'/JMSResource/'+jmsSystemResourceName)
							if jmssystemresourcemb is None:
								print '@@@ No JMSSystemResources MBean found , hence Eror Handler cannot be deleted !!!'
							else:
								safErrorHandlerMB=jmssystemresourcemb.lookupSAFErrorHandling(safErrorHandler)
								if safErrorHandlerMB is None:
									print '@@@ No Error Handler MBean found !!!'								

								else:
									try:
										print '@@@ Deleting  Error Handler  @@@  '+safErrorHandler
										jmssystemresourcemb.destroySAFErrorHandling(safErrorHandlerMB)
										print '@@@ Deleted  Error Handler   @@@  '+safErrorHandler

									except 	Exception, e1:
										print 'Exception occurs while creating Error Handler '+safErrorHandler	

							activate()
							print 'End of deletingErrorHandlers() ...'
						except Exception, e2:
							print 'ACTIVATION FAILED in deletingErrorHandlers() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
							undo('true','y')							
################################################################################################################################################################
#creating WorkManagers .#
################################################################################################################################################################	
def createWorkManager():

					try:
						edit()
						startEdit(true)
						cd('/')
						#get MBean instance of the Cluster Server
						targetmb=getMBean('Clusters/'+CLUSTER_NAME)
						if targetmb is None:
							print '@@@ No cluster MBean found ,so target cannot be set !!!'
							
						# MBean instance is valid
						else:
						        wrkMgrsLst=WorkMgrsList[1:-1]
							workManagersList=wrkMgrsLst
							domainName=WLS_DOMAIN_NAME
							#split it and make it as a list
							workManagers=workManagersList.split(',')
							wrkMgrdict={}
							minmaxdict={}
							for workManager in workManagers:
								a,b,c = workManager.split(":")
								minmaxdict[b]=c
								wrkMgrdict[a]=minmaxdict
							for workManagerName, threadContraints in wrkMgrdict.items():
							 

									workmanagerMB=getMBean('/SelfTuning/'+domainName+ '/WorkManagers/' + workManagerName)
									maxThreadConstraintName=workManagerName+'_'+'maxThreadCnst'
									minThreadConstraintName=workManagerName+'_'+'minThreadCnst'
									maxTheadConstrinMB=getMBean('/SelfTuning/'+domainName+ '/MaxThreadsConstraints/' + maxThreadConstraintName)
									for MaxThread , MinThread in threadContraints.items():
										if maxTheadConstrinMB != None:
											print '@@@ MaxThreadsConstraints MBean '+   maxThreadConstraintName +' already found!!!'
										else:
											try:
												print '@@@ Creating MaxThreadsConstraints  @@@  '+maxThreadConstraintName
												cd('/SelfTuning/'+domainName+ '/MaxThreadsConstraints/'  )
												maxTheadConstrinMB=create(maxThreadConstraintName,'MaxThreadsConstraints')
												maxTheadConstrinMB.setCount(int(MaxThread))
												maxTheadConstrinMB.addTarget(targetmb)
												print '@@@ Created MaxThreadsConstraints  @@@  '+maxThreadConstraintName

											except 	Exception, e1:
												print 'Exception occurs while Creating MaxThreadsConstraints '+maxThreadConstraintName	
										minTheadConstrinMB=getMBean('/SelfTuning/'+domainName+ '/MinThreadsConstraints/' + minThreadConstraintName)
										if minTheadConstrinMB != None:
											print '@@@ MinThreadsConstraints MBean '+  minThreadConstraintName +' already found!!!'
										else:
											try:
												print '@@@ Creating MinThreadsConstraints  @@@  '+minThreadConstraintName
												cd('/SelfTuning/'+domainName+ '/MinThreadsConstraints/'  )
												minTheadConstrinMB=create(minThreadConstraintName,'MinThreadsConstraints')
												minTheadConstrinMB.setCount(int(MinThread))
												minTheadConstrinMB.addTarget(targetmb)
												print '@@@ Created MinThreadsConstraints  @@@  '+minThreadConstraintName							
											except 	Exception, e1:
												print 'Exception occurs while Creating MinThreadsConstraints '+minThreadConstraintName	
									if workmanagerMB != None:
										print '@@@ WorkManager MBean '+  workManagerName +' already found!!!'

									else:
										try:
											print '@@@ Creating WorkManager  @@@  '+workManagerName
											cd('/SelfTuning/'+domainName+ '/WorkManagers/' )
											
											workmanagerMB=create(workManagerName,'WorkManagers')
											workmanagerMB.addTarget(targetmb)
											workmanagerMB.setMaxThreadsConstraint(maxTheadConstrinMB)
											workmanagerMB.setMinThreadsConstraint(minTheadConstrinMB)
											print '@@@ Created WorkManager  @@@  '+workManagerName

										except 	Exception, e1:
											print 'Exception occurs while Creating WorkManager '+workManagerName	

						activate()
						print 'End of createWorkManager() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in createWorkManager() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
################################################################################################################################################################
#Deleting WorkManagers .#
################################################################################################################################################################	
def deleteWorkManager():

					try:
						edit()
						startEdit(true)
						cd('/')
						wrkMgrsLst=WorkMgrsList[1:-1]
						workManagersList=wrkMgrsLst
						domainName=WLS_DOMAIN_NAME
						#split it and make it as a list
						workManagers=workManagersList.split(',')
						wrkMgrdict={}
						minmaxdict={}
						for workManager in workManagers:
							a,b,c = workManager.split(":")
							minmaxdict[b]=c
							wrkMgrdict[a]=minmaxdict
						for workManagerName, threadContraints in wrkMgrdict.items():
								try:
									domainMB=getMBean('/SelfTuning/'+domainName)
									workmanagerMB=getMBean('/SelfTuning/'+domainName+ '/WorkManagers/' + workManagerName)
									maxThreadConstraintName=workManagerName+'_'+'maxThreadCnst'
									minThreadConstraintName=workManagerName+'_'+'minThreadCnst'
									maxTheadConstrinMB=getMBean('/SelfTuning/'+domainName+ '/MaxThreadsConstraints/' + maxThreadConstraintName)
									minTheadConstrinMB=getMBean('/SelfTuning/'+domainName+ '/MinThreadsConstraints/' + minThreadConstraintName)
									if workmanagerMB!=None:
									        print '@@@ Deleting  WorkManager @@@  '+workManagerName
										domainMB.destroyWorkManager(workmanagerMB)
										print '@@@ Deleted  WorkManager @@@  '+workManagerName
									else:
										print '@@@ WorkManager MBean '+ workManagerName +' not found !!!'									
									
									if maxTheadConstrinMB != None:
										print '@@@ Deleting  MaxThreadsConstraint @@@  '+maxThreadConstraintName
										domainMB.destroyMaxThreadsConstraint(maxTheadConstrinMB)
										print '@@@ Deleted  MaxThreadsConstraint @@@  '+maxThreadConstraintName
									else:
										print '@@@ MaxThreadsConstraints MBean '+ maxThreadConstraintName +' not found !!!'									
									if minTheadConstrinMB != None:
										print '@@@ Deleting  MinThreadsConstraint @@@  '+minThreadConstraintName
										domainMB.destroyMinThreadsConstraint(minTheadConstrinMB)
										print '@@@ Deleted  MinThreadsConstraint @@@  '+minThreadConstraintName
									else:
										print '@@@ MinThreadsConstraints MBean '+ minThreadConstraintName +' not found !!!'
									
								except 	Exception, e1:
									print 'Exception occurs while Deleting WorkManager '+workManagerName	
						activate()
						print 'End of deleteWorkManager() ...'
					except Exception, e2:
						print 'ACTIVATION FAILED in deleteWorkManager() !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! '
						undo('true','y')
#JMSTasks_Executed=<jms.filestores.create,jms.servers.create,jms.systemmodule.create,jms.subdeployments.create,connection.factories.create,jmstemplates.create,uniform.distributed.destinations.create,distributed.destinations.create,SetRedeliveryLimit,bridges.create>						
#JMSTasks_Executed=<bridges.clean,distributed.destinations.clean,uniform.distributed.destinations.clean,jmstemplates.clean,connection.factories.clean,jms.subdeployments.clean,jms.systemmodule.clean,jms.servers.clean,jms.filestores.clean>
JMSTasksList=JMSTasks_Executed[1:-1]
jmsTasksTobeExecuted=JMSTasksList.split(',')
for casevalue in jmsTasksTobeExecuted:
	print '##############################################################################################'
	print casevalue + ' task is going to be executed '
	print '##############################################################################################'
	if(casevalue=='jms.filestores.create'):						
		creatingFileStores()
	if(casevalue=='jms.filestores.clean'):							
		deletingFileStores()
	if(casevalue=='jms.servers.create'):							
		creatingJMSServers()
	if(casevalue=='jms.servers.clean'):							
		deletingJMSServers()
	if(casevalue=='jms.systemmodule.create'):							
		creatingJMSSystemModule()
	if(casevalue=='jms.systemmodule.clean'):							
		deletingJMSSystemModule()
	if(casevalue=='jms.subdeployments.create'):							
		creatingSubDeployment()
	if(casevalue=='jms.subdeployments.clean'):							
		deletingSubDeployment()
	if(casevalue=='jms.connection.factories.create'):							
		creatingXAQueueConnectionFactories()
	if(casevalue=='jms.connection.factories.clean'):							
		deletingXAQueueConnectionFactories()
	if(casevalue=='jms.uniform.distributed.destinations.create'):							
		creatingUniformDistributedQueues()
	if(casevalue=='jms.uniform.distributed.destinations.clean'):							
		deletinguniformDistributedQueues()
	if(casevalue=='jms.uniform.distributed.topic.destinations.create'):							
		creatingUniformDistributedTopics()
	if(casevalue=='jms.uniform.distributed.topic.destinations.clean'):							
		deletinguniformDistributedTopics()
	if(casevalue=='jdbc.datasource.create'):							
		createDataSource()
	if(casevalue=='jdbc.datasource.clean'):							
		deletingDataSource()
	if(casevalue=='jms.setredeliverylimit'):							
		setRedeliverylimit()
	if(casevalue=='workmanager.create'):
		createWorkManager()
        if(casevalue=='workmanager.delete'):
		deleteWorkManager()	
	if(casevalue=='saf.agent.create'):							
		creatingSAFAgents()
		creatingSubDeploymentForSAFAgent()
		creatingSAFRemotecontext()
		creatingErrorHandlers()
		creatingSAFImportedDestination()
		addingQueues_TopicsToSAFImportedDestination()
	if(casevalue=='saf.agent.clean'):
		deletingSAFImportedDestination()
		deletingSAFRemotecontext()
		deletingErrorHandlers()
		deletingSubDeploymentOfSAFAgents()
		deletingSAFAgents()
		
disconnect()	
exit()
